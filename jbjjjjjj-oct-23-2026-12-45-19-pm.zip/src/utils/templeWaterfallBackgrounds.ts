// =============================================================================
// TWO ULTRA-REALISTIC PROCEDURAL CANVAS 2D BACKGROUNDS (Zero Image Files)
// 1. Ancient Stone Temple Ruins (Carved Khmer spires, glowing sanctuary, lotus moat, mossy pillars)
// 2. Rainforest Waterfall Valley (3-stage cataract, twin side falls, plunge pool, rainbow mist)
// =============================================================================

// =============================================================================
// ENVIRONMENT 5: ANCIENT STONE TEMPLE RUINS (Photorealistic Procedural Canvas 2D)
// =============================================================================
export function renderProceduralStoneTemple(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  screenGroundY: number
): void {
  // 1. MYSTIC TWILIGHT SUNSET SKY DOME
  const skyGrad = ctx.createLinearGradient(0, 0, 0, screenGroundY);
  skyGrad.addColorStop(0.0, '#140b29');  // Deep celestial twilight indigo
  skyGrad.addColorStop(0.20, '#2a164d'); // Royal dusk purple
  skyGrad.addColorStop(0.42, '#581c4f'); // Rich mulberry crimson
  skyGrad.addColorStop(0.64, '#8f3447'); // Burnt terracotta rose
  skyGrad.addColorStop(0.82, '#c85a32'); // Glowing ember orange
  skyGrad.addColorStop(0.93, '#ea8c42'); // Warm saffron horizon
  skyGrad.addColorStop(1.0, '#fde68a');  // Luminous golden temple mist
  ctx.fillStyle = skyGrad;
  ctx.fillRect(0, 0, width, screenGroundY);

  // 2. GOLDEN SUNSET ORB & VOLUMETRIC CREPUSCULAR RAYS
  const sunX = width * 0.72;
  const sunY = Math.min(126, screenGroundY * 0.27);

  const sunHalo = ctx.createRadialGradient(sunX, sunY, 16, sunX, sunY, width * 0.58);
  sunHalo.addColorStop(0, 'rgba(254, 240, 138, 0.38)');
  sunHalo.addColorStop(0.3, 'rgba(251, 146, 60, 0.18)');
  sunHalo.addColorStop(0.65, 'rgba(154, 52, 18, 0.06)');
  sunHalo.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = sunHalo;
  ctx.fillRect(0, 0, width, screenGroundY);

  // Volumetric Dusk Sunbeams Slanting Over the Ruins
  ctx.save();
  ctx.translate(sunX, sunY);
  const numRays = 12;
  for (let r = 0; r < numRays; r++) {
    const angle = (r * Math.PI) / 6 + 0.18;
    const rayLength = 370 + (r % 3) * 65;
    const rayWidth = 0.065;
    const rayGrad = ctx.createRadialGradient(0, 0, 18, 0, 0, rayLength);
    rayGrad.addColorStop(0, 'rgba(254, 215, 170, 0.22)');
    rayGrad.addColorStop(0.5, 'rgba(251, 146, 60, 0.07)');
    rayGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = rayGrad;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.arc(0, 0, rayLength, angle - rayWidth, angle + rayWidth);
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();

  // Glowing Sunset Orb
  const sunOrb = ctx.createRadialGradient(sunX, sunY, 6, sunX, sunY, 76);
  sunOrb.addColorStop(0, '#ffffff');
  sunOrb.addColorStop(0.25, '#fef08a');
  sunOrb.addColorStop(0.6, '#fb923c');
  sunOrb.addColorStop(1, 'rgba(234, 88, 12, 0)');
  ctx.fillStyle = sunOrb;
  ctx.beginPath();
  ctx.arc(sunX, sunY, 76, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = '#fffbeb';
  ctx.beginPath();
  ctx.arc(sunX, sunY, 25, 0, Math.PI * 2);
  ctx.fill();

  // 3. DISTANT KARST JUNGLE MOUNTAINS & ANCIENT STUPA SILHOUETTES
  const farMountGrad = ctx.createLinearGradient(0, screenGroundY * 0.38, 0, screenGroundY * 0.76);
  farMountGrad.addColorStop(0, '#3b1747');
  farMountGrad.addColorStop(0.6, '#4c1d48');
  farMountGrad.addColorStop(1, '#2a1029');
  ctx.fillStyle = farMountGrad;
  ctx.beginPath();
  ctx.moveTo(0, screenGroundY * 0.74);
  ctx.lineTo(0, screenGroundY * 0.56);
  ctx.quadraticCurveTo(width * 0.14, screenGroundY * 0.42, width * 0.28, screenGroundY * 0.54);
  ctx.quadraticCurveTo(width * 0.44, screenGroundY * 0.39, width * 0.60, screenGroundY * 0.52);
  ctx.quadraticCurveTo(width * 0.78, screenGroundY * 0.41, width, screenGroundY * 0.53);
  ctx.lineTo(width, screenGroundY * 0.74);
  ctx.closePath();
  ctx.fill();

  // Mid-Distance Misty Jungle Ridges
  const midRidgeGrad = ctx.createLinearGradient(0, screenGroundY * 0.52, 0, screenGroundY * 0.85);
  midRidgeGrad.addColorStop(0, '#271936');
  midRidgeGrad.addColorStop(1, '#161324');
  ctx.fillStyle = midRidgeGrad;
  ctx.beginPath();
  ctx.moveTo(0, screenGroundY * 0.82);
  ctx.lineTo(0, screenGroundY * 0.64);
  ctx.quadraticCurveTo(width * 0.18, screenGroundY * 0.55, width * 0.36, screenGroundY * 0.66);
  ctx.quadraticCurveTo(width * 0.55, screenGroundY * 0.57, width * 0.74, screenGroundY * 0.67);
  ctx.quadraticCurveTo(width * 0.88, screenGroundY * 0.59, width, screenGroundY * 0.65);
  ctx.lineTo(width, screenGroundY * 0.82);
  ctx.closePath();
  ctx.fill();

  // Golden Valley Mist Layer Behind Sanctuary
  const templeMist = ctx.createLinearGradient(0, screenGroundY * 0.65, 0, screenGroundY * 0.92);
  templeMist.addColorStop(0, 'rgba(251, 146, 60, 0)');
  templeMist.addColorStop(1, 'rgba(253, 186, 116, 0.28)');
  ctx.fillStyle = templeMist;
  ctx.fillRect(0, screenGroundY * 0.65, width, screenGroundY * 0.27);

  // 4. CENTRAL GRAND STEPPED KHMER / ANGKOR TEMPLE SANCTUARY (3-Tower Complex)
  const sanctuaryCenterX = width * 0.48;
  const sanctuaryBaseY = screenGroundY - 12;
  const sanctuaryWidth = Math.min(350, width * 0.46);

  const stoneBlockGrad = ctx.createLinearGradient(0, sanctuaryBaseY - 190, 0, sanctuaryBaseY);
  stoneBlockGrad.addColorStop(0, '#665e57');
  stoneBlockGrad.addColorStop(0.28, '#4e4843');
  stoneBlockGrad.addColorStop(0.65, '#38332f');
  stoneBlockGrad.addColorStop(1, '#211e1c');
  ctx.fillStyle = stoneBlockGrad;

  // 4 Stepped Pyramid Terrace Plinths
  ctx.fillRect(sanctuaryCenterX - sanctuaryWidth * 0.5, sanctuaryBaseY - 26, sanctuaryWidth, 26);
  ctx.fillRect(sanctuaryCenterX - sanctuaryWidth * 0.41, sanctuaryBaseY - 52, sanctuaryWidth * 0.82, 26);
  ctx.fillRect(sanctuaryCenterX - sanctuaryWidth * 0.31, sanctuaryBaseY - 78, sanctuaryWidth * 0.62, 26);
  ctx.fillRect(sanctuaryCenterX - sanctuaryWidth * 0.20, sanctuaryBaseY - 106, sanctuaryWidth * 0.40, 28);

  // Helper for Carved Lotus Prang Spire
  const drawLotusSpire = (sx: number, baseY: number, spireW: number, spireH: number) => {
    ctx.fillStyle = stoneBlockGrad;
    ctx.beginPath();
    ctx.moveTo(sx - spireW * 0.5, baseY);
    ctx.quadraticCurveTo(sx - spireW * 0.38, baseY - spireH * 0.68, sx, baseY - spireH);
    ctx.quadraticCurveTo(sx + spireW * 0.38, baseY - spireH * 0.68, sx + spireW * 0.5, baseY);
    ctx.closePath();
    ctx.fill();

    // Horizontal Tiered Lotus Petal Courses on Spire
    ctx.strokeStyle = 'rgba(254, 215, 170, 0.22)';
    ctx.lineWidth = 1.1;
    for (let t = 0.2; t < 0.85; t += 0.16) {
      const ty = baseY - spireH * t;
      const hw = spireW * 0.48 * (1 - t * 0.72);
      ctx.beginPath();
      ctx.moveTo(sx - hw, ty);
      ctx.lineTo(sx + hw, ty);
      ctx.stroke();
    }

    // Golden Finial Pinnacle
    ctx.fillStyle = '#d97706';
    ctx.beginPath();
    ctx.arc(sx, baseY - spireH - 3, 3.8, 0, Math.PI * 2);
    ctx.fill();
  };

  // Central Tall Spire & Two Flanking Side Spires
  drawLotusSpire(sanctuaryCenterX, sanctuaryBaseY - 106, sanctuaryWidth * 0.26, 92);
  drawLotusSpire(sanctuaryCenterX - sanctuaryWidth * 0.24, sanctuaryBaseY - 78, sanctuaryWidth * 0.18, 64);
  drawLotusSpire(sanctuaryCenterX + sanctuaryWidth * 0.24, sanctuaryBaseY - 78, sanctuaryWidth * 0.18, 64);

  // Central Monumental Staircase Leading Up the Pyramid
  ctx.fillStyle = '#292524';
  ctx.fillRect(sanctuaryCenterX - 20, sanctuaryBaseY - 78, 40, 78);
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.16)';
  ctx.lineWidth = 1;
  for (let st = 4; st < 78; st += 6) {
    ctx.beginPath();
    ctx.moveTo(sanctuaryCenterX - 18, sanctuaryBaseY - st);
    ctx.lineTo(sanctuaryCenterX + 18, sanctuaryBaseY - st);
    ctx.stroke();
  }

  // Carved Shrine Portal & Glowing Torch Chamber
  ctx.fillStyle = '#0c0a09';
  ctx.beginPath();
  ctx.roundRect(sanctuaryCenterX - 13, sanctuaryBaseY - 46, 26, 46, [12, 12, 0, 0]);
  ctx.fill();

  const torchGlow = ctx.createRadialGradient(sanctuaryCenterX, sanctuaryBaseY - 22, 2, sanctuaryCenterX, sanctuaryBaseY - 22, 42);
  torchGlow.addColorStop(0, 'rgba(254, 240, 138, 0.95)');
  torchGlow.addColorStop(0.4, 'rgba(249, 115, 22, 0.55)');
  torchGlow.addColorStop(1, 'rgba(249, 115, 22, 0)');
  ctx.fillStyle = torchGlow;
  ctx.beginPath();
  ctx.arc(sanctuaryCenterX, sanctuaryBaseY - 22, 42, 0, Math.PI * 2);
  ctx.fill();

  // 4b. REFLECTING TEMPLE LOTUS MOAT IN FRONT OF SANCTUARY
  const moatY = screenGroundY - 6;
  const moatGrad = ctx.createLinearGradient(sanctuaryCenterX - sanctuaryWidth * 0.55, moatY - 8, sanctuaryCenterX + sanctuaryWidth * 0.55, moatY + 8);
  moatGrad.addColorStop(0, '#311b54');
  moatGrad.addColorStop(0.35, '#9a3412');
  moatGrad.addColorStop(0.5, '#f59e0b'); // Torchlight & sunset reflection
  moatGrad.addColorStop(0.65, '#9a3412');
  moatGrad.addColorStop(1, '#311b54');
  ctx.fillStyle = moatGrad;
  ctx.beginPath();
  ctx.ellipse(sanctuaryCenterX, moatY, sanctuaryWidth * 0.58, 10, 0, 0, Math.PI * 2);
  ctx.fill();

  // Floating Emerald Lotus Pads & Pink Blooms on Moat
  for (let lp = -4; lp <= 4; lp++) {
    if (lp === 0) continue;
    const lpx = sanctuaryCenterX + lp * 34;
    const lpy = moatY + (lp % 2) * 2.5;
    ctx.fillStyle = '#15803d';
    ctx.beginPath();
    ctx.ellipse(lpx, lpy, 6.5, 2.2, 0, 0, Math.PI * 2);
    ctx.fill();
    if (lp % 2 === 0) {
      ctx.fillStyle = '#f472b6';
      ctx.beginPath();
      ctx.arc(lpx, lpy - 1.5, 2.2, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // 5. WEATHERED MEGALITHIC STONE PILLARS & COLONNADE
  const pillarGroundY = screenGroundY + 8;
  const leftPillarHeight = 190;
  const architraveY = pillarGroundY - leftPillarHeight - 14;

  drawStonePillar(ctx, width * 0.11, pillarGroundY, 36, leftPillarHeight, true);
  drawStonePillar(ctx, width * 0.21, pillarGroundY, 34, leftPillarHeight, true);

  // Carved Stone Architrave Lintel Beam
  const lintelGrad = ctx.createLinearGradient(width * 0.07, 0, width * 0.25, 0);
  lintelGrad.addColorStop(0, '#5c554e');
  lintelGrad.addColorStop(0.5, '#46403b');
  lintelGrad.addColorStop(1, '#302c28');
  ctx.fillStyle = lintelGrad;
  ctx.fillRect(width * 0.07, architraveY, width * 0.18, 22);

  drawStonePillar(ctx, width * 0.79, pillarGroundY, 34, 178, true);
  drawStonePillar(ctx, width * 0.89, pillarGroundY, 38, 198, true);
  drawFallenPillar(ctx, width * 0.63, screenGroundY + 12, 72, 24);

  // 6. OVERGROWN CREEPING MOSS, LIANAS & TROPICAL FLORA
  drawAncientCreepingVines(ctx, width * 0.09, architraveY + 16, 120);
  drawAncientCreepingVines(ctx, width * 0.87, pillarGroundY - 185, 102);

  // 7. FOREGROUND TEMPLE FLAGSTONE PAVING & ANCIENT RUIN GROUNDS
  const turfHeight = height - screenGroundY;
  const flagstoneGrad = ctx.createLinearGradient(0, screenGroundY, 0, height);
  flagstoneGrad.addColorStop(0, '#443f3a');
  flagstoneGrad.addColorStop(0.35, '#35312d');
  flagstoneGrad.addColorStop(0.7, '#25221f');
  flagstoneGrad.addColorStop(1, '#161412');
  ctx.fillStyle = flagstoneGrad;
  ctx.fillRect(0, screenGroundY, width, turfHeight);

  // Perspective Flagstone Courses with Mossy Joints & Sunset Rim Light
  const rowHeights = [0, 16, 38, 66, 102, 144, 196];
  for (let r = 0; r < rowHeights.length - 1; r++) {
    const yTop = screenGroundY + rowHeights[r];
    ctx.strokeStyle = 'rgba(18, 16, 14, 0.88)';
    ctx.lineWidth = 2.4;
    ctx.beginPath();
    ctx.moveTo(0, yTop);
    ctx.lineTo(width, yTop);
    ctx.stroke();

    // Moss & Golden Sunset Edge Glint on Flagstones
    ctx.strokeStyle = r < 2 ? 'rgba(251, 146, 60, 0.25)' : 'rgba(74, 107, 48, 0.48)';
    ctx.lineWidth = 1.3;
    ctx.beginPath();
    ctx.moveTo(0, yTop + 1.5);
    ctx.lineTo(width, yTop + 1.5);
    ctx.stroke();

    const stoneW = 56 + (r % 3) * 14;
    const offset = (r * 31) % stoneW;
    ctx.strokeStyle = 'rgba(18, 16, 14, 0.85)';
    ctx.lineWidth = 2.2;
    for (let x = -offset; x < width; x += stoneW) {
      ctx.beginPath();
      ctx.moveTo(x, yTop);
      ctx.lineTo(x + (x % 5) * 1.5, screenGroundY + rowHeights[r + 1]);
      ctx.stroke();
    }
  }

  // Banyan Tree Roots Winding Over Flagstones
  ctx.save();
  ctx.strokeStyle = '#291b11';
  ctx.lineWidth = 4.2;
  ctx.beginPath();
  ctx.moveTo(width * 0.11, screenGroundY);
  ctx.bezierCurveTo(width * 0.15, screenGroundY + 22, width * 0.19, screenGroundY + 15, width * 0.25, screenGroundY + 38);
  ctx.bezierCurveTo(width * 0.29, screenGroundY + 50, width * 0.36, screenGroundY + 34, width * 0.43, screenGroundY + 56);
  ctx.stroke();
  ctx.restore();

  for (let f = 0; f < width; f += 62) {
    drawRuinsFern(ctx, f + (f % 5) * 8, screenGroundY + 8 + (f % 4) * 6);
  }

  const ruinsVignette = ctx.createLinearGradient(0, screenGroundY, 0, height);
  ruinsVignette.addColorStop(0, 'rgba(0, 0, 0, 0.04)');
  ruinsVignette.addColorStop(0.4, 'rgba(0, 0, 0, 0.18)');
  ruinsVignette.addColorStop(1, 'rgba(0, 0, 0, 0.55)');
  ctx.fillStyle = ruinsVignette;
  ctx.fillRect(0, screenGroundY, width, turfHeight);
}

function drawStonePillar(
  ctx: CanvasRenderingContext2D,
  x: number,
  baseY: number,
  pillarW: number,
  pillarH: number,
  withCapital: boolean
): void {
  ctx.save();
  const pillarGrad = ctx.createLinearGradient(x - pillarW / 2, 0, x + pillarW / 2, 0);
  pillarGrad.addColorStop(0, '#696159');
  pillarGrad.addColorStop(0.28, '#7c736a');
  pillarGrad.addColorStop(0.72, '#4a433d');
  pillarGrad.addColorStop(1, '#292521');
  ctx.fillStyle = pillarGrad;

  const topY = baseY - pillarH;
  ctx.fillRect(x - pillarW / 2, topY, pillarW, pillarH);

  // Horizontal Carved Lotus Band Rings on Pillar
  ctx.fillStyle = 'rgba(254, 215, 170, 0.22)';
  ctx.fillRect(x - pillarW / 2, topY + 24, pillarW, 3);
  ctx.fillRect(x - pillarW / 2, baseY - 34, pillarW, 3);

  // Vertical Fluting Channels
  ctx.strokeStyle = 'rgba(22, 19, 17, 0.48)';
  ctx.lineWidth = 1.5;
  const numFlutes = 4;
  for (let f = 1; f <= numFlutes; f++) {
    const fx = x - pillarW / 2 + (pillarW / (numFlutes + 1)) * f;
    ctx.beginPath();
    ctx.moveTo(fx, topY + 10);
    ctx.lineTo(fx, baseY - 10);
    ctx.stroke();
  }

  if (withCapital) {
    ctx.fillStyle = '#736a61';
    ctx.fillRect(x - pillarW * 0.66, topY - 14, pillarW * 1.32, 14);
  }

  ctx.fillStyle = '#443e39';
  ctx.fillRect(x - pillarW * 0.62, baseY - 16, pillarW * 1.24, 16);
  ctx.fillStyle = '#2d2824';
  ctx.fillRect(x - pillarW * 0.74, baseY, pillarW * 1.48, 14);

  // Emerald Moss Cushions
  ctx.fillStyle = 'rgba(74, 102, 46, 0.78)';
  ctx.beginPath();
  ctx.ellipse(x - pillarW * 0.15, topY + pillarH * 0.64, pillarW * 0.36, 12, 0.2, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawFallenPillar(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  len: number,
  dia: number
): void {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(0.08);

  const grad = ctx.createLinearGradient(0, -dia / 2, 0, dia / 2);
  grad.addColorStop(0, '#635b53');
  grad.addColorStop(0.5, '#4c4640');
  grad.addColorStop(1, '#292521');
  ctx.fillStyle = grad;
  ctx.fillRect(0, -dia / 2, len, dia);

  ctx.fillStyle = '#3a342e';
  ctx.beginPath();
  ctx.moveTo(len, -dia / 2);
  ctx.lineTo(len + 6, -dia * 0.1);
  ctx.lineTo(len + 2, dia * 0.2);
  ctx.lineTo(len + 8, dia / 2);
  ctx.lineTo(len, dia / 2);
  ctx.closePath();
  ctx.fill();

  ctx.fillStyle = 'rgba(78, 108, 48, 0.82)';
  ctx.beginPath();
  ctx.ellipse(len * 0.45, -dia * 0.25, len * 0.26, 4.5, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawAncientCreepingVines(
  ctx: CanvasRenderingContext2D,
  startX: number,
  startY: number,
  vineLength: number
): void {
  ctx.save();
  ctx.strokeStyle = '#253819';
  ctx.lineWidth = 2.3;
  ctx.beginPath();
  ctx.moveTo(startX, startY);
  ctx.quadraticCurveTo(startX + 18, startY + vineLength * 0.4, startX + 6, startY + vineLength * 0.7);
  ctx.quadraticCurveTo(startX - 8, startY + vineLength * 0.88, startX + 4, startY + vineLength);
  ctx.stroke();

  ctx.fillStyle = '#4d7c2b';
  for (let l = 0.14; l < 0.95; l += 0.15) {
    const lx = startX + Math.sin(l * Math.PI * 2) * 10;
    const ly = startY + vineLength * l;
    ctx.beginPath();
    ctx.ellipse(lx + (l > 0.5 ? 4 : -4), ly, 5.8, 3.1, l * 2, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

function drawRuinsFern(ctx: CanvasRenderingContext2D, x: number, y: number): void {
  ctx.save();
  ctx.translate(x, y);
  const fernGrad = ctx.createLinearGradient(0, 0, 0, -22);
  fernGrad.addColorStop(0, '#1f3b14');
  fernGrad.addColorStop(1, '#65a30d');
  ctx.strokeStyle = fernGrad;
  ctx.lineWidth = 1.7;

  [-0.95, -0.48, 0, 0.48, 0.95].forEach((ang) => {
    ctx.beginPath();
    ctx.moveTo(0, 0);
    const endX = Math.sin(ang) * 19;
    const endY = -Math.cos(ang) * 19;
    ctx.quadraticCurveTo(endX * 0.5 + (ang > 0 ? 3 : -3), endY * 0.5, endX, endY);
    ctx.stroke();
  });
  ctx.restore();
}

// =============================================================================
// ENVIRONMENT 6: RAINFOREST WATERFALL VALLEY (Photorealistic Canvas 2D)
// =============================================================================
export function renderProceduralWaterfallValley(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  screenGroundY: number
): void {
  // 1. TROPICAL RAINFOREST CANYON SKY WITH MIST SCATTERING
  const skyGrad = ctx.createLinearGradient(0, 0, 0, screenGroundY);
  skyGrad.addColorStop(0.0, '#083344');  // Deep rainforest canopy teal-azure
  skyGrad.addColorStop(0.20, '#0284c7'); // Crisp mountain sky blue
  skyGrad.addColorStop(0.45, '#38bdf8'); // Luminous cyan
  skyGrad.addColorStop(0.68, '#7dd3fc'); // Sunlit vapor blue
  skyGrad.addColorStop(0.86, '#bae6fd'); // Rising canyon mist
  skyGrad.addColorStop(1.0, '#ecfdf5');  // Emerald valley dew haze
  ctx.fillStyle = skyGrad;
  ctx.fillRect(0, 0, width, screenGroundY);

  // 2. MORNING SUN & DIAGONAL TYNDALL CATHEDRAL SUNBEAMS
  const sunX = width * 0.28;
  const sunY = Math.min(112, screenGroundY * 0.20);

  const sunGlow = ctx.createRadialGradient(sunX, sunY, 20, sunX, sunY, width * 0.58);
  sunGlow.addColorStop(0, 'rgba(254, 249, 195, 0.45)');
  sunGlow.addColorStop(0.32, 'rgba(186, 230, 253, 0.20)');
  sunGlow.addColorStop(0.68, 'rgba(56, 189, 248, 0.05)');
  sunGlow.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = sunGlow;
  ctx.fillRect(0, 0, width, screenGroundY);

  // Diagonal Volumetric Sunbeams Piercing Into the Gorge
  ctx.save();
  ctx.translate(sunX, sunY);
  for (let r = 0; r < 9; r++) {
    const ang = 0.25 + r * 0.16;
    const len = width * 0.65;
    const rGrad = ctx.createRadialGradient(0, 0, 15, 0, 0, len);
    rGrad.addColorStop(0, 'rgba(254, 249, 195, 0.22)');
    rGrad.addColorStop(0.45, 'rgba(186, 230, 253, 0.09)');
    rGrad.addColorStop(1, 'rgba(255, 255, 255, 0)');
    ctx.fillStyle = rGrad;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.arc(0, 0, len, ang - 0.045, ang + 0.045);
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();

  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(sunX, sunY, 26, 0, Math.PI * 2);
  ctx.fill();

  // 3. DISTANT LUSH EMERALD HIGHLAND RIDGES
  const farCliffGrad = ctx.createLinearGradient(0, screenGroundY * 0.24, 0, screenGroundY * 0.66);
  farCliffGrad.addColorStop(0, '#064e3b');
  farCliffGrad.addColorStop(0.5, '#065f46');
  farCliffGrad.addColorStop(1, '#047857');
  ctx.fillStyle = farCliffGrad;
  ctx.beginPath();
  ctx.moveTo(0, screenGroundY * 0.66);
  ctx.lineTo(0, screenGroundY * 0.34);
  ctx.lineTo(width * 0.18, screenGroundY * 0.26);
  ctx.lineTo(width * 0.35, screenGroundY * 0.44);
  ctx.lineTo(width * 0.52, screenGroundY * 0.34);
  ctx.lineTo(width * 0.68, screenGroundY * 0.48);
  ctx.lineTo(width * 0.85, screenGroundY * 0.30);
  ctx.lineTo(width, screenGroundY * 0.40);
  ctx.lineTo(width, screenGroundY * 0.66);
  ctx.closePath();
  ctx.fill();

  // 4. SHEER BASALT & MOSSY LIMESTONE CANYON CLIFF WALLS
  const leftCliffGrad = ctx.createLinearGradient(0, screenGroundY * 0.24, width * 0.40, screenGroundY * 0.92);
  leftCliffGrad.addColorStop(0, '#065f46');
  leftCliffGrad.addColorStop(0.35, '#064e3b');
  leftCliffGrad.addColorStop(0.75, '#115e59');
  leftCliffGrad.addColorStop(1, '#0f172a');
  ctx.fillStyle = leftCliffGrad;
  ctx.beginPath();
  ctx.moveTo(0, screenGroundY * 0.95);
  ctx.lineTo(0, screenGroundY * 0.24);
  ctx.lineTo(width * 0.15, screenGroundY * 0.23);
  ctx.lineTo(width * 0.24, screenGroundY * 0.37);
  ctx.lineTo(width * 0.30, screenGroundY * 0.52);
  ctx.lineTo(width * 0.35, screenGroundY * 0.72);
  ctx.lineTo(width * 0.39, screenGroundY * 0.95);
  ctx.closePath();
  ctx.fill();

  const rightCliffGrad = ctx.createLinearGradient(width * 0.54, 0, width, screenGroundY * 0.92);
  rightCliffGrad.addColorStop(0, '#065f46');
  rightCliffGrad.addColorStop(0.45, '#022c22');
  rightCliffGrad.addColorStop(1, '#09111e');
  ctx.fillStyle = rightCliffGrad;
  ctx.beginPath();
  ctx.moveTo(width * 0.55, screenGroundY * 0.95);
  ctx.lineTo(width * 0.57, screenGroundY * 0.60);
  ctx.lineTo(width * 0.65, screenGroundY * 0.40);
  ctx.lineTo(width * 0.76, screenGroundY * 0.25);
  ctx.lineTo(width, screenGroundY * 0.21);
  ctx.lineTo(width, screenGroundY * 0.95);
  ctx.closePath();
  ctx.fill();

  // Geological Basalt Ledges & Moss Shelves on Cliffs
  ctx.strokeStyle = 'rgba(110, 231, 183, 0.16)';
  ctx.lineWidth = 1.6;
  for (let cl = 0; cl < 6; cl++) {
    const cly = screenGroundY * (0.32 + cl * 0.10);
    ctx.beginPath();
    ctx.moveTo(0, cly);
    ctx.lineTo(width * 0.27, cly + 16);
    ctx.moveTo(width * 0.64, cly);
    ctx.lineTo(width, cly + 20);
    ctx.stroke();
  }

  // 5. THE MONUMENTAL MULTI-TIER CASCADING WATERFALL & TWIN SIDE STREAMS
  const fallX = width * 0.46;
  const fallTopY = screenGroundY * 0.31;
  const fallBaseY = screenGroundY * 0.93;
  const fallW = Math.max(38, width * 0.088);

  // Dark Wet Basalt Gorge Wall Behind Waterfall
  ctx.fillStyle = '#082f49';
  ctx.fillRect(fallX - fallW * 0.58, fallTopY, fallW * 1.16, fallBaseY - fallTopY);

  const waterGrad = ctx.createLinearGradient(fallX - fallW / 2, 0, fallX + fallW / 2, 0);
  waterGrad.addColorStop(0.0, 'rgba(186, 230, 253, 0.88)');
  waterGrad.addColorStop(0.22, 'rgba(255, 255, 255, 0.98)');
  waterGrad.addColorStop(0.50, 'rgba(56, 189, 248, 0.92)');
  waterGrad.addColorStop(0.78, 'rgba(255, 255, 255, 0.98)');
  waterGrad.addColorStop(1.0, 'rgba(186, 230, 253, 0.88)');
  ctx.fillStyle = waterGrad;

  // Upper Cataract Tier
  const tier1BottomY = fallTopY + (fallBaseY - fallTopY) * 0.44;
  ctx.fillRect(fallX - fallW * 0.44, fallTopY, fallW * 0.88, tier1BottomY - fallTopY);

  // Mossy Mid-Cascade Outcrop Ledge
  ctx.fillStyle = '#0f172a';
  ctx.beginPath();
  ctx.roundRect(fallX - fallW * 0.68, tier1BottomY - 5, fallW * 1.36, 15, [5, 5, 2, 2]);
  ctx.fill();
  ctx.fillStyle = '#15803d';
  ctx.fillRect(fallX - fallW * 0.62, tier1BottomY - 5, fallW * 1.24, 3.5);

  // Lower Fanning Cascade Tier
  ctx.fillStyle = waterGrad;
  ctx.beginPath();
  ctx.moveTo(fallX - fallW * 0.48, tier1BottomY + 7);
  ctx.lineTo(fallX + fallW * 0.48, tier1BottomY + 7);
  ctx.lineTo(fallX + fallW * 0.72, fallBaseY);
  ctx.lineTo(fallX - fallW * 0.72, fallBaseY);
  ctx.closePath();
  ctx.fill();

  // Churning White-Water Vertical Foam Filaments
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = 1.9;
  const numStreaks = 8;
  for (let s = 0; s < numStreaks; s++) {
    const sx = fallX - fallW * 0.38 + (fallW * 0.76 / (numStreaks - 1)) * s;
    ctx.beginPath();
    ctx.moveTo(sx, fallTopY + 3);
    ctx.lineTo(sx + (s % 2 === 0 ? 3.5 : -3.5), fallBaseY - 10);
    ctx.stroke();
  }

  // Twin Bridal-Veil Side Streams on Left & Right Cliffs
  ctx.fillStyle = 'rgba(224, 242, 254, 0.82)';
  ctx.fillRect(width * 0.21, screenGroundY * 0.44, 6.5, screenGroundY * 0.88 - screenGroundY * 0.44);
  ctx.fillRect(width * 0.67, screenGroundY * 0.46, 5.5, screenGroundY * 0.89 - screenGroundY * 0.46);

  // 6. EMERALD PLUNGE POOL, CONCENTRIC FOAM RIPPLES & BILLOWING SPRAY MIST
  const poolGrad = ctx.createRadialGradient(fallX, fallBaseY + 4, 8, fallX, fallBaseY + 6, fallW * 2.4);
  poolGrad.addColorStop(0, '#ffffff');
  poolGrad.addColorStop(0.25, '#67e8f9');
  poolGrad.addColorStop(0.65, '#0891b2');
  poolGrad.addColorStop(1, '#064e3b');
  ctx.fillStyle = poolGrad;
  ctx.beginPath();
  ctx.ellipse(fallX, fallBaseY + 4, fallW * 2.3, 16, 0, 0, Math.PI * 2);
  ctx.fill();

  // Billowing Spray Mist Clouds
  const mistGrad = ctx.createRadialGradient(fallX, fallBaseY - 14, 8, fallX, fallBaseY - 14, fallW * 2.4);
  mistGrad.addColorStop(0, 'rgba(255, 255, 255, 0.88)');
  mistGrad.addColorStop(0.38, 'rgba(224, 242, 254, 0.58)');
  mistGrad.addColorStop(0.72, 'rgba(186, 230, 253, 0.22)');
  mistGrad.addColorStop(1, 'rgba(255, 255, 255, 0)');
  ctx.fillStyle = mistGrad;
  ctx.beginPath();
  ctx.ellipse(fallX, fallBaseY - 10, fallW * 2.4, 48, 0, 0, Math.PI * 2);
  ctx.fill();

  // 7. VIVID OPTICAL RAINBOW ARC IN WATERFALL SPRAY
  ctx.save();
  ctx.lineWidth = 3.6;
  const rainbowColors = [
    'rgba(239, 68, 68, 0.38)',
    'rgba(245, 158, 11, 0.38)',
    'rgba(234, 179, 8, 0.38)',
    'rgba(34, 197, 94, 0.38)',
    'rgba(14, 165, 233, 0.38)',
    'rgba(139, 92, 246, 0.34)',
  ];
  rainbowColors.forEach((col, idx) => {
    ctx.strokeStyle = col;
    ctx.beginPath();
    ctx.arc(fallX + 36, fallBaseY - 18, 78 + idx * 3.5, Math.PI * 1.04, Math.PI * 1.76);
    ctx.stroke();
  });
  ctx.restore();

  // 8. TROPICAL RAINFOREST CANOPY & WEEPING CLIFF LIANAS
  const treeGroundY = screenGroundY + 6;
  drawRainforestTree(ctx, width * 0.06, treeGroundY, 64, 116);
  drawRainforestTree(ctx, width * 0.16, treeGroundY, 78, 134);
  drawRainforestTree(ctx, width * 0.73, treeGroundY, 74, 128);
  drawRainforestTree(ctx, width * 0.88, treeGroundY, 88, 148);

  drawHangingWaterfallVines(ctx, width * 0.19, screenGroundY * 0.36, 96);
  drawHangingWaterfallVines(ctx, width * 0.71, screenGroundY * 0.40, 88);

  // 9. FOREGROUND LUSH RIVERBANK & MOWED EMERALD OUTFIELD
  const turfHeight = height - screenGroundY;
  const stripeW = 64;
  const stripeCount = Math.ceil(width / stripeW) + 1;

  for (let st = 0; st < stripeCount; st++) {
    const sx = st * stripeW;
    const isAlt = st % 2 === 0;
    const rGrad = ctx.createLinearGradient(0, screenGroundY, 0, height);
    rGrad.addColorStop(0, isAlt ? '#16a34a' : '#15803d');
    rGrad.addColorStop(0.32, isAlt ? '#15803d' : '#166534');
    rGrad.addColorStop(0.70, '#14532d');
    rGrad.addColorStop(1, '#052e16');
    ctx.fillStyle = rGrad;
    ctx.fillRect(sx, screenGroundY, stripeW + 1, turfHeight);
  }

  // Crystal Streamlets Reflecting Sky Along Riverbank
  const streamPoolGrad = ctx.createLinearGradient(0, screenGroundY + 4, 0, screenGroundY + 28);
  streamPoolGrad.addColorStop(0, 'rgba(186, 230, 253, 0.52)');
  streamPoolGrad.addColorStop(0.5, 'rgba(56, 189, 248, 0.40)');
  streamPoolGrad.addColorStop(1, 'rgba(12, 74, 110, 0.18)');
  ctx.fillStyle = streamPoolGrad;
  ctx.beginPath();
  ctx.ellipse(width * 0.42, screenGroundY + 15, 92, 12, 0.04, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(width * 0.78, screenGroundY + 21, 64, 9.5, -0.06, 0, Math.PI * 2);
  ctx.fill();

  // Wet River Cobbles with Specular Sheen
  for (let p = 0; p < width; p += 38) {
    const px = p + (p % 7) * 5;
    const py = screenGroundY + 10 + (p % 5) * 6;
    ctx.fillStyle = p % 3 === 0 ? '#64748b' : p % 2 === 0 ? '#475569' : '#334155';
    ctx.beginPath();
    ctx.ellipse(px, py, 4.8, 2.9, (p % 4) * 0.3, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = 'rgba(255, 255, 255, 0.48)';
    ctx.beginPath();
    ctx.arc(px - 1.2, py - 1, 1.3, 0, Math.PI * 2);
    ctx.fill();
  }

  for (let tf = 0; tf < width; tf += 50) {
    drawRiverbankFern(ctx, tf + (tf % 6) * 6, screenGroundY + 4 + (tf % 3) * 5);
  }

  const valleyVignette = ctx.createLinearGradient(0, screenGroundY, 0, height);
  valleyVignette.addColorStop(0, 'rgba(0, 0, 0, 0.02)');
  valleyVignette.addColorStop(0.35, 'rgba(0, 0, 0, 0.12)');
  valleyVignette.addColorStop(1, 'rgba(0, 0, 0, 0.45)');
  ctx.fillStyle = valleyVignette;
  ctx.fillRect(0, screenGroundY, width, turfHeight);
}

function drawRainforestTree(
  ctx: CanvasRenderingContext2D,
  trunkX: number,
  groundY: number,
  canopyR: number,
  treeH: number
): void {
  ctx.save();
  const topY = groundY - treeH;

  const trunkGrad = ctx.createLinearGradient(trunkX - 9, 0, trunkX + 9, 0);
  trunkGrad.addColorStop(0, '#2d1b0f');
  trunkGrad.addColorStop(0.5, '#4a2e1b');
  trunkGrad.addColorStop(1, '#1b1008');
  ctx.fillStyle = trunkGrad;

  ctx.beginPath();
  ctx.moveTo(trunkX - 11, groundY);
  ctx.quadraticCurveTo(trunkX - 4, groundY - treeH * 0.5, trunkX - 5, topY);
  ctx.lineTo(trunkX + 5, topY);
  ctx.quadraticCurveTo(trunkX + 4, groundY - treeH * 0.5, trunkX + 11, groundY);
  ctx.closePath();
  ctx.fill();

  // Deep Under-Canopy Shadow Layer
  ctx.fillStyle = '#052e16';
  ctx.beginPath();
  ctx.arc(trunkX - canopyR * 0.48, topY + 14, canopyR * 0.62, 0, Math.PI * 2);
  ctx.arc(trunkX + canopyR * 0.48, topY + 12, canopyR * 0.65, 0, Math.PI * 2);
  ctx.arc(trunkX, topY + 4, canopyR * 0.82, 0, Math.PI * 2);
  ctx.fill();

  // Mid Emerald Foliage Layer
  const canopyGrad = ctx.createRadialGradient(trunkX - 8, topY - 16, 8, trunkX, topY, canopyR);
  canopyGrad.addColorStop(0, '#4ade80');
  canopyGrad.addColorStop(0.45, '#16a34a');
  canopyGrad.addColorStop(1, '#14532d');
  ctx.fillStyle = canopyGrad;

  ctx.beginPath();
  ctx.arc(trunkX, topY, canopyR * 0.78, 0, Math.PI * 2);
  ctx.arc(trunkX - canopyR * 0.46, topY + 10, canopyR * 0.56, 0, Math.PI * 2);
  ctx.arc(trunkX + canopyR * 0.46, topY + 8, canopyR * 0.60, 0, Math.PI * 2);
  ctx.arc(trunkX, topY - canopyR * 0.36, canopyR * 0.62, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawHangingWaterfallVines(
  ctx: CanvasRenderingContext2D,
  startX: number,
  startY: number,
  len: number
): void {
  ctx.save();
  ctx.strokeStyle = '#14532d';
  ctx.lineWidth = 1.9;
  ctx.beginPath();
  ctx.moveTo(startX, startY);
  ctx.bezierCurveTo(startX - 12, startY + len * 0.35, startX + 10, startY + len * 0.7, startX - 5, startY + len);
  ctx.stroke();

  ctx.fillStyle = '#22c55e';
  for (let vl = 0.18; vl < 0.95; vl += 0.18) {
    const vy = startY + len * vl;
    ctx.beginPath();
    ctx.ellipse(startX + (vl > 0.5 ? 4 : -4), vy, 4.8, 2.5, vl * 1.5, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

function drawRiverbankFern(ctx: CanvasRenderingContext2D, x: number, y: number): void {
  ctx.save();
  ctx.translate(x, y);
  ctx.strokeStyle = '#22c55e';
  ctx.lineWidth = 1.5;

  [-1.1, -0.58, 0, 0.58, 1.1].forEach((ang) => {
    ctx.beginPath();
    ctx.moveTo(0, 0);
    const fx = Math.sin(ang) * 17;
    const fy = -Math.cos(ang) * 15;
    ctx.quadraticCurveTo(fx * 0.5 + (ang > 0 ? 2 : -2), fy * 0.5, fx, fy);
    ctx.stroke();
  });
  ctx.restore();
}
