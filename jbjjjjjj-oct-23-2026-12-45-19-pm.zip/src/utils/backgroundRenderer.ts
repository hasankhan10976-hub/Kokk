import { BackgroundTheme } from '../types/game';
import {
  renderProceduralDesertDunes,
  renderProceduralSnowyPeaks,
  renderProceduralOceanBeach
} from './distinctBackgrounds';
import {
  renderProceduralStoneTemple,
  renderProceduralWaterfallValley
} from './templeWaterfallBackgrounds';

export const renderProceduralBackground = (
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  screenGroundY: number,
  theme: BackgroundTheme
): void => {
  if (theme === 'TEMPLE') {
    renderProceduralStoneTemple(ctx, width, height, screenGroundY);
    return;
  }
  if (theme === 'WATERFALL') {
    renderProceduralWaterfallValley(ctx, width, height, screenGroundY);
    return;
  }
  if (theme === 'DESERT' || theme === 'SUNSET') {
    renderProceduralDesertDunes(ctx, width, height, screenGroundY);
    return;
  }
  if (theme === 'SNOW' || theme === 'NIGHT') {
    renderProceduralSnowyPeaks(ctx, width, height, screenGroundY);
    return;
  }
  if (theme === 'BEACH' || theme === 'JUNGLE') {
    renderProceduralOceanBeach(ctx, width, height, screenGroundY);
    return;
  }

  // Default / DAY: Ultra-Realistic Green Village Meadow & Stadium Valley
  renderMasterpieceDayBackground(ctx, width, height, screenGroundY);
};

/**
 * Lightweight, zero-allocation 60 FPS real-time ambient animation overlay.
 * Renders living water shimmers, gently flapping sky birds, and biome-authentic
 * atmospheric motes on top of the cached offscreen background with zero lag.
 */
export const renderAmbientBackgroundOverlay = (
  ctx: CanvasRenderingContext2D,
  bgWidth: number,
  viewportHeight: number,
  screenGroundY: number,
  theme: BackgroundTheme,
  timeMs: number,
  parallaxX: number
): void => {
  const t = timeMs * 0.001;
  ctx.save();
  ctx.translate(-parallaxX, 0);

  // 1. REAL-TIME WATER SPECULAR SHIMMER & GLINTS PER BIOME
  if (theme === 'DAY') {
    const riverY = screenGroundY - 60;
    for (let i = 0; i < 14; i++) {
      const phase = t * 2.4 + i * 1.37;
      const alpha = 0.25 + 0.65 * Math.max(0, Math.sin(phase));
      const gx = bgWidth * (0.16 + (i / 14) * 0.45) + Math.sin(t + i) * 4;
      const gy = riverY + 3 + (i % 4) * 3.2;
      const gw = 5 + Math.sin(phase) * 4;
      ctx.fillStyle = `rgba(255, 255, 255, ${alpha.toFixed(2)})`;
      ctx.fillRect(gx, gy, Math.max(2, gw), 1.4);
    }
  } else if (theme === 'DESERT' || theme === 'SUNSET') {
    const oasisX = bgWidth * 0.20;
    const oasisY = screenGroundY * 0.91;
    for (let i = 0; i < 10; i++) {
      const phase = t * 2.8 + i * 1.1;
      const alpha = 0.3 + 0.65 * Math.max(0, Math.sin(phase));
      const gx = oasisX - 75 + i * 16 + Math.cos(t + i) * 3;
      const gy = oasisY - 6 + (i % 3) * 5;
      ctx.fillStyle = `rgba(254, 249, 195, ${alpha.toFixed(2)})`;
      ctx.fillRect(gx, gy, 7, 1.5);
    }
  } else if (theme === 'BEACH' || theme === 'JUNGLE') {
    const seaY = screenGroundY * 0.58;
    const seaH = screenGroundY * 0.30;
    for (let i = 0; i < 18; i++) {
      const phase = t * 2.6 + i * 0.95;
      const alpha = 0.3 + 0.65 * Math.max(0, Math.sin(phase));
      const gx = bgWidth * (0.08 + ((i * 19) % 84) * 0.01) + Math.sin(t * 1.5 + i) * 5;
      const gy = seaY + ((i * 23) % 100) * 0.01 * seaH;
      ctx.fillStyle = `rgba(255, 255, 255, ${alpha.toFixed(2)})`;
      ctx.fillRect(gx, gy, 8 + Math.sin(phase) * 4, 1.6);
    }
  } else if (theme === 'WATERFALL') {
    const fallX = bgWidth * 0.46;
    const fallTopY = screenGroundY * 0.31;
    const fallBaseY = screenGroundY * 0.93;
    const fallW = Math.max(38, bgWidth * 0.088);

    // Animated cascading water streaks falling downward
    ctx.fillStyle = 'rgba(255, 255, 255, 0.55)';
    for (let s = 0; s < 10; s++) {
      const sx = fallX - fallW * 0.36 + (s / 9) * (fallW * 0.72);
      const dropProg = (t * 1.4 + s * 0.23) % 1;
      const sy = fallTopY + dropProg * (fallBaseY - fallTopY - 24);
      ctx.fillRect(sx, sy, 2.2, 18);
    }

    // Expanding concentric plunge pool ripple rings
    for (let r = 0; r < 3; r++) {
      const rp = (t * 0.65 + r * 0.33) % 1;
      const rx = fallW * (0.6 + rp * 1.6);
      const ry = 4 + rp * 11;
      const rAlpha = (1 - rp) * 0.55;
      ctx.strokeStyle = `rgba(255, 255, 255, ${rAlpha.toFixed(2)})`;
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.ellipse(fallX, fallBaseY + 4, rx, ry, 0, 0, Math.PI * 2);
      ctx.stroke();
    }
  } else if (theme === 'TEMPLE') {
    const sanctuaryCenterX = bgWidth * 0.48;
    const moatY = screenGroundY - 6;
    // Flickering torchlight reflection on temple lotus moat
    const flicker = 0.65 + Math.sin(t * 7.5) * 0.18 + Math.cos(t * 13.2) * 0.1;
    ctx.fillStyle = `rgba(254, 215, 170, ${(flicker * 0.45).toFixed(2)})`;
    ctx.beginPath();
    ctx.ellipse(sanctuaryCenterX, moatY, 24 + Math.sin(t * 5) * 4, 4.5, 0, 0, Math.PI * 2);
    ctx.fill();
  } else if (theme === 'SNOW' || theme === 'NIGHT') {
    const lakeX = bgWidth * 0.46;
    const lakeY = screenGroundY * 0.91;
    for (let i = 0; i < 8; i++) {
      const phase = t * 2.2 + i * 1.3;
      const alpha = 0.25 + 0.65 * Math.max(0, Math.sin(phase));
      ctx.fillStyle = `rgba(255, 255, 255, ${alpha.toFixed(2)})`;
      ctx.fillRect(lakeX - 110 + i * 30, lakeY - 3 + (i % 3) * 3, 6, 1.4);
    }
  }

  // 2. SOARING BIRDS WITH GENTLE WINGBEAT ANIMATION (Day, Beach, Waterfall, Temple)
  if (theme === 'DAY' || theme === 'BEACH' || theme === 'JUNGLE' || theme === 'WATERFALL' || theme === 'TEMPLE') {
    ctx.strokeStyle = theme === 'TEMPLE' ? 'rgba(28, 25, 23, 0.75)' : 'rgba(15, 23, 42, 0.72)';
    ctx.lineWidth = 1.7;
    for (let b = 0; b < 5; b++) {
      const bx = ((bgWidth * (0.18 + b * 0.032) + t * 14) % (bgWidth * 0.85)) + bgWidth * 0.05;
      const by = screenGroundY * (0.16 + (b % 3) * 0.028) + Math.sin(t * 2 + b) * 3;
      const wingFlap = Math.sin(t * 6.5 + b * 1.4) * 3.8;
      const span = 6.5 + (b % 2) * 1.8;
      ctx.beginPath();
      ctx.moveTo(bx - span, by - wingFlap);
      ctx.quadraticCurveTo(bx - span * 0.45, by - 3.2, bx, by);
      ctx.quadraticCurveTo(bx + span * 0.45, by - 3.2, bx + span, by - wingFlap);
      ctx.stroke();
    }
  }

  // 3. BIOME-SPECIFIC FLOATING ATMOSPHERIC PARTICLES (Zero GC Allocations)
  const particleCount = theme === 'SNOW' || theme === 'NIGHT' ? 28 : 16;
  for (let p = 0; p < particleCount; p++) {
    const seedX = (p * 137.5) % 100;
    const seedY = (p * 73.1) % 100;

    if (theme === 'SNOW' || theme === 'NIGHT') {
      // Gently falling crystalline snowflakes
      const px = ((seedX * 0.01 * bgWidth) + Math.sin(t * 0.8 + p) * 18 + t * 10) % bgWidth;
      const py = ((seedY * 0.01 * viewportHeight) + t * (22 + (p % 4) * 6)) % viewportHeight;
      const r = 1.3 + (p % 3) * 0.7;
      ctx.fillStyle = 'rgba(255, 255, 255, 0.82)';
      ctx.beginPath();
      ctx.arc(px, py, r, 0, Math.PI * 2);
      ctx.fill();
    } else if (theme === 'TEMPLE') {
      // Rising mystical golden embers / fireflies
      const px = (seedX * 0.01 * bgWidth) + Math.sin(t * 1.2 + p) * 12;
      const py = screenGroundY - ((seedY * 0.01 * screenGroundY * 0.7 + t * 14) % (screenGroundY * 0.7));
      const pulse = 0.35 + 0.65 * Math.max(0, Math.sin(t * 3.2 + p));
      ctx.fillStyle = `rgba(253, 224, 71, ${(pulse * 0.8).toFixed(2)})`;
      ctx.beginPath();
      ctx.arc(px, py, 2.0, 0, Math.PI * 2);
      ctx.fill();
    } else {
      // Sunlit golden pollen / mist / desert shimmer motes
      const px = ((seedX * 0.01 * bgWidth) + t * 8 + Math.sin(t + p) * 10) % bgWidth;
      const py = (screenGroundY * 0.25) + ((seedY * 0.01) * screenGroundY * 0.72) + Math.cos(t * 1.1 + p) * 6;
      const alpha = 0.2 + 0.5 * Math.max(0, Math.sin(t * 2.1 + p));
      ctx.fillStyle =
        theme === 'WATERFALL'
          ? `rgba(224, 242, 254, ${alpha.toFixed(2)})`
          : `rgba(254, 249, 195, ${alpha.toFixed(2)})`;
      ctx.beginPath();
      ctx.arc(px, py, 1.6, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  ctx.restore();
};

function renderMasterpieceDayBackground(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  screenGroundY: number
): void {
  // =========================================================================
  // 1. SKY DOME & ATMOSPHERIC RAYLEIGH SCATTERING GRADIENT
  // =========================================================================
  const skyGrad = ctx.createLinearGradient(0, 0, 0, screenGroundY);
  skyGrad.addColorStop(0.0, '#02456b');   // Deep zenith sapphire
  skyGrad.addColorStop(0.16, '#0369a1');  // Rich celestial blue
  skyGrad.addColorStop(0.35, '#0284c7');  // Vibrant sky azure
  skyGrad.addColorStop(0.55, '#38bdf8');  // Crystal cerulean
  skyGrad.addColorStop(0.74, '#7dd3fc');  // Soft cyan scattering
  skyGrad.addColorStop(0.88, '#bae6fd');  // Warm horizon diffusion
  skyGrad.addColorStop(0.96, '#fef08a');  // Golden horizon sunlight
  skyGrad.addColorStop(1.0, '#fef9c3');   // Luminous golden mist
  ctx.fillStyle = skyGrad;
  ctx.fillRect(0, 0, width, screenGroundY);

  const sunX = width * 0.82;
  const sunY = Math.min(122, screenGroundY * 0.23);

  const skySunWash = ctx.createRadialGradient(sunX, sunY, 30, sunX, sunY, width * 0.68);
  skySunWash.addColorStop(0, 'rgba(254, 249, 195, 0.36)');
  skySunWash.addColorStop(0.32, 'rgba(253, 224, 71, 0.14)');
  skySunWash.addColorStop(0.68, 'rgba(56, 189, 248, 0.05)');
  skySunWash.addColorStop(1, 'rgba(255, 255, 255, 0)');
  ctx.fillStyle = skySunWash;
  ctx.fillRect(0, 0, width, screenGroundY);

  // =========================================================================
  // 2. HIGH WISPY CIRRUS CLOUDS
  // =========================================================================
  ctx.save();
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.48)';
  ctx.lineWidth = 2.6;
  const cirrusStreaks = [
    { x1: width * 0.04, y1: screenGroundY * 0.11, cx: width * 0.22, cy: screenGroundY * 0.07, x2: width * 0.40, y2: screenGroundY * 0.09 },
    { x1: width * 0.28, y1: screenGroundY * 0.05, cx: width * 0.48, cy: screenGroundY * 0.03, x2: width * 0.68, y2: screenGroundY * 0.06 },
    { x1: width * 0.58, y1: screenGroundY * 0.12, cx: width * 0.74, cy: screenGroundY * 0.08, x2: width * 0.94, y2: screenGroundY * 0.11 },
    { x1: width * 0.12, y1: screenGroundY * 0.17, cx: width * 0.26, cy: screenGroundY * 0.13, x2: width * 0.38, y2: screenGroundY * 0.16 },
  ];
  cirrusStreaks.forEach((s) => {
    ctx.beginPath();
    ctx.moveTo(s.x1, s.y1);
    ctx.quadraticCurveTo(s.cx, s.cy, s.x2, s.y2);
    ctx.stroke();
  });
  ctx.restore();

  // =========================================================================
  // 3. PHOTOREALISTIC SOLAR OPTICS & VOLUMETRIC CREPUSCULAR GOD RAYS
  // =========================================================================
  ctx.save();
  ctx.translate(sunX, sunY);
  const numGodRays = 14;
  for (let ray = 0; ray < numGodRays; ray++) {
    const rayAngle = (ray * Math.PI) / (numGodRays / 2) + 0.12;
    const rayLength = 420 + (ray % 3) * 55;
    const raySpread = 0.075 + (ray % 2) * 0.025;
    const rayGrad = ctx.createRadialGradient(0, 0, 24, 0, 0, rayLength);
    rayGrad.addColorStop(0, 'rgba(254, 249, 195, 0.26)');
    rayGrad.addColorStop(0.38, 'rgba(253, 224, 71, 0.10)');
    rayGrad.addColorStop(0.75, 'rgba(253, 224, 71, 0.02)');
    rayGrad.addColorStop(1, 'rgba(253, 224, 71, 0)');
    ctx.fillStyle = rayGrad;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.arc(0, 0, rayLength, rayAngle - raySpread, rayAngle + raySpread);
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();

  const sunAuraOuter = ctx.createRadialGradient(sunX, sunY, 18, sunX, sunY, 190);
  sunAuraOuter.addColorStop(0, 'rgba(255, 255, 255, 0.98)');
  sunAuraOuter.addColorStop(0.18, 'rgba(254, 240, 138, 0.88)');
  sunAuraOuter.addColorStop(0.45, 'rgba(253, 224, 71, 0.38)');
  sunAuraOuter.addColorStop(0.75, 'rgba(251, 191, 36, 0.12)');
  sunAuraOuter.addColorStop(1, 'rgba(251, 191, 36, 0)');
  ctx.fillStyle = sunAuraOuter;
  ctx.beginPath();
  ctx.arc(sunX, sunY, 190, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(sunX, sunY, 32, 0, Math.PI * 2);
  ctx.fill();

  // =========================================================================
  // 4. VOLUMETRIC 3D CUMULUS CLOUD FORMATIONS
  // =========================================================================
  const clouds = [
    { x: width * 0.10, y: screenGroundY * 0.19, s: 1.32 },
    { x: width * 0.33, y: screenGroundY * 0.29, s: 1.02 },
    { x: width * 0.54, y: screenGroundY * 0.14, s: 1.58 },
    { x: width * 0.72, y: screenGroundY * 0.35, s: 0.90 },
    { x: width * 0.91, y: screenGroundY * 0.22, s: 1.18 },
  ];
  clouds.forEach((c) => {
    ctx.save();
    ctx.translate(c.x, c.y);
    ctx.scale(c.s, c.s);

    ctx.fillStyle = 'rgba(148, 163, 184, 0.62)';
    ctx.beginPath();
    ctx.arc(-36, 10, 26, 0, Math.PI * 2);
    ctx.arc(0, 12, 34, 0, Math.PI * 2);
    ctx.arc(36, 10, 24, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = 'rgba(203, 213, 225, 0.85)';
    ctx.beginPath();
    ctx.arc(-34, 6, 24, 0, Math.PI * 2);
    ctx.arc(-8, 3, 28, 0, Math.PI * 2);
    ctx.arc(14, 4, 26, 0, Math.PI * 2);
    ctx.arc(34, 6, 22, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = 'rgba(248, 250, 252, 0.97)';
    ctx.beginPath();
    ctx.arc(-32, 0, 22, 0, Math.PI * 2);
    ctx.arc(-12, -15, 26, 0, Math.PI * 2);
    ctx.arc(16, -13, 24, 0, Math.PI * 2);
    ctx.arc(32, 1, 20, 0, Math.PI * 2);
    ctx.arc(6, -4, 22, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(-12, -18, 20, 0, Math.PI * 2);
    ctx.arc(16, -16, 18, 0, Math.PI * 2);
    ctx.arc(2, -20, 16, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  });

  // =========================================================================
  // 5. DISTANT 3D FACETED MOUNTAIN RANGES WITH SUNLIT & SHADOWED FACES
  // =========================================================================
  const drawMountainMassif = (peakX: number, peakY: number, baseW: number) => {
    const baseY = screenGroundY;
    const leftX = peakX - baseW * 0.54;
    const rightX = peakX + baseW * 0.48;
    const ridgeX = peakX + baseW * 0.04;

    // Shadowed Left Face
    const shGrad = ctx.createLinearGradient(leftX, peakY, peakX, baseY);
    shGrad.addColorStop(0, '#1e3a5f');
    shGrad.addColorStop(0.55, '#2d4860');
    shGrad.addColorStop(1, '#334155');
    ctx.fillStyle = shGrad;
    ctx.beginPath();
    ctx.moveTo(peakX, peakY);
    ctx.lineTo(leftX, baseY);
    ctx.lineTo(ridgeX, baseY);
    ctx.closePath();
    ctx.fill();

    // Sunlit Right Face (Illuminated by Sun on Right)
    const litGrad = ctx.createLinearGradient(peakX, peakY, rightX, baseY);
    litGrad.addColorStop(0, '#94a3b8');
    litGrad.addColorStop(0.35, '#64748b');
    litGrad.addColorStop(1, '#3b596e');
    ctx.fillStyle = litGrad;
    ctx.beginPath();
    ctx.moveTo(peakX, peakY);
    ctx.lineTo(ridgeX, baseY);
    ctx.lineTo(rightX, baseY);
    ctx.closePath();
    ctx.fill();

    // Snow/Granite Summit Crown Highlight
    ctx.fillStyle = 'rgba(248, 250, 252, 0.75)';
    ctx.beginPath();
    ctx.moveTo(peakX, peakY);
    ctx.lineTo(peakX + baseW * 0.14, peakY + 42);
    ctx.lineTo(peakX + baseW * 0.02, peakY + 34);
    ctx.lineTo(peakX - baseW * 0.06, peakY + 38);
    ctx.closePath();
    ctx.fill();

    // Central Ridge Spine
    ctx.strokeStyle = 'rgba(241, 245, 249, 0.55)';
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(peakX, peakY);
    ctx.lineTo(ridgeX, peakY + 95);
    ctx.stroke();
  };

  const mSeg = width / 5;
  drawMountainMassif(mSeg * 0.65, screenGroundY - 230, mSeg * 1.6);
  drawMountainMassif(mSeg * 1.85, screenGroundY - 205, mSeg * 1.5);
  drawMountainMassif(mSeg * 2.75, screenGroundY - 262, mSeg * 1.8);
  drawMountainMassif(mSeg * 3.90, screenGroundY - 218, mSeg * 1.6);
  drawMountainMassif(mSeg * 4.65, screenGroundY - 248, mSeg * 1.6);

  // Mountain Valley Mist Inversion Layer
  const mMist = ctx.createLinearGradient(0, screenGroundY - 175, 0, screenGroundY);
  mMist.addColorStop(0, 'rgba(224, 242, 254, 0)');
  mMist.addColorStop(0.55, 'rgba(224, 242, 254, 0.36)');
  mMist.addColorStop(1, 'rgba(254, 249, 195, 0.58)');
  ctx.fillStyle = mMist;
  ctx.fillRect(0, screenGroundY - 175, width, 175);

  // Mid-Distance Forested Ridge
  const forestRidgeGrad = ctx.createLinearGradient(0, screenGroundY - 180, 0, screenGroundY);
  forestRidgeGrad.addColorStop(0, '#1e4638');
  forestRidgeGrad.addColorStop(1, '#132e24');
  ctx.fillStyle = forestRidgeGrad;
  ctx.beginPath();
  ctx.moveTo(0, screenGroundY);
  ctx.bezierCurveTo(width * 0.18, screenGroundY - 168, width * 0.42, screenGroundY - 112, width * 0.62, screenGroundY - 154);
  ctx.bezierCurveTo(width * 0.78, screenGroundY - 182, width * 0.92, screenGroundY - 102, width, screenGroundY - 124);
  ctx.lineTo(width, screenGroundY);
  ctx.closePath();
  ctx.fill();

  // =========================================================================
  // 6. ROLLING TERRACED FOOTHILLS & SUNLIT EMERALD MEADOWS
  // =========================================================================
  const farHillGrad = ctx.createLinearGradient(0, screenGroundY - 140, 0, screenGroundY);
  farHillGrad.addColorStop(0, '#3f7d20');
  farHillGrad.addColorStop(1, '#244a12');
  ctx.fillStyle = farHillGrad;
  ctx.beginPath();
  ctx.moveTo(0, screenGroundY);
  ctx.quadraticCurveTo(width * 0.26, screenGroundY - 134, width * 0.52, screenGroundY - 72);
  ctx.quadraticCurveTo(width * 0.78, screenGroundY - 142, width, screenGroundY - 58);
  ctx.lineTo(width, screenGroundY);
  ctx.closePath();
  ctx.fill();

  const meadowGrad = ctx.createLinearGradient(0, screenGroundY - 98, 0, screenGroundY);
  meadowGrad.addColorStop(0, '#84cc16'); // Sunlit golden-lime crest
  meadowGrad.addColorStop(0.45, '#4d7c0f');
  meadowGrad.addColorStop(1, '#365314');
  ctx.fillStyle = meadowGrad;
  ctx.beginPath();
  ctx.moveTo(0, screenGroundY);
  ctx.quadraticCurveTo(width * 0.35, screenGroundY - 98, width * 0.70, screenGroundY - 52);
  ctx.quadraticCurveTo(width * 0.88, screenGroundY - 82, width, screenGroundY - 46);
  ctx.lineTo(width, screenGroundY);
  ctx.closePath();
  ctx.fill();

  // Terraced Paddy Contours on Hills
  ctx.strokeStyle = 'rgba(190, 242, 100, 0.5)';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(width * 0.12, screenGroundY - 90);
  ctx.quadraticCurveTo(width * 0.24, screenGroundY - 102, width * 0.36, screenGroundY - 85);
  ctx.moveTo(width * 0.65, screenGroundY - 75);
  ctx.quadraticCurveTo(width * 0.76, screenGroundY - 96, width * 0.86, screenGroundY - 70);
  ctx.stroke();

  // =========================================================================
  // 7. SERENE WINDING RIVER WITH REFLECTIONS & TRADITIONAL COUNTRY BOATS
  // =========================================================================
  const riverY = screenGroundY - 60;
  const riverGrad = ctx.createLinearGradient(width * 0.14, riverY, width * 0.64, riverY + 18);
  riverGrad.addColorStop(0, '#0369a1');
  riverGrad.addColorStop(0.35, '#0ea5e9');
  riverGrad.addColorStop(0.7, '#7dd3fc');
  riverGrad.addColorStop(1, '#0284c7');
  ctx.fillStyle = riverGrad;
  ctx.beginPath();
  ctx.moveTo(width * 0.14, riverY);
  ctx.bezierCurveTo(width * 0.30, riverY - 9, width * 0.45, riverY + 15, width * 0.63, riverY + 6);
  ctx.lineTo(width * 0.63, riverY + 19);
  ctx.bezierCurveTo(width * 0.45, riverY + 24, width * 0.30, riverY + 5, width * 0.14, riverY + 10);
  ctx.closePath();
  ctx.fill();

  // Earthen Riverbank Edge & Reeds
  ctx.strokeStyle = '#78350f';
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.moveTo(width * 0.14, riverY);
  ctx.bezierCurveTo(width * 0.30, riverY - 9, width * 0.45, riverY + 15, width * 0.63, riverY + 6);
  ctx.stroke();

  ctx.fillStyle = '#15803d';
  for (let r = 0; r < 16; r++) {
    const rx = width * 0.17 + r * (width * 0.026);
    const ry = riverY + 3 + (r % 3) * 2;
    ctx.fillRect(rx, ry, 1.5, 4.5);
  }

  // Helper to draw Traditional Wooden Country Sailboat
  const drawCountryBoat = (boatX: number, boatY: number, scale: number) => {
    ctx.save();
    ctx.translate(boatX, boatY);
    ctx.scale(scale, scale);

    ctx.fillStyle = 'rgba(69, 26, 3, 0.35)';
    ctx.fillRect(-10, 3.5, 20, 2.5);

    ctx.fillStyle = '#451a03';
    ctx.beginPath();
    ctx.moveTo(-14, 0);
    ctx.quadraticCurveTo(0, 5, 14, 0);
    ctx.lineTo(11, 3.5);
    ctx.quadraticCurveTo(0, 6.5, -11, 3.5);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = '#b45309';
    ctx.beginPath();
    ctx.arc(-3, -1, 5.5, Math.PI, 0);
    ctx.fill();

    ctx.strokeStyle = '#291104';
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.moveTo(3, 0);
    ctx.lineTo(3, -18);
    ctx.stroke();

    ctx.fillStyle = '#fef9c3';
    ctx.beginPath();
    ctx.moveTo(3, -17);
    ctx.quadraticCurveTo(13, -9, 14, -2);
    ctx.lineTo(3, -2);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  };

  drawCountryBoat(width * 0.38, riverY + 7, 1.0);
  drawCountryBoat(width * 0.25, riverY + 4, 0.72);

  // =========================================================================
  // 8. PICTURESQUE RURAL HERITAGE VILLAGE & HAYSTACK CLUSTER
  // =========================================================================
  const hutX = width * 0.68;
  const hutY = screenGroundY - 78;
  ctx.save();
  ctx.fillStyle = '#78350f';
  ctx.fillRect(hutX - 18, hutY + 14, 36, 4);
  ctx.fillStyle = '#92400e';
  ctx.fillRect(hutX - 15, hutY, 30, 14);
  ctx.fillStyle = '#451a03';
  ctx.fillRect(hutX - 15, hutY, 2.5, 14);
  ctx.fillRect(hutX + 12.5, hutY, 2.5, 14);
  ctx.fillStyle = '#1c1917';
  ctx.fillRect(hutX - 4, hutY + 3.5, 8, 10.5);
  ctx.fillStyle = '#451a03';
  ctx.fillRect(hutX + 6, hutY + 4, 5, 5);
  ctx.fillStyle = '#fde68a';
  ctx.fillRect(hutX + 7, hutY + 5, 3, 3);

  ctx.fillStyle = '#d97706';
  ctx.beginPath();
  ctx.moveTo(hutX - 20, hutY);
  ctx.lineTo(hutX, hutY - 12);
  ctx.lineTo(hutX + 20, hutY);
  ctx.closePath();
  ctx.fill();

  ctx.fillStyle = '#f59e0b';
  ctx.beginPath();
  ctx.moveTo(hutX - 18, hutY - 2);
  ctx.lineTo(hutX, hutY - 11);
  ctx.lineTo(hutX + 18, hutY - 2);
  ctx.lineTo(hutX + 20, hutY);
  ctx.lineTo(hutX - 20, hutY);
  ctx.closePath();
  ctx.fill();

  const hayX = hutX + 28;
  const hayY = hutY + 14;
  ctx.fillStyle = '#b45309';
  ctx.beginPath();
  ctx.moveTo(hayX - 11, hayY);
  ctx.quadraticCurveTo(hayX - 11, hayY - 13, hayX, hayY - 18);
  ctx.quadraticCurveTo(hayX + 11, hayY - 13, hayX + 11, hayY);
  ctx.closePath();
  ctx.fill();

  ctx.fillStyle = '#f59e0b';
  ctx.beginPath();
  ctx.moveTo(hayX - 3, hayY - 17);
  ctx.quadraticCurveTo(hayX + 9, hayY - 12, hayX + 9, hayY);
  ctx.lineTo(hayX + 4, hayY);
  ctx.quadraticCurveTo(hayX + 4, hayY - 12, hayX - 3, hayY - 17);
  ctx.closePath();
  ctx.fill();
  ctx.restore();

  // =========================================================================
  // 9. CRICKET STADIUM GRANDSTAND & PAVILION CLOCK TOWER
  // =========================================================================
  ctx.save();
  const standColor = '#1e3a1f';
  const trimColor = '#fef08a';
  ctx.fillStyle = standColor;

  const standWidth = width * 0.52;
  const standStartX = width * 0.05;
  const standTopY = screenGroundY - 58;

  ctx.fillRect(standStartX, standTopY, standWidth, 58);

  ctx.fillStyle = '#142715';
  for (let tier = 0; tier < 4; tier++) {
    ctx.fillRect(standStartX, standTopY + 12 + tier * 11, standWidth, 3);
  }

  ctx.strokeStyle = '#f8fafc';
  ctx.lineWidth = 1.4;
  for (let arch = 0; arch < standWidth - 30; arch += 24) {
    const ax = standStartX + 15 + arch;
    ctx.beginPath();
    ctx.arc(ax + 8, standTopY + 7, 8, Math.PI, 0);
    ctx.stroke();
  }

  ctx.fillStyle = standColor;
  ctx.beginPath();
  ctx.moveTo(standStartX - 16, standTopY);
  ctx.quadraticCurveTo(standStartX + standWidth / 2, standTopY - 26, standStartX + standWidth + 16, standTopY);
  ctx.lineTo(standStartX + standWidth, standTopY + 8);
  ctx.quadraticCurveTo(standStartX + standWidth / 2, standTopY - 17, standStartX, standTopY + 8);
  ctx.closePath();
  ctx.fill();

  ctx.strokeStyle = trimColor;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(standStartX - 16, standTopY);
  ctx.quadraticCurveTo(standStartX + standWidth / 2, standTopY - 26, standStartX + standWidth + 16, standTopY);
  ctx.stroke();

  const towerX = standStartX + standWidth * 0.44;
  ctx.fillStyle = standColor;
  ctx.fillRect(towerX - 22, standTopY - 38, 44, 40);
  ctx.fillStyle = trimColor;
  ctx.fillRect(towerX - 22, standTopY - 38, 3, 40);
  ctx.fillRect(towerX + 19, standTopY - 38, 3, 40);

  ctx.fillStyle = '#065f46';
  ctx.beginPath();
  ctx.moveTo(towerX - 25, standTopY - 38);
  ctx.lineTo(towerX, standTopY - 56);
  ctx.lineTo(towerX + 25, standTopY - 38);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = trimColor;
  ctx.lineWidth = 1.8;
  ctx.stroke();

  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(towerX, standTopY - 25, 7, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#0f172a';
  ctx.lineWidth = 1.2;
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(towerX, standTopY - 25);
  ctx.lineTo(towerX + 3.8, standTopY - 24);
  ctx.moveTo(towerX, standTopY - 25);
  ctx.lineTo(towerX, standTopY - 29.5);
  ctx.stroke();

  ctx.strokeStyle = '#334155';
  ctx.lineWidth = 1.8;
  ctx.beginPath();
  ctx.moveTo(towerX, standTopY - 56);
  ctx.lineTo(towerX, standTopY - 74);
  ctx.stroke();

  ctx.fillStyle = '#ef4444';
  ctx.beginPath();
  ctx.moveTo(towerX, standTopY - 74);
  ctx.lineTo(towerX + 15, standTopY - 69);
  ctx.lineTo(towerX, standTopY - 64);
  ctx.closePath();
  ctx.fill();
  ctx.restore();

  // =========================================================================
  // 10. HORIZON FLORA & BOTANICAL MASTERPIECE (Bamboo, Palms, Banyan)
  // =========================================================================
  const treeSpacing = 58;
  const numTrees = Math.floor(width / treeSpacing);

  for (let tx = 0; tx <= numTrees; tx++) {
    const treeX = tx * treeSpacing + ((tx % 4) * 8);
    const treeH = 54 + Math.sin(tx * 0.82) * 16;
    const isPalm = tx % 3 === 0;
    const isBamboo = tx % 5 === 1;

    ctx.save();
    if (isBamboo) {
      const numCanes = 6;
      for (let c = 0; c < numCanes; c++) {
        const cx = treeX - 12 + c * 4.8;
        const ch = treeH - 5 + (c % 3) * 6;
        ctx.strokeStyle = '#84cc16';
        ctx.lineWidth = 2.4;
        ctx.beginPath();
        ctx.moveTo(cx, screenGroundY);
        ctx.lineTo(cx, screenGroundY - ch);
        ctx.stroke();

        ctx.fillStyle = '#3f6212';
        for (let n = screenGroundY - 8; n > screenGroundY - ch; n -= 11) {
          ctx.fillRect(cx - 2, n, 4, 1.6);
        }

        ctx.fillStyle = '#4d7c0f';
        for (let l = 0; l < 5; l++) {
          const ly = screenGroundY - ch + l * 7.5;
          const isRight = l % 2 === 0;
          ctx.beginPath();
          ctx.ellipse(cx + (isRight ? 6 : -6), ly, 7, 2.2, isRight ? 0.35 : -0.35, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    } else if (isPalm) {
      ctx.strokeStyle = '#78350f';
      ctx.lineWidth = 5.2;
      ctx.beginPath();
      ctx.moveTo(treeX, screenGroundY);
      ctx.quadraticCurveTo(treeX + 4.5, screenGroundY - treeH / 2, treeX + 7, screenGroundY - treeH);
      ctx.stroke();

      ctx.fillStyle = '#65a30d';
      ctx.beginPath();
      ctx.arc(treeX + 6, screenGroundY - treeH + 3.5, 3.2, 0, Math.PI * 2);
      ctx.arc(treeX + 9, screenGroundY - treeH + 4, 3.2, 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = '#15803d';
      ctx.lineWidth = 2.6;
      for (let f = 0; f < 6; f++) {
        const fAngle = (f * Math.PI) / 3 - Math.PI / 1.1;
        ctx.beginPath();
        ctx.moveTo(treeX + 7, screenGroundY - treeH);
        ctx.quadraticCurveTo(
          treeX + 7 + Math.cos(fAngle) * 22,
          screenGroundY - treeH - 12,
          treeX + 7 + Math.cos(fAngle) * 35,
          screenGroundY - treeH + Math.sin(fAngle) * 16
        );
        ctx.stroke();
      }
    } else {
      const trunkW = 6.5;
      ctx.fillStyle = '#451a03';
      ctx.fillRect(treeX - trunkW / 2, screenGroundY - treeH, trunkW, treeH);

      ctx.strokeStyle = '#5c2b09';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(treeX - 8, screenGroundY - treeH + 12);
      ctx.lineTo(treeX - 7, screenGroundY);
      ctx.moveTo(treeX + 8, screenGroundY - treeH + 12);
      ctx.lineTo(treeX + 9, screenGroundY);
      ctx.stroke();

      ctx.fillStyle = '#14532d';
      ctx.beginPath();
      ctx.arc(treeX - 12, screenGroundY - treeH + 7, 17, 0, Math.PI * 2);
      ctx.arc(treeX + 12, screenGroundY - treeH + 7, 17, 0, Math.PI * 2);
      ctx.arc(treeX, screenGroundY - treeH - 7, 21, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#16a34a';
      ctx.beginPath();
      ctx.arc(treeX - 10, screenGroundY - treeH + 5, 14, 0, Math.PI * 2);
      ctx.arc(treeX + 10, screenGroundY - treeH + 5, 14, 0, Math.PI * 2);
      ctx.arc(treeX, screenGroundY - treeH - 8, 17, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#4ade80';
      ctx.beginPath();
      ctx.arc(treeX, screenGroundY - treeH - 10, 13, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }

  // =========================================================================
  // 11. BOUNDARY PERIMETER WALL & CRISP WHITE BRAIDED CRICKET ROPE
  // =========================================================================
  ctx.save();
  ctx.fillStyle = '#1e293b';
  ctx.fillRect(0, screenGroundY - 14, width, 14);

  const boardW = 95;
  for (let b = 0; b < width / boardW; b++) {
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.18)';
    ctx.strokeRect(b * boardW, screenGroundY - 14, boardW, 14);
    ctx.fillStyle = b % 3 === 0 ? '#f59e0b' : b % 3 === 1 ? '#38bdf8' : '#ef4444';
    ctx.fillRect(b * boardW + 15, screenGroundY - 8, boardW - 30, 2);
  }

  ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
  ctx.fillRect(0, screenGroundY - 0.5, width, 2.5);

  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = 3.6;
  ctx.beginPath();
  ctx.moveTo(0, screenGroundY - 2.5);
  ctx.lineTo(width, screenGroundY - 2.5);
  ctx.stroke();

  ctx.strokeStyle = '#94a3b8';
  ctx.lineWidth = 1.1;
  for (let r = 0; r < width; r += 14) {
    ctx.beginPath();
    ctx.moveTo(r, screenGroundY - 4.5);
    ctx.lineTo(r + 4, screenGroundY - 0.5);
    ctx.stroke();
  }
  ctx.restore();

  // =========================================================================
  // 12. MASTER-CLASS OUTFIELD TURF WITH PRECISION-MOWED LAWN STRIPES
  // =========================================================================
  const turfHeight = height - screenGroundY;
  const stripeW = 64;
  const stripeCount = Math.ceil(width / stripeW) + 1;

  for (let stIdx = 0; stIdx < stripeCount; stIdx++) {
    const stX = stIdx * stripeW;
    const isAlternate = stIdx % 2 === 0;
    const stripeLight = '#16a34a';
    const stripeDark = '#15803d';

    const stripeGrad = ctx.createLinearGradient(stX, screenGroundY, stX + stripeW, screenGroundY);
    stripeGrad.addColorStop(0, isAlternate ? stripeLight : stripeDark);
    stripeGrad.addColorStop(1, isAlternate ? stripeDark : stripeLight);
    ctx.fillStyle = stripeGrad;
    ctx.fillRect(stX, screenGroundY, stripeW, turfHeight);
  }

  for (let g = 0; g < width; g += 6.5) {
    const gh = 3.5 + (g % 3) * 2;
    ctx.fillStyle = '#4ade80';
    ctx.fillRect(g, screenGroundY - gh, 1.8, gh);

    if (g % 39 === 0) {
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(g + 1, screenGroundY - gh - 1, 1.6, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  const turfOverlay = ctx.createLinearGradient(0, screenGroundY, 0, height);
  turfOverlay.addColorStop(0, 'rgba(0, 0, 0, 0.03)');
  turfOverlay.addColorStop(0.35, 'rgba(0, 0, 0, 0.12)');
  turfOverlay.addColorStop(1, 'rgba(0, 0, 0, 0.44)');
  ctx.fillStyle = turfOverlay;
  ctx.fillRect(0, screenGroundY, width, turfHeight);
}
