// =============================================================================
// THREE ULTRA-REALISTIC PROCEDURAL CANVAS 2D BACKGROUNDS (Zero Image Files)
// 1. Desert Dunes & Oasis (Faceted sandstone canyons, 3D barchan dunes, mirrored oasis)
// 2. Snowy Mountain Peaks (3D Himalayan granite/glacier peaks, frozen alpine lake, snow pines)
// 3. Tropical Ocean Beach (Multi-zone coral reef lagoon, rolling surf barrels, coastal palms)
// =============================================================================

// =============================================================================
// ENVIRONMENT 2: DESERT DUNES & OASIS (Photorealistic Procedural Canvas 2D)
// =============================================================================
export function renderProceduralDesertDunes(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  screenGroundY: number
): void {
  // 1. MULTI-STOP ATMOSPHERIC DESERT GOLDEN-HOUR SKY
  const skyGrad = ctx.createLinearGradient(0, 0, 0, screenGroundY);
  skyGrad.addColorStop(0.0, '#451a03');  // Deep scorched sienna zenith
  skyGrad.addColorStop(0.14, '#7c2d12'); // Rich burnt terracotta
  skyGrad.addColorStop(0.32, '#9a3412'); // Warm canyon crimson-amber
  skyGrad.addColorStop(0.52, '#c2410c'); // Radiant desert orange
  skyGrad.addColorStop(0.72, '#ea580c'); // Luminous saffron glow
  skyGrad.addColorStop(0.86, '#f59e0b'); // Golden desert haze
  skyGrad.addColorStop(0.95, '#fde047'); // Sunlit horizon gold
  skyGrad.addColorStop(1.0, '#fef9c3');  // Blazing horizon mist
  ctx.fillStyle = skyGrad;
  ctx.fillRect(0, 0, width, screenGroundY);

  // 2. BLAZING DESERT SUN, VOLUMETRIC GOD RAYS & HEAT RADIANCE
  const sunX = width * 0.76;
  const sunY = Math.min(122, screenGroundY * 0.22);

  // Wide atmospheric solar scattering wash
  const heatWash = ctx.createRadialGradient(sunX, sunY, 20, sunX, sunY, width * 0.7);
  heatWash.addColorStop(0, 'rgba(254, 249, 195, 0.48)');
  heatWash.addColorStop(0.25, 'rgba(253, 224, 71, 0.24)');
  heatWash.addColorStop(0.55, 'rgba(245, 158, 11, 0.10)');
  heatWash.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = heatWash;
  ctx.fillRect(0, 0, width, screenGroundY);

  // Volumetric Crepuscular Desert Sunbeams
  ctx.save();
  ctx.translate(sunX, sunY);
  const rayCount = 14;
  for (let r = 0; r < rayCount; r++) {
    const angle = (r * Math.PI) / (rayCount / 2) + 0.08;
    const len = width * 0.55 + (r % 3) * 60;
    const spread = 0.055 + (r % 2) * 0.025;
    const rayGrad = ctx.createRadialGradient(0, 0, 18, 0, 0, len);
    rayGrad.addColorStop(0, 'rgba(254, 249, 195, 0.24)');
    rayGrad.addColorStop(0.4, 'rgba(251, 191, 36, 0.09)');
    rayGrad.addColorStop(1, 'rgba(251, 191, 36, 0)');
    ctx.fillStyle = rayGrad;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.arc(0, 0, len, angle - spread, angle + spread);
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();

  // High-Altitude Wispy Desert Cirrus Clouds Burnished by Sunset
  ctx.save();
  const cirrusBands = [
    { x: width * 0.12, y: screenGroundY * 0.11, w: 180, h: 8 },
    { x: width * 0.36, y: screenGroundY * 0.08, w: 220, h: 10 },
    { x: width * 0.58, y: screenGroundY * 0.14, w: 160, h: 7 },
    { x: width * 0.85, y: screenGroundY * 0.10, w: 150, h: 7 },
  ];
  cirrusBands.forEach((cb) => {
    const cGrad = ctx.createLinearGradient(cb.x - cb.w / 2, cb.y, cb.x + cb.w / 2, cb.y);
    cGrad.addColorStop(0, 'rgba(254, 215, 170, 0)');
    cGrad.addColorStop(0.5, 'rgba(254, 240, 138, 0.35)');
    cGrad.addColorStop(1, 'rgba(254, 215, 170, 0)');
    ctx.fillStyle = cGrad;
    ctx.beginPath();
    ctx.ellipse(cb.x, cb.y, cb.w / 2, cb.h, -0.04, 0, Math.PI * 2);
    ctx.fill();
  });
  ctx.restore();

  // Sun Outer Corona & Blazing Core
  const sunCorona = ctx.createRadialGradient(sunX, sunY, 12, sunX, sunY, 145);
  sunCorona.addColorStop(0, '#ffffff');
  sunCorona.addColorStop(0.18, '#fef08a');
  sunCorona.addColorStop(0.48, 'rgba(251, 191, 36, 0.45)');
  sunCorona.addColorStop(1, 'rgba(245, 158, 11, 0)');
  ctx.fillStyle = sunCorona;
  ctx.beginPath();
  ctx.arc(sunX, sunY, 145, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(sunX, sunY, 28, 0, Math.PI * 2);
  ctx.fill();

  // 3. DISTANT 3D FACETED SANDSTONE MESAS & MONUMENT VALLEY CANYONS
  const drawFacetedMesa = (
    baseX: number,
    baseY: number,
    mesaW: number,
    mesaH: number,
    topFlatRatio: number
  ) => {
    const leftBase = baseX - mesaW * 0.5;
    const rightBase = baseX + mesaW * 0.5;
    const topY = baseY - mesaH;
    const topLeft = baseX - mesaW * topFlatRatio * 0.5;
    const topRight = baseX + mesaW * topFlatRatio * 0.5;
    const ridgeSplit = baseX + mesaW * 0.08;

    // Left Shadowed Cliff Face (Facing away from sun)
    const shadowGrad = ctx.createLinearGradient(leftBase, topY, ridgeSplit, baseY);
    shadowGrad.addColorStop(0, '#7c2d12');
    shadowGrad.addColorStop(0.55, '#5c1f0b');
    shadowGrad.addColorStop(1, '#3b1105');
    ctx.fillStyle = shadowGrad;
    ctx.beginPath();
    ctx.moveTo(leftBase, baseY);
    ctx.lineTo(topLeft - mesaW * 0.06, topY + mesaH * 0.35);
    ctx.lineTo(topLeft, topY);
    ctx.lineTo(ridgeSplit, topY);
    ctx.lineTo(ridgeSplit + mesaW * 0.04, baseY);
    ctx.closePath();
    ctx.fill();

    // Right Sunlit Sandstone Face (Facing toward sun)
    const litGrad = ctx.createLinearGradient(ridgeSplit, topY, rightBase, baseY);
    litGrad.addColorStop(0, '#f97316');
    litGrad.addColorStop(0.45, '#c2410c');
    litGrad.addColorStop(1, '#7c2d12');
    ctx.fillStyle = litGrad;
    ctx.beginPath();
    ctx.moveTo(ridgeSplit, topY);
    ctx.lineTo(topRight, topY);
    ctx.lineTo(topRight + mesaW * 0.07, topY + mesaH * 0.32);
    ctx.lineTo(rightBase, baseY);
    ctx.lineTo(ridgeSplit + mesaW * 0.04, baseY);
    ctx.closePath();
    ctx.fill();

    // Horizontal Sedimentary Strata Striations
    ctx.save();
    ctx.strokeStyle = 'rgba(254, 215, 170, 0.26)';
    ctx.lineWidth = 1.2;
    for (let s = 0.18; s < 0.88; s += 0.14) {
      const sy = topY + mesaH * s;
      const halfSpan = (mesaW * topFlatRatio * 0.5) + (mesaW * (1 - topFlatRatio) * 0.5 * s);
      ctx.beginPath();
      ctx.moveTo(baseX - halfSpan * 0.92, sy);
      ctx.lineTo(baseX + halfSpan * 0.92, sy);
      ctx.stroke();
    }

    // Vertical Canyon Erosional Fluting Cracks
    ctx.strokeStyle = 'rgba(40, 10, 3, 0.45)';
    ctx.lineWidth = 1.3;
    for (let v = -2; v <= 2; v++) {
      const vx = baseX + v * (mesaW * topFlatRatio * 0.18);
      ctx.beginPath();
      ctx.moveTo(vx, topY + 2);
      ctx.lineTo(vx + v * 4, baseY - mesaH * 0.25);
      ctx.stroke();
    }
    ctx.restore();
  };

  // Render Distant Canyon Range
  drawFacetedMesa(width * 0.13, screenGroundY * 0.70, width * 0.24, screenGroundY * 0.19, 0.52);
  drawFacetedMesa(width * 0.34, screenGroundY * 0.71, width * 0.14, screenGroundY * 0.22, 0.38);
  drawFacetedMesa(width * 0.52, screenGroundY * 0.70, width * 0.19, screenGroundY * 0.17, 0.48);
  drawFacetedMesa(width * 0.82, screenGroundY * 0.71, width * 0.28, screenGroundY * 0.21, 0.58);

  // Atmospheric Golden Dust Veil at Mesa Base
  const dustHaze = ctx.createLinearGradient(0, screenGroundY * 0.54, 0, screenGroundY * 0.74);
  dustHaze.addColorStop(0, 'rgba(254, 243, 199, 0)');
  dustHaze.addColorStop(0.65, 'rgba(253, 224, 71, 0.28)');
  dustHaze.addColorStop(1, 'rgba(254, 243, 199, 0.52)');
  ctx.fillStyle = dustHaze;
  ctx.fillRect(0, screenGroundY * 0.54, width, screenGroundY * 0.20);

  // 4. MULTI-LAYER 3D WIND-SCULPTED BARCHAN SAND DUNES
  // Far Dune Tier
  const farDuneGrad = ctx.createLinearGradient(0, screenGroundY * 0.65, 0, screenGroundY * 0.85);
  farDuneGrad.addColorStop(0, '#d97706');
  farDuneGrad.addColorStop(1, '#9a3412');
  ctx.fillStyle = farDuneGrad;
  ctx.beginPath();
  ctx.moveTo(0, screenGroundY * 0.73);
  ctx.quadraticCurveTo(width * 0.22, screenGroundY * 0.63, width * 0.48, screenGroundY * 0.71);
  ctx.quadraticCurveTo(width * 0.74, screenGroundY * 0.79, width, screenGroundY * 0.67);
  ctx.lineTo(width, screenGroundY);
  ctx.lineTo(0, screenGroundY);
  ctx.closePath();
  ctx.fill();

  // Midground Sweeping S-Curve Dune — Deep Slip-Face Shadow Side
  const duneShadowGrad = ctx.createLinearGradient(0, screenGroundY * 0.68, width * 0.55, screenGroundY);
  duneShadowGrad.addColorStop(0, '#9a3412');
  duneShadowGrad.addColorStop(0.5, '#7c2d12');
  duneShadowGrad.addColorStop(1, '#b45309');
  ctx.fillStyle = duneShadowGrad;
  ctx.beginPath();
  ctx.moveTo(0, screenGroundY * 0.83);
  ctx.bezierCurveTo(width * 0.18, screenGroundY * 0.68, width * 0.40, screenGroundY * 0.81, width * 0.64, screenGroundY * 0.73);
  ctx.bezierCurveTo(width * 0.80, screenGroundY * 0.67, width * 0.92, screenGroundY * 0.75, width, screenGroundY * 0.77);
  ctx.lineTo(width, screenGroundY);
  ctx.lineTo(0, screenGroundY);
  ctx.closePath();
  ctx.fill();

  // Midground Dune — Radiant Sunlit Windward Slope
  const duneSunGrad = ctx.createLinearGradient(width * 0.55, screenGroundY * 0.68, width, screenGroundY);
  duneSunGrad.addColorStop(0, '#fef08a');
  duneSunGrad.addColorStop(0.32, '#fbbf24');
  duneSunGrad.addColorStop(0.68, '#f59e0b');
  duneSunGrad.addColorStop(1, '#d97706');
  ctx.fillStyle = duneSunGrad;
  ctx.beginPath();
  ctx.moveTo(width * 0.30, screenGroundY * 0.84);
  ctx.bezierCurveTo(width * 0.45, screenGroundY * 0.75, width * 0.56, screenGroundY * 0.71, width * 0.64, screenGroundY * 0.73);
  ctx.bezierCurveTo(width * 0.80, screenGroundY * 0.67, width * 0.92, screenGroundY * 0.75, width, screenGroundY * 0.77);
  ctx.lineTo(width, screenGroundY);
  ctx.lineTo(width * 0.38, screenGroundY);
  ctx.closePath();
  ctx.fill();

  // Razor-Sharp Sunlit Dune Crest Rim Highlight
  ctx.strokeStyle = '#fef9c3';
  ctx.lineWidth = 2.4;
  ctx.beginPath();
  ctx.moveTo(0, screenGroundY * 0.83);
  ctx.bezierCurveTo(width * 0.18, screenGroundY * 0.68, width * 0.40, screenGroundY * 0.81, width * 0.64, screenGroundY * 0.73);
  ctx.bezierCurveTo(width * 0.80, screenGroundY * 0.67, width * 0.92, screenGroundY * 0.75, width, screenGroundY * 0.77);
  ctx.stroke();

  // Fine Wind-Carved Ripple Micro-Texture across Dune Slopes
  ctx.strokeStyle = 'rgba(120, 53, 15, 0.32)';
  ctx.lineWidth = 1.1;
  for (let r = 0; r < 22; r++) {
    const rx = width * (0.03 + r * 0.044);
    const ry = screenGroundY * (0.76 + (r % 5) * 0.032);
    ctx.beginPath();
    ctx.moveTo(rx, ry);
    ctx.quadraticCurveTo(rx + 22, ry - 2.5, rx + 44, ry + 1.5);
    ctx.stroke();
  }

  // 5. CRYSTAL DESERT OASIS LAGOON WITH MIRRORED REFLECTIONS & DATE PALMS
  const oasisX = width * 0.20;
  const oasisY = screenGroundY * 0.91;

  // Wet Damp Sand Bank Ring Around Oasis
  ctx.fillStyle = '#92400e';
  ctx.beginPath();
  ctx.ellipse(oasisX, oasisY, 114, 18, -0.03, 0, Math.PI * 2);
  ctx.fill();

  // Multi-Zone Turquoise Oasis Lagoon
  const oasisGrad = ctx.createRadialGradient(oasisX, oasisY - 2, 8, oasisX, oasisY, 105);
  oasisGrad.addColorStop(0, '#67e8f9');
  oasisGrad.addColorStop(0.35, '#06b6d4');
  oasisGrad.addColorStop(0.75, '#0284c7');
  oasisGrad.addColorStop(1, '#0c4a6e');
  ctx.fillStyle = oasisGrad;
  ctx.beginPath();
  ctx.ellipse(oasisX, oasisY, 106, 15.5, -0.03, 0, Math.PI * 2);
  ctx.fill();

  // Submerged Golden Sandbar & Sky Reflection inside Oasis Water
  ctx.fillStyle = 'rgba(254, 240, 138, 0.28)';
  ctx.beginPath();
  ctx.ellipse(oasisX + 18, oasisY - 2, 52, 6, -0.03, 0, Math.PI * 2);
  ctx.fill();

  // Oasis Specular Water Ripples
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.72)';
  ctx.lineWidth = 1.3;
  [-45, -12, 22, 54].forEach((ox, idx) => {
    ctx.beginPath();
    ctx.moveTo(oasisX + ox, oasisY - 3 + (idx % 2) * 4);
    ctx.lineTo(oasisX + ox + 24, oasisY - 3 + (idx % 2) * 4);
    ctx.stroke();
  });

  // Helper for Detailed Realistic Date Palm Tree
  const drawDatePalm = (px: number, py: number, treeHeight: number, leanAngle: number) => {
    // Subtle Ground Cast Shadow
    ctx.save();
    ctx.fillStyle = 'rgba(69, 26, 3, 0.32)';
    ctx.beginPath();
    ctx.ellipse(px - 18, py + 2, 26, 4.5, -0.1, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    ctx.save();
    ctx.translate(px, py);
    ctx.rotate(leanAngle);

    // Sculpted Diamond-Barked Trunk with 3D Cylindrical Shading
    const segments = 15;
    const segH = treeHeight / segments;
    for (let s = 0; s < segments; s++) {
      const sy = -s * segH;
      const trunkW = 8.5 - (s / segments) * 3.4;
      const tGrad = ctx.createLinearGradient(-trunkW / 2, 0, trunkW / 2, 0);
      tGrad.addColorStop(0, '#451a03');
      tGrad.addColorStop(0.55, s % 2 === 0 ? '#78350f' : '#92400e');
      tGrad.addColorStop(1, '#d97706');
      ctx.fillStyle = tGrad;
      ctx.beginPath();
      ctx.moveTo(-trunkW * 0.55, sy);
      ctx.lineTo(-trunkW * 0.42, sy - segH);
      ctx.lineTo(trunkW * 0.42, sy - segH);
      ctx.lineTo(trunkW * 0.55, sy);
      ctx.closePath();
      ctx.fill();
    }

    // Lush Multi-Layered Feather Frond Crown
    ctx.translate(0, -treeHeight);

    // Ripening Golden-Amber Date Clusters
    ctx.fillStyle = '#d97706';
    [-5, 5].forEach((dx) => {
      for (let d = 0; d < 5; d++) {
        ctx.beginPath();
        ctx.arc(dx + (d % 2) * 2 - 1, 3 + d * 2.2, 2.2, 0, Math.PI * 2);
        ctx.fill();
      }
    });

    const frondAngles = [-2.55, -2.05, -1.5, -0.95, -0.4, 0.0, 0.45, 1.0, 1.55, 2.1, 2.6];
    frondAngles.forEach((fa, fIdx) => {
      ctx.save();
      ctx.rotate(fa);
      const frondLen = 36 + (fIdx % 3) * 7;
      const isUpper = fIdx >= 3 && fIdx <= 7;

      // Central Rachis Stem
      ctx.strokeStyle = isUpper ? '#65a30d' : '#15803d';
      ctx.lineWidth = 2.4;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.quadraticCurveTo(frondLen * 0.48, -13, frondLen, 7);
      ctx.stroke();

      // Individual Pinnae Leaflets (Both sides of stem)
      ctx.strokeStyle = isUpper ? '#84cc16' : '#166534';
      ctx.lineWidth = 1.15;
      for (let l = 5; l < frondLen - 3; l += 3.8) {
        const stemY = -Math.sin((l / frondLen) * Math.PI) * 6.5 + (l / frondLen) * 7;
        ctx.beginPath();
        ctx.moveTo(l, stemY);
        ctx.lineTo(l + 3.5, stemY + 8.5);
        ctx.moveTo(l, stemY);
        ctx.lineTo(l + 2.5, stemY - 5.5);
        ctx.stroke();
      }
      ctx.restore();
    });

    ctx.restore();
  };

  drawDatePalm(oasisX - 72, oasisY + 7, 94, -0.14);
  drawDatePalm(oasisX - 42, oasisY + 11, 116, -0.05);
  drawDatePalm(oasisX + 68, oasisY + 9, 102, 0.14);
  drawDatePalm(oasisX + 96, oasisY + 13, 82, 0.24);

  // Oasis Reed Clumps & Desert Agave Scrub
  for (let b = 0; b < 9; b++) {
    const bx = oasisX - 88 + b * 22;
    const by = oasisY + 8 + (b % 3) * 3;
    ctx.fillStyle = b % 2 === 0 ? '#15803d' : '#3f6212';
    ctx.beginPath();
    ctx.arc(bx, by, 6 + (b % 4), Math.PI, 0);
    ctx.fill();
  }

  // 6. FOREGROUND DESERT STADIUM SAND & ROLLED TURF OUTFIELD
  const turfHeight = height - screenGroundY;
  const stripeW = 68;
  const stripeCount = Math.ceil(width / stripeW) + 1;

  for (let st = 0; st < stripeCount; st++) {
    const sx = st * stripeW;
    const isAlt = st % 2 === 0;
    const gGrad = ctx.createLinearGradient(0, screenGroundY, 0, height);
    gGrad.addColorStop(0, isAlt ? '#f59e0b' : '#eab308');
    gGrad.addColorStop(0.35, isAlt ? '#d97706' : '#ca8a04');
    gGrad.addColorStop(0.75, '#b45309');
    gGrad.addColorStop(1, '#78350f');
    ctx.fillStyle = gGrad;
    ctx.fillRect(sx, screenGroundY, stripeW + 1, turfHeight);
  }

  // Sculpted Wind Ripples & Sandstone Pebbles on Outfield
  ctx.strokeStyle = 'rgba(120, 53, 15, 0.34)';
  ctx.lineWidth = 1.4;
  for (let sw = 0; sw < width; sw += 32) {
    const sy = screenGroundY + 6 + (sw % 5) * 4.5;
    ctx.beginPath();
    ctx.moveTo(sw, sy);
    ctx.quadraticCurveTo(sw + 15, sy - 2.2, sw + 30, sy + 1.5);
    ctx.stroke();
  }

  for (let p = 0; p < width; p += 38) {
    const px = p + (p % 7) * 4;
    const py = screenGroundY + 11 + (p % 5) * 6;
    ctx.fillStyle = p % 2 === 0 ? '#78350f' : '#92400e';
    ctx.beginPath();
    ctx.ellipse(px, py, 3.8, 2.1, 0.12, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = 'rgba(254, 240, 138, 0.45)';
    ctx.fillRect(px - 1.5, py - 1.2, 2, 0.9);
  }

  // Outfield Depth Vignette
  const turfOverlay = ctx.createLinearGradient(0, screenGroundY, 0, height);
  turfOverlay.addColorStop(0, 'rgba(0, 0, 0, 0.02)');
  turfOverlay.addColorStop(0.35, 'rgba(0, 0, 0, 0.14)');
  turfOverlay.addColorStop(1, 'rgba(0, 0, 0, 0.48)');
  ctx.fillStyle = turfOverlay;
  ctx.fillRect(0, screenGroundY, width, turfHeight);
}

// =============================================================================
// ENVIRONMENT 3: SNOWY MOUNTAIN PEAKS & ALPINE LAKE (Photorealistic Canvas 2D)
// =============================================================================
export function renderProceduralSnowyPeaks(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  screenGroundY: number
): void {
  // 1. HIGH-ALTITUDE HIMALAYAN SKY DOME WITH SUBTLE ALPENGLOW
  const skyGrad = ctx.createLinearGradient(0, 0, 0, screenGroundY);
  skyGrad.addColorStop(0.0, '#091124');  // Stratospheric midnight indigo
  skyGrad.addColorStop(0.18, '#172554'); // Deep alpine sapphire
  skyGrad.addColorStop(0.38, '#0369a1'); // Crisp cerulean blue
  skyGrad.addColorStop(0.62, '#0ea5e9'); // Glacial sky cyan
  skyGrad.addColorStop(0.82, '#7dd3fc'); // Crystalline horizon frost
  skyGrad.addColorStop(0.94, '#e0f2fe'); // Ice mist diffusion
  skyGrad.addColorStop(1.0, '#f8fafc');  // Snow glare horizon
  ctx.fillStyle = skyGrad;
  ctx.fillRect(0, 0, width, screenGroundY);

  // Subtle Upper-Atmosphere Aurora / Ice-Ribbon Shimmer
  ctx.save();
  const auroraGrad = ctx.createLinearGradient(width * 0.15, screenGroundY * 0.05, width * 0.85, screenGroundY * 0.22);
  auroraGrad.addColorStop(0, 'rgba(56, 189, 248, 0)');
  auroraGrad.addColorStop(0.35, 'rgba(45, 212, 191, 0.12)');
  auroraGrad.addColorStop(0.65, 'rgba(125, 211, 252, 0.14)');
  auroraGrad.addColorStop(1, 'rgba(56, 189, 248, 0)');
  ctx.fillStyle = auroraGrad;
  ctx.beginPath();
  ctx.moveTo(width * 0.1, screenGroundY * 0.14);
  ctx.bezierCurveTo(width * 0.35, screenGroundY * 0.03, width * 0.62, screenGroundY * 0.22, width * 0.9, screenGroundY * 0.09);
  ctx.lineTo(width * 0.9, screenGroundY * 0.18);
  ctx.bezierCurveTo(width * 0.62, screenGroundY * 0.30, width * 0.35, screenGroundY * 0.11, width * 0.1, screenGroundY * 0.22);
  ctx.closePath();
  ctx.fill();
  ctx.restore();

  // 2. WINTER SUN, ICE HALO & VOLUMETRIC FROST RAYS
  const sunX = width * 0.74;
  const sunY = Math.min(114, screenGroundY * 0.20);

  // Parhelion (22-degree Ice Halo Ring around Winter Sun)
  const haloGrad = ctx.createRadialGradient(sunX, sunY, 55, sunX, sunY, 155);
  haloGrad.addColorStop(0, 'rgba(255, 255, 255, 0.28)');
  haloGrad.addColorStop(0.45, 'rgba(186, 230, 253, 0.12)');
  haloGrad.addColorStop(0.75, 'rgba(255, 255, 255, 0.16)');
  haloGrad.addColorStop(1, 'rgba(255, 255, 255, 0)');
  ctx.fillStyle = haloGrad;
  ctx.beginPath();
  ctx.arc(sunX, sunY, 155, 0, Math.PI * 2);
  ctx.fill();

  // Volumetric Slanting Winter Sunbeams
  ctx.save();
  ctx.translate(sunX, sunY);
  for (let r = 0; r < 10; r++) {
    const ang = (r * Math.PI) / 5 + 0.15;
    const len = 340 + (r % 2) * 70;
    const rGrad = ctx.createRadialGradient(0, 0, 15, 0, 0, len);
    rGrad.addColorStop(0, 'rgba(255, 255, 255, 0.26)');
    rGrad.addColorStop(0.5, 'rgba(186, 230, 253, 0.08)');
    rGrad.addColorStop(1, 'rgba(186, 230, 253, 0)');
    ctx.fillStyle = rGrad;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.arc(0, 0, len, ang - 0.05, ang + 0.05);
    ctx.closePath();
    ctx.fill();
  }

  // 8-Point Crystalline Starburst
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.75)';
  ctx.lineWidth = 1.6;
  for (let s = 0; s < 4; s++) {
    const sAngle = (s * Math.PI) / 4;
    const spikeLen = s % 2 === 0 ? 64 : 38;
    ctx.beginPath();
    ctx.moveTo(-Math.cos(sAngle) * spikeLen, -Math.sin(sAngle) * spikeLen);
    ctx.lineTo(Math.cos(sAngle) * spikeLen, Math.sin(sAngle) * spikeLen);
    ctx.stroke();
  }
  ctx.restore();

  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(sunX, sunY, 24, 0, Math.PI * 2);
  ctx.fill();

  // 3. TOWERING 3D FACETED HIMALAYAN MASSIFS WITH ROCK STRATA & GLACIERS
  const drawAlpineMassif = (peakX: number, baseW: number, peakHeight: number, hasSpindrift: boolean) => {
    const peakY = screenGroundY * (0.68 - peakHeight);
    const leftX = peakX - baseW * 0.56;
    const rightX = peakX + baseW * 0.48;
    const baseY = screenGroundY * 0.77;
    const ridgeMidX = peakX + baseW * 0.03;

    // Wind-blown Spindrift Snow Plume off Summit Crest
    if (hasSpindrift) {
      const plumeGrad = ctx.createLinearGradient(peakX, peakY, peakX + 85, peakY - 12);
      plumeGrad.addColorStop(0, 'rgba(255, 255, 255, 0.65)');
      plumeGrad.addColorStop(0.5, 'rgba(224, 242, 254, 0.25)');
      plumeGrad.addColorStop(1, 'rgba(255, 255, 255, 0)');
      ctx.fillStyle = plumeGrad;
      ctx.beginPath();
      ctx.moveTo(peakX, peakY);
      ctx.quadraticCurveTo(peakX + 45, peakY - 14, peakX + 90, peakY + 4);
      ctx.quadraticCurveTo(peakX + 40, peakY + 8, peakX, peakY + 12);
      ctx.closePath();
      ctx.fill();
    }

    // Left Shadowed Granite & Blue-Ice Face
    const shadowGrad = ctx.createLinearGradient(leftX, baseY, peakX, peakY);
    shadowGrad.addColorStop(0, '#0f172a');
    shadowGrad.addColorStop(0.45, '#1e293b');
    shadowGrad.addColorStop(0.8, '#334155');
    shadowGrad.addColorStop(1, '#475569');
    ctx.fillStyle = shadowGrad;
    ctx.beginPath();
    ctx.moveTo(peakX, peakY);
    ctx.lineTo(peakX - baseW * 0.22, peakY + (baseY - peakY) * 0.32);
    ctx.lineTo(leftX, baseY);
    ctx.lineTo(ridgeMidX, baseY);
    ctx.closePath();
    ctx.fill();

    // Right Sunlit Snowfield & Glacier Face
    const snowGrad = ctx.createLinearGradient(peakX, peakY, rightX, baseY);
    snowGrad.addColorStop(0, '#ffffff');
    snowGrad.addColorStop(0.35, '#f8fafc');
    snowGrad.addColorStop(0.72, '#bae6fd');
    snowGrad.addColorStop(1, '#7dd3fc');
    ctx.fillStyle = snowGrad;
    ctx.beginPath();
    ctx.moveTo(peakX, peakY);
    ctx.lineTo(ridgeMidX, baseY);
    ctx.lineTo(rightX, baseY);
    ctx.lineTo(peakX + baseW * 0.24, peakY + (baseY - peakY) * 0.38);
    ctx.closePath();
    ctx.fill();

    // Exposed Dark Granite Crags on Steep Upper Faces
    ctx.fillStyle = '#334155';
    for (let cr = 0; cr < 4; cr++) {
      const cy = peakY + 26 + cr * 28;
      const cx = peakX + 10 + cr * 16;
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.lineTo(cx + 18, cy + 14);
      ctx.lineTo(cx - 6, cy + 18);
      ctx.closePath();
      ctx.fill();
    }

    // Secondary Shadowed Sub-Ridge Spine
    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 2.2;
    ctx.beginPath();
    ctx.moveTo(peakX, peakY);
    ctx.lineTo(peakX - baseW * 0.06, peakY + (baseY - peakY) * 0.45);
    ctx.lineTo(ridgeMidX, baseY);
    ctx.stroke();

    // Deep Turquoise Glacial Crevasses
    ctx.strokeStyle = '#0284c7';
    ctx.lineWidth = 1.4;
    for (let g = 1; g <= 3; g++) {
      const gy = peakY + (baseY - peakY) * (0.28 + g * 0.16);
      const gx = peakX + baseW * (0.06 + g * 0.05);
      ctx.beginPath();
      ctx.moveTo(gx, gy);
      ctx.lineTo(gx + 18, gy + 8);
      ctx.lineTo(gx + 32, gy + 4);
      ctx.stroke();
    }
  };

  drawAlpineMassif(width * 0.11, width * 0.34, 0.39, false);
  drawAlpineMassif(width * 0.33, width * 0.42, 0.50, true);
  drawAlpineMassif(width * 0.54, width * 0.36, 0.43, false);
  drawAlpineMassif(width * 0.76, width * 0.40, 0.47, true);
  drawAlpineMassif(width * 0.94, width * 0.30, 0.37, false);

  // Valley Cloud Inversion Mist Blanket
  const valleyMist = ctx.createLinearGradient(0, screenGroundY * 0.56, 0, screenGroundY * 0.79);
  valleyMist.addColorStop(0, 'rgba(241, 245, 249, 0)');
  valleyMist.addColorStop(0.55, 'rgba(224, 242, 254, 0.45)');
  valleyMist.addColorStop(1, 'rgba(248, 250, 252, 0.78)');
  ctx.fillStyle = valleyMist;
  ctx.fillRect(0, screenGroundY * 0.56, width, screenGroundY * 0.23);

  // 4. MIDGROUND SNOW SLOPES & FROZEN ALPINE GLACIAL LAKE
  const midSlopeGrad = ctx.createLinearGradient(0, screenGroundY * 0.64, 0, screenGroundY * 0.92);
  midSlopeGrad.addColorStop(0, '#f8fafc');
  midSlopeGrad.addColorStop(0.4, '#e2e8f0');
  midSlopeGrad.addColorStop(0.75, '#cbd5e1');
  midSlopeGrad.addColorStop(1, '#94a3b8');
  ctx.fillStyle = midSlopeGrad;
  ctx.beginPath();
  ctx.moveTo(0, screenGroundY * 0.73);
  ctx.quadraticCurveTo(width * 0.26, screenGroundY * 0.64, width * 0.55, screenGroundY * 0.75);
  ctx.quadraticCurveTo(width * 0.80, screenGroundY * 0.67, width, screenGroundY * 0.73);
  ctx.lineTo(width, screenGroundY);
  ctx.lineTo(0, screenGroundY);
  ctx.closePath();
  ctx.fill();

  // Crystalline Frozen Glacial Lake in Midground Valley
  const lakeX = width * 0.46;
  const lakeY = screenGroundY * 0.91;
  const lakeGrad = ctx.createLinearGradient(lakeX - 180, lakeY - 14, lakeX + 180, lakeY + 14);
  lakeGrad.addColorStop(0, '#0369a1');
  lakeGrad.addColorStop(0.35, '#38bdf8');
  lakeGrad.addColorStop(0.65, '#bae6fd');
  lakeGrad.addColorStop(1, '#0284c7');
  ctx.fillStyle = lakeGrad;
  ctx.beginPath();
  ctx.ellipse(lakeX, lakeY, width * 0.22, 13, 0, 0, Math.PI * 2);
  ctx.fill();

  // Ice Crack Striations on Frozen Lake
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.78)';
  ctx.lineWidth = 1.1;
  ctx.beginPath();
  ctx.moveTo(lakeX - 90, lakeY - 2);
  ctx.lineTo(lakeX - 20, lakeY + 4);
  ctx.lineTo(lakeX + 65, lakeY - 3);
  ctx.moveTo(lakeX - 20, lakeY + 4);
  ctx.lineTo(lakeX + 25, lakeY + 8);
  ctx.stroke();

  // 5. DENSE SNOW-LADEN ALPINE SPRUCE & FIR FOREST
  const drawSnowPineTree = (tx: number, ty: number, treeH: number) => {
    ctx.save();
    ctx.translate(tx, ty);

    // Timber Trunk
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(-2.8, -treeH * 0.2, 5.6, treeH * 0.2);

    // 5 Layered Conical Boughs with Pillowed Snow Mantles
    const tiers = 5;
    for (let t = 0; t < tiers; t++) {
      const tierY = -treeH * (0.18 + (t / tiers) * 0.78);
      const tierW = (treeH * 0.44) * (1 - (t / tiers) * 0.58);
      const tierH = treeH * 0.27;

      // Deep Pine Needle Shadow Foliage
      ctx.fillStyle = t % 2 === 0 ? '#064e3b' : '#0f5132';
      ctx.beginPath();
      ctx.moveTo(0, tierY - tierH);
      ctx.lineTo(-tierW, tierY);
      ctx.lineTo(tierW, tierY);
      ctx.closePath();
      ctx.fill();

      // Pillowed Snow Mantle with Soft Blue Shadow Underside
      ctx.fillStyle = '#cbd5e1';
      ctx.beginPath();
      ctx.moveTo(-tierW, tierY);
      ctx.quadraticCurveTo(0, tierY - tierH * 0.45, tierW, tierY);
      ctx.quadraticCurveTo(0, tierY + 4, -tierW, tierY);
      ctx.fill();

      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.moveTo(-tierW * 0.92, tierY - 1);
      ctx.quadraticCurveTo(0, tierY - tierH * 0.52, tierW * 0.92, tierY - 1);
      ctx.quadraticCurveTo(0, tierY + 1.5, -tierW * 0.92, tierY - 1);
      ctx.fill();
    }
    ctx.restore();
  };

  for (let px = -15; px < width + 35; px += 32) {
    // Leave scenic gap around center lake
    if (Math.abs(px - lakeX) < width * 0.14) continue;
    const pVar = Math.abs(Math.sin(px * 0.05)) * 20;
    const pineH = 52 + pVar;
    const pineY = screenGroundY * 0.89 + ((px % 5) * 3.5);
    drawSnowPineTree(px, pineY, pineH);
  }

  // Hero Foreground Framing Pines
  drawSnowPineTree(width * 0.05, screenGroundY * 0.95, 96);
  drawSnowPineTree(width * 0.13, screenGroundY * 0.97, 80);
  drawSnowPineTree(width * 0.87, screenGroundY * 0.96, 88);
  drawSnowPineTree(width * 0.95, screenGroundY * 0.94, 106);

  // 6. FOREGROUND SNOW-DUSTED STADIUM OUTFIELD
  const turfHeight = height - screenGroundY;
  const stripeW = 64;
  const stripeCount = Math.ceil(width / stripeW) + 1;

  for (let st = 0; st < stripeCount; st++) {
    const sx = st * stripeW;
    const isAlt = st % 2 === 0;
    const sGrad = ctx.createLinearGradient(0, screenGroundY, 0, height);
    sGrad.addColorStop(0, isAlt ? '#f8fafc' : '#f1f5f9');
    sGrad.addColorStop(0.28, isAlt ? '#e2e8f0' : '#cbd5e1');
    sGrad.addColorStop(0.65, '#94a3b8');
    sGrad.addColorStop(1, '#475569');
    ctx.fillStyle = sGrad;
    ctx.fillRect(sx, screenGroundY, stripeW + 1, turfHeight);
  }

  // Sculpted Wind-Drifted Snow Contours
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.92)';
  ctx.lineWidth = 1.8;
  for (let d = 0; d < width; d += 36) {
    const dy = screenGroundY + 5 + (d % 4) * 4;
    ctx.beginPath();
    ctx.moveTo(d, dy);
    ctx.quadraticCurveTo(d + 18, dy - 2.5, d + 34, dy + 1);
    ctx.stroke();
  }

  // Diamond Frost Sparkles on Snowpack
  for (let s = 0; s < width; s += 22) {
    const sx = s + (s % 7) * 3;
    const sy = screenGroundY + 8 + (s % 6) * 5;
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(sx, sy, 1.5, 0, Math.PI * 2);
    ctx.fill();
  }

  const turfOverlay = ctx.createLinearGradient(0, screenGroundY, 0, height);
  turfOverlay.addColorStop(0, 'rgba(15, 23, 42, 0.02)');
  turfOverlay.addColorStop(0.35, 'rgba(15, 23, 42, 0.12)');
  turfOverlay.addColorStop(1, 'rgba(15, 23, 42, 0.44)');
  ctx.fillStyle = turfOverlay;
  ctx.fillRect(0, screenGroundY, width, turfHeight);
}

// =============================================================================
// ENVIRONMENT 4: TROPICAL OCEAN BEACH & CORAL LAGOON (Photorealistic Canvas 2D)
// =============================================================================
export function renderProceduralOceanBeach(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  screenGroundY: number
): void {
  // 1. TROPICAL CARIBBEAN SKY DOME
  const skyGrad = ctx.createLinearGradient(0, 0, 0, screenGroundY);
  skyGrad.addColorStop(0.0, '#0c4a6e');  // Deep tropical zenith
  skyGrad.addColorStop(0.22, '#0284c7'); // Rich ocean azure
  skyGrad.addColorStop(0.48, '#38bdf8'); // Radiant sky cerulean
  skyGrad.addColorStop(0.74, '#7dd3fc'); // Luminous turquoise mist
  skyGrad.addColorStop(0.90, '#bae6fd'); // Warm horizon glow
  skyGrad.addColorStop(1.0, '#fef9c3');  // Sunlit horizon gold
  ctx.fillStyle = skyGrad;
  ctx.fillRect(0, 0, width, screenGroundY);

  // 2. TROPICAL SUN & VOLUMETRIC COASTAL LIGHT RAYS
  const sunX = width * 0.80;
  const sunY = Math.min(120, screenGroundY * 0.21);

  const sunAura = ctx.createRadialGradient(sunX, sunY, 18, sunX, sunY, width * 0.62);
  sunAura.addColorStop(0, 'rgba(254, 249, 195, 0.44)');
  sunAura.addColorStop(0.28, 'rgba(253, 224, 71, 0.18)');
  sunAura.addColorStop(0.65, 'rgba(56, 189, 248, 0.05)');
  sunAura.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = sunAura;
  ctx.fillRect(0, 0, width, screenGroundY);

  // Crepuscular Sunbeams Fanning Over the Ocean
  ctx.save();
  ctx.translate(sunX, sunY);
  for (let r = 0; r < 11; r++) {
    const ang = (r * Math.PI) / 5.5 + 0.1;
    const len = 360 + (r % 3) * 55;
    const rGrad = ctx.createRadialGradient(0, 0, 20, 0, 0, len);
    rGrad.addColorStop(0, 'rgba(254, 249, 195, 0.22)');
    rGrad.addColorStop(0.5, 'rgba(253, 224, 71, 0.07)');
    rGrad.addColorStop(1, 'rgba(253, 224, 71, 0)');
    ctx.fillStyle = rGrad;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.arc(0, 0, len, ang - 0.06, ang + 0.06);
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();

  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(sunX, sunY, 27, 0, Math.PI * 2);
  ctx.fill();

  // Multi-Pass Volumetric Trade-Wind Cumulus Clouds
  const drawTradeCloud = (cx: number, cy: number, scale: number) => {
    ctx.save();
    ctx.translate(cx, cy);
    ctx.scale(scale, scale);

    ctx.fillStyle = 'rgba(148, 163, 184, 0.48)';
    ctx.beginPath();
    ctx.ellipse(0, 8, 52, 12, 0, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = 'rgba(255, 255, 255, 0.94)';
    ctx.beginPath();
    ctx.arc(-28, 2, 18, 0, Math.PI * 2);
    ctx.arc(-8, -8, 24, 0, Math.PI * 2);
    ctx.arc(16, -6, 21, 0, Math.PI * 2);
    ctx.arc(34, 3, 16, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  };

  drawTradeCloud(width * 0.16, screenGroundY * 0.28, 1.15);
  drawTradeCloud(width * 0.44, screenGroundY * 0.22, 1.35);
  drawTradeCloud(width * 0.66, screenGroundY * 0.30, 0.95);

  // 3. DISTANT VOLCANIC ISLAND ATOLLS & HORIZON SAILBOAT
  const seaY = screenGroundY * 0.56;

  // Far Volcanic Island Silhouette with Sunlit Slope
  const islGrad1 = ctx.createLinearGradient(width * 0.08, seaY - 50, width * 0.28, seaY);
  islGrad1.addColorStop(0, '#0f766e');
  islGrad1.addColorStop(0.6, '#115e59');
  islGrad1.addColorStop(1, '#134e4a');
  ctx.fillStyle = islGrad1;
  ctx.beginPath();
  ctx.moveTo(width * 0.06, seaY);
  ctx.lineTo(width * 0.14, seaY - 38);
  ctx.lineTo(width * 0.19, seaY - 48);
  ctx.lineTo(width * 0.24, seaY - 26);
  ctx.lineTo(width * 0.31, seaY);
  ctx.closePath();
  ctx.fill();

  // Closer Lush Emerald Island with White Lighthouse
  const islGrad2 = ctx.createLinearGradient(width * 0.48, seaY - 55, width * 0.68, seaY);
  islGrad2.addColorStop(0, '#047857');
  islGrad2.addColorStop(1, '#064e3b');
  ctx.fillStyle = islGrad2;
  ctx.beginPath();
  ctx.moveTo(width * 0.47, seaY);
  ctx.quadraticCurveTo(width * 0.54, seaY - 52, width * 0.60, seaY - 34);
  ctx.quadraticCurveTo(width * 0.65, seaY - 42, width * 0.70, seaY);
  ctx.closePath();
  ctx.fill();

  // Distant White Yacht Sail on Horizon
  const yachtX = width * 0.38;
  const yachtY = seaY + 4;
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.moveTo(yachtX, yachtY);
  ctx.lineTo(yachtX + 4, yachtY - 14);
  ctx.lineTo(yachtX + 9, yachtY);
  ctx.closePath();
  ctx.fill();

  // 4. MULTI-ZONE CORAL REEF LAGOON & BREAKING SURF BARRELS
  const seaH = screenGroundY * 0.35;
  const oceanGrad = ctx.createLinearGradient(0, seaY, 0, screenGroundY * 0.91);
  oceanGrad.addColorStop(0.0, '#075985');  // Deep pelagic sapphire
  oceanGrad.addColorStop(0.28, '#0284c7'); // Outer reef azure
  oceanGrad.addColorStop(0.55, '#06b6d4'); // Translucent turquoise lagoon
  oceanGrad.addColorStop(0.82, '#22d3ee'); // Shallow coral aqua
  oceanGrad.addColorStop(1.0, '#a5f3fc');  // Foamy shore shallows
  ctx.fillStyle = oceanGrad;
  ctx.fillRect(0, seaY, width, seaH);

  // Subtle Underwater Coral Reef Patches Visible Through Turquoise Water
  ctx.fillStyle = 'rgba(13, 148, 136, 0.28)';
  for (let cr = 0; cr < 7; cr++) {
    const rx = width * (0.1 + cr * 0.13);
    const ry = seaY + seaH * (0.35 + (cr % 3) * 0.14);
    ctx.beginPath();
    ctx.ellipse(rx, ry, 48 + (cr % 2) * 20, 7, 0.05, 0, Math.PI * 2);
    ctx.fill();
  }

  // Sun Glint Path (Golden-White Shimmer Column under the Sun)
  for (let g = 0; g < 16; g++) {
    const gy = seaY + 6 + g * (seaH * 0.055);
    const gw = 18 + g * 3.5;
    const gx = sunX + Math.sin(g * 1.7) * 8;
    ctx.fillStyle = 'rgba(254, 249, 195, 0.55)';
    ctx.fillRect(gx - gw / 2, gy, gw, 1.8);
  }

  // Rolling Mid-Ocean Swells & Translucent Breaking Wave Crest
  const waveY = screenGroundY * 0.77;
  const waveGrad = ctx.createLinearGradient(0, waveY - 16, 0, waveY + 12);
  waveGrad.addColorStop(0, '#cffafe');
  waveGrad.addColorStop(0.45, '#06b6d4');
  waveGrad.addColorStop(1, '#0e7490');
  ctx.fillStyle = waveGrad;
  ctx.beginPath();
  ctx.moveTo(0, waveY);
  for (let wx = 0; wx <= width; wx += 24) {
    ctx.lineTo(wx, waveY + Math.sin(wx * 0.018) * 7.5);
  }
  ctx.lineTo(width, screenGroundY * 0.88);
  ctx.lineTo(0, screenGroundY * 0.88);
  ctx.closePath();
  ctx.fill();

  // Frothy Whitecap Foam Crest & Lace Webbing
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = 3.4;
  ctx.beginPath();
  ctx.moveTo(0, waveY - 1.5);
  for (let wx = 0; wx <= width; wx += 24) {
    ctx.lineTo(wx, waveY + Math.sin(wx * 0.018) * 7.5 - 1.5);
  }
  ctx.stroke();

  // Secondary Shorebreak Foam Wash
  const shoreFoamY = screenGroundY * 0.89;
  ctx.fillStyle = 'rgba(255, 255, 255, 0.68)';
  ctx.beginPath();
  ctx.moveTo(0, shoreFoamY);
  for (let sx = 0; sx <= width; sx += 28) {
    ctx.lineTo(sx, shoreFoamY + Math.cos(sx * 0.022) * 4);
  }
  ctx.lineTo(width, shoreFoamY + 7);
  ctx.lineTo(0, shoreFoamY + 7);
  ctx.closePath();
  ctx.fill();

  // 5. WET REFLECTIVE SHORELINE SAND & GRACEFUL COCONUT PALMS
  const wetSandGrad = ctx.createLinearGradient(0, screenGroundY * 0.89, 0, screenGroundY);
  wetSandGrad.addColorStop(0, '#bae6fd'); // Sky mirror reflection on wet sand
  wetSandGrad.addColorStop(0.35, '#fde68a');
  wetSandGrad.addColorStop(0.75, '#f59e0b');
  wetSandGrad.addColorStop(1, '#d97706');
  ctx.fillStyle = wetSandGrad;
  ctx.fillRect(0, screenGroundY * 0.89, width, screenGroundY * 0.11);

  const drawCoconutPalm = (px: number, py: number, treeH: number, leanAngle: number) => {
    ctx.save();
    ctx.translate(px, py);
    ctx.rotate(leanAngle);

    // Curved Segmented Trunk with 3D Cylindrical Bark Shading
    const segs = 16;
    const sH = treeH / segs;
    for (let s = 0; s < segs; s++) {
      const sy = -s * sH;
      const trunkW = 8.8 - (s / segs) * 4.0;
      const curveX = Math.sin((s / segs) * Math.PI * 0.65) * 16;
      const tGrad = ctx.createLinearGradient(curveX - trunkW / 2, 0, curveX + trunkW / 2, 0);
      tGrad.addColorStop(0, '#451a03');
      tGrad.addColorStop(0.55, s % 2 === 0 ? '#78350f' : '#92400e');
      tGrad.addColorStop(1, '#d97706');
      ctx.fillStyle = tGrad;
      ctx.fillRect(curveX - trunkW / 2, sy - sH, trunkW, sH + 0.8);
    }

    const crownX = Math.sin(Math.PI * 0.65) * 16;
    ctx.translate(crownX, -treeH);

    // Fronds
    const frondSpokes = [-2.65, -2.1, -1.5, -0.85, -0.25, 0.25, 0.85, 1.5, 2.1, 2.65];
    frondSpokes.forEach((fa, fIdx) => {
      ctx.save();
      ctx.rotate(fa);
      const fLen = 40 + (fIdx % 3) * 8;
      ctx.strokeStyle = fIdx % 2 === 0 ? '#15803d' : '#16a34a';
      ctx.lineWidth = 2.8;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.quadraticCurveTo(fLen * 0.46, -15, fLen, 9);
      ctx.stroke();

      ctx.strokeStyle = fIdx % 2 === 0 ? '#4ade80' : '#84cc16';
      ctx.lineWidth = 1.2;
      for (let lf = 5; lf < fLen - 3; lf += 4) {
        const stemY = -Math.sin((lf / fLen) * Math.PI) * 7 + (lf / fLen) * 9;
        ctx.beginPath();
        ctx.moveTo(lf, stemY);
        ctx.lineTo(lf + 4, stemY + 9);
        ctx.stroke();
      }
      ctx.restore();
    });

    // Cluster of Coconuts
    ctx.fillStyle = '#713f12';
    [[-4, 3], [4, 4], [0, 8]].forEach(([cx, cy]) => {
      ctx.beginPath();
      ctx.arc(cx, cy, 4.6, 0, Math.PI * 2);
      ctx.fill();
    });

    ctx.restore();
  };

  drawCoconutPalm(width * 0.07, screenGroundY * 0.94, 122, -0.24);
  drawCoconutPalm(width * 0.15, screenGroundY * 0.96, 98, -0.14);
  drawCoconutPalm(width * 0.85, screenGroundY * 0.95, 110, 0.20);
  drawCoconutPalm(width * 0.94, screenGroundY * 0.92, 130, 0.30);

  // 6. FOREGROUND GOLDEN BEACH SAND & COASTAL TURF OUTFIELD
  const turfHeight = height - screenGroundY;
  const stripeW = 66;
  const stripeCount = Math.ceil(width / stripeW) + 1;

  for (let st = 0; st < stripeCount; st++) {
    const sx = st * stripeW;
    const isAlt = st % 2 === 0;
    const bGrad = ctx.createLinearGradient(0, screenGroundY, 0, height);
    bGrad.addColorStop(0, isAlt ? '#fef08a' : '#fde047');
    bGrad.addColorStop(0.35, isAlt ? '#fde047' : '#facc15');
    bGrad.addColorStop(0.72, '#eab308');
    bGrad.addColorStop(1, '#ca8a04');
    ctx.fillStyle = bGrad;
    ctx.fillRect(sx, screenGroundY, stripeW + 1, turfHeight);
  }

  // Sand Ripples & Tropical Seashells / Starfish
  ctx.strokeStyle = 'rgba(202, 138, 4, 0.38)';
  ctx.lineWidth = 1.3;
  for (let br = 0; br < width; br += 30) {
    const bry = screenGroundY + 5 + (br % 4) * 4;
    ctx.beginPath();
    ctx.moveTo(br, bry);
    ctx.quadraticCurveTo(br + 14, bry - 2, br + 28, bry + 1);
    ctx.stroke();
  }

  for (let sh = 0; sh < width; sh += 38) {
    const shx = sh + (sh % 6) * 4;
    const shy = screenGroundY + 10 + (sh % 5) * 5;
    ctx.fillStyle = sh % 3 === 0 ? '#fb7185' : sh % 2 === 0 ? '#ffffff' : '#fed7aa';
    ctx.beginPath();
    ctx.arc(shx, shy, 2.3, 0, Math.PI * 2);
    ctx.fill();
  }

  const turfOverlay = ctx.createLinearGradient(0, screenGroundY, 0, height);
  turfOverlay.addColorStop(0, 'rgba(0, 0, 0, 0.02)');
  turfOverlay.addColorStop(0.35, 'rgba(0, 0, 0, 0.12)');
  turfOverlay.addColorStop(1, 'rgba(0, 0, 0, 0.44)');
  ctx.fillStyle = turfOverlay;
  ctx.fillRect(0, screenGroundY, width, turfHeight);
}
