/**
 * High-fidelity Sound Effects Manager.
 * Uses real acoustic audio samples loaded from high-speed local assets and CDN,
 * with zero-latency preloading and instant realistic procedural synthesis fallback.
 */

type SoundName =
  | 'bat_hit'
  | 'bamboo_snap'
  | 'wood_crash'
  | 'coin_drop'
  | 'ball_whoosh'
  | 'explosion'
  | 'stump_hit'
  | 'ball_bounce'
  | 'button_click'
  | 'fire_ignite'
  | 'acid_burn';

const SOUND_SOURCES: Record<SoundName, { local: string; volume: number }> = {
  button_click: {
    local: '/sounds/button click.mp3',
    volume: 1.0,
  },
  bat_hit: {
    local: '/sounds/bat_hit.mp3',
    volume: 1.15,
  },
  bamboo_snap: {
    local: '/sounds/bamboo_snap.mp3',
    volume: 0.9,
  },
  wood_crash: {
    local: '/sounds/bamboo house destroy.mp3',
    volume: 1.1,
  },
  coin_drop: {
    local: '/sounds/coin_drop.mp3',
    volume: 0.8,
  },
  ball_whoosh: {
    local: '/sounds/ball_whoosh.mp3',
    volume: 0.55,
  },
  explosion: {
    local: '/sounds/boom.mp3',
    volume: 1.25,
  },
  fire_ignite: {
    local: '/sounds/fire.mp3',
    volume: 1.05,
  },
  acid_burn: {
    local: '/sounds/bambo_acid.mp3',
    volume: 1.0,
  },
  stump_hit: {
    local: '/sounds/stump_hit.mp3',
    volume: 0.9,
  },
  ball_bounce: {
    local: '/sounds/ball_bounce.wav',
    volume: 0.85,
  },
};

class SoundEffectsManager {
  private ctx: AudioContext | null = null;
  private userMuted: boolean = false;
  private audioBuffers: Map<SoundName, AudioBuffer> = new Map();
  private loadingSet: Set<SoundName> = new Set();

  public get isMuted(): boolean {
    return this.userMuted;
  }

  public set isMuted(value: boolean) {
    this.userMuted = value;
    this.syncAudioContextState();
  }

  private syncAudioContextState() {
    if (!this.ctx) return;
    if (this.isMuted) {
      if (this.ctx.state === 'running') {
        this.ctx.suspend().catch(() => {});
      }
    } else {
      if (this.ctx.state === 'suspended') {
        this.ctx.resume().catch(() => {});
      }
    }
  }

  constructor() {
    if (typeof window !== 'undefined') {
      // Pre-warm AudioContext and preload immediately on page load with 0 delay
      const startPreload = () => {
        this.initCtx();
        this.preloadAllSounds();
      };

      startPreload();
      window.addEventListener('pointerdown', startPreload, { once: true });
      window.addEventListener('keydown', startPreload, { once: true });
      window.addEventListener('touchstart', startPreload, { once: true });
    }
  }

  private initCtx() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended' && !this.isMuted) {
      this.ctx.resume().catch(() => {});
    }
  }

  /**
   * Strips any leading silence/encoder padding from a decoded AudioBuffer for instant 0ms playback.
   */
  private trimLeadingSilence(buffer: AudioBuffer): AudioBuffer {
    if (!this.ctx) return buffer;
    const numChannels = buffer.numberOfChannels;
    const length = buffer.length;
    const sampleRate = buffer.sampleRate;

    let startSample = 0;
    const threshold = 0.005;
    outer: for (let i = 0; i < length; i++) {
      for (let ch = 0; ch < numChannels; ch++) {
        if (Math.abs(buffer.getChannelData(ch)[i]) > threshold) {
          startSample = i;
          break outer;
        }
      }
    }

    const margin = Math.min(startSample, Math.floor(sampleRate * 0.001));
    startSample -= margin;

    if (startSample <= 48 || startSample >= length - 48) {
      return buffer;
    }

    const trimmedLength = length - startSample;
    const trimmed = this.ctx.createBuffer(numChannels, trimmedLength, sampleRate);
    for (let ch = 0; ch < numChannels; ch++) {
      const channelData = buffer.getChannelData(ch).subarray(startSample, length);
      trimmed.copyToChannel(channelData, ch, 0);
    }
    return trimmed;
  }

  /**
   * Pre-fetches and decodes all sound assets into memory for instant zero-latency playback.
   */
  public preloadAllSounds() {
    this.initCtx();

    (Object.keys(SOUND_SOURCES) as SoundName[]).forEach((name) => {
      if (!this.audioBuffers.has(name) && !this.loadingSet.has(name)) {
        this.loadSound(name);
      }
    });
  }

  private async loadSound(name: SoundName): Promise<AudioBuffer | null> {
    if (this.audioBuffers.has(name)) {
      return this.audioBuffers.get(name)!;
    }
    if (this.loadingSet.has(name)) return null;
    this.loadingSet.add(name);

    this.initCtx();
    if (!this.ctx) {
      this.loadingSet.delete(name);
      return null;
    }

    const { local } = SOUND_SOURCES[name];
    const embeddedMap = (window as unknown as { __EMBEDDED_SOUNDS__?: Record<string, string> }).__EMBEDDED_SOUNDS__;
    if (embeddedMap && embeddedMap[local]) {
      try {
        const rawB64 = embeddedMap[local];
        const b64 = rawB64.includes(',') ? rawB64.split(',')[1] : rawB64;
        const binaryStr = window.atob(b64);
        const len = binaryStr.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) {
          bytes[i] = binaryStr.charCodeAt(i);
        }
        const decoded = await this.ctx.decodeAudioData(bytes.buffer.slice(0));
        const trimmed = this.trimLeadingSilence(decoded);
        this.audioBuffers.set(name, trimmed);
        this.loadingSet.delete(name);
        return trimmed;
      } catch {
        // Fall through to network fetch if base64 decode fails
      }
    }

    const urls = local.includes(' ') ? [encodeURI(local), local] : [local];

    for (const url of urls) {
      try {
        const response = await fetch(url);
        if (!response.ok) continue;
        const arrayBuffer = await response.arrayBuffer();
        if (!this.ctx) break;
        const decoded = await this.ctx.decodeAudioData(arrayBuffer);
        const trimmed = this.trimLeadingSilence(decoded);
        this.audioBuffers.set(name, trimmed);
        this.loadingSet.delete(name);
        return trimmed;
      } catch {
        // Continue to next URL encoding
      }
    }

    this.loadingSet.delete(name);
    return null;
  }

  /**
   * Plays a decoded audio buffer with zero latency.
   * Returns true if played from real audio sample, false if fallback is needed.
   */
  private playBuffer(
    name: SoundName,
    options: {
      volume?: number;
      playbackRate?: number;
      randomizePitch?: boolean;
    } = {}
  ): boolean {
    if (this.isMuted) return true;
    this.initCtx();
    if (!this.ctx) return false;

    const buffer = this.audioBuffers.get(name);
    if (!buffer) {
      this.loadSound(name);
      return false;
    }

    try {
      const source = this.ctx.createBufferSource();
      source.buffer = buffer;

      const baseVolume = SOUND_SOURCES[name]?.volume ?? 1.0;
      const finalVolume = Math.max(0.01, Math.min(2.0, (options.volume ?? 1.0) * baseVolume));

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(finalVolume, this.ctx.currentTime);

      let rate = options.playbackRate ?? 1.0;
      if (options.randomizePitch) {
        rate *= 0.97 + Math.random() * 0.06;
      }
      source.playbackRate.setValueAtTime(rate, this.ctx.currentTime);

      source.connect(gain);
      gain.connect(this.ctx.destination);
      source.start(0);
      return true;
    } catch {
      return false;
    }
  }

  // =========================================================================
  // PUBLIC SOUND EFFECTS INTERFACE
  // =========================================================================

  /**
   * Crisp, explosive crack of willow wood bat striking a leather cricket ball.
   * Guaranteed microsecond-zero latency.
   */
  playBatCrack(power: number = 1.0, isSuper: boolean = false) {
    if (this.isMuted) return;
    this.initCtx();

    const played = this.playBuffer('bat_hit', {
      volume: Math.min(1.5, power * 1.1),
      playbackRate: isSuper ? 1.15 : 1.0,
      randomizePitch: true,
    });

    if (isSuper) {
      this.playSuperWhoosh();
    }

    if (played) return;

    if (!this.ctx) return;
    const t = this.ctx.currentTime;

    const crackNoise = this.ctx.createBuffer(1, Math.floor(this.ctx.sampleRate * 0.035), this.ctx.sampleRate);
    const crackData = crackNoise.getChannelData(0);
    for (let i = 0; i < crackData.length; i++) {
      const prog = i / crackData.length;
      crackData[i] = (Math.random() * 2 - 1) * Math.exp(-prog * 8);
    }
    const noiseSource = this.ctx.createBufferSource();
    noiseSource.buffer = crackNoise;

    const noiseFilter = this.ctx.createBiquadFilter();
    noiseFilter.type = 'bandpass';
    noiseFilter.frequency.value = isSuper ? 2400 : 1850;
    noiseFilter.Q.value = 2.5;

    const noiseGain = this.ctx.createGain();
    noiseGain.gain.setValueAtTime(0.85 * Math.min(1.5, power), t);
    noiseGain.gain.exponentialRampToValueAtTime(0.001, t + 0.035);

    noiseSource.connect(noiseFilter);
    noiseFilter.connect(noiseGain);
    noiseGain.connect(this.ctx.destination);
    noiseSource.start(t);

    const bodyOsc = this.ctx.createOscillator();
    const bodyGain = this.ctx.createGain();
    bodyOsc.type = 'sine';
    bodyOsc.frequency.setValueAtTime(isSuper ? 380 : 310, t);
    bodyOsc.frequency.exponentialRampToValueAtTime(75, t + 0.14);

    bodyGain.gain.setValueAtTime(0.9 * Math.min(1.5, power), t);
    bodyGain.gain.exponentialRampToValueAtTime(0.001, t + 0.16);

    bodyOsc.connect(bodyGain);
    bodyGain.connect(this.ctx.destination);
    bodyOsc.start(t);
    bodyOsc.stop(t + 0.16);
  }

  /**
   * Turf / pitch ball bounce sound.
   */
  playBallBounce(volumeScale: number = 1.0) {
    if (this.isMuted) return;
    this.initCtx();

    const scale = Math.max(0.25, Math.min(1.5, volumeScale));
    const played = this.playBuffer('ball_bounce', {
      volume: 0.85 * scale,
      randomizePitch: true,
    });
    if (played) return;

    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(155, t);
    osc.frequency.exponentialRampToValueAtTime(75, t + 0.07);
    gain.gain.setValueAtTime(0.55 * scale, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.08);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(t);
    osc.stop(t + 0.08);
  }

  /**
   * Organic bamboo splintering and snapping impact.
   */
  playBambooSnap(intensity: number = 1.0) {
    if (this.isMuted) return;
    this.initCtx();

    const played = this.playBuffer('bamboo_snap', {
      volume: Math.min(1.3, intensity * 0.9),
      randomizePitch: true,
    });
    if (played) return;

    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const duration = 0.18;
    const bufferSize = Math.floor(this.ctx.sampleRate * duration);
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      const progress = i / bufferSize;
      const crackle = Math.random() > 0.85 ? (Math.random() * 2 - 1) * 1.5 : (Math.random() * 2 - 1) * 0.4;
      data[i] = crackle * Math.exp(-progress * 5);
    }
    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'highpass';
    filter.frequency.value = 900;
    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(Math.min(1.0, 0.4 * intensity), t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + duration);
    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.ctx.destination);
    noise.start(t);
  }

  /**
   * Bamboo house collapse sound when the structure collapses on its own due to missing pillars underneath.
   */
  playStructureCrash() {
    if (this.isMuted) return;
    this.initCtx();

    const played = this.playBuffer('wood_crash', {
      volume: 1.0,
      randomizePitch: false,
    });
    if (played) return;

    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(95, t);
    osc.frequency.exponentialRampToValueAtTime(30, t + 0.4);
    gain.gain.setValueAtTime(0.6, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.45);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(t);
    osc.stop(t + 0.45);
  }

  /**
   * Powerful, punchy bomb ball detonation / explosion sound.
   */
  playExplosion() {
    if (this.isMuted) return;
    this.initCtx();

    const played = this.playBuffer('explosion', {
      volume: 1.25,
      randomizePitch: true,
    });
    if (played) return;

    if (!this.ctx) return;
    const t = this.ctx.currentTime;

    const subOsc = this.ctx.createOscillator();
    const subGain = this.ctx.createGain();
    subOsc.type = 'sine';
    subOsc.frequency.setValueAtTime(58, t);
    subOsc.frequency.exponentialRampToValueAtTime(28, t + 0.35);
    subGain.gain.setValueAtTime(0.9, t);
    subGain.gain.exponentialRampToValueAtTime(0.001, t + 0.45);
    subOsc.connect(subGain);
    subGain.connect(this.ctx.destination);
    subOsc.start(t);
    subOsc.stop(t + 0.45);
  }

  /**
   * Roaring flame ignition & burning sizzle for Fire Ball.
   */
  playFireIgnite() {
    if (this.isMuted) return;
    this.initCtx();

    const played = this.playBuffer('fire_ignite', {
      volume: 1.0,
      randomizePitch: true,
    });
    if (played) return;

    if (!this.ctx) return;
    const t = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(160, t);
    osc.frequency.exponentialRampToValueAtTime(65, t + 0.35);
    gain.gain.setValueAtTime(0.001, t);
    gain.gain.linearRampToValueAtTime(0.4, t + 0.05);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.4);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(t);
    osc.stop(t + 0.4);
  }

  /**
   * Corrosive chemical sizzle and acid dissolving hiss for Acid Ball.
   */
  playAcidBurn() {
    if (this.isMuted) return;
    this.initCtx();

    const played = this.playBuffer('acid_burn', {
      volume: 0.95,
      randomizePitch: true,
    });
    if (played) return;

    if (!this.ctx) return;
    const t = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const oscGain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(950, t);
    osc.frequency.exponentialRampToValueAtTime(320, t + 0.08);
    oscGain.gain.setValueAtTime(0.3, t);
    oscGain.gain.exponentialRampToValueAtTime(0.001, t + 0.08);
    osc.connect(oscGain);
    oscGain.connect(this.ctx.destination);
    osc.start(t);
    osc.stop(t + 0.08);
  }

  /**
   * Fast bowler delivery whoosh through the air.
   */
  playBowlerRelease() {
    if (this.isMuted) return;
    this.initCtx();

    const played = this.playBuffer('ball_whoosh', {
      volume: 0.5,
      randomizePitch: true,
    });
    if (played) return;

    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(160, t);
    osc.frequency.exponentialRampToValueAtTime(380, t + 0.12);
    gain.gain.setValueAtTime(0.15, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.14);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(t);
    osc.stop(t + 0.14);
  }

  /**
   * Super shot fire / thunder whoosh.
   */
  playSuperWhoosh() {
    if (this.isMuted) return;
    this.initCtx();

    const played = this.playBuffer('ball_whoosh', {
      volume: 0.85,
      playbackRate: 0.85,
    });
    if (played) return;

    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(350, t);
    osc.frequency.exponentialRampToValueAtTime(80, t + 0.35);
    gain.gain.setValueAtTime(0.4, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.35);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(t);
    osc.stop(t + 0.35);
  }

  /**
   * Stadium crowd cheering and applause (disabled).
   */
  playCrowdCheer() {
    // Clapping / cheer audio removed as requested
  }

  /**
   * Victory celebration fanfare.
   */
  playVictory() {
    if (this.isMuted) return;
    this.initCtx();

    if (!this.ctx) return;
    const notes = [261.63, 329.63, 392.0, 523.25];
    const t = this.ctx.currentTime;

    notes.forEach((freq, idx) => {
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const startTime = t + idx * 0.12;
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, startTime);
      gain.gain.setValueAtTime(0.3, startTime);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.35);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(startTime);
      osc.stop(startTime + 0.35);
    });
  }

  /**
   * Failure sound.
   */
  playFailure() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx) return;

    const notes = [320, 280, 240, 190];
    const t = this.ctx.currentTime;

    notes.forEach((freq, idx) => {
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const startTime = t + idx * 0.15;
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, startTime);
      gain.gain.setValueAtTime(0.2, startTime);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.25);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(startTime);
      osc.stop(startTime + 0.25);
    });
  }

  /**
   * Wooden stumps rattling and bails shattering when bowled out.
   */
  playStumpShatter() {
    if (this.isMuted) return;
    this.initCtx();

    const played = this.playBuffer('stump_hit', {
      volume: 0.9,
      randomizePitch: true,
    });
    if (played) return;

    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    [480, 620, 310].forEach((freq, idx) => {
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, t + idx * 0.05);
      osc.frequency.exponentialRampToValueAtTime(100, t + idx * 0.05 + 0.12);
      gain.gain.setValueAtTime(0.5, t + idx * 0.05);
      gain.gain.exponentialRampToValueAtTime(0.001, t + idx * 0.05 + 0.15);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(t + idx * 0.05);
      osc.stop(t + idx * 0.05 + 0.15);
    });
  }

  /**
   * Sparkling golden coin dropping / pickup clink.
   */
  playCoin() {
    if (this.isMuted) return;
    this.initCtx();

    const played = this.playBuffer('coin_drop', {
      volume: 0.8,
      randomizePitch: true,
    });
    if (played) return;

    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(1046.5, t);
    osc.frequency.setValueAtTime(1567.98, t + 0.07);
    gain.gain.setValueAtTime(0.35, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.28);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(t);
    osc.stop(t + 0.28);
  }

  /**
   * Button click sound for all UI buttons and bat power button presses.
   */
  playButtonClick() {
    if (this.isMuted) return;
    this.initCtx();

    const played = this.playBuffer('button_click', {
      volume: 1.0,
      randomizePitch: false,
    });
    if (played) return;

    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(1150, t);
    osc.frequency.exponentialRampToValueAtTime(680, t + 0.035);

    gain.gain.setValueAtTime(0.4, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.035);

    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(t);
    osc.stop(t + 0.035);
  }
}

export const soundManager = new SoundEffectsManager();
