import { BambooBlock, LevelConfig } from '../types/game';

export const LEVEL_CONFIGS: LevelConfig[] = [
  {
    id: 1,
    name: 'Village Watch-Hut',
    subtitle: 'Standard Single-Tier Bamboo Shelter & Outpost',
    balls: 12,
    targetDestruction: 60,
    bowlerSpeed: 105,
    bowlerType: 'FAST',
    bowlerLabel: 'Medium Pacer',
    description: 'A traditional single-tier bamboo shelter with 3 responsive pillars, authentic thatch roof, climbing ladder, and stashed gold bricks.',
    hutType: 'simple_hut'
  },
  {
    id: 2,
    name: 'Twin Bamboo Homestead',
    subtitle: 'Two-Story Living Cottage & Kitchen Barn Compound',
    balls: 12,
    targetDestruction: 68,
    bowlerSpeed: 118,
    bowlerType: 'SWING',
    bowlerLabel: 'Outswing Specialist',
    description: 'A 2-story living cottage paired with an adjacent kitchen shed. Knock down the 3 ground pillars to bring the upper floor crashing down!',
    hutType: 'two_story'
  },
  {
    id: 3,
    name: 'River Stilt Village',
    subtitle: 'Dual Elevated Stilt Cabins & Bamboo Boardwalk',
    balls: 12,
    targetDestruction: 72,
    bowlerSpeed: 95,
    bowlerType: 'SPIN',
    bowlerLabel: 'Mystery Off-Spinner',
    description: 'Two elevated 3-stilt river dwellings linked by a suspension walkway. Collapse the stilts to watch the structures plunge into the outfield.',
    hutType: 'stilt_house'
  },
  {
    id: 4,
    name: 'Fortified Granary Compound',
    subtitle: 'Reinforced Gola-Ghar & 3-Tier Watchtower',
    balls: 12,
    targetDestruction: 78,
    bowlerSpeed: 135,
    bowlerType: 'BOUNCER',
    bowlerLabel: 'Speed Merchant (Bouncers)',
    description: 'A reinforced 3-pillar granary alongside a soaring 3-story bamboo watchtower loaded with gold bullion.',
    hutType: 'granary'
  },
  {
    id: 5,
    name: 'The Royal Bamboo Pavilion',
    subtitle: 'Triple-Pagoda Rural Heritage Citadel',
    balls: 12,
    targetDestruction: 82,
    bowlerSpeed: 142,
    bowlerType: 'YORKER',
    bowlerLabel: 'Toe-Crushing Yorker Master',
    description: 'A grand multi-building estate with a soaring 3-tier pagoda, West pavilion, and East treasury packed with sparkling gold.',
    hutType: 'royal_pavilion'
  },
  {
    id: 6,
    name: 'Ultimate Village Fortress',
    subtitle: 'Multi-Structure Stronghold Complex',
    balls: 12,
    targetDestruction: 85,
    bowlerSpeed: 148,
    bowlerType: 'FAST',
    bowlerLabel: 'Express Thunder Bowler',
    description: 'The supreme demolition arena: Gatehouse outpost, 3-story central fortress keep, and rear storehouses spanning the outfield.',
    hutType: 'fortress'
  },
  {
    id: 7,
    name: 'Highland Bamboo Monastery',
    subtitle: 'Cantilevered Bell Shrine & 3-Tier Sanctuary Pagoda',
    balls: 13,
    targetDestruction: 75,
    bowlerSpeed: 96,
    bowlerType: 'SPIN',
    bowlerLabel: 'Carrom Ball Wizard',
    description: 'An elevated hillside sanctuary featuring a sacred bell pavilion, 3-tier pagoda prayer hall, and incense altar rich with relic gold.',
    hutType: 'monastery'
  },
  {
    id: 8,
    name: 'Fishermen Harbor Wharf',
    subtitle: 'Overwater Stilt Boathouse & Coastal Beacon Tower',
    balls: 14,
    targetDestruction: 78,
    bowlerSpeed: 126,
    bowlerType: 'SWING',
    bowlerLabel: 'Reverse Swing Maestro',
    description: 'A coastal village pier with an overwater stilt boathouse connected via bamboo bridge to a 3-tier lighthouse tower.',
    hutType: 'harbor_wharf'
  },
  {
    id: 9,
    name: 'Terraced Tea Estate Mill',
    subtitle: 'High-Rafter Curing Barn & Triple-Tier Processing Keep',
    balls: 14,
    targetDestruction: 82,
    bowlerSpeed: 144,
    bowlerType: 'BOUNCER',
    bowlerLabel: 'Express Firebrand (Bouncers)',
    description: 'A terraced tea plantation mill complex: broad curing barn with open rafters, soaring central elevator tower, and elevated storage racks.',
    hutType: 'tea_mill'
  },
  {
    id: 10,
    name: 'The Imperial Bamboo Citadel',
    subtitle: 'Grand Bastion with Twin Flanking Watchtowers',
    balls: 15,
    targetDestruction: 86,
    bowlerSpeed: 152,
    bowlerType: 'YORKER',
    bowlerLabel: 'Toe-Crushing Yorker Demon',
    description: 'The crowning achievement of village architecture: twin fortified guard bastions flanking a massive 3-floor imperial palace loaded with royal treasure.',
    hutType: 'imperial_citadel'
  },
  {
    id: 11,
    name: 'Ancient Floating River Citadel',
    subtitle: 'Submerged Pilings & Floating Pavilion Bastions',
    balls: 16,
    targetDestruction: 80,
    bowlerSpeed: 136,
    bowlerType: 'SWING',
    bowlerLabel: 'Drifting Outswing Virtuoso',
    description: 'A river delta sanctuary supported on deep submerged stilts: elevated fishery pier, grand central water pavilion, and floating lighthouse watchtower.',
    hutType: 'floating_citadel'
  },
  {
    id: 12,
    name: 'Dragon Ridge Cloud Fortress',
    subtitle: 'Stepped Mountain Ramparts & Dragon-Tail Eaves',
    balls: 16,
    targetDestruction: 84,
    bowlerSpeed: 154,
    bowlerType: 'BOUNCER',
    bowlerLabel: 'High-Bouncing Ridge Demon',
    description: 'A stepped mountain bastion rising diagonally like dragon spine: lower gatehouse, soaring mid-terrace keep, and high peak pagoda with cantilevered eaves.',
    hutType: 'dragon_ridge'
  },
  {
    id: 13,
    name: 'Grand Spice Merchant Bazaar',
    subtitle: 'Domed Granary Arcade & Twin Merchant Vaults',
    balls: 17,
    targetDestruction: 85,
    bowlerSpeed: 105,
    bowlerType: 'SPIN',
    bowlerLabel: 'Mystic Doosra & Googly Wizard',
    description: 'A bustling commercial trading bazaar: twin spice storehouses with terracotta jars flanking an enormous arched central grain dome loaded with hidden treasures.',
    hutType: 'spice_bazaar'
  },
  {
    id: 14,
    name: 'Sky-High Bamboo Colosseum',
    subtitle: 'Monumental Multi-Tier Demolition Arena',
    balls: 18,
    targetDestruction: 88,
    bowlerSpeed: 158,
    bowlerType: 'YORKER',
    bowlerLabel: 'Supreme 160 km/h Inswing Yorker',
    description: 'The ultimate architectural marvel: monumental 4-story imperial arena with double-braced fortress pillars, twin spectator galleries, and a soaring royal crown keep holding a fortune in gold.',
    hutType: 'bamboo_colosseum'
  },
  {
    id: 15,
    name: 'Celestial Bamboo Observatory',
    subtitle: 'Star-Gazer Rotunda & Suspended Astrolabe Rafters',
    balls: 18,
    targetDestruction: 88,
    bowlerSpeed: 160,
    bowlerType: 'FAST',
    bowlerLabel: 'Hyper-Speed Laser Pacer',
    description: 'An elevated astronomical observatory with twin telescope lookout towers, high-altitude star-gazer rotunda, and suspended celestial gold vaults.',
    hutType: 'celestial_observatory'
  },
  {
    id: 16,
    name: 'Ancient Serpent Pagoda',
    subtitle: 'Coiled Tiered Shrines & Sacred Naga Altar',
    balls: 19,
    targetDestruction: 88,
    bowlerSpeed: 110,
    bowlerType: 'SPIN',
    bowlerLabel: 'Cobra Spin & Googly Magician',
    description: 'A multi-tiered jungle sanctuary with flared pagoda eaves mimicking the cobra hood, ceremonial guardian gates, and hidden relic vaults.',
    hutType: 'serpent_temple'
  },
  {
    id: 17,
    name: 'Skyward Windmill Bastion',
    subtitle: 'Twin Rotational Towers & Skybridge Deck',
    balls: 19,
    targetDestruction: 90,
    bowlerSpeed: 156,
    bowlerType: 'BOUNCER',
    bowlerLabel: 'Gale-Force Bouncer Titan',
    description: 'A dual-hub wind bastion: twin soaring mill towers connected by an aerial skybridge beam over an underground milling silo loaded with treasure.',
    hutType: 'wind_mill_bastion'
  },
  {
    id: 18,
    name: 'Royal Lotus Water Palace',
    subtitle: 'Floating Multi-Wing Sovereign Palace & Pavilion Gardens',
    balls: 20,
    targetDestruction: 90,
    bowlerSpeed: 162,
    bowlerType: 'YORKER',
    bowlerLabel: 'Unstoppable Lightning Yorker',
    description: 'The monumental pinnacle of waterborne bamboo architecture: twin stilt pavilions flanking a majestic 4-column throne palace adorned with cascading lotus roofs and royal riches.',
    hutType: 'lotus_water_palace'
  },
  {
    id: 19,
    name: 'Emerald Phoenix Spire',
    subtitle: 'Towering Multi-Wing Aviary & Sky Bridges',
    balls: 20,
    targetDestruction: 90,
    bowlerSpeed: 154,
    bowlerType: 'SWING',
    bowlerLabel: 'Mystic Inswing Cyclone',
    description: 'A soaring multi-wing aviary fortress crowned by cantilevered bamboo wings, suspended ropeway bridges, and elevated treasure roosts.',
    hutType: 'phoenix_spire'
  },
  {
    id: 20,
    name: 'Thunder Mountain Bastion',
    subtitle: 'Fortified Mountain Ridge & Cliffside Ramparts',
    balls: 21,
    targetDestruction: 90,
    bowlerSpeed: 160,
    bowlerType: 'BOUNCER',
    bowlerLabel: '160 km/h Thunder Bouncer',
    description: 'A multi-tier alpine bastion built along stone cliffs with reinforced bamboo pylons, battlements, and hidden explosive powder vaults.',
    hutType: 'thunder_mountain'
  },
  {
    id: 21,
    name: 'Sunken Temple of the Naga King',
    subtitle: 'Aquatic Stepped Shrine & Sacred Water Columns',
    balls: 22,
    targetDestruction: 92,
    bowlerSpeed: 115,
    bowlerType: 'SPIN',
    bowlerLabel: 'Legendary Royal Doosra',
    description: 'An ancient stepped water shrine featuring tiered waterboard columns, ceremonial lotus arches, and jewel-encrusted idol altars.',
    hutType: 'sunken_temple'
  },
  {
    id: 22,
    name: 'Great Bamboo Acropolis',
    subtitle: 'Supreme Imperial Capitol & Skyward Colonnades',
    balls: 22,
    targetDestruction: 92,
    bowlerSpeed: 165,
    bowlerType: 'YORKER',
    bowlerLabel: '165 km/h Unstoppable Fireball Yorker',
    description: 'The monumental zenith of bamboo civilization: four majestic palatial structures linked by imperial colonnades and laden with imperial gold.',
    hutType: 'bamboo_acropolis'
  },
  {
    id: 23,
    name: 'Mythical Titan Fortress',
    subtitle: 'Double-Bastion Bastille & Enchanted Gateway',
    balls: 24,
    targetDestruction: 92,
    bowlerSpeed: 155,
    bowlerType: 'SWING',
    bowlerLabel: '155 km/h Mythic Reverse-Swing Artist',
    description: 'Massive dual-turret defensive bastion with an elevated central keep, arched gatehouse, double reinforced bamboo walls, hanging lanterns, and gold vaults.',
    hutType: 'mythical_fortress'
  },
  {
    id: 24,
    name: 'Sunken Pirate Galleon',
    subtitle: "Three-Mast Warship Deck, Rigging & Captain's Quarters",
    balls: 24,
    targetDestruction: 93,
    bowlerSpeed: 160,
    bowlerType: 'SPIN',
    bowlerLabel: '160 km/h Tempest Googly Spinner',
    description: "High-seas bamboo warship structure featuring bow and stern castles, 3 soaring masts with horizontal yardarms, crow's nests, rope ladders, deck railings, and buried treasure chests.",
    hutType: 'pirate_galleon'
  },
  {
    id: 25,
    name: 'Royal Clocktower Citadel',
    subtitle: 'Soaring 5-Tier Bell Tower & Mechanical Spire',
    balls: 24,
    targetDestruction: 94,
    bowlerSpeed: 165,
    bowlerType: 'BOUNCER',
    bowlerLabel: '165 km/h Heavy Searing Bouncer',
    description: 'Tall monumental clocktower flanked by twin observatory wings, multi-tier bell chamber, cantilevered balconies, pendulum weights, and rooftop spire.',
    hutType: 'royal_clocktower'
  },
  {
    id: 26,
    name: 'Imperial Dragon Pagoda',
    subtitle: 'Grand 6-Tier Sacred Temple & Serpentine Crests',
    balls: 25,
    targetDestruction: 95,
    bowlerSpeed: 170,
    bowlerType: 'YORKER',
    bowlerLabel: '170 km/h Ultimate Firestorm Yorker',
    description: 'The pinnacle test of destruction: a towering 6-tier oriental dragon pagoda with sweeping eave thatch brackets, central sacred pillar core, twin incense pavilions, and imperial gold dragon shrines.',
    hutType: 'dragon_pagoda'
  },
  {
    id: 27,
    name: 'Royal Skybridge Palace',
    subtitle: 'Twin Multi-Story Palace Wings & Elevated Suspension Bridge',
    balls: 24,
    targetDestruction: 90,
    bowlerSpeed: 105,
    bowlerType: 'FAST',
    bowlerLabel: 'Medium Pacer',
    description: 'Twin 3-story royal bamboo palace wings linked high above the ground by a pillar-braced suspension skybridge and guarded by dense bamboo colonnades.',
    hutType: 'skybridge_palace'
  },
  {
    id: 28,
    name: 'Grand Imperial Bastion',
    subtitle: '4-Story Sovereign Keep & Heavy Pillar Colonnades',
    balls: 25,
    targetDestruction: 90,
    bowlerSpeed: 105,
    bowlerType: 'FAST',
    bowlerLabel: 'Medium Pacer',
    description: 'A monumental 4-story imperial palace keep reinforced with dense multi-pillar bamboo colonnades, flanked by twin fortified rampart towers and royal vaults.',
    hutType: 'imperial_bastion'
  },
  {
    id: 29,
    name: 'Twin Fortress & Suspension Bridge',
    subtitle: 'Dual Bastion Keeps & Double-Decked Skybridge Span',
    balls: 25,
    targetDestruction: 92,
    bowlerSpeed: 105,
    bowlerType: 'FAST',
    bowlerLabel: 'Medium Pacer',
    description: 'Two towering 4-tier fortress keeps connected across a central gorge by a double-decked bamboo suspension bridge resting on tall stilt pylons.',
    hutType: 'bridge_citadel'
  },
  {
    id: 30,
    name: 'Royal Outpost Separate Estate',
    subtitle: '4 Separate 1-Story, 2-Story & 3-Story Bamboo Houses',
    balls: 26,
    targetDestruction: 90,
    bowlerSpeed: 105,
    bowlerType: 'FAST',
    bowlerLabel: 'Medium Pacer',
    description: 'Four completely separate bamboo buildings spanning the outfield: a 1-story guard hut, a 3-story watch-keep, a 2-story homestead, and a 3-story tower.',
    hutType: 'sovereign_fortress'
  },
  {
    id: 31,
    name: 'Four-House Pagoda Village',
    subtitle: 'Standalone 1-Story, 2-Story & 3-Story Village Houses',
    balls: 26,
    targetDestruction: 90,
    bowlerSpeed: 105,
    bowlerType: 'FAST',
    bowlerLabel: 'Medium Pacer',
    description: 'Four independent village buildings with wide open spacing: a 2-story watch house, 1-story shrine cottage, 3-story pagoda keep, and 2-story barn.',
    hutType: 'pagoda_watchtower'
  },
  {
    id: 32,
    name: 'Separate Bastion & Cottage Quartet',
    subtitle: 'Unconnected 1-Story, 2-Story & 3-Story Fortified Houses',
    balls: 26,
    targetDestruction: 91,
    bowlerSpeed: 105,
    bowlerType: 'FAST',
    bowlerLabel: 'Medium Pacer',
    description: 'Two standalone 3-story bastion houses separated by an independent 1-story granary hut and a 2-story living cottage.',
    hutType: 'twin_bridge_citadel'
  },
  {
    id: 33,
    name: 'Stepped Homestead Quartet',
    subtitle: '4 Independent 1-Story, 2-Story & 3-Story Bamboo Dwellings',
    balls: 26,
    targetDestruction: 91,
    bowlerSpeed: 105,
    bowlerType: 'FAST',
    bowlerLabel: 'Medium Pacer',
    description: 'A stepped progression of four separate bamboo structures: a 1-story shelter, 2-story village barn, 3-story sanctuary house, and 2-story treasury.',
    hutType: 'celestial_pagoda_fortress'
  },
  {
    id: 34,
    name: 'Four-Garrison Standalone Compound',
    subtitle: 'Separate 1-Story, 2-Story & 3-Story Garrison Houses',
    balls: 26,
    targetDestruction: 91,
    bowlerSpeed: 105,
    bowlerType: 'FAST',
    bowlerLabel: 'Medium Pacer',
    description: 'Four reinforced standalone garrison buildings arranged with blast-isolated spacing across the outfield.',
    hutType: 'skybridge_garrison'
  },
  {
    id: 35,
    name: 'Four-Building Imperial Settlement',
    subtitle: 'Independent 1-Story, 2-Story & 3-Story Royal Houses',
    balls: 26,
    targetDestruction: 92,
    bowlerSpeed: 105,
    bowlerType: 'FAST',
    bowlerLabel: 'Medium Pacer',
    description: 'An imperial settlement of four separate buildings: a 2-story lodge, 3-story manor, 1-story pavilion, and 3-story crown keep.',
    hutType: 'supreme_pagoda_citadel'
  },
  {
    id: 36,
    name: 'Four-Hut Separate Village Row',
    subtitle: '4 Standalone 1-Story, 2-Story & 3-Story Village Cottages',
    balls: 26,
    targetDestruction: 90,
    bowlerSpeed: 105,
    bowlerType: 'FAST',
    bowlerLabel: 'Medium Pacer',
    description: 'Four completely separate village houses of 1-story, 2-story, and 3-story heights spaced across the right outfield.',
    hutType: 'village_row_four'
  },
  {
    id: 37,
    name: 'Riverside Separate Stilt Houses',
    subtitle: '4 Independent 1-Story, 2-Story & 3-Story Stilt Dwellings',
    balls: 26,
    targetDestruction: 90,
    bowlerSpeed: 105,
    bowlerType: 'FAST',
    bowlerLabel: 'Medium Pacer',
    description: 'Four standalone riverside stilt houses of varying 1-to-3 story heights standing on reinforced stilt foundations.',
    hutType: 'stilt_bazaar_four'
  },
  {
    id: 38,
    name: 'Four-Cottage Separate Hamlet',
    subtitle: 'Standalone 1-Story & 3-Story Rural Bamboo Houses',
    balls: 26,
    targetDestruction: 91,
    bowlerSpeed: 105,
    bowlerType: 'FAST',
    bowlerLabel: 'Medium Pacer',
    description: 'A rural bamboo hamlet featuring two 1-story cottages and two 3-story watch-houses standing completely separate from one another.',
    hutType: 'bamboo_hamlet_five'
  },
  {
    id: 39,
    name: 'Merchant Quarter Standalone Houses',
    subtitle: '4 Separate 1-Story, 2-Story & 3-Story Trading Houses',
    balls: 26,
    targetDestruction: 91,
    bowlerSpeed: 105,
    bowlerType: 'FAST',
    bowlerLabel: 'Medium Pacer',
    description: 'Four independent merchant guild houses mixing 1-story, 2-story, and 3-story bamboo architecture with reinforced pillars.',
    hutType: 'merchant_quarter_four'
  },
  {
    id: 40,
    name: 'Grand Township Separate Quartet',
    subtitle: '4 Reinforced 1-Story, 2-Story & 3-Story Township Houses',
    balls: 26,
    targetDestruction: 92,
    bowlerSpeed: 105,
    bowlerType: 'FAST',
    bowlerLabel: 'Medium Pacer',
    description: 'The ultimate four-house bamboo township with separate 1-story, 2-story, and 3-story buildings built on heavy multi-pillar foundations.',
    hutType: 'grand_township_five'
  },
  {
    id: 41,
    name: 'Skyward Spire Quartet',
    subtitle: '4 Separate Houses with a Tall 4-Story Bamboo Tower',
    balls: 26,
    targetDestruction: 91,
    bowlerSpeed: 105,
    bowlerType: 'FAST',
    bowlerLabel: 'Medium Pacer',
    description: 'Four standalone bamboo buildings featuring a soaring 4-story spire tower alongside 1-story, 2-story, and 3-story houses.',
    hutType: 'skyward_spire_quartet'
  },
  {
    id: 42,
    name: 'Twin Tower Bastion',
    subtitle: '4 Separate Houses with Twin 4-Story Bamboo Keeps',
    balls: 26,
    targetDestruction: 91,
    bowlerSpeed: 105,
    bowlerType: 'FAST',
    bowlerLabel: 'Medium Pacer',
    description: 'Two towering 4-story bamboo keeps paired with wide 1-story and 2-story houses separated by open gaps.',
    hutType: 'twin_tower_bastion'
  },
  {
    id: 43,
    name: 'Imperial High Hamlet',
    subtitle: '4 Separate 1-Story, 2-Story, 3-Story & 4-Story Houses',
    balls: 26,
    targetDestruction: 92,
    bowlerSpeed: 105,
    bowlerType: 'FAST',
    bowlerLabel: 'Medium Pacer',
    description: 'A royal hillside hamlet of four separate bamboo structures crowned by a 246px-tall 4-story imperial tower.',
    hutType: 'imperial_high_hamlet'
  },
  {
    id: 44,
    name: 'Soaring Pagoda Row',
    subtitle: '4 Separate High-Rise & Multi-Story Bamboo Houses',
    balls: 26,
    targetDestruction: 92,
    bowlerSpeed: 105,
    bowlerType: 'FAST',
    bowlerLabel: 'Medium Pacer',
    description: 'Four heavily reinforced standalone bamboo houses featuring two 4-story pagodas, a 3-story keep, and a 1-story gatehouse.',
    hutType: 'soaring_pagoda_row'
  },
  {
    id: 45,
    name: 'Grand Sky Citadel',
    subtitle: '4 Separate Monumental Houses with Twin 4-Story Towers',
    balls: 26,
    targetDestruction: 92,
    bowlerSpeed: 105,
    bowlerType: 'FAST',
    bowlerLabel: 'Medium Pacer',
    description: 'The grand skyline citadel with four independent multi-story bamboo houses reaching up to 4 stories high.',
    hutType: 'grand_sky_citadel'
  },
  {
    id: 46,
    name: 'Skyline Pentagon Spire',
    subtitle: '5 Standalone Houses with a Soaring 5-Story Bamboo Spire',
    balls: 26,
    targetDestruction: 91,
    bowlerSpeed: 105,
    bowlerType: 'FAST',
    bowlerLabel: 'Medium Pacer',
    description: 'Five independent bamboo buildings spanning further to the right, crowned by a 275px-tall 5-story bamboo spire.',
    hutType: 'skyline_pentagon_spire'
  },
  {
    id: 47,
    name: 'Twin Monarch Citadels',
    subtitle: '5 Standalone Houses with Twin 5-Story Towers',
    balls: 26,
    targetDestruction: 91,
    bowlerSpeed: 105,
    bowlerType: 'FAST',
    bowlerLabel: 'Medium Pacer',
    description: 'Two towering 282px-high 5-story bamboo citadels paired with wide 1-story, 2-story, and 3-story separate houses.',
    hutType: 'twin_monarch_citadels'
  },
  {
    id: 48,
    name: 'Hexagonal Highland Row',
    subtitle: '6 Standalone Multi-Story Houses across the Skyline',
    balls: 26,
    targetDestruction: 92,
    bowlerSpeed: 105,
    bowlerType: 'FAST',
    bowlerLabel: 'Medium Pacer',
    description: 'Six independent bamboo houses expanding wide to the right with 1-story, 2-story, 3-story, 4-story, and 5-story buildings.',
    hutType: 'hexagonal_highland_row'
  },
  {
    id: 49,
    name: 'Imperial Skyline Bastion',
    subtitle: '6 Standalone Houses with Imperial 5-Story Bastion',
    balls: 26,
    targetDestruction: 92,
    bowlerSpeed: 105,
    bowlerType: 'FAST',
    bowlerLabel: 'Medium Pacer',
    description: 'An extended six-compound royal outpost featuring a massive 288px-tall 5-story citadel alongside twin 4-story keeps.',
    hutType: 'imperial_skyline_bastion'
  },
  {
    id: 50,
    name: 'Grand Celestial Metropolis',
    subtitle: '6 Monumental Separate Houses with Twin 290px Spire Keeps',
    balls: 26,
    targetDestruction: 92,
    bowlerSpeed: 105,
    bowlerType: 'FAST',
    bowlerLabel: 'Medium Pacer',
    description: 'The monumental six-house bamboo metropolis reaching 290px high with twin 5-story towers on reinforced foundations.',
    hutType: 'grand_celestial_metropolis'
  }
];

export function generateBambooHut(type: LevelConfig['hutType'], baseX: number = 990, groundY: number = 570): BambooBlock[] {
  const blocks: BambooBlock[] = [];
  let blockCounter = 0;

  const createId = (prefix: string) => `${prefix}_${++blockCounter}`;

  // Authentic Colors
  const BAMBOO_POST_COLOR = '#8da850';
  const BAMBOO_BEAM_COLOR = '#a3bc63';
  const BAMBOO_WALL_COLOR = '#c2a472';
  const THATCH_COLOR = '#c79d46';
  const STILT_COLOR = '#6e7e40';
  const POT_COLOR = '#d9643a';
  const LANTERN_COLOR = '#eab308';
  const LADDER_COLOR = '#8ea84e';
  const GOLD_COLOR = '#fbbf24';

  // Helper to place a sparkling gold item (brick or coin stack)
  const addGold = (x: number, y: number, isCoinStack: boolean = false) => {
    blocks.push({
      id: createId('gold'),
      x,
      y,
      width: isCoinStack ? 18 : 24,
      height: isCoinStack ? 14 : 12,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 25,
      maxHp: 25,
      type: 'gold',
      color: GOLD_COLOR,
      mass: 6,
      isStructural: false,
      broken: false,
      grounded: true
    });
  };

  // Helper to construct a standard 3-pillar bamboo building
  // USER REQUIREMENT: Exactly 3 pillars (Left, Center, Right) for accessible and satisfying collapse!
  const buildHut3Pillars = (
    startX: number,
    width: number,
    postH: number,
    roofTiers: number,
    options: {
      hasWall?: boolean;
      hasLadder?: boolean;
      ladderSide?: 'left' | 'right';
      potSide?: 'left' | 'right' | 'both';
      hasLantern?: boolean;
      goldCount?: number;
    } = {}
  ) => {
    // 1. Foundation Posts: EXACTLY 3 PILLARS (Left, Center, Right)
    const postPositions = [startX, startX + width / 2, startX + width];
    postPositions.forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: groundY - postH / 2,
        width: 15,
        height: postH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 110,
        maxHp: 110,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 12,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: Math.max(3, Math.round(postH / 28))
      });
    });

    // 2. Mid-rail Horizontal Beam connecting the 3 posts
    const midBeamY = groundY - postH * 0.45;
    blocks.push({
      id: createId('beam'),
      x: startX + width / 2,
      y: midBeamY,
      width: width + 18,
      height: 11,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 105,
      maxHp: 105,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 10,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 4
    });

    // 3. Top Eaves Beam
    const topBeamY = groundY - postH - 6;
    blocks.push({
      id: createId('beam'),
      x: startX + width / 2,
      y: topBeamY,
      width: width + 28,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 130,
      maxHp: 130,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 14,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // 4. Woven Bamboo Wall Panel (Chatai mat)
    if (options.hasWall) {
      blocks.push({
        id: createId('wall'),
        x: startX + width / 2,
        y: groundY - postH * 0.45,
        width: width - 26,
        height: postH * 0.75,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 80,
        maxHp: 80,
        type: 'wall',
        color: BAMBOO_WALL_COLOR,
        mass: 8,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    // 5. Layered Straw Thatch Roof Tiers
    const roofBaseY = topBeamY - 10;
    for (let r = 0; r < roofTiers; r++) {
      const tierWidth = (width + 36) - (r * 32);
      if (tierWidth < 30) break;
      const ty = roofBaseY - (r * 18) - 8;
      blocks.push({
        id: createId('thatch'),
        x: startX + width / 2,
        y: ty,
        width: tierWidth,
        height: 18,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 60,
        maxHp: 60,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 6,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    // 6. Stashed Gold inside the hut
    const goldCount = options.goldCount ?? 2;
    if (goldCount >= 1) {
      // Gold brick resting on mid beam (left side room)
      addGold(startX + width * 0.28, midBeamY - 11, false);
    }
    if (goldCount >= 2) {
      // Gold coin stack resting on mid beam (right side room)
      addGold(startX + width * 0.72, midBeamY - 12, true);
    }
    if (goldCount >= 3) {
      // Third gold cache
      addGold(startX + width * 0.50, topBeamY - 12, false);
    }

    // 7. Leaning Bamboo Ladder
    if (options.hasLadder) {
      const ladderX = options.ladderSide === 'right' ? startX + width + 12 : startX - 12;
      const ladderH = postH + 20;
      blocks.push({
        id: createId('ladder'),
        x: ladderX,
        y: groundY - ladderH / 2,
        width: 16,
        height: ladderH,
        angle: options.ladderSide === 'right' ? -0.16 : 0.16,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 55,
        maxHp: 55,
        type: 'ladder',
        color: LADDER_COLOR,
        mass: 7,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    // 8. Pots & Lanterns
    if (options.potSide === 'left' || options.potSide === 'both') {
      blocks.push({
        id: createId('pot'),
        x: startX - 8,
        y: topBeamY + 22,
        width: 18,
        height: 22,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 35,
        maxHp: 35,
        type: 'pot',
        color: POT_COLOR,
        mass: 4,
        isStructural: false,
        broken: false,
        grounded: true,
        hanging: true
      });
    }
    if (options.potSide === 'right' || options.potSide === 'both') {
      blocks.push({
        id: createId('pot'),
        x: startX + width + 8,
        y: topBeamY + 22,
        width: 18,
        height: 22,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 35,
        maxHp: 35,
        type: 'pot',
        color: POT_COLOR,
        mass: 4,
        isStructural: false,
        broken: false,
        grounded: true,
        hanging: true
      });
    }

    if (options.hasLantern) {
      blocks.push({
        id: createId('lantern'),
        x: startX + width / 2,
        y: topBeamY + 24,
        width: 16,
        height: 22,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 30,
        maxHp: 30,
        type: 'lantern',
        color: LANTERN_COLOR,
        mass: 3,
        isStructural: false,
        broken: false,
        grounded: true,
        hanging: true
      });
    }
  };

  // =========================================================================
  // LEVEL 1: Single 1-Story Village Watch-Hut (3 Pillars + Gold Caches)
  // =========================================================================
  if (type === 'simple_hut') {
    buildHut3Pillars(baseX + 15, 185, 115, 4, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'left',
      potSide: 'both',
      hasLantern: true,
      goldCount: 2
    });
  }

  // =========================================================================
  // LEVEL 2: 2-Story Living Cottage (3 Pillars/Floor) + Kitchen Hut (3 Pillars)
  // =========================================================================
  else if (type === 'two_story') {
    const cottageX = baseX;
    const cottageW = 195;
    const floor1H = 95;
    const floor2H = 85;

    // --- Building 1: Two-Story Living Cottage ---
    // Floor 1 Posts (EXACTLY 3 Pillars: Left, Center, Right)
    [cottageX, cottageX + cottageW / 2, cottageX + cottageW].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: groundY - floor1H / 2,
        width: 16,
        height: floor1H,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 120,
        maxHp: 120,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 14,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 4
      });
    });

    // Floor 1 Mid-beam
    const midBeam1Y = groundY - floor1H * 0.45;
    blocks.push({
      id: createId('beam'),
      x: cottageX + cottageW / 2,
      y: midBeam1Y,
      width: cottageW + 16,
      height: 11,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 110,
      maxHp: 110,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 11,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 4
    });

    // Floor 1 Gold Cache
    addGold(cottageX + cottageW * 0.28, midBeam1Y - 11, false);

    // Floor 1 Woven Wall
    blocks.push({
      id: createId('wall'),
      x: cottageX + cottageW / 2,
      y: groundY - floor1H * 0.5,
      width: cottageW - 26,
      height: floor1H * 0.8,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 85,
      maxHp: 85,
      type: 'wall',
      color: BAMBOO_WALL_COLOR,
      mass: 9,
      isStructural: false,
      broken: false,
      grounded: true
    });

    // Mid Floor Deck Beam
    const midDeckY = groundY - floor1H - 6;
    blocks.push({
      id: createId('beam'),
      x: cottageX + cottageW / 2,
      y: midDeckY,
      width: cottageW + 30,
      height: 15,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 140,
      maxHp: 140,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 15,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Floor 2 Posts (EXACTLY 3 Pillars: Left, Center, Right)
    const upperW = cottageW - 20;
    const upperStartX = cottageX + 10;
    [upperStartX, upperStartX + upperW / 2, upperStartX + upperW].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: midDeckY - floor2H / 2 - 8,
        width: 15,
        height: floor2H,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 105,
        maxHp: 105,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 11,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 3
      });
    });

    // Floor 2 Upper Gold Caches
    addGold(upperStartX + upperW * 0.3, midDeckY - 14, false);
    addGold(upperStartX + upperW * 0.7, midDeckY - 15, true);

    // Floor 2 Upper Roof Beam
    const upperBeamY = midDeckY - floor2H - 14;
    blocks.push({
      id: createId('beam'),
      x: upperStartX + upperW / 2,
      y: upperBeamY,
      width: upperW + 28,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 125,
      maxHp: 125,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 13,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Floor 2 Thatch Tiers
    for (let r = 0; r < 4; r++) {
      blocks.push({
        id: createId('thatch'),
        x: upperStartX + upperW / 2,
        y: upperBeamY - 14 - r * 18,
        width: (upperW + 36) - r * 34,
        height: 18,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 60,
        maxHp: 60,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 6,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    // Access Ladder to Floor 2
    blocks.push({
      id: createId('ladder'),
      x: cottageX - 16,
      y: groundY - 60,
      width: 16,
      height: 130,
      angle: 0.18,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 60,
      maxHp: 60,
      type: 'ladder',
      color: LADDER_COLOR,
      mass: 8,
      isStructural: false,
      broken: false,
      grounded: true
    });

    // --- Building 2: Adjacent Thatched Kitchen Shed (3 Pillars) ---
    const shedX = cottageX + cottageW + 40;
    buildHut3Pillars(shedX, 145, 85, 3, {
      hasWall: true,
      hasLadder: false,
      potSide: 'both',
      hasLantern: true,
      goldCount: 1
    });

    // Covered Breezeway Connecting Beam
    blocks.push({
      id: createId('beam'),
      x: cottageX + cottageW + 20,
      y: groundY - 65,
      width: 45,
      height: 10,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 80,
      maxHp: 80,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 7,
      isStructural: true,
      broken: false,
      grounded: true
    });
  }

  // =========================================================================
  // LEVEL 3: River Stilt Village (Dual Elevated Cabins, 3 Stilts Each + Bridge)
  // =========================================================================
  else if (type === 'stilt_house') {
    const stiltHeight = 75;
    const cabinH = 90;
    const cabin1X = baseX;
    const cabin1W = 165;

    // Helper for 3-Stilt Elevated Cabin
    const buildStiltCabin3Pillars = (startX: number, width: number, hasWalkwaySide: 'left' | 'right') => {
      // EXACTLY 3 Stilts from ground to platform (Left, Center, Right)
      [startX, startX + width / 2, startX + width].forEach((sx) => {
        blocks.push({
          id: createId('stilt'),
          x: sx,
          y: groundY - stiltHeight / 2,
          width: 16,
          height: stiltHeight,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 125,
          maxHp: 125,
          type: 'stilt',
          color: STILT_COLOR,
          mass: 14,
          isStructural: true,
          broken: false,
          grounded: true,
          nodes: 3
        });
      });

      // Platform Deck Beam
      const deckY = groundY - stiltHeight - 6;
      blocks.push({
        id: createId('beam'),
        x: startX + width / 2,
        y: deckY,
        width: width + 26,
        height: 14,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 135,
        maxHp: 135,
        type: 'beam',
        color: BAMBOO_BEAM_COLOR,
        mass: 15,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 5
      });

      // Upper Cabin Posts: EXACTLY 3 Pillars
      [startX, startX + width / 2, startX + width].forEach((px) => {
        blocks.push({
          id: createId('post'),
          x: px,
          y: deckY - cabinH / 2 - 8,
          width: 14,
          height: cabinH,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 100,
          maxHp: 100,
          type: 'post',
          color: BAMBOO_POST_COLOR,
          mass: 11,
          isStructural: true,
          broken: false,
          grounded: true,
          nodes: 3
        });
      });

      // Gold Caches on the deck
      addGold(startX + width * 0.3, deckY - 14, false);
      addGold(startX + width * 0.7, deckY - 14, true);

      // Cabin Wall Mat
      blocks.push({
        id: createId('wall'),
        x: startX + width / 2,
        y: deckY - cabinH * 0.5 - 6,
        width: width - 20,
        height: cabinH * 0.75,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 80,
        maxHp: 80,
        type: 'wall',
        color: BAMBOO_WALL_COLOR,
        mass: 9,
        isStructural: false,
        broken: false,
        grounded: true
      });

      // Roof Beam & Thatch
      const roofBeamY = deckY - cabinH - 12;
      blocks.push({
        id: createId('beam'),
        x: startX + width / 2,
        y: roofBeamY,
        width: width + 28,
        height: 13,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 120,
        maxHp: 120,
        type: 'beam',
        color: BAMBOO_BEAM_COLOR,
        mass: 12,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 5
      });

      for (let r = 0; r < 4; r++) {
        blocks.push({
          id: createId('thatch'),
          x: startX + width / 2,
          y: roofBeamY - 14 - r * 18,
          width: (width + 36) - r * 30,
          height: 18,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 60,
          maxHp: 60,
          type: 'thatch',
          color: THATCH_COLOR,
          mass: 6,
          isStructural: false,
          broken: false,
          grounded: true
        });
      }

      // Climbing Ladder
      const ladX = hasWalkwaySide === 'right' ? startX - 14 : startX + width + 14;
      blocks.push({
        id: createId('ladder'),
        x: ladX,
        y: groundY - 45,
        width: 15,
        height: 95,
        angle: hasWalkwaySide === 'right' ? 0.18 : -0.18,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 55,
        maxHp: 55,
        type: 'ladder',
        color: LADDER_COLOR,
        mass: 7,
        isStructural: false,
        broken: false,
        grounded: true
      });
    };

    // Stilt Cabin 1
    buildStiltCabin3Pillars(cabin1X, cabin1W, 'right');

    // Central Boardwalk Bridge (with gold stash)
    const bridgeX = cabin1X + cabin1W + 8;
    const bridgeW = 85;
    const deckY = groundY - stiltHeight - 6;

    blocks.push({
      id: createId('stilt'),
      x: bridgeX + bridgeW / 2,
      y: groundY - stiltHeight / 2,
      width: 15,
      height: stiltHeight,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 110,
      maxHp: 110,
      type: 'stilt',
      color: STILT_COLOR,
      mass: 12,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 3
    });

    blocks.push({
      id: createId('beam'),
      x: bridgeX + bridgeW / 2,
      y: deckY,
      width: bridgeW + 16,
      height: 12,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 100,
      maxHp: 100,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 10,
      isStructural: true,
      broken: false,
      grounded: true
    });

    // Boardwalk Gold Coin Stash
    addGold(bridgeX + bridgeW / 2, deckY - 14, true);

    // Stilt Cabin 2
    const cabin2X = bridgeX + bridgeW + 8;
    const cabin2W = 165;
    buildStiltCabin3Pillars(cabin2X, cabin2W, 'left');
  }

  // =========================================================================
  // LEVEL 4: Fortified Granary Compound (3 Pillars) + 3-Story Watchtower (3 Pillars)
  // =========================================================================
  else if (type === 'granary') {
    const granaryX = baseX;
    const granaryW = 190;
    const granaryPostH = 120;

    // 1. Reinforced Granary: EXACTLY 3 Pillars (Left, Center, Right)
    [granaryX, granaryX + granaryW / 2, granaryX + granaryW].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: groundY - granaryPostH / 2,
        width: 18,
        height: granaryPostH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 145,
        maxHp: 145,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 17,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 5
      });
    });

    // Mid-beam & Top-beam
    const gMidY = groundY - granaryPostH * 0.45;
    blocks.push({
      id: createId('beam'),
      x: granaryX + granaryW / 2,
      y: gMidY,
      width: granaryW + 20,
      height: 12,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 130,
      maxHp: 130,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 13,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Granary Gold Bullion Bars
    addGold(granaryX + granaryW * 0.3, gMidY - 12, false);
    addGold(granaryX + granaryW * 0.7, gMidY - 12, false);

    const gTopY = groundY - granaryPostH - 8;
    blocks.push({
      id: createId('beam'),
      x: granaryX + granaryW / 2,
      y: gTopY,
      width: granaryW + 36,
      height: 16,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 155,
      maxHp: 155,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 17,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Granary Heavy Thatch Roof
    for (let r = 0; r < 5; r++) {
      blocks.push({
        id: createId('thatch'),
        x: granaryX + granaryW / 2,
        y: gTopY - 14 - r * 18,
        width: (granaryW + 42) - r * 32,
        height: 20,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 70,
        maxHp: 70,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 7,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    // --- Building 2: Soaring 3-Story Watchtower (3 Pillars per level) ---
    const towerX = granaryX + granaryW + 45;
    const towerW = 140;
    const tFloor1H = 85;
    const tFloor2H = 75;

    // Tower Level 1: EXACTLY 3 Pillars
    [towerX, towerX + towerW / 2, towerX + towerW].forEach((tx) => {
      blocks.push({
        id: createId('post'),
        x: tx,
        y: groundY - tFloor1H / 2,
        width: 16,
        height: tFloor1H,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 130,
        maxHp: 130,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 14,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 4
      });
    });

    const tPlatform1Y = groundY - tFloor1H - 6;
    blocks.push({
      id: createId('beam'),
      x: towerX + towerW / 2,
      y: tPlatform1Y,
      width: towerW + 24,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 135,
      maxHp: 135,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 14,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 4
    });

    // Level 1 Gold
    addGold(towerX + towerW * 0.35, tPlatform1Y - 14, true);

    // Tower Level 2: EXACTLY 3 Pillars
    const tUpperW = towerW - 20;
    const tUpperX = towerX + 10;
    [tUpperX, tUpperX + tUpperW / 2, tUpperX + tUpperW].forEach((tx) => {
      blocks.push({
        id: createId('post'),
        x: tx,
        y: tPlatform1Y - tFloor2H / 2 - 8,
        width: 14,
        height: tFloor2H,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 110,
        maxHp: 110,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 11,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 3
      });
    });

    // Lookout Platform Beam & Gold
    const tTopY = tPlatform1Y - tFloor2H - 14;
    blocks.push({
      id: createId('beam'),
      x: tUpperX + tUpperW / 2,
      y: tTopY,
      width: tUpperW + 28,
      height: 13,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 125,
      maxHp: 125,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 12,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 4
    });

    // Lookout Gold Bullion
    addGold(tUpperX + tUpperW * 0.5, tTopY - 14, false);

    // Tower Roof
    for (let r = 0; r < 3; r++) {
      blocks.push({
        id: createId('thatch'),
        x: tUpperX + tUpperW / 2,
        y: tTopY - 12 - r * 16,
        width: (tUpperW + 34) - r * 30,
        height: 16,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 55,
        maxHp: 55,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 5,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    // Long Ladder
    blocks.push({
      id: createId('ladder'),
      x: towerX - 14,
      y: groundY - 70,
      width: 16,
      height: 145,
      angle: 0.16,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 70,
      maxHp: 70,
      type: 'ladder',
      color: LADDER_COLOR,
      mass: 9,
      isStructural: false,
      broken: false,
      grounded: true
    });
  }

  // =========================================================================
  // LEVEL 5: Royal Bamboo Pavilion (Triple Pagoda Complex, 3 Pillars/Tier)
  // =========================================================================
  else if (type === 'royal_pavilion') {
    // 1. West Reception Pavilion (3 Pillars)
    const westX = baseX;
    const westW = 155;
    buildHut3Pillars(westX, westW, 100, 3, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'left',
      potSide: 'both',
      hasLantern: true,
      goldCount: 2
    });

    // 2. Grand Central 3-Tier Royal Pagoda (3 Pillars per Tier)
    const centralX = westX + westW + 35;
    const centralW = 210;
    const cFloor1H = 100;
    const cFloor2H = 90;

    // Central Tier 1 Posts: EXACTLY 3 Pillars (Left, Center, Right)
    [centralX, centralX + centralW / 2, centralX + centralW].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: groundY - cFloor1H / 2,
        width: 18,
        height: cFloor1H,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 155,
        maxHp: 155,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 17,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 5
      });
    });

    const cDeck1Y = groundY - cFloor1H - 6;
    blocks.push({
      id: createId('beam'),
      x: centralX + centralW / 2,
      y: cDeck1Y,
      width: centralW + 38,
      height: 16,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 165,
      maxHp: 165,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 17,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Central Level 1 Royal Gold
    addGold(centralX + centralW * 0.3, cDeck1Y - 14, false);
    addGold(centralX + centralW * 0.7, cDeck1Y - 14, true);

    // Tier 1 Eaves Thatch
    blocks.push({
      id: createId('thatch'),
      x: centralX + centralW / 2,
      y: cDeck1Y - 14,
      width: centralW + 48,
      height: 18,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 70,
      maxHp: 70,
      type: 'thatch',
      color: THATCH_COLOR,
      mass: 8,
      isStructural: false,
      broken: false,
      grounded: true
    });

    // Central Tier 2 Posts: EXACTLY 3 Pillars
    const cUpperW = centralW - 35;
    const cUpperX = centralX + 17.5;
    [cUpperX, cUpperX + cUpperW / 2, cUpperX + cUpperW].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: cDeck1Y - cFloor2H / 2 - 20,
        width: 15,
        height: cFloor2H,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 125,
        maxHp: 125,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 13,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 4
      });
    });

    // Tier 2 Crown Beam
    const cCrownY = cDeck1Y - cFloor2H - 26;
    blocks.push({
      id: createId('beam'),
      x: cUpperX + cUpperW / 2,
      y: cCrownY,
      width: cUpperW + 32,
      height: 15,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 145,
      maxHp: 145,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 14,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 4
    });

    // Tier 2 Gold Bullion
    addGold(cUpperX + cUpperW * 0.5, cCrownY - 14, false);

    // Cascading Pagoda Crown Thatch
    for (let r = 0; r < 4; r++) {
      blocks.push({
        id: createId('thatch'),
        x: cUpperX + cUpperW / 2,
        y: cCrownY - 14 - r * 18,
        width: (cUpperW + 40) - r * 35,
        height: 18,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 65,
        maxHp: 65,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 7,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    // 3. East Treasury Pavilion (3 Pillars)
    const eastX = centralX + centralW + 35;
    const eastW = 160;
    buildHut3Pillars(eastX, eastW, 95, 3, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'right',
      potSide: 'both',
      hasLantern: true,
      goldCount: 3
    });
  }

  // =========================================================================
  // LEVEL 6: Ultimate Village Fortress (3 Structures, 3 Pillars Each)
  // =========================================================================
  else if (type === 'fortress') {
    // 1. Gatehouse Tower (3 Pillars)
    const gateX = baseX;
    const gateW = 145;
    buildHut3Pillars(gateX, gateW, 110, 4, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'left',
      potSide: 'both',
      hasLantern: true,
      goldCount: 2
    });

    // 2. Central Fortress Keep (3 Pillars per level)
    const citX = gateX + gateW + 30;
    const citW = 215;
    const citH = 115;

    [citX, citX + citW / 2, citX + citW].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: groundY - citH / 2,
        width: 18,
        height: citH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 165,
        maxHp: 165,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 18,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 5
      });
    });

    const citMidY = groundY - citH * 0.45;
    blocks.push({
      id: createId('beam'),
      x: citX + citW / 2,
      y: citMidY,
      width: citW + 24,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 150,
      maxHp: 150,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 15,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Citadel Gold
    addGold(citX + citW * 0.3, citMidY - 14, false);
    addGold(citX + citW * 0.7, citMidY - 14, false);

    const citTopY = groundY - citH - 8;
    blocks.push({
      id: createId('beam'),
      x: citX + citW / 2,
      y: citTopY,
      width: citW + 36,
      height: 16,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 170,
      maxHp: 170,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 17,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Upper Citadel Gold
    addGold(citX + citW * 0.5, citTopY - 14, true);

    for (let r = 0; r < 5; r++) {
      blocks.push({
        id: createId('thatch'),
        x: citX + citW / 2,
        y: citTopY - 14 - r * 18,
        width: (citW + 42) - r * 32,
        height: 20,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 75,
        maxHp: 75,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 8,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    // 3. Rear Citadel Storehouse (3 Pillars)
    const rearX = citX + citW + 30;
    const rearW = 155;
    buildHut3Pillars(rearX, rearW, 105, 4, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'right',
      potSide: 'both',
      hasLantern: true,
      goldCount: 3
    });
  }

  // =========================================================================
  // LEVEL 7: Highland Bamboo Monastery (Cantilever Bell Shrine + Grand Pagoda)
  // =========================================================================
  else if (type === 'monastery') {
    // 1. West Bell Shrine (3 Pillars)
    const bellX = baseX;
    const bellW = 145;
    buildHut3Pillars(bellX, bellW, 110, 3, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'left',
      potSide: 'left',
      hasLantern: true,
      goldCount: 2
    });

    // Hanging ceremonial bell pot in shrine
    blocks.push({
      id: createId('pot'),
      x: bellX + bellW / 2,
      y: groundY - 70,
      width: 22,
      height: 26,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 40,
      maxHp: 40,
      type: 'pot',
      color: POT_COLOR,
      mass: 5,
      isStructural: false,
      broken: false,
      grounded: true,
      hanging: true
    });

    // 2. Central Sanctuary Pagoda (2-Tier Multi-Story Structure with 3 Pillars per Tier)
    const pagX = bellX + bellW + 28;
    const pagW = 190;
    const pagH1 = 95;
    const pagH2 = 85;

    // Floor 1 Foundation Posts (3 Pillars)
    [pagX, pagX + pagW / 2, pagX + pagW].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: groundY - pagH1 / 2,
        width: 17,
        height: pagH1,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 150,
        maxHp: 150,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 16,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 4
      });
    });

    // Floor 1 Deck / Beam
    const pagDeckY = groundY - pagH1 - 6;
    blocks.push({
      id: createId('beam'),
      x: pagX + pagW / 2,
      y: pagDeckY,
      width: pagW + 30,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 155,
      maxHp: 155,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 15,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Gold on First Floor (rests securely on deck beam)
    addGold(pagX + pagW * 0.35, pagDeckY - 12, false);
    addGold(pagX + pagW * 0.65, pagDeckY - 12, true);

    // Floor 2 Posts (3 Pillars)
    [pagX + 12, pagX + pagW / 2, pagX + pagW - 12].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: pagDeckY - pagH2 / 2,
        width: 15,
        height: pagH2,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 125,
        maxHp: 125,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 13,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 4
      });
    });

    // Pagoda Upper Beam
    const pagTopY = pagDeckY - pagH2 - 6;
    blocks.push({
      id: createId('beam'),
      x: pagX + pagW / 2,
      y: pagTopY,
      width: pagW + 18,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 140,
      maxHp: 140,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 14,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Upper Sanctuary Gold
    addGold(pagX + pagW * 0.5, pagTopY - 14, true);

    // 4 Pagoda Roof Tiers
    for (let r = 0; r < 4; r++) {
      blocks.push({
        id: createId('thatch'),
        x: pagX + pagW / 2,
        y: pagTopY - 14 - r * 18,
        width: (pagW + 36) - r * 30,
        height: 19,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 70,
        maxHp: 70,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 7,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    // 3. East Incense Terrace (3 Pillars)
    const incX = pagX + pagW + 28;
    const incW = 150;
    buildHut3Pillars(incX, incW, 100, 3, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'right',
      potSide: 'both',
      hasLantern: true,
      goldCount: 3
    });
  }

  // =========================================================================
  // LEVEL 8: Fishermen Harbor Wharf (Stilt Boathouse + Pier + Lighthouse Tower)
  // =========================================================================
  else if (type === 'harbor_wharf') {
    const stiltH = 75;

    // 1. Overwater Stilt Boathouse (3 Stilts + 3 Pillars Cabin)
    const boatX = baseX;
    const boatW = 165;

    // 3 River Stilts
    [boatX, boatX + boatW / 2, boatX + boatW].forEach((sx) => {
      blocks.push({
        id: createId('stilt'),
        x: sx,
        y: groundY - stiltH / 2,
        width: 16,
        height: stiltH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 135,
        maxHp: 135,
        type: 'stilt',
        color: STILT_COLOR,
        mass: 14,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 3
      });
    });

    // Boathouse Deck Beam
    const boatDeckY = groundY - stiltH - 6;
    blocks.push({
      id: createId('beam'),
      x: boatX + boatW / 2,
      y: boatDeckY,
      width: boatW + 26,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 145,
      maxHp: 145,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 14,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Boathouse Cabin Posts (3 Pillars)
    const cabinH = 85;
    [boatX + 5, boatX + boatW / 2, boatX + boatW - 5].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: boatDeckY - cabinH / 2,
        width: 14,
        height: cabinH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 115,
        maxHp: 115,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 11,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 3
      });
    });

    // Boathouse Roof Beam & 3 Thatch Tiers
    const boatTopY = boatDeckY - cabinH - 6;
    blocks.push({
      id: createId('beam'),
      x: boatX + boatW / 2,
      y: boatTopY,
      width: boatW + 20,
      height: 12,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 120,
      maxHp: 120,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 12,
      isStructural: true,
      broken: false,
      grounded: true
    });

    addGold(boatX + boatW * 0.35, boatDeckY - 12, false);
    addGold(boatX + boatW * 0.65, boatDeckY - 12, true);

    for (let r = 0; r < 3; r++) {
      blocks.push({
        id: createId('thatch'),
        x: boatX + boatW / 2,
        y: boatTopY - 12 - r * 16,
        width: (boatW + 24) - r * 30,
        height: 18,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 60,
        maxHp: 60,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 6,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    // 2. Suspension Wharf Plank connecting to Lighthouse
    const pierX = boatX + boatW + 25;
    const pierW = 50;
    blocks.push({
      id: createId('beam'),
      x: pierX,
      y: boatDeckY,
      width: pierW,
      height: 12,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 95,
      maxHp: 95,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 8,
      isStructural: true,
      broken: false,
      grounded: true
    });

    // 3. Coastal Bamboo Lighthouse Tower (3-Tier Structure, 3 Pillars per tier)
    const lhX = boatX + boatW + 50;
    const lhW = 160;
    const lhH1 = 90;
    const lhH2 = 80;

    // Foundation Level Posts (3 Pillars)
    [lhX, lhX + lhW / 2, lhX + lhW].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: groundY - lhH1 / 2,
        width: 17,
        height: lhH1,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 155,
        maxHp: 155,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 17,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 4
      });
    });

    const lhMidDeckY = groundY - lhH1 - 6;
    blocks.push({
      id: createId('beam'),
      x: lhX + lhW / 2,
      y: lhMidDeckY,
      width: lhW + 24,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 145,
      maxHp: 145,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 15,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    addGold(lhX + lhW * 0.5, lhMidDeckY - 12, false);

    // Watch Room Posts (3 Pillars)
    [lhX + 10, lhX + lhW / 2, lhX + lhW - 10].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: lhMidDeckY - lhH2 / 2,
        width: 15,
        height: lhH2,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 125,
        maxHp: 125,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 13,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 3
      });
    });

    const lhTopY = lhMidDeckY - lhH2 - 6;
    blocks.push({
      id: createId('beam'),
      x: lhX + lhW / 2,
      y: lhTopY,
      width: lhW + 20,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 135,
      maxHp: 135,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 13,
      isStructural: true,
      broken: false,
      grounded: true
    });

    // Beacon Lantern at the top of Lighthouse
    blocks.push({
      id: createId('lantern'),
      x: lhX + lhW / 2,
      y: lhTopY - 15,
      width: 20,
      height: 24,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 45,
      maxHp: 45,
      type: 'lantern',
      color: LANTERN_COLOR,
      mass: 4,
      isStructural: false,
      broken: false,
      grounded: true
    });

    // Lighthouse Smuggler Gold
    addGold(lhX + lhW * 0.35, lhTopY - 14, true);
    addGold(lhX + lhW * 0.65, lhTopY - 14, true);

    for (let r = 0; r < 4; r++) {
      blocks.push({
        id: createId('thatch'),
        x: lhX + lhW / 2,
        y: lhTopY - 16 - r * 16,
        width: (lhW + 32) - r * 28,
        height: 18,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 65,
        maxHp: 65,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 7,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    // Leaning ladder for harbor pier
    blocks.push({
      id: createId('ladder'),
      x: boatX - 12,
      y: groundY - 50,
      width: 16,
      height: 100,
      angle: 0.16,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 55,
      maxHp: 55,
      type: 'ladder',
      color: LADDER_COLOR,
      mass: 7,
      isStructural: false,
      broken: false,
      grounded: true
    });
  }

  // =========================================================================
  // LEVEL 9: Terraced Tea Estate Mill (Curing Barn + Gearhouse + Stilt Store)
  // =========================================================================
  else if (type === 'tea_mill') {
    // 1. Rustic Curing & Drying Barn (3 Pillars)
    const cureX = baseX;
    const cureW = 155;
    buildHut3Pillars(cureX, cureW, 110, 4, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'left',
      potSide: 'both',
      hasLantern: true,
      goldCount: 2
    });

    // 2. Central Tea Processing Elevator Tower (3 Tiers, 3 Pillars per Tier)
    const towX = cureX + cureW + 28;
    const towW = 180;
    const towH1 = 95;
    const towH2 = 85;
    const towH3 = 70;

    // Floor 1 Posts (3 Pillars)
    [towX, towX + towW / 2, towX + towW].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: groundY - towH1 / 2,
        width: 18,
        height: towH1,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 160,
        maxHp: 160,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 17,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 4
      });
    });

    const towDeck1Y = groundY - towH1 - 6;
    blocks.push({
      id: createId('beam'),
      x: towX + towW / 2,
      y: towDeck1Y,
      width: towW + 28,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 155,
      maxHp: 155,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 16,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    addGold(towX + towW * 0.35, towDeck1Y - 12, false);
    addGold(towX + towW * 0.65, towDeck1Y - 12, false);

    // Floor 2 Posts (3 Pillars)
    [towX + 8, towX + towW / 2, towX + towW - 8].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: towDeck1Y - towH2 / 2,
        width: 16,
        height: towH2,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 135,
        maxHp: 135,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 14,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 4
      });
    });

    const towDeck2Y = towDeck1Y - towH2 - 6;
    blocks.push({
      id: createId('beam'),
      x: towX + towW / 2,
      y: towDeck2Y,
      width: towW + 22,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 140,
      maxHp: 140,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 14,
      isStructural: true,
      broken: false,
      grounded: true
    });

    addGold(towX + towW * 0.5, towDeck2Y - 12, true);

    // Floor 3 Attic Posts (3 Pillars)
    [towX + 16, towX + towW / 2, towX + towW - 16].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: towDeck2Y - towH3 / 2,
        width: 14,
        height: towH3,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 110,
        maxHp: 110,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 11,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 3
      });
    });

    const towTopY = towDeck2Y - towH3 - 6;
    blocks.push({
      id: createId('beam'),
      x: towX + towW / 2,
      y: towTopY,
      width: towW + 16,
      height: 12,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 125,
      maxHp: 125,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 12,
      isStructural: true,
      broken: false,
      grounded: true
    });

    for (let r = 0; r < 4; r++) {
      blocks.push({
        id: createId('thatch'),
        x: towX + towW / 2,
        y: towTopY - 14 - r * 16,
        width: (towW + 26) - r * 28,
        height: 18,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 65,
        maxHp: 65,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 7,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    // 3. Right Tea Leaf Stilt Granary (3 Stilts + 3 Pillars)
    const granX = towX + towW + 28;
    const granW = 150;
    const granStiltH = 65;

    [granX, granX + granW / 2, granX + granW].forEach((sx) => {
      blocks.push({
        id: createId('stilt'),
        x: sx,
        y: groundY - granStiltH / 2,
        width: 16,
        height: granStiltH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 125,
        maxHp: 125,
        type: 'stilt',
        color: STILT_COLOR,
        mass: 13,
        isStructural: true,
        broken: false,
        grounded: true
      });
    });

    const granDeckY = groundY - granStiltH - 6;
    blocks.push({
      id: createId('beam'),
      x: granX + granW / 2,
      y: granDeckY,
      width: granW + 24,
      height: 13,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 135,
      maxHp: 135,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 13,
      isStructural: true,
      broken: false,
      grounded: true
    });

    const granBarnH = 80;
    [granX + 5, granX + granW / 2, granX + granW - 5].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: granDeckY - granBarnH / 2,
        width: 14,
        height: granBarnH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 110,
        maxHp: 110,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 11,
        isStructural: true,
        broken: false,
        grounded: true
      });
    });

    const granTopY = granDeckY - granBarnH - 6;
    blocks.push({
      id: createId('beam'),
      x: granX + granW / 2,
      y: granTopY,
      width: granW + 20,
      height: 12,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 120,
      maxHp: 120,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 12,
      isStructural: true,
      broken: false,
      grounded: true
    });

    addGold(granX + granW * 0.35, granDeckY - 12, true);
    addGold(granX + granW * 0.65, granDeckY - 12, true);

    for (let r = 0; r < 3; r++) {
      blocks.push({
        id: createId('thatch'),
        x: granX + granW / 2,
        y: granTopY - 12 - r * 16,
        width: (granW + 24) - r * 28,
        height: 18,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 60,
        maxHp: 60,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 6,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }
  }

  // =========================================================================
  // LEVEL 10: The Imperial Bamboo Citadel (Twin Fortified Bastions + Royal Keep)
  // =========================================================================
  else if (type === 'imperial_citadel') {
    // 1. West Bastion Watchtower (3 Pillars)
    const westX = baseX;
    const westW = 150;
    buildHut3Pillars(westX, westW, 115, 4, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'left',
      potSide: 'both',
      hasLantern: true,
      goldCount: 2
    });

    // 2. Grand Central Imperial Keep (3 Massive Floors, 3 Pillars per Floor)
    const impX = westX + westW + 30;
    const impW = 220;
    const impH1 = 100;
    const impH2 = 85;
    const impH3 = 75;

    // Floor 1 Imperial Columns (3 Heavy Pillars)
    [impX, impX + impW / 2, impX + impW].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: groundY - impH1 / 2,
        width: 19,
        height: impH1,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 175,
        maxHp: 175,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 19,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 5
      });
    });

    const impDeck1Y = groundY - impH1 - 6;
    blocks.push({
      id: createId('beam'),
      x: impX + impW / 2,
      y: impDeck1Y,
      width: impW + 36,
      height: 16,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 175,
      maxHp: 175,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 18,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 6
    });

    addGold(impX + impW * 0.28, impDeck1Y - 14, false);
    addGold(impX + impW * 0.72, impDeck1Y - 14, false);

    // Floor 2 Imperial Chambers (3 Pillars)
    [impX + 12, impX + impW / 2, impX + impW - 12].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: impDeck1Y - impH2 / 2,
        width: 17,
        height: impH2,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 145,
        maxHp: 145,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 15,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 4
      });
    });

    const impDeck2Y = impDeck1Y - impH2 - 6;
    blocks.push({
      id: createId('beam'),
      x: impX + impW / 2,
      y: impDeck2Y,
      width: impW + 28,
      height: 15,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 160,
      maxHp: 160,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 16,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    addGold(impX + impW * 0.5, impDeck2Y - 14, true);

    // Floor 3 Crown Pavilion (3 Pillars)
    [impX + 24, impX + impW / 2, impX + impW - 24].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: impDeck2Y - impH3 / 2,
        width: 15,
        height: impH3,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 125,
        maxHp: 125,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 13,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 3
      });
    });

    const impTopY = impDeck2Y - impH3 - 6;
    blocks.push({
      id: createId('beam'),
      x: impX + impW / 2,
      y: impTopY,
      width: impW + 22,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 145,
      maxHp: 145,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 14,
      isStructural: true,
      broken: false,
      grounded: true
    });

    // Imperial Pavilion Lanterns
    blocks.push({
      id: createId('lantern'),
      x: impX + 35,
      y: impTopY + 20,
      width: 16,
      height: 22,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 35,
      maxHp: 35,
      type: 'lantern',
      color: LANTERN_COLOR,
      mass: 3,
      isStructural: false,
      broken: false,
      grounded: true,
      hanging: true
    });
    blocks.push({
      id: createId('lantern'),
      x: impX + impW - 35,
      y: impTopY + 20,
      width: 16,
      height: 22,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 35,
      maxHp: 35,
      type: 'lantern',
      color: LANTERN_COLOR,
      mass: 3,
      isStructural: false,
      broken: false,
      grounded: true,
      hanging: true
    });

    // Imperial Treasure Vault Gold
    addGold(impX + impW * 0.38, impTopY - 14, true);
    addGold(impX + impW * 0.62, impTopY - 14, true);

    // 5 Majestic Thatch Roof Tiers
    for (let r = 0; r < 5; r++) {
      blocks.push({
        id: createId('thatch'),
        x: impX + impW / 2,
        y: impTopY - 14 - r * 18,
        width: (impW + 44) - r * 34,
        height: 20,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 80,
        maxHp: 80,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 8,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    // 3. East Treasury Bastion (3 Pillars)
    const eastX = impX + impW + 30;
    const eastW = 160;
    buildHut3Pillars(eastX, eastW, 110, 4, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'right',
      potSide: 'both',
      hasLantern: true,
      goldCount: 4
    });
  }

  // 11. Ancient Floating River Citadel (Level 11)
  else if (type === 'floating_citadel') {
    // 1. West Fishery Pier on Submerged Stilts
    const pierX = baseX;
    const pierW = 150;
    const pierStiltH = 65;
    const pierDeckY = groundY - pierStiltH;

    // Submerged Water Stilts (3 Pilings)
    [pierX, pierX + pierW / 2, pierX + pierW].forEach((sx) => {
      blocks.push({
        id: createId('stilt'),
        x: sx,
        y: groundY - pierStiltH / 2,
        width: 14,
        height: pierStiltH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 110,
        maxHp: 110,
        type: 'stilt',
        color: STILT_COLOR,
        mass: 14,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 3
      });
    });

    // Pier Deck Platform Beam
    blocks.push({
      id: createId('beam'),
      x: pierX + pierW / 2,
      y: pierDeckY,
      width: pierW + 20,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 125,
      maxHp: 125,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 14,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Pier Fishery Outpost (3 Posts rising from deck)
    const pierPostH = 90;
    const pierTopY = pierDeckY - pierPostH;
    [pierX, pierX + pierW / 2, pierX + pierW].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: pierDeckY - pierPostH / 2,
        width: 14,
        height: pierPostH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 105,
        maxHp: 105,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 11,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 3
      });
    });

    // Pier Eaves Beam
    blocks.push({
      id: createId('beam'),
      x: pierX + pierW / 2,
      y: pierTopY - 5,
      width: pierW + 26,
      height: 12,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 100,
      maxHp: 100,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 10,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 4
    });

    // Pier Wall Panel
    blocks.push({
      id: createId('wall'),
      x: pierX + pierW / 2,
      y: pierDeckY - pierPostH * 0.45,
      width: pierW - 24,
      height: pierPostH * 0.75,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 75,
      maxHp: 75,
      type: 'wall',
      color: BAMBOO_WALL_COLOR,
      mass: 8,
      isStructural: false,
      broken: false,
      grounded: true
    });

    // Pier Thatch Roof Tiers (3 tiers)
    for (let r = 0; r < 3; r++) {
      blocks.push({
        id: createId('thatch'),
        x: pierX + pierW / 2,
        y: pierTopY - 14 - r * 16,
        width: (pierW + 30) - r * 28,
        height: 18,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 60,
        maxHp: 60,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 6,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    // River Ladder climbing to pier deck
    blocks.push({
      id: createId('ladder'),
      x: pierX - 12,
      y: groundY - pierStiltH * 0.75,
      width: 16,
      height: pierStiltH + 20,
      angle: 0.16,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 55,
      maxHp: 55,
      type: 'ladder',
      color: LADDER_COLOR,
      mass: 7,
      isStructural: false,
      broken: false,
      grounded: true
    });

    // Fishery Urn & Lantern
    blocks.push({
      id: createId('pot'),
      x: pierX + 16,
      y: pierDeckY - 12,
      width: 18,
      height: 20,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 35,
      maxHp: 35,
      type: 'pot',
      color: POT_COLOR,
      mass: 4,
      isStructural: false,
      broken: false,
      grounded: true
    });
    blocks.push({
      id: createId('lantern'),
      x: pierX + pierW - 20,
      y: pierTopY + 18,
      width: 15,
      height: 20,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 35,
      maxHp: 35,
      type: 'lantern',
      color: LANTERN_COLOR,
      mass: 3,
      isStructural: false,
      broken: false,
      grounded: true,
      hanging: true
    });
    addGold(pierX + pierW * 0.35, pierDeckY - 10, false);
    addGold(pierX + pierW * 0.70, pierDeckY - 10, true);

    // Suspension Walkway 1 connecting Pier to Central Pavilion
    const walk1X = pierX + pierW + 18;
    blocks.push({
      id: createId('beam'),
      x: walk1X,
      y: pierDeckY + 2,
      width: 42,
      height: 11,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 85,
      maxHp: 85,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 8,
      isStructural: true,
      broken: false,
      grounded: true
    });

    // 2. Central Grand Floating River Pavilion (4 Heavy Piling Columns & Multi-Tier Pagoda)
    const pavX = pierX + pierW + 35;
    const pavW = 210;
    const pavStiltH = 75;
    const pavDeckY = groundY - pavStiltH;

    // 4 Heavy Water Piling Stilts
    const pavCols = [pavX, pavX + pavW * 0.33, pavX + pavW * 0.67, pavX + pavW];
    pavCols.forEach((px) => {
      blocks.push({
        id: createId('stilt'),
        x: px,
        y: groundY - pavStiltH / 2,
        width: 16,
        height: pavStiltH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 130,
        maxHp: 130,
        type: 'stilt',
        color: STILT_COLOR,
        mass: 16,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 4
      });
    });

    // Grand Deck Beam
    blocks.push({
      id: createId('beam'),
      x: pavX + pavW / 2,
      y: pavDeckY,
      width: pavW + 28,
      height: 16,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 140,
      maxHp: 140,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 16,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Main Pavilion Hall Pillars (4 Pillars)
    const pavHallH = 125;
    const pavHallTopY = pavDeckY - pavHallH;
    pavCols.forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: pavDeckY - pavHallH / 2,
        width: 15,
        height: pavHallH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 120,
        maxHp: 120,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 13,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 4
      });
    });

    // Mid-Hall Gallery Beam
    blocks.push({
      id: createId('beam'),
      x: pavX + pavW / 2,
      y: pavDeckY - pavHallH * 0.5,
      width: pavW + 16,
      height: 12,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 115,
      maxHp: 115,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 12,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 4
    });

    // Pavilion Upper Observation Deck Beam
    blocks.push({
      id: createId('beam'),
      x: pavX + pavW / 2,
      y: pavHallTopY,
      width: pavW + 36,
      height: 15,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 135,
      maxHp: 135,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 15,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Woven Sanctuary Wall Backing
    blocks.push({
      id: createId('wall'),
      x: pavX + pavW / 2,
      y: pavDeckY - pavHallH * 0.45,
      width: pavW - 32,
      height: pavHallH * 0.72,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 95,
      maxHp: 95,
      type: 'wall',
      color: BAMBOO_WALL_COLOR,
      mass: 10,
      isStructural: false,
      broken: false,
      grounded: true
    });

    // Hanging River Lanterns
    blocks.push({
      id: createId('lantern'),
      x: pavX + 24,
      y: pavHallTopY + 22,
      width: 16,
      height: 22,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 35,
      maxHp: 35,
      type: 'lantern',
      color: LANTERN_COLOR,
      mass: 3,
      isStructural: false,
      broken: false,
      grounded: true,
      hanging: true
    });
    blocks.push({
      id: createId('lantern'),
      x: pavX + pavW - 24,
      y: pavHallTopY + 22,
      width: 16,
      height: 22,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 35,
      maxHp: 35,
      type: 'lantern',
      color: LANTERN_COLOR,
      mass: 3,
      isStructural: false,
      broken: false,
      grounded: true,
      hanging: true
    });

    // 4 Stored Gold Treasures
    addGold(pavX + pavW * 0.30, pavDeckY - 12, false);
    addGold(pavX + pavW * 0.70, pavDeckY - 12, true);
    addGold(pavX + pavW * 0.40, pavHallTopY - 12, true);
    addGold(pavX + pavW * 0.60, pavHallTopY - 12, false);

    // 5 Flared River Thatch Roof Tiers
    for (let r = 0; r < 5; r++) {
      blocks.push({
        id: createId('thatch'),
        x: pavX + pavW / 2,
        y: pavHallTopY - 14 - r * 17,
        width: (pavW + 42) - r * 30,
        height: 19,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 75,
        maxHp: 75,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 7,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    // Suspension Walkway 2 connecting Pavilion to East Outpost
    const walk2X = pavX + pavW + 16;
    blocks.push({
      id: createId('beam'),
      x: walk2X,
      y: pavDeckY + 4,
      width: 36,
      height: 11,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 80,
      maxHp: 80,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 8,
      isStructural: true,
      broken: false,
      grounded: true
    });

    // 3. East Floating Lighthouse Outpost (3 Pillars on Stilts)
    const eastX = pavX + pavW + 35;
    const eastW = 145;
    const eastStiltH = 65;
    const eastDeckY = groundY - eastStiltH;

    // East Stilts
    [eastX, eastX + eastW / 2, eastX + eastW].forEach((sx) => {
      blocks.push({
        id: createId('stilt'),
        x: sx,
        y: groundY - eastStiltH / 2,
        width: 14,
        height: eastStiltH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 110,
        maxHp: 110,
        type: 'stilt',
        color: STILT_COLOR,
        mass: 13,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 3
      });
    });

    // East Deck
    blocks.push({
      id: createId('beam'),
      x: eastX + eastW / 2,
      y: eastDeckY,
      width: eastW + 18,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 120,
      maxHp: 120,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 13,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 4
    });

    // East Watchtower (3 Posts)
    const eastPostH = 115;
    const eastTopY = eastDeckY - eastPostH;
    [eastX, eastX + eastW / 2, eastX + eastW].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: eastDeckY - eastPostH / 2,
        width: 14,
        height: eastPostH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 110,
        maxHp: 110,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 12,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 4
      });
    });

    // East Eaves Beam
    blocks.push({
      id: createId('beam'),
      x: eastX + eastW / 2,
      y: eastTopY - 6,
      width: eastW + 24,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 110,
      maxHp: 110,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 11,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 4
    });

    // East Wall Panel
    blocks.push({
      id: createId('wall'),
      x: eastX + eastW / 2,
      y: eastDeckY - eastPostH * 0.45,
      width: eastW - 24,
      height: eastPostH * 0.72,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 80,
      maxHp: 80,
      type: 'wall',
      color: BAMBOO_WALL_COLOR,
      mass: 8,
      isStructural: false,
      broken: false,
      grounded: true
    });

    // 4 Tiers of Steep Roof Thatch
    for (let r = 0; r < 4; r++) {
      blocks.push({
        id: createId('thatch'),
        x: eastX + eastW / 2,
        y: eastTopY - 14 - r * 17,
        width: (eastW + 28) - r * 26,
        height: 18,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 65,
        maxHp: 65,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 6,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    // East Ladder, Pot & Lantern
    blocks.push({
      id: createId('ladder'),
      x: eastX + eastW + 12,
      y: groundY - eastStiltH * 0.75,
      width: 16,
      height: eastStiltH + 20,
      angle: -0.16,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 55,
      maxHp: 55,
      type: 'ladder',
      color: LADDER_COLOR,
      mass: 7,
      isStructural: false,
      broken: false,
      grounded: true
    });
    blocks.push({
      id: createId('lantern'),
      x: eastX + eastW - 18,
      y: eastTopY + 20,
      width: 16,
      height: 22,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 35,
      maxHp: 35,
      type: 'lantern',
      color: LANTERN_COLOR,
      mass: 3,
      isStructural: false,
      broken: false,
      grounded: true,
      hanging: true
    });
    addGold(eastX + eastW * 0.35, eastDeckY - 12, true);
    addGold(eastX + eastW * 0.70, eastDeckY - 12, false);
    addGold(eastX + eastW * 0.50, eastTopY - 12, true);
  }

  // 12. Dragon Ridge Cloud Fortress (Level 12)
  else if (type === 'dragon_ridge') {
    // Stepped terraced mountain ridge ascending like dragon spine:
    // Terrace 1: Lower West Rampart (at ground)
    const t1X = baseX;
    const t1W = 145;
    buildHut3Pillars(t1X, t1W, 95, 3, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'left',
      potSide: 'both',
      hasLantern: true,
      goldCount: 3
    });

    // Terrace 2: Mid-Elevation Spine Keep (on 50-height foundation stilts)
    const t2X = t1X + t1W + 25;
    const t2W = 165;
    const t2StiltH = 50;
    const t2DeckY = groundY - t2StiltH;

    // Foundation Stilts for Terrace 2
    [t2X, t2X + t2W / 2, t2X + t2W].forEach((sx) => {
      blocks.push({
        id: createId('stilt'),
        x: sx,
        y: groundY - t2StiltH / 2,
        width: 15,
        height: t2StiltH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 120,
        maxHp: 120,
        type: 'stilt',
        color: STILT_COLOR,
        mass: 14,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 3
      });
    });

    // Terrace 2 Deck Beam
    blocks.push({
      id: createId('beam'),
      x: t2X + t2W / 2,
      y: t2DeckY,
      width: t2W + 22,
      height: 15,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 130,
      maxHp: 130,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 15,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 4
    });

    // Terrace 2 Keep Posts (3 Heavy Pillars)
    const t2PostH = 120;
    const t2TopY = t2DeckY - t2PostH;
    [t2X, t2X + t2W / 2, t2X + t2W].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: t2DeckY - t2PostH / 2,
        width: 15,
        height: t2PostH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 120,
        maxHp: 120,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 13,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 4
      });
    });

    // Terrace 2 Eaves Beam
    blocks.push({
      id: createId('beam'),
      x: t2X + t2W / 2,
      y: t2TopY - 6,
      width: t2W + 30,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 115,
      maxHp: 115,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 12,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Terrace 2 Wall
    blocks.push({
      id: createId('wall'),
      x: t2X + t2W / 2,
      y: t2DeckY - t2PostH * 0.45,
      width: t2W - 24,
      height: t2PostH * 0.72,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 85,
      maxHp: 85,
      type: 'wall',
      color: BAMBOO_WALL_COLOR,
      mass: 9,
      isStructural: false,
      broken: false,
      grounded: true
    });

    // Terrace 2 Dragon Thatch Tiers (4 tiers)
    for (let r = 0; r < 4; r++) {
      blocks.push({
        id: createId('thatch'),
        x: t2X + t2W / 2,
        y: t2TopY - 14 - r * 17,
        width: (t2W + 36) - r * 28,
        height: 19,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 70,
        maxHp: 70,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 7,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    addGold(t2X + t2W * 0.30, t2DeckY - 12, false);
    addGold(t2X + t2W * 0.70, t2DeckY - 12, true);
    addGold(t2X + t2W * 0.50, t2TopY - 12, true);

    // Terrace 3: High Peak Dragon Shrine (on 100-height mountain stilts!)
    const t3X = t2X + t2W + 25;
    const t3W = 150;
    const t3StiltH = 100;
    const t3DeckY = groundY - t3StiltH;

    // Mountain Stilts (3 massive pilings)
    [t3X, t3X + t3W / 2, t3X + t3W].forEach((sx) => {
      blocks.push({
        id: createId('stilt'),
        x: sx,
        y: groundY - t3StiltH / 2,
        width: 16,
        height: t3StiltH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 140,
        maxHp: 140,
        type: 'stilt',
        color: STILT_COLOR,
        mass: 17,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 5
      });
    });

    // Terrace 3 High Deck Beam
    blocks.push({
      id: createId('beam'),
      x: t3X + t3W / 2,
      y: t3DeckY,
      width: t3W + 26,
      height: 16,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 135,
      maxHp: 135,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 16,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 4
    });

    // Terrace 3 Peak Shrine Posts (3 Tall Pagoda Pillars)
    const t3PostH = 135;
    const t3TopY = t3DeckY - t3PostH;
    [t3X, t3X + t3W / 2, t3X + t3W].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: t3DeckY - t3PostH / 2,
        width: 15,
        height: t3PostH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 125,
        maxHp: 125,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 14,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 5
      });
    });

    // Terrace 3 Cantilevered Dragon Eaves Beam
    blocks.push({
      id: createId('beam'),
      x: t3X + t3W / 2,
      y: t3TopY - 6,
      width: t3W + 40,
      height: 15,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 120,
      maxHp: 120,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 14,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Terrace 3 Peak Wall
    blocks.push({
      id: createId('wall'),
      x: t3X + t3W / 2,
      y: t3DeckY - t3PostH * 0.45,
      width: t3W - 24,
      height: t3PostH * 0.72,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 90,
      maxHp: 90,
      type: 'wall',
      color: BAMBOO_WALL_COLOR,
      mass: 9,
      isStructural: false,
      broken: false,
      grounded: true
    });

    // Cantilevered Dragon Pagoda Roof (5 wide tiers)
    for (let r = 0; r < 5; r++) {
      blocks.push({
        id: createId('thatch'),
        x: t3X + t3W / 2,
        y: t3TopY - 14 - r * 18,
        width: (t3W + 48) - r * 28,
        height: 20,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 75,
        maxHp: 75,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 8,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    // High Peak Wind Lanterns & Relic Gold
    blocks.push({
      id: createId('lantern'),
      x: t3X + 20,
      y: t3TopY + 22,
      width: 16,
      height: 22,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 35,
      maxHp: 35,
      type: 'lantern',
      color: LANTERN_COLOR,
      mass: 3,
      isStructural: false,
      broken: false,
      grounded: true,
      hanging: true
    });
    blocks.push({
      id: createId('lantern'),
      x: t3X + t3W - 20,
      y: t3TopY + 22,
      width: 16,
      height: 22,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 35,
      maxHp: 35,
      type: 'lantern',
      color: LANTERN_COLOR,
      mass: 3,
      isStructural: false,
      broken: false,
      grounded: true,
      hanging: true
    });
    blocks.push({
      id: createId('ladder'),
      x: t3X + t3W + 12,
      y: groundY - t3StiltH * 0.75,
      width: 16,
      height: t3StiltH + 24,
      angle: -0.16,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 60,
      maxHp: 60,
      type: 'ladder',
      color: LADDER_COLOR,
      mass: 8,
      isStructural: false,
      broken: false,
      grounded: true
    });

    addGold(t3X + t3W * 0.32, t3DeckY - 12, true);
    addGold(t3X + t3W * 0.68, t3DeckY - 12, false);
    addGold(t3X + t3W * 0.50, t3TopY - 14, true);
    addGold(t3X + t3W * 0.50, t3TopY - 70, false);
  }

  // 13. Grand Spice Merchant Bazaar (Level 13)
  else if (type === 'spice_bazaar') {
    // 1. West Spice & Herb Storehouse (Packed with Clay Jars)
    const spX = baseX;
    const spW = 145;
    buildHut3Pillars(spX, spW, 105, 3, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'left',
      potSide: 'both',
      hasLantern: true,
      goldCount: 3
    });

    // Extra spice jars on west terrace
    blocks.push({
      id: createId('pot'),
      x: spX + 25,
      y: groundY - 12,
      width: 18,
      height: 22,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 35,
      maxHp: 35,
      type: 'pot',
      color: POT_COLOR,
      mass: 4,
      isStructural: false,
      broken: false,
      grounded: true
    });
    blocks.push({
      id: createId('pot'),
      x: spX + spW - 25,
      y: groundY - 12,
      width: 18,
      height: 22,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 35,
      maxHp: 35,
      type: 'pot',
      color: POT_COLOR,
      mass: 4,
      isStructural: false,
      broken: false,
      grounded: true
    });

    // 2. Central Grand Domed Grain & Spice Arcade (4 Heavy Columns & Arched Vault Canopy)
    const arcX = spX + spW + 25;
    const arcW = 220;
    const arcH = 155;
    const arcTopY = groundY - arcH;

    // 4 Massive Bazaar Colonnade Pillars
    const arcCols = [arcX, arcX + arcW * 0.33, arcX + arcW * 0.67, arcX + arcW];
    arcCols.forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: groundY - arcH / 2,
        width: 16,
        height: arcH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 130,
        maxHp: 130,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 15,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 5
      });
    });

    // Lower Counter Beam (Market trading deck)
    const lowerDeckY = groundY - 45;
    blocks.push({
      id: createId('beam'),
      x: arcX + arcW / 2,
      y: lowerDeckY,
      width: arcW + 20,
      height: 12,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 115,
      maxHp: 115,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 12,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 4
    });

    // Mid Storage Loft Beam
    const midDeckY = groundY - 95;
    blocks.push({
      id: createId('beam'),
      x: arcX + arcW / 2,
      y: midDeckY,
      width: arcW + 24,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 125,
      maxHp: 125,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 14,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Top Eaves Arch Beam
    blocks.push({
      id: createId('beam'),
      x: arcX + arcW / 2,
      y: arcTopY - 6,
      width: arcW + 36,
      height: 16,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 140,
      maxHp: 140,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 16,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Twin Woven Walls (Left and Right bays of the arcade)
    blocks.push({
      id: createId('wall'),
      x: arcX + arcW * 0.25,
      y: groundY - arcH * 0.45,
      width: arcW * 0.42,
      height: arcH * 0.72,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 85,
      maxHp: 85,
      type: 'wall',
      color: BAMBOO_WALL_COLOR,
      mass: 9,
      isStructural: false,
      broken: false,
      grounded: true
    });
    blocks.push({
      id: createId('wall'),
      x: arcX + arcW * 0.75,
      y: groundY - arcH * 0.45,
      width: arcW * 0.42,
      height: arcH * 0.72,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 85,
      maxHp: 85,
      type: 'wall',
      color: BAMBOO_WALL_COLOR,
      mass: 9,
      isStructural: false,
      broken: false,
      grounded: true
    });

    // 5 Tiers of Stepped Domed Canopy Thatch
    for (let r = 0; r < 5; r++) {
      blocks.push({
        id: createId('thatch'),
        x: arcX + arcW / 2,
        y: arcTopY - 14 - r * 18,
        width: (arcW + 44) - r * 30,
        height: 20,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 75,
        maxHp: 75,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 8,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    // Bazaar Jars on lower deck
    blocks.push({
      id: createId('pot'),
      x: arcX + arcW * 0.20,
      y: lowerDeckY - 12,
      width: 18,
      height: 22,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 35,
      maxHp: 35,
      type: 'pot',
      color: POT_COLOR,
      mass: 4,
      isStructural: false,
      broken: false,
      grounded: true
    });
    blocks.push({
      id: createId('pot'),
      x: arcX + arcW * 0.80,
      y: lowerDeckY - 12,
      width: 18,
      height: 22,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 35,
      maxHp: 35,
      type: 'pot',
      color: POT_COLOR,
      mass: 4,
      isStructural: false,
      broken: false,
      grounded: true
    });

    // Bazaar Hanging Lanterns
    blocks.push({
      id: createId('lantern'),
      x: arcX + 30,
      y: arcTopY + 22,
      width: 16,
      height: 22,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 35,
      maxHp: 35,
      type: 'lantern',
      color: LANTERN_COLOR,
      mass: 3,
      isStructural: false,
      broken: false,
      grounded: true,
      hanging: true
    });
    blocks.push({
      id: createId('lantern'),
      x: arcX + arcW - 30,
      y: arcTopY + 22,
      width: 16,
      height: 22,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 35,
      maxHp: 35,
      type: 'lantern',
      color: LANTERN_COLOR,
      mass: 3,
      isStructural: false,
      broken: false,
      grounded: true,
      hanging: true
    });

    // 5 Hidden Gold Caches
    addGold(arcX + arcW * 0.25, midDeckY - 12, true);
    addGold(arcX + arcW * 0.50, midDeckY - 12, false);
    addGold(arcX + arcW * 0.75, midDeckY - 12, true);
    addGold(arcX + arcW * 0.38, arcTopY - 12, false);
    addGold(arcX + arcW * 0.62, arcTopY - 12, true);

    // 3. East Precious Silk & Gem Vault (3 Pillars, Double Wall)
    const eastX = arcX + arcW + 25;
    const eastW = 155;
    buildHut3Pillars(eastX, eastW, 115, 4, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'right',
      potSide: 'both',
      hasLantern: true,
      goldCount: 4
    });
  }

  // 14. Sky-High Bamboo Colosseum (Level 14)
  else if (type === 'bamboo_colosseum') {
    // 1. West Gladiator Gallery & Armory Tower (3 Pillars)
    const westX = baseX;
    const westW = 155;
    buildHut3Pillars(westX, westW, 125, 4, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'left',
      potSide: 'both',
      hasLantern: true,
      goldCount: 3
    });

    // 2. Central Monumental Imperial Colosseum Keep (4-story Arena reaching 250 units high!)
    const colX = westX + westW + 25;
    const colW = 230;
    const colH = 175;
    const colTopY = groundY - colH;

    // 4 Massive Colosseum Foundation Columns
    const colPosts = [colX, colX + colW * 0.33, colX + colW * 0.67, colX + colW];
    colPosts.forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: groundY - colH / 2,
        width: 17,
        height: colH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 145,
        maxHp: 145,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 17,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 6
      });
    });

    // Floor 1: Arena Ring Colonnade Beam
    const f1Y = groundY - 55;
    blocks.push({
      id: createId('beam'),
      x: colX + colW / 2,
      y: f1Y,
      width: colW + 24,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 130,
      maxHp: 130,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 14,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Floor 2: Spectator Balcony Deck Beam
    const f2Y = groundY - 110;
    blocks.push({
      id: createId('beam'),
      x: colX + colW / 2,
      y: f2Y,
      width: colW + 28,
      height: 15,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 135,
      maxHp: 135,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 15,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Floor 3: Imperial Royal Box Deck Beam
    blocks.push({
      id: createId('beam'),
      x: colX + colW / 2,
      y: colTopY - 6,
      width: colW + 38,
      height: 16,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 145,
      maxHp: 145,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 16,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Triple Woven Wall Backing Panels
    blocks.push({
      id: createId('wall'),
      x: colX + colW / 2,
      y: groundY - colH * 0.48,
      width: colW - 30,
      height: colH * 0.76,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 105,
      maxHp: 105,
      type: 'wall',
      color: BAMBOO_WALL_COLOR,
      mass: 11,
      isStructural: false,
      broken: false,
      grounded: true
    });

    // Floor 4: Sky-High Crown Pavilion (2 Central Columns rising above the imperial box!)
    const crownH = 65;
    const crownTopY = colTopY - crownH;
    const crownPosts = [colX + colW * 0.35, colX + colW * 0.65];
    crownPosts.forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: colTopY - crownH / 2,
        width: 15,
        height: crownH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 120,
        maxHp: 120,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 12,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 3
      });
    });

    // Crown Pavilion Top Beam
    blocks.push({
      id: createId('beam'),
      x: colX + colW / 2,
      y: crownTopY - 6,
      width: colW * 0.82,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 125,
      maxHp: 125,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 13,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 4
    });

    // 6 Majestic Imperial Thatch Roof Tiers (Crown Dome)
    for (let r = 0; r < 6; r++) {
      blocks.push({
        id: createId('thatch'),
        x: colX + colW / 2,
        y: crownTopY - 14 - r * 18,
        width: (colW + 48) - r * 32,
        height: 20,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 85,
        maxHp: 85,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 9,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    // Imperial Triumphal Lanterns
    blocks.push({
      id: createId('lantern'),
      x: colX + 28,
      y: colTopY + 22,
      width: 16,
      height: 22,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 35,
      maxHp: 35,
      type: 'lantern',
      color: LANTERN_COLOR,
      mass: 3,
      isStructural: false,
      broken: false,
      grounded: true,
      hanging: true
    });
    blocks.push({
      id: createId('lantern'),
      x: colX + colW - 28,
      y: colTopY + 22,
      width: 16,
      height: 22,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 35,
      maxHp: 35,
      type: 'lantern',
      color: LANTERN_COLOR,
      mass: 3,
      isStructural: false,
      broken: false,
      grounded: true,
      hanging: true
    });
    blocks.push({
      id: createId('lantern'),
      x: colX + colW / 2,
      y: crownTopY + 18,
      width: 16,
      height: 22,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 35,
      maxHp: 35,
      type: 'lantern',
      color: LANTERN_COLOR,
      mass: 3,
      isStructural: false,
      broken: false,
      grounded: true,
      hanging: true
    });

    // 6 Royal Gold Caches inside the Colosseum
    addGold(colX + colW * 0.28, f1Y - 12, false);
    addGold(colX + colW * 0.72, f1Y - 12, true);
    addGold(colX + colW * 0.35, f2Y - 12, true);
    addGold(colX + colW * 0.65, f2Y - 12, false);
    addGold(colX + colW * 0.42, colTopY - 12, true);
    addGold(colX + colW * 0.58, crownTopY - 12, false);

    // 3. East Imperial Treasury Vault (3 Pillars, Fortified)
    const eastX = colX + colW + 25;
    const eastW = 160;
    buildHut3Pillars(eastX, eastW, 130, 4, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'right',
      potSide: 'both',
      hasLantern: true,
      goldCount: 4
    });
  }

  // 15. Celestial Bamboo Observatory (Level 15)
  else if (type === 'celestial_observatory') {
    // 1. West Stargazer Lookout Tower (3 Pillars)
    const westX = baseX;
    const westW = 150;
    buildHut3Pillars(westX, westW, 130, 4, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'left',
      potSide: 'both',
      hasLantern: true,
      goldCount: 3
    });

    // 2. Central High-Altitude Observation Rotunda
    const obsX = westX + westW + 25;
    const obsW = 230;
    const obsH = 175;
    const obsTopY = groundY - obsH;

    // 4 Soaring Observation Columns
    const obsPosts = [obsX, obsX + obsW * 0.33, obsX + obsW * 0.67, obsX + obsW];
    obsPosts.forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: groundY - obsH / 2,
        width: 17,
        height: obsH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 145,
        maxHp: 145,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 17,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 6
      });
    });

    // Floor 1: Astrolabe Gallery Beam
    const f1Y = groundY - 55;
    blocks.push({
      id: createId('beam'),
      x: obsX + obsW / 2,
      y: f1Y,
      width: obsW + 24,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 130,
      maxHp: 130,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 14,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Floor 2: Planetary Orrery Terrace Beam
    const f2Y = groundY - 110;
    blocks.push({
      id: createId('beam'),
      x: obsX + obsW / 2,
      y: f2Y,
      width: obsW + 28,
      height: 15,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 135,
      maxHp: 135,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 15,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Floor 3: Telescope Dome Deck Beam
    blocks.push({
      id: createId('beam'),
      x: obsX + obsW / 2,
      y: obsTopY - 6,
      width: obsW + 32,
      height: 16,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 140,
      maxHp: 140,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 16,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 6
    });

    // Rotunda Wall Panels (Chatai weave)
    blocks.push({
      id: createId('wall'),
      x: obsX + obsW / 2,
      y: (groundY + f1Y) / 2,
      width: obsW - 35,
      height: 40,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 85,
      maxHp: 85,
      type: 'wall',
      color: BAMBOO_WALL_COLOR,
      mass: 9,
      isStructural: false,
      broken: false,
      grounded: true
    });
    blocks.push({
      id: createId('wall'),
      x: obsX + obsW / 2,
      y: (f1Y + f2Y) / 2,
      width: obsW - 35,
      height: 40,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 85,
      maxHp: 85,
      type: 'wall',
      color: BAMBOO_WALL_COLOR,
      mass: 9,
      isStructural: false,
      broken: false,
      grounded: true
    });

    // 5-Tier Hemispherical Star Dome Roof
    const roofBaseY = obsTopY - 16;
    for (let r = 0; r < 5; r++) {
      const tierW = (obsW + 40) - (r * 32);
      blocks.push({
        id: createId('thatch'),
        x: obsX + obsW / 2,
        y: roofBaseY - (r * 18),
        width: tierW,
        height: 18,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 65,
        maxHp: 65,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 7,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    // Telescope Rafter Wings bracing the dome
    blocks.push({
      id: createId('rafter'),
      x: obsX + obsW * 0.22,
      y: obsTopY - 25,
      width: 48,
      height: 10,
      angle: -0.35,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 65,
      maxHp: 65,
      type: 'rafter',
      color: BAMBOO_POST_COLOR,
      mass: 5,
      isStructural: false,
      broken: false,
      grounded: true
    });
    blocks.push({
      id: createId('rafter'),
      x: obsX + obsW * 0.78,
      y: obsTopY - 25,
      width: 48,
      height: 10,
      angle: 0.35,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 65,
      maxHp: 65,
      type: 'rafter',
      color: BAMBOO_POST_COLOR,
      mass: 5,
      isStructural: false,
      broken: false,
      grounded: true
    });

    // Hanging Celestial Lanterns
    [obsX + 22, obsX + obsW / 2, obsX + obsW - 22].forEach((lx) => {
      blocks.push({
        id: createId('lantern'),
        x: lx,
        y: obsTopY + 16,
        width: 16,
        height: 22,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 35,
        maxHp: 35,
        type: 'lantern',
        color: LANTERN_COLOR,
        mass: 3,
        isStructural: false,
        broken: false,
        grounded: true,
        hanging: true
      });
    });

    // Astrolabe Gold Caches inside the Rotunda
    addGold(obsX + obsW * 0.25, f1Y - 12, false);
    addGold(obsX + obsW * 0.75, f1Y - 12, true);
    addGold(obsX + obsW * 0.32, f2Y - 12, true);
    addGold(obsX + obsW * 0.68, f2Y - 12, false);
    addGold(obsX + obsW * 0.50, obsTopY - 12, true);

    // 3. East Celestial Archive & Star Chart Library (3 Pillars)
    const eastX = obsX + obsW + 25;
    const eastW = 160;
    buildHut3Pillars(eastX, eastW, 125, 4, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'right',
      potSide: 'both',
      hasLantern: true,
      goldCount: 4
    });
  }

  // 16. Ancient Serpent Pagoda (Level 16)
  else if (type === 'serpent_temple') {
    // 1. West Ceremonial Naga Gatehouse (3 Pillars)
    const westX = baseX;
    const westW = 150;
    buildHut3Pillars(westX, westW, 120, 4, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'left',
      potSide: 'both',
      hasLantern: true,
      goldCount: 3
    });

    // 2. Central Multi-Tier Sacred Naga Sanctuary Pagoda
    const nagaX = westX + westW + 25;
    const nagaW = 230;
    const nagaH = 175;
    const nagaTopY = groundY - nagaH;

    // 4 Sacred Totem Posts
    const nagaPosts = [nagaX, nagaX + nagaW * 0.33, nagaX + nagaW * 0.67, nagaX + nagaW];
    nagaPosts.forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: groundY - nagaH / 2,
        width: 17,
        height: nagaH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 145,
        maxHp: 145,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 17,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 6
      });
    });

    // Floor 1: Naga Altar Base Beam
    const f1Y = groundY - 55;
    blocks.push({
      id: createId('beam'),
      x: nagaX + nagaW / 2,
      y: f1Y,
      width: nagaW + 26,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 130,
      maxHp: 130,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 14,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Floor 2: Relic Sanctum Beam
    const f2Y = groundY - 110;
    blocks.push({
      id: createId('beam'),
      x: nagaX + nagaW / 2,
      y: f2Y,
      width: nagaW + 30,
      height: 15,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 135,
      maxHp: 135,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 15,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Floor 3: Upper Serpent Hood Eaves Beam
    blocks.push({
      id: createId('beam'),
      x: nagaX + nagaW / 2,
      y: nagaTopY - 6,
      width: nagaW + 36,
      height: 16,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 140,
      maxHp: 140,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 16,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 6
    });

    // Wall panels for the relic sanctum
    blocks.push({
      id: createId('wall'),
      x: nagaX + nagaW / 2,
      y: (groundY + f1Y) / 2,
      width: nagaW - 35,
      height: 40,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 85,
      maxHp: 85,
      type: 'wall',
      color: BAMBOO_WALL_COLOR,
      mass: 9,
      isStructural: false,
      broken: false,
      grounded: true
    });
    blocks.push({
      id: createId('wall'),
      x: nagaX + nagaW / 2,
      y: (f1Y + f2Y) / 2,
      width: nagaW - 35,
      height: 40,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 85,
      maxHp: 85,
      type: 'wall',
      color: BAMBOO_WALL_COLOR,
      mass: 9,
      isStructural: false,
      broken: false,
      grounded: true
    });

    // 6-Tier Flared Serpent Hood Pagoda Roof
    const roofBaseY = nagaTopY - 16;
    for (let r = 0; r < 6; r++) {
      const tierW = (nagaW + 44) - (r * 28);
      blocks.push({
        id: createId('thatch'),
        x: nagaX + nagaW / 2,
        y: roofBaseY - (r * 18),
        width: tierW,
        height: 18,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 65,
        maxHp: 65,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 7,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    // Sacred Incense Pots at sanctuary base
    blocks.push({
      id: createId('pot'),
      x: nagaX - 16,
      y: groundY - 12,
      width: 18,
      height: 22,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 35,
      maxHp: 35,
      type: 'pot',
      color: POT_COLOR,
      mass: 4,
      isStructural: false,
      broken: false,
      grounded: true
    });
    blocks.push({
      id: createId('pot'),
      x: nagaX + nagaW + 16,
      y: groundY - 12,
      width: 18,
      height: 22,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 35,
      maxHp: 35,
      type: 'pot',
      color: POT_COLOR,
      mass: 4,
      isStructural: false,
      broken: false,
      grounded: true
    });

    // 4 Hanging Temple Lanterns
    [nagaX + 22, nagaX + nagaW * 0.4, nagaX + nagaW * 0.6, nagaX + nagaW - 22].forEach((lx) => {
      blocks.push({
        id: createId('lantern'),
        x: lx,
        y: nagaTopY + 16,
        width: 16,
        height: 22,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 35,
        maxHp: 35,
        type: 'lantern',
        color: LANTERN_COLOR,
        mass: 3,
        isStructural: false,
        broken: false,
        grounded: true,
        hanging: true
      });
    });

    // 6 Relic Gold Caches inside the Pagoda
    addGold(nagaX + nagaW * 0.28, f1Y - 12, false);
    addGold(nagaX + nagaW * 0.72, f1Y - 12, true);
    addGold(nagaX + nagaW * 0.35, f2Y - 12, true);
    addGold(nagaX + nagaW * 0.65, f2Y - 12, false);
    addGold(nagaX + nagaW * 0.42, nagaTopY - 12, true);
    addGold(nagaX + nagaW * 0.58, nagaTopY - 12, false);

    // 3. East Incense & Offering Treasury (3 Pillars)
    const eastX = nagaX + nagaW + 25;
    const eastW = 160;
    buildHut3Pillars(eastX, eastW, 125, 4, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'right',
      potSide: 'both',
      hasLantern: true,
      goldCount: 4
    });
  }

  // 17. Skyward Windmill Bastion (Level 17)
  else if (type === 'wind_mill_bastion') {
    // 1. West Windmill Tower
    const westX = baseX;
    const westW = 135;
    const towerH = 165;
    const towerTopY = groundY - towerH;

    // 3 Soaring Posts for West Tower
    [westX, westX + westW / 2, westX + westW].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: groundY - towerH / 2,
        width: 16,
        height: towerH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 135,
        maxHp: 135,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 15,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 6
      });
    });

    // West Tower Mid Beam
    blocks.push({
      id: createId('beam'),
      x: westX + westW / 2,
      y: groundY - 75,
      width: westW + 20,
      height: 13,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 115,
      maxHp: 115,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 12,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 4
    });

    // West Tower Top Beam
    blocks.push({
      id: createId('beam'),
      x: westX + westW / 2,
      y: towerTopY - 6,
      width: westW + 26,
      height: 15,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 130,
      maxHp: 130,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 14,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // West Windmill Vanes/Rafters
    blocks.push({
      id: createId('rafter'),
      x: westX + westW / 2 - 24,
      y: towerTopY - 25,
      width: 52,
      height: 11,
      angle: -0.45,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 60,
      maxHp: 60,
      type: 'rafter',
      color: BAMBOO_POST_COLOR,
      mass: 5,
      isStructural: false,
      broken: false,
      grounded: true
    });
    blocks.push({
      id: createId('rafter'),
      x: westX + westW / 2 + 24,
      y: towerTopY - 25,
      width: 52,
      height: 11,
      angle: 0.45,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 60,
      maxHp: 60,
      type: 'rafter',
      color: BAMBOO_POST_COLOR,
      mass: 5,
      isStructural: false,
      broken: false,
      grounded: true
    });

    // 4 Thatch Tiers for West Tower
    for (let r = 0; r < 4; r++) {
      const tierW = (westW + 32) - (r * 28);
      blocks.push({
        id: createId('thatch'),
        x: westX + westW / 2,
        y: towerTopY - 16 - (r * 18),
        width: tierW,
        height: 18,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 60,
        maxHp: 60,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 6,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    addGold(westX + westW * 0.3, groundY - 87, false);
    addGold(westX + westW * 0.7, groundY - 87, true);
    addGold(westX + westW / 2, towerTopY - 12, false);

    // 2. Central Milling Silo & Grain Depot (3 Ground Posts)
    const midX = westX + westW + 15;
    const midW = 140;
    const midH = 95;
    const midTopY = groundY - midH;

    [midX, midX + midW / 2, midX + midW].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: groundY - midH / 2,
        width: 15,
        height: midH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 110,
        maxHp: 110,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 12,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 4
      });
    });

    // Central Silo Deck Beam
    blocks.push({
      id: createId('beam'),
      x: midX + midW / 2,
      y: midTopY - 6,
      width: midW + 24,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 120,
      maxHp: 120,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 13,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 4
    });

    // Central Silo Wall
    blocks.push({
      id: createId('wall'),
      x: midX + midW / 2,
      y: groundY - midH * 0.45,
      width: midW - 24,
      height: midH * 0.75,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 80,
      maxHp: 80,
      type: 'wall',
      color: BAMBOO_WALL_COLOR,
      mass: 8,
      isStructural: false,
      broken: false,
      grounded: true
    });

    // Central Silo Thatch Roof
    for (let r = 0; r < 3; r++) {
      const tierW = (midW + 28) - (r * 30);
      blocks.push({
        id: createId('thatch'),
        x: midX + midW / 2,
        y: midTopY - 16 - (r * 18),
        width: tierW,
        height: 18,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 60,
        maxHp: 60,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 6,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    addGold(midX + midW * 0.3, midTopY - 12, true);
    addGold(midX + midW * 0.7, midTopY - 12, false);

    // 3. East Windmill Tower
    const eastX = midX + midW + 15;
    const eastW = 135;
    const eastTopY = groundY - towerH;

    // 3 Soaring Posts for East Tower
    [eastX, eastX + eastW / 2, eastX + eastW].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: groundY - towerH / 2,
        width: 16,
        height: towerH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 135,
        maxHp: 135,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 15,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 6
      });
    });

    // East Tower Mid Beam
    blocks.push({
      id: createId('beam'),
      x: eastX + eastW / 2,
      y: groundY - 75,
      width: eastW + 20,
      height: 13,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 115,
      maxHp: 115,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 12,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 4
    });

    // East Tower Top Beam
    blocks.push({
      id: createId('beam'),
      x: eastX + eastW / 2,
      y: eastTopY - 6,
      width: eastW + 26,
      height: 15,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 130,
      maxHp: 130,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 14,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // East Windmill Vanes/Rafters
    blocks.push({
      id: createId('rafter'),
      x: eastX + eastW / 2 - 24,
      y: eastTopY - 25,
      width: 52,
      height: 11,
      angle: -0.45,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 60,
      maxHp: 60,
      type: 'rafter',
      color: BAMBOO_POST_COLOR,
      mass: 5,
      isStructural: false,
      broken: false,
      grounded: true
    });
    blocks.push({
      id: createId('rafter'),
      x: eastX + eastW / 2 + 24,
      y: eastTopY - 25,
      width: 52,
      height: 11,
      angle: 0.45,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 60,
      maxHp: 60,
      type: 'rafter',
      color: BAMBOO_POST_COLOR,
      mass: 5,
      isStructural: false,
      broken: false,
      grounded: true
    });

    // 4 Thatch Tiers for East Tower
    for (let r = 0; r < 4; r++) {
      const tierW = (eastW + 32) - (r * 28);
      blocks.push({
        id: createId('thatch'),
        x: eastX + eastW / 2,
        y: eastTopY - 16 - (r * 18),
        width: tierW,
        height: 18,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 60,
        maxHp: 60,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 6,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    addGold(eastX + eastW * 0.3, groundY - 87, true);
    addGold(eastX + eastW * 0.7, groundY - 87, false);
    addGold(eastX + eastW / 2, eastTopY - 12, true);

    // 4. Grand High-Altitude Skybridge Deck Beam connecting West and East Towers!
    const bridgeCenterX = (westX + westW + eastX) / 2;
    const bridgeWidth = (eastX + 20) - (westX + westW - 20);
    blocks.push({
      id: createId('beam'),
      x: bridgeCenterX,
      y: groundY - 125,
      width: bridgeWidth,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 130,
      maxHp: 130,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 14,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Skybridge Gold Treasure & Hanging Lanterns
    addGold(bridgeCenterX, groundY - 137, true);
    blocks.push({
      id: createId('lantern'),
      x: bridgeCenterX,
      y: groundY - 105,
      width: 16,
      height: 22,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 35,
      maxHp: 35,
      type: 'lantern',
      color: LANTERN_COLOR,
      mass: 3,
      isStructural: false,
      broken: false,
      grounded: true,
      hanging: true
    });
  }

  // 18. Royal Lotus Water Palace (Level 18)
  else if (type === 'lotus_water_palace') {
    // 1. West Stilt Boardwalk Water Pavilion (Stilts + Upper Pavilion)
    const westX = baseX;
    const westW = 150;
    const stiltH = 45;
    const deckY = groundY - stiltH;
    const westPavH = 85;
    const westTopY = deckY - westPavH;

    // 3 Submerged Water Stilts
    [westX, westX + westW / 2, westX + westW].forEach((sx) => {
      blocks.push({
        id: createId('stilt'),
        x: sx,
        y: groundY - stiltH / 2,
        width: 16,
        height: stiltH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 110,
        maxHp: 110,
        type: 'stilt',
        color: STILT_COLOR,
        mass: 12,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 2
      });
    });

    // West Boardwalk Deck Beam
    blocks.push({
      id: createId('beam'),
      x: westX + westW / 2,
      y: deckY - 6,
      width: westW + 24,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 125,
      maxHp: 125,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 13,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // 3 Upper Posts on the Boardwalk
    [westX, westX + westW / 2, westX + westW].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: deckY - westPavH / 2,
        width: 15,
        height: westPavH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 105,
        maxHp: 105,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 11,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 3
      });
    });

    // West Pavilion Top Eaves Beam
    blocks.push({
      id: createId('beam'),
      x: westX + westW / 2,
      y: westTopY - 6,
      width: westW + 28,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 125,
      maxHp: 125,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 13,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // 4 Lotus Thatch Tiers for West Pavilion
    for (let r = 0; r < 4; r++) {
      const tierW = (westW + 36) - (r * 32);
      blocks.push({
        id: createId('thatch'),
        x: westX + westW / 2,
        y: westTopY - 16 - (r * 18),
        width: tierW,
        height: 18,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 60,
        maxHp: 60,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 6,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    addGold(westX + westW * 0.28, deckY - 18, false);
    addGold(westX + westW * 0.72, deckY - 18, true);
    addGold(westX + westW / 2, westTopY - 12, false);

    // 2. Central Sovereign Lotus Throne Palace (4 Monumental Pillars)
    const palX = westX + westW + 30;
    const palW = 230;
    const palH = 180;
    const palTopY = groundY - palH;

    // 4 Massive Foundation Posts
    const palPosts = [palX, palX + palW * 0.33, palX + palW * 0.67, palX + palW];
    palPosts.forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: groundY - palH / 2,
        width: 18,
        height: palH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 155,
        maxHp: 155,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 18,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 6
      });
    });

    // Floor 1: Royal Veranda Beam
    const f1Y = groundY - 55;
    blocks.push({
      id: createId('beam'),
      x: palX + palW / 2,
      y: f1Y,
      width: palW + 28,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 135,
      maxHp: 135,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 15,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Floor 2: Sovereign Throne Hall Gallery Beam
    const f2Y = groundY - 110;
    blocks.push({
      id: createId('beam'),
      x: palX + palW / 2,
      y: f2Y,
      width: palW + 32,
      height: 15,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 140,
      maxHp: 140,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 15,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Floor 3: Imperial Lotus Crown Eaves Beam
    blocks.push({
      id: createId('beam'),
      x: palX + palW / 2,
      y: palTopY - 6,
      width: palW + 36,
      height: 16,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 145,
      maxHp: 145,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 16,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 6
    });

    // Throne Palace Wall Panels
    blocks.push({
      id: createId('wall'),
      x: palX + palW / 2,
      y: (groundY + f1Y) / 2,
      width: palW - 35,
      height: 40,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 90,
      maxHp: 90,
      type: 'wall',
      color: BAMBOO_WALL_COLOR,
      mass: 9,
      isStructural: false,
      broken: false,
      grounded: true
    });
    blocks.push({
      id: createId('wall'),
      x: palX + palW / 2,
      y: (f1Y + f2Y) / 2,
      width: palW - 35,
      height: 40,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 90,
      maxHp: 90,
      type: 'wall',
      color: BAMBOO_WALL_COLOR,
      mass: 9,
      isStructural: false,
      broken: false,
      grounded: true
    });

    // 6-Tier Cascading Lotus Petal Thatch Dome Roof
    const roofBaseY = palTopY - 16;
    for (let r = 0; r < 6; r++) {
      const tierW = (palW + 48) - (r * 30);
      blocks.push({
        id: createId('thatch'),
        x: palX + palW / 2,
        y: roofBaseY - (r * 18),
        width: tierW,
        height: 18,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 70,
        maxHp: 70,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 7,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    // 4 Hanging Royal Golden Lanterns
    [palX + 22, palX + palW * 0.38, palX + palW * 0.62, palX + palW - 22].forEach((lx) => {
      blocks.push({
        id: createId('lantern'),
        x: lx,
        y: palTopY + 16,
        width: 16,
        height: 22,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 35,
        maxHp: 35,
        type: 'lantern',
        color: LANTERN_COLOR,
        mass: 3,
        isStructural: false,
        broken: false,
        grounded: true,
        hanging: true
      });
    });

    // 6 Emperor's Royal Gold Hoards
    addGold(palX + palW * 0.26, f1Y - 12, false);
    addGold(palX + palW * 0.74, f1Y - 12, true);
    addGold(palX + palW * 0.35, f2Y - 12, true);
    addGold(palX + palW * 0.65, f2Y - 12, false);
    addGold(palX + palW * 0.45, palTopY - 12, true);
    addGold(palX + palW * 0.55, palTopY - 12, false);

    // 3. East Royal Treasury Water Pavilion (Matching Stilts + Treasury Keep)
    const eastX = palX + palW + 30;
    const eastW = 150;
    const eastTopY = deckY - westPavH;

    // 3 Submerged Water Stilts for East Pavilion
    [eastX, eastX + eastW / 2, eastX + eastW].forEach((sx) => {
      blocks.push({
        id: createId('stilt'),
        x: sx,
        y: groundY - stiltH / 2,
        width: 16,
        height: stiltH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 110,
        maxHp: 110,
        type: 'stilt',
        color: STILT_COLOR,
        mass: 12,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 2
      });
    });

    // East Boardwalk Deck Beam
    blocks.push({
      id: createId('beam'),
      x: eastX + eastW / 2,
      y: deckY - 6,
      width: eastW + 24,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 125,
      maxHp: 125,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 13,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // 3 Upper Posts on the East Boardwalk
    [eastX, eastX + eastW / 2, eastX + eastW].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: deckY - westPavH / 2,
        width: 15,
        height: westPavH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 105,
        maxHp: 105,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 11,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 3
      });
    });

    // East Pavilion Top Eaves Beam
    blocks.push({
      id: createId('beam'),
      x: eastX + eastW / 2,
      y: eastTopY - 6,
      width: eastW + 28,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 125,
      maxHp: 125,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 13,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // 4 Lotus Thatch Tiers for East Pavilion
    for (let r = 0; r < 4; r++) {
      const tierW = (eastW + 36) - (r * 32);
      blocks.push({
        id: createId('thatch'),
        x: eastX + eastW / 2,
        y: eastTopY - 16 - (r * 18),
        width: tierW,
        height: 18,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 60,
        maxHp: 60,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 6,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    addGold(eastX + eastW * 0.28, deckY - 18, true);
    addGold(eastX + eastW * 0.72, deckY - 18, false);
    addGold(eastX + eastW * 0.50, deckY - 18, true);
    addGold(eastX + eastW / 2, eastTopY - 12, true);
  }

  // 19. Emerald Phoenix Spire (Level 19)
  else if (type === 'phoenix_spire') {
    // 1. West Aviary Loft (3 Pillars)
    const b1X = baseX;
    const b1W = 145;
    buildHut3Pillars(b1X, b1W, 115, 4, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'left',
      potSide: 'both',
      hasLantern: true,
      goldCount: 3
    });

    // 2. Central Soaring Phoenix Spire (4 Colossal Pillars & Cantilever Wings)
    const b2X = b1X + b1W + 25;
    const b2W = 220;
    const b2H = 185;
    const b2TopY = groundY - b2H;

    // 4 Soaring Columns
    [b2X, b2X + b2W * 0.33, b2X + b2W * 0.67, b2X + b2W].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: groundY - b2H / 2,
        width: 17,
        height: b2H,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 155,
        maxHp: 155,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 18,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 6
      });
    });

    // Floor 1 Beam
    const f1Y = groundY - 55;
    blocks.push({
      id: createId('beam'),
      x: b2X + b2W / 2,
      y: f1Y,
      width: b2W + 24,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 135,
      maxHp: 135,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 14,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Floor 2 Beam
    const f2Y = groundY - 115;
    blocks.push({
      id: createId('beam'),
      x: b2X + b2W / 2,
      y: f2Y,
      width: b2W + 28,
      height: 15,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 140,
      maxHp: 140,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 15,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Floor 3 Top Beam
    blocks.push({
      id: createId('beam'),
      x: b2X + b2W / 2,
      y: b2TopY - 6,
      width: b2W + 36,
      height: 16,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 145,
      maxHp: 145,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 16,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 6
    });

    // Woven Wall Backing
    blocks.push({
      id: createId('wall'),
      x: b2X + b2W / 2,
      y: groundY - b2H * 0.48,
      width: b2W - 35,
      height: b2H * 0.76,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 105,
      maxHp: 105,
      type: 'wall',
      color: BAMBOO_WALL_COLOR,
      mass: 11,
      isStructural: false,
      broken: false,
      grounded: true
    });

    // 5-Tier Phoenix Feather Stepped Thatch
    const b2RoofY = b2TopY - 16;
    for (let r = 0; r < 5; r++) {
      const tierW = (b2W + 42) - (r * 32);
      blocks.push({
        id: createId('thatch'),
        x: b2X + b2W / 2,
        y: b2RoofY - (r * 18),
        width: tierW,
        height: 18,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 65,
        maxHp: 65,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 7,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    // Phoenix Wing Cantilever Rafters
    blocks.push({
      id: createId('rafter'),
      x: b2X + 20,
      y: b2TopY - 18,
      width: 48,
      height: 10,
      angle: -0.32,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 65,
      maxHp: 65,
      type: 'rafter',
      color: BAMBOO_POST_COLOR,
      mass: 5,
      isStructural: false,
      broken: false,
      grounded: true
    });
    blocks.push({
      id: createId('rafter'),
      x: b2X + b2W - 20,
      y: b2TopY - 18,
      width: 48,
      height: 10,
      angle: 0.32,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 65,
      maxHp: 65,
      type: 'rafter',
      color: BAMBOO_POST_COLOR,
      mass: 5,
      isStructural: false,
      broken: false,
      grounded: true
    });

    // Hanging Lanterns
    blocks.push({
      id: createId('lantern'),
      x: b2X + 30,
      y: b2TopY + 22,
      width: 16,
      height: 22,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 35,
      maxHp: 35,
      type: 'lantern',
      color: LANTERN_COLOR,
      mass: 3,
      isStructural: false,
      broken: false,
      grounded: true,
      hanging: true
    });
    blocks.push({
      id: createId('lantern'),
      x: b2X + b2W - 30,
      y: b2TopY + 22,
      width: 16,
      height: 22,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 35,
      maxHp: 35,
      type: 'lantern',
      color: LANTERN_COLOR,
      mass: 3,
      isStructural: false,
      broken: false,
      grounded: true,
      hanging: true
    });

    // Gold Caches in Spire
    addGold(b2X + b2W * 0.28, f1Y - 12, false);
    addGold(b2X + b2W * 0.72, f1Y - 12, true);
    addGold(b2X + b2W * 0.35, f2Y - 12, true);
    addGold(b2X + b2W * 0.65, f2Y - 12, false);
    addGold(b2X + b2W * 0.50, b2TopY - 12, true);

    // 3. East Roost Pavilion (3 Pillars)
    const b3X = b2X + b2W + 25;
    const b3W = 155;
    buildHut3Pillars(b3X, b3W, 125, 4, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'right',
      potSide: 'both',
      hasLantern: true,
      goldCount: 4
    });

    // 4. Far-East Wind Chime Shrine (3 Pillars)
    const b4X = b3X + b3W + 25;
    const b4W = 135;
    buildHut3Pillars(b4X, b4W, 100, 3, {
      hasWall: true,
      hasLadder: false,
      potSide: 'both',
      hasLantern: true,
      goldCount: 2
    });
  }

  // 20. Thunder Mountain Bastion (Level 20)
  else if (type === 'thunder_mountain') {
    // 1. Lower Mountain Gatehouse (3 Pillars)
    const b1X = baseX;
    const b1W = 150;
    buildHut3Pillars(b1X, b1W, 110, 4, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'left',
      potSide: 'both',
      hasLantern: true,
      goldCount: 3
    });

    // 2. Mid-Tier Rampart on 45-height Stilts (3 Stilts + 3 Pillars)
    const b2X = b1X + b1W + 25;
    const b2W = 160;
    const b2StiltH = 45;
    const b2DeckY = groundY - b2StiltH;
    const b2PostH = 95;
    const b2TopY = b2DeckY - b2PostH;

    // 3 Foundation Stilts
    [b2X, b2X + b2W / 2, b2X + b2W].forEach((sx) => {
      blocks.push({
        id: createId('stilt'),
        x: sx,
        y: groundY - b2StiltH / 2,
        width: 16,
        height: b2StiltH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 125,
        maxHp: 125,
        type: 'stilt',
        color: STILT_COLOR,
        mass: 14,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 3
      });
    });

    // Deck Beam
    blocks.push({
      id: createId('beam'),
      x: b2X + b2W / 2,
      y: b2DeckY - 6,
      width: b2W + 24,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 135,
      maxHp: 135,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 14,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 4
    });

    // Upper Posts (3 Pillars)
    [b2X, b2X + b2W / 2, b2X + b2W].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: b2DeckY - b2PostH / 2,
        width: 15,
        height: b2PostH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 110,
        maxHp: 110,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 12,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 3
      });
    });

    // Mid Rampart Top Beam
    blocks.push({
      id: createId('beam'),
      x: b2X + b2W / 2,
      y: b2TopY - 6,
      width: b2W + 28,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 125,
      maxHp: 125,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 13,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 4
    });

    // Mid Rampart Wall
    blocks.push({
      id: createId('wall'),
      x: b2X + b2W / 2,
      y: b2DeckY - b2PostH * 0.5,
      width: b2W - 22,
      height: b2PostH * 0.78,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 85,
      maxHp: 85,
      type: 'wall',
      color: BAMBOO_WALL_COLOR,
      mass: 9,
      isStructural: false,
      broken: false,
      grounded: true
    });

    // 4 Thatch Tiers for Mid Rampart
    const b2RoofY = b2TopY - 16;
    for (let r = 0; r < 4; r++) {
      const tierW = (b2W + 36) - (r * 30);
      blocks.push({
        id: createId('thatch'),
        x: b2X + b2W / 2,
        y: b2RoofY - (r * 18),
        width: tierW,
        height: 18,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 60,
        maxHp: 60,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 6,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    addGold(b2X + b2W * 0.3, b2DeckY - 18, false);
    addGold(b2X + b2W * 0.7, b2DeckY - 18, true);

    // 3. High Peak Citadel Keep (4 Heavy Pillars, 3 Floors, 190 Height)
    const b3X = b2X + b2W + 25;
    const b3W = 230;
    const b3H = 190;
    const b3TopY = groundY - b3H;

    // 4 Monumental Mountain Columns
    [b3X, b3X + b3W * 0.33, b3X + b3W * 0.67, b3X + b3W].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: groundY - b3H / 2,
        width: 18,
        height: b3H,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 160,
        maxHp: 160,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 19,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 6
      });
    });

    const b3F1Y = groundY - 60;
    blocks.push({
      id: createId('beam'),
      x: b3X + b3W / 2,
      y: b3F1Y,
      width: b3W + 24,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 135,
      maxHp: 135,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 14,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    const b3F2Y = groundY - 120;
    blocks.push({
      id: createId('beam'),
      x: b3X + b3W / 2,
      y: b3F2Y,
      width: b3W + 28,
      height: 15,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 140,
      maxHp: 140,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 15,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    blocks.push({
      id: createId('beam'),
      x: b3X + b3W / 2,
      y: b3TopY - 6,
      width: b3W + 36,
      height: 16,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 145,
      maxHp: 145,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 16,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 6
    });

    blocks.push({
      id: createId('wall'),
      x: b3X + b3W / 2,
      y: groundY - b3H * 0.48,
      width: b3W - 35,
      height: b3H * 0.78,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 105,
      maxHp: 105,
      type: 'wall',
      color: BAMBOO_WALL_COLOR,
      mass: 11,
      isStructural: false,
      broken: false,
      grounded: true
    });

    const b3RoofY = b3TopY - 16;
    for (let r = 0; r < 5; r++) {
      const tierW = (b3W + 42) - (r * 32);
      blocks.push({
        id: createId('thatch'),
        x: b3X + b3W / 2,
        y: b3RoofY - (r * 18),
        width: tierW,
        height: 18,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 65,
        maxHp: 65,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 7,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    addGold(b3X + b3W * 0.28, b3F1Y - 12, false);
    addGold(b3X + b3W * 0.72, b3F1Y - 12, true);
    addGold(b3X + b3W * 0.35, b3F2Y - 12, true);
    addGold(b3X + b3W * 0.65, b3F2Y - 12, false);
    addGold(b3X + b3W * 0.50, b3TopY - 12, true);

    // 4. East Arsenal Watchtower (3 Pillars)
    const b4X = b3X + b3W + 25;
    const b4W = 150;
    buildHut3Pillars(b4X, b4W, 125, 4, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'right',
      potSide: 'both',
      hasLantern: true,
      goldCount: 4
    });
  }

  // 21. Sunken Temple of the Naga King (Level 21)
  else if (type === 'sunken_temple') {
    // 1. West Ceremonial Portico on 45-height Stilts (3 Pillars)
    const b1X = baseX;
    const b1W = 145;
    const b1StiltH = 45;
    const b1DeckY = groundY - b1StiltH;
    const b1PostH = 95;
    const b1TopY = b1DeckY - b1PostH;

    [b1X, b1X + b1W / 2, b1X + b1W].forEach((sx) => {
      blocks.push({
        id: createId('stilt'),
        x: sx,
        y: groundY - b1StiltH / 2,
        width: 16,
        height: b1StiltH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 120,
        maxHp: 120,
        type: 'stilt',
        color: STILT_COLOR,
        mass: 13,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 3
      });
    });

    blocks.push({
      id: createId('beam'),
      x: b1X + b1W / 2,
      y: b1DeckY - 6,
      width: b1W + 24,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 130,
      maxHp: 130,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 14,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 4
    });

    [b1X, b1X + b1W / 2, b1X + b1W].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: b1DeckY - b1PostH / 2,
        width: 15,
        height: b1PostH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 110,
        maxHp: 110,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 12,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 3
      });
    });

    blocks.push({
      id: createId('beam'),
      x: b1X + b1W / 2,
      y: b1TopY - 6,
      width: b1W + 26,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 120,
      maxHp: 120,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 13,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 4
    });

    blocks.push({
      id: createId('wall'),
      x: b1X + b1W / 2,
      y: b1DeckY - b1PostH * 0.5,
      width: b1W - 22,
      height: b1PostH * 0.76,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 85,
      maxHp: 85,
      type: 'wall',
      color: BAMBOO_WALL_COLOR,
      mass: 9,
      isStructural: false,
      broken: false,
      grounded: true
    });

    const b1RoofY = b1TopY - 16;
    for (let r = 0; r < 4; r++) {
      const tierW = (b1W + 36) - (r * 30);
      blocks.push({
        id: createId('thatch'),
        x: b1X + b1W / 2,
        y: b1RoofY - (r * 18),
        width: tierW,
        height: 18,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 60,
        maxHp: 60,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 6,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    addGold(b1X + b1W * 0.3, b1DeckY - 18, false);
    addGold(b1X + b1W * 0.7, b1DeckY - 18, true);

    // 2. Western Water Stupa (3 Pillars)
    const b2X = b1X + b1W + 25;
    const b2W = 155;
    buildHut3Pillars(b2X, b2W, 120, 4, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'left',
      potSide: 'both',
      hasLantern: true,
      goldCount: 3
    });

    // 3. Grand Sunken Altar Sanctuary (4 Pillars, 185 Height)
    const b3X = b2X + b2W + 25;
    const b3W = 230;
    const b3H = 185;
    const b3TopY = groundY - b3H;

    [b3X, b3X + b3W * 0.33, b3X + b3W * 0.67, b3X + b3W].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: groundY - b3H / 2,
        width: 18,
        height: b3H,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 160,
        maxHp: 160,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 19,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 6
      });
    });

    const b3F1Y = groundY - 55;
    blocks.push({
      id: createId('beam'),
      x: b3X + b3W / 2,
      y: b3F1Y,
      width: b3W + 24,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 135,
      maxHp: 135,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 14,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    const b3F2Y = groundY - 115;
    blocks.push({
      id: createId('beam'),
      x: b3X + b3W / 2,
      y: b3F2Y,
      width: b3W + 28,
      height: 15,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 140,
      maxHp: 140,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 15,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    blocks.push({
      id: createId('beam'),
      x: b3X + b3W / 2,
      y: b3TopY - 6,
      width: b3W + 36,
      height: 16,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 145,
      maxHp: 145,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 16,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 6
    });

    blocks.push({
      id: createId('wall'),
      x: b3X + b3W / 2,
      y: groundY - b3H * 0.48,
      width: b3W - 35,
      height: b3H * 0.78,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 105,
      maxHp: 105,
      type: 'wall',
      color: BAMBOO_WALL_COLOR,
      mass: 11,
      isStructural: false,
      broken: false,
      grounded: true
    });

    const b3RoofY = b3TopY - 16;
    for (let r = 0; r < 5; r++) {
      const tierW = (b3W + 42) - (r * 32);
      blocks.push({
        id: createId('thatch'),
        x: b3X + b3W / 2,
        y: b3RoofY - (r * 18),
        width: tierW,
        height: 18,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 65,
        maxHp: 65,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 7,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    addGold(b3X + b3W * 0.28, b3F1Y - 12, false);
    addGold(b3X + b3W * 0.72, b3F1Y - 12, true);
    addGold(b3X + b3W * 0.35, b3F2Y - 12, true);
    addGold(b3X + b3W * 0.65, b3F2Y - 12, false);
    addGold(b3X + b3W * 0.50, b3TopY - 12, true);

    // 4. East Naga Reliquary Pavilion (3 Pillars)
    const b4X = b3X + b3W + 25;
    const b4W = 150;
    buildHut3Pillars(b4X, b4W, 125, 4, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'right',
      potSide: 'both',
      hasLantern: true,
      goldCount: 4
    });
  }

  // 22. Great Bamboo Acropolis (Level 22)
  else if (type === 'bamboo_acropolis') {
    // 1. West Propylaea Grand Portal (3 Pillars)
    const b1X = baseX;
    const b1W = 155;
    buildHut3Pillars(b1X, b1W, 125, 4, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'left',
      potSide: 'both',
      hasLantern: true,
      goldCount: 3
    });

    // 2. Imperial Senate Colonnade Hall (3 Pillars)
    const b2X = b1X + b1W + 25;
    const b2W = 170;
    buildHut3Pillars(b2X, b2W, 135, 4, {
      hasWall: true,
      hasLadder: false,
      potSide: 'both',
      hasLantern: true,
      goldCount: 4
    });

    // 3. Monumental Parthenon Palace (4 Colossal Pillars, 3 Floors, 200 Height)
    const b3X = b2X + b2W + 25;
    const b3W = 240;
    const b3H = 200;
    const b3TopY = groundY - b3H;

    // 4 Massive Imperial Columns
    [b3X, b3X + b3W * 0.33, b3X + b3W * 0.67, b3X + b3W].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: groundY - b3H / 2,
        width: 19,
        height: b3H,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 170,
        maxHp: 170,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 20,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 6
      });
    });

    // Floor 1 Beam
    const b3F1Y = groundY - 60;
    blocks.push({
      id: createId('beam'),
      x: b3X + b3W / 2,
      y: b3F1Y,
      width: b3W + 26,
      height: 15,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 140,
      maxHp: 140,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 15,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Floor 2 Beam
    const b3F2Y = groundY - 125;
    blocks.push({
      id: createId('beam'),
      x: b3X + b3W / 2,
      y: b3F2Y,
      width: b3W + 30,
      height: 15,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 145,
      maxHp: 145,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 16,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Top Beam
    blocks.push({
      id: createId('beam'),
      x: b3X + b3W / 2,
      y: b3TopY - 6,
      width: b3W + 38,
      height: 17,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 150,
      maxHp: 150,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 17,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 6
    });

    // Double Woven Wall Panel
    blocks.push({
      id: createId('wall'),
      x: b3X + b3W / 2,
      y: groundY - b3H * 0.48,
      width: b3W - 35,
      height: b3H * 0.78,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 110,
      maxHp: 110,
      type: 'wall',
      color: BAMBOO_WALL_COLOR,
      mass: 12,
      isStructural: false,
      broken: false,
      grounded: true
    });

    // 5-Tier Acropolis Pediment Thatch
    const b3RoofY = b3TopY - 16;
    for (let r = 0; r < 5; r++) {
      const tierW = (b3W + 44) - (r * 32);
      blocks.push({
        id: createId('thatch'),
        x: b3X + b3W / 2,
        y: b3RoofY - (r * 18),
        width: tierW,
        height: 18,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 70,
        maxHp: 70,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 7,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    // Imperial Gold in Palace
    addGold(b3X + b3W * 0.25, b3F1Y - 12, false);
    addGold(b3X + b3W * 0.75, b3F1Y - 12, true);
    addGold(b3X + b3W * 0.35, b3F2Y - 12, true);
    addGold(b3X + b3W * 0.65, b3F2Y - 12, false);
    addGold(b3X + b3W * 0.50, b3TopY - 12, true);

    // 4. East Treasury Citadel & Vault (3 Pillars, Double Wall)
    const b4X = b3X + b3W + 25;
    const b4W = 160;
    buildHut3Pillars(b4X, b4W, 130, 4, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'right',
      potSide: 'both',
      hasLantern: true,
      goldCount: 5
    });
  }

  // ===========================================================================
  // LEVEL 23: MYTHICAL TITAN FORTRESS
  // Dual-bastion fortified citadel with an elevated arched keep & central gateway
  // ===========================================================================
  else if (type === 'mythical_fortress') {
    // 1. West Vanguard Turret (3 Heavy Pillars, High Battlement)
    const wX = baseX - 20;
    const wW = 150;
    buildHut3Pillars(wX, wW, 140, 4, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'left',
      potSide: 'left',
      hasLantern: true,
      goldCount: 4
    });

    // 2. Central Titan Gatehouse & Elevated Keep
    const cX = wX + wW + 20;
    const cW = 200;
    const cPostH = 90; // Lower arched foundation gateway
    const cTopY = groundY - cPostH;

    // Gatehouse 3 ground pillars
    [cX, cX + cW / 2, cX + cW].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: groundY - cPostH / 2,
        width: 18,
        height: cPostH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 130,
        maxHp: 130,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 19,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 4
      });
    });

    // Archway cross beam
    blocks.push({
      id: createId('beam'),
      x: cX + cW / 2,
      y: cTopY - 7,
      width: cW + 40,
      height: 16,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 140,
      maxHp: 140,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 18,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Gate Wall Planks
    blocks.push({
      id: createId('wall'),
      x: cX + cW / 2,
      y: groundY - cPostH * 0.45,
      width: cW - 40,
      height: cPostH * 0.7,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 110,
      maxHp: 110,
      type: 'wall',
      color: BAMBOO_WALL_COLOR,
      mass: 14,
      isStructural: false,
      broken: false,
      grounded: true
    });

    // Elevated Upper Keep (Floor 2 - resting firmly on gatehouse beam)
    const keepFloorY = cTopY - 15;
    const kH = 100;
    const kTopY = keepFloorY - kH;
    [cX + 20, cX + cW / 2, cX + cW - 20].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: keepFloorY - kH / 2,
        width: 16,
        height: kH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 120,
        maxHp: 120,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 16,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 4
      });
    });

    // Keep Upper Crown Beam
    blocks.push({
      id: createId('beam'),
      x: cX + cW / 2,
      y: kTopY - 6,
      width: cW,
      height: 15,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 130,
      maxHp: 130,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 16,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // 4-Tier Heavy Thatch Battlement
    for (let r = 0; r < 4; r++) {
      const tierW = (cW + 20) - (r * 28);
      blocks.push({
        id: createId('thatch'),
        x: cX + cW / 2,
        y: kTopY - 14 - (r * 16),
        width: tierW,
        height: 16,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 75,
        maxHp: 75,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 8,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    // Keep Gold & Relics
    addGold(cX + cW * 0.35, keepFloorY - 8, true);
    addGold(cX + cW * 0.65, keepFloorY - 8, false);
    addGold(cX + cW * 0.50, kTopY - 12, true);

    // 3. East Grand Bastion Tower (3 Heavy Pillars, 5-Tier Tower)
    const eX = cX + cW + 20;
    const eW = 160;
    buildHut3Pillars(eX, eW, 160, 5, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'right',
      potSide: 'right',
      hasLantern: true,
      goldCount: 6
    });

    // Rampart Bridge Linking West to Gatehouse
    blocks.push({
      id: createId('beam'),
      x: (wX + wW + cX) / 2,
      y: groundY - 105,
      width: 45,
      height: 12,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 100,
      maxHp: 100,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 10,
      isStructural: false,
      broken: false,
      grounded: true
    });
  }

  // ===========================================================================
  // LEVEL 24: SUNKEN PIRATE GALLEON
  // Three-mast warship with deck keel, crow's nests, and captain's quarterdeck
  // ===========================================================================
  else if (type === 'pirate_galleon') {
    const shipStartX = baseX - 30;
    const shipW = 420;
    const deckH = 55;
    const deckY = groundY - deckH;

    // 1. Ship Hull Stilts & Keel Blocks (Grounded Foundation)
    const hullPillars = 6;
    for (let i = 0; i <= hullPillars; i++) {
      const hx = shipStartX + (i * (shipW / hullPillars));
      blocks.push({
        id: createId('stilt'),
        x: hx,
        y: groundY - deckH / 2,
        width: 16,
        height: deckH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 120,
        maxHp: 120,
        type: 'stilt',
        color: STILT_COLOR,
        mass: 18,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 3
      });
    }

    // Main Deck Beam (The Spine of the Galleon)
    blocks.push({
      id: createId('beam'),
      x: shipStartX + shipW / 2,
      y: deckY - 6,
      width: shipW + 30,
      height: 16,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 160,
      maxHp: 160,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 28,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 8
    });

    // Hull Cladding
    blocks.push({
      id: createId('wall'),
      x: shipStartX + shipW / 2,
      y: groundY - deckH * 0.45,
      width: shipW - 20,
      height: deckH * 0.75,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 110,
      maxHp: 110,
      type: 'wall',
      color: BAMBOO_WALL_COLOR,
      mass: 20,
      isStructural: false,
      broken: false,
      grounded: true
    });

    // 2. Forecastle (Bow Castle - Left)
    const bowX = shipStartX;
    const bowW = 90;
    const bowH = 70;
    buildHut3Pillars(bowX, bowW, bowH, 3, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'left',
      potSide: 'left',
      hasLantern: true,
      goldCount: 3
    });

    // 3. Stern Quarterdeck (Captain's Cabin - Right)
    const sternX = shipStartX + shipW - 110;
    const sternW = 110;
    const sternH = 95;
    buildHut3Pillars(sternX, sternW, sternH, 3, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'right',
      potSide: 'both',
      hasLantern: true,
      goldCount: 5
    });

    // 4. Three Soaring Masts (Fore, Main, Mizzen)
    const mastConfigs = [
      { x: shipStartX + 125, height: 165, yardW: 80, crowsNestY: 95 },
      { x: shipStartX + 215, height: 210, yardW: 105, crowsNestY: 130 },
      { x: shipStartX + 295, height: 155, yardW: 75, crowsNestY: 85 }
    ];

    mastConfigs.forEach((m) => {
      // Vertical Mast Post
      blocks.push({
        id: createId('post'),
        x: m.x,
        y: deckY - m.height / 2,
        width: 17,
        height: m.height,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 135,
        maxHp: 135,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 20,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 6
      });

      // Lower Yardarm Beam
      blocks.push({
        id: createId('beam'),
        x: m.x,
        y: deckY - m.height * 0.45,
        width: m.yardW,
        height: 12,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 95,
        maxHp: 95,
        type: 'beam',
        color: BAMBOO_BEAM_COLOR,
        mass: 9,
        isStructural: false,
        broken: false,
        grounded: true
      });

      // Upper Yardarm Beam
      blocks.push({
        id: createId('beam'),
        x: m.x,
        y: deckY - m.height * 0.80,
        width: m.yardW * 0.75,
        height: 11,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 90,
        maxHp: 90,
        type: 'beam',
        color: BAMBOO_BEAM_COLOR,
        mass: 8,
        isStructural: false,
        broken: false,
        grounded: true
      });

      // Crow's Nest Thatch Basket
      blocks.push({
        id: createId('thatch'),
        x: m.x,
        y: deckY - m.crowsNestY,
        width: 44,
        height: 15,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 60,
        maxHp: 60,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 6,
        isStructural: false,
        broken: false,
        grounded: true
      });

      // Stashed pirate loot in crow's nest
      addGold(m.x, deckY - m.crowsNestY - 10, true);
    });

    // Treasure chests in the hold
    addGold(shipStartX + 150, deckY - 10, false);
    addGold(shipStartX + 180, deckY - 10, true);
    addGold(shipStartX + 250, deckY - 10, false);
    addGold(shipStartX + 270, deckY - 10, true);
  }

  // ===========================================================================
  // LEVEL 25: ROYAL CLOCKTOWER CITADEL
  // Monumental 5-tier clocktower with twin observatory wings and mechanical spire
  // ===========================================================================
  else if (type === 'royal_clocktower') {
    // 1. West Astronomical Observatory (3 Pillars, Dome Thatch)
    const obsX = baseX - 25;
    const obsW = 135;
    buildHut3Pillars(obsX, obsW, 115, 3, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'left',
      potSide: 'left',
      hasLantern: true,
      goldCount: 3
    });

    // 2. Central Monumental Clocktower (5 Tiers High)
    const towerX = obsX + obsW + 20;
    const towerW = 160;

    // Tier 1: Heavy Arcade Foundation (ground to floor 1)
    const t1H = 80;
    const t1TopY = groundY - t1H;
    [towerX, towerX + towerW / 2, towerX + towerW].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: groundY - t1H / 2,
        width: 18,
        height: t1H,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 135,
        maxHp: 135,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 22,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 4
      });
    });

    blocks.push({
      id: createId('beam'),
      x: towerX + towerW / 2,
      y: t1TopY - 6,
      width: towerW + 25,
      height: 16,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 140,
      maxHp: 140,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 18,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Tier 2: The Clock Chamber (floor 1 to floor 2 - resting firmly on Tier 1 beam)
    const t2FloorY = t1TopY - 14;
    const t2H = 75;
    const t2TopY = t2FloorY - t2H;
    [towerX + 10, towerX + towerW / 2, towerX + towerW - 10].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: t2FloorY - t2H / 2,
        width: 16,
        height: t2H,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 125,
        maxHp: 125,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 17,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 4
      });
    });

    blocks.push({
      id: createId('wall'),
      x: towerX + towerW / 2,
      y: t2FloorY - t2H / 2,
      width: towerW - 35,
      height: t2H * 0.8,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 100,
      maxHp: 100,
      type: 'wall',
      color: BAMBOO_WALL_COLOR,
      mass: 12,
      isStructural: false,
      broken: false,
      grounded: true
    });

    blocks.push({
      id: createId('beam'),
      x: towerX + towerW / 2,
      y: t2TopY - 6,
      width: towerW + 15,
      height: 15,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 130,
      maxHp: 130,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 16,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Tier 3: The Belfry (Bell Chamber with Golden Bells - resting firmly on Tier 2 beam)
    const t3FloorY = t2TopY - 14;
    const t3H = 70;
    const t3TopY = t3FloorY - t3H;
    [towerX + 20, towerX + towerW / 2, towerX + towerW - 20].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: t3FloorY - t3H / 2,
        width: 15,
        height: t3H,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 115,
        maxHp: 115,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 15,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 3
      });
    });

    // Golden bells hanging inside the belfry
    addGold(towerX + towerW * 0.40, t3FloorY - t3H * 0.45, true);
    addGold(towerX + towerW * 0.60, t3FloorY - t3H * 0.45, true);

    blocks.push({
      id: createId('beam'),
      x: towerX + towerW / 2,
      y: t3TopY - 6,
      width: towerW,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 120,
      maxHp: 120,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 14,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 4
    });

    // Tier 4: Observation Balcony & Cantilevered Eaves
    for (let r = 0; r < 3; r++) {
      const tierW = (towerW + 20) - (r * 24);
      blocks.push({
        id: createId('thatch'),
        x: towerX + towerW / 2,
        y: t3TopY - 14 - (r * 15),
        width: tierW,
        height: 15,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 70,
        maxHp: 70,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 7,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    // Tier 5: Skyward Spire & Finial Peak
    const spireBaseY = t3TopY - 14 - (3 * 15);
    blocks.push({
      id: createId('post'),
      x: towerX + towerW / 2,
      y: spireBaseY - 30,
      width: 14,
      height: 60,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 95,
      maxHp: 95,
      type: 'post',
      color: BAMBOO_POST_COLOR,
      mass: 10,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 2
    });

    // Golden Weather Vane & Spire Orb
    addGold(towerX + towerW / 2, spireBaseY - 65, false);

    // 3. East Royal Library Annex (3 Pillars, 4 Thatch Tiers)
    const libX = towerX + towerW + 20;
    const libW = 140;
    buildHut3Pillars(libX, libW, 125, 4, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'right',
      potSide: 'both',
      hasLantern: true,
      goldCount: 4
    });
  }

  // ===========================================================================
  // LEVEL 26: IMPERIAL DRAGON PAGODA
  // Pinnacle 6-tier oriental pagoda with sweeping eave thatch brackets & dragon crests
  // ===========================================================================
  else if (type === 'dragon_pagoda') {
    // 1. West Serpentine Incense Pavilion (3 Pillars, Curved Thatch)
    const westPavX = baseX - 25;
    const westPavW = 130;
    buildHut3Pillars(westPavX, westPavW, 120, 3, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'left',
      potSide: 'both',
      hasLantern: true,
      goldCount: 4
    });

    // 2. Central Imperial 6-Tier Dragon Pagoda
    const pagodaX = westPavX + westPavW + 20;
    const pagodaW = 190;

    // Ground Floor: Imperial Foundation Arcade (3 Heavy Pillars)
    const f1H = 75;
    const f1TopY = groundY - f1H;
    [pagodaX, pagodaX + pagodaW / 2, pagodaX + pagodaW].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: groundY - f1H / 2,
        width: 19,
        height: f1H,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 140,
        maxHp: 140,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 24,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 4
      });
    });

    // Main Floor Beam
    blocks.push({
      id: createId('beam'),
      x: pagodaX + pagodaW / 2,
      y: f1TopY - 6,
      width: pagodaW + 35,
      height: 16,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 150,
      maxHp: 150,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 20,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 6
    });

    // Sweeping Eaves Tier 1
    blocks.push({
      id: createId('thatch'),
      x: pagodaX + pagodaW / 2,
      y: f1TopY - 18,
      width: pagodaW + 55,
      height: 16,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 75,
      maxHp: 75,
      type: 'thatch',
      color: THATCH_COLOR,
      mass: 9,
      isStructural: false,
      broken: false,
      grounded: true
    });

    // Multi-Tier Pagoda Body (Floors 2 to 5 - resting firmly on floor beams)
    let currentFloorY = f1TopY - 14;
    let currentFloorW = pagodaW - 15;
    const floorH = 50;

    for (let f = 2; f <= 5; f++) {
      const topOfFloorY = currentFloorY - floorH;

      // 3 pillars per floor
      [pagodaX + (pagodaW - currentFloorW) / 2, pagodaX + pagodaW / 2, pagodaX + pagodaW - (pagodaW - currentFloorW) / 2].forEach((px) => {
        blocks.push({
          id: createId('post'),
          x: px,
          y: currentFloorY - floorH / 2,
          width: 16,
          height: floorH,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 120,
          maxHp: 120,
          type: 'post',
          color: BAMBOO_POST_COLOR,
          mass: 16,
          isStructural: true,
          broken: false,
          grounded: true,
          nodes: 3
        });
      });

      // Supporting Floor Beam
      blocks.push({
        id: createId('beam'),
        x: pagodaX + pagodaW / 2,
        y: topOfFloorY - 6,
        width: currentFloorW + 25,
        height: 14,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 125,
        maxHp: 125,
        type: 'beam',
        color: BAMBOO_BEAM_COLOR,
        mass: 14,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 5
      });

      // Sweeping Cantilevered Eave Thatch (Signature Pagoda Silhouette)
      blocks.push({
        id: createId('thatch'),
        x: pagodaX + pagodaW / 2,
        y: topOfFloorY - 17,
        width: currentFloorW + 45,
        height: 15,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 70,
        maxHp: 70,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 8,
        isStructural: false,
        broken: false,
        grounded: true
      });

      // Imperial Gold Offerings on alternating floors
      if (f % 2 === 0) {
        addGold(pagodaX + pagodaW * 0.42, currentFloorY - 8, true);
        addGold(pagodaX + pagodaW * 0.58, currentFloorY - 8, false);
      } else {
        addGold(pagodaX + pagodaW * 0.50, currentFloorY - 8, true);
      }

      currentFloorY = topOfFloorY - 14;
      currentFloorW -= 25;
    }

    // Tier 6: Grand Dragon Crest Pinnacle
    const apexX = pagodaX + pagodaW / 2;
    blocks.push({
      id: createId('thatch'),
      x: apexX,
      y: currentFloorY - 10,
      width: 55,
      height: 18,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 75,
      maxHp: 75,
      type: 'thatch',
      color: THATCH_COLOR,
      mass: 8,
      isStructural: false,
      broken: false,
      grounded: true
    });

    // Dragon Horn Spire
    blocks.push({
      id: createId('post'),
      x: apexX,
      y: currentFloorY - 35,
      width: 14,
      height: 40,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 90,
      maxHp: 90,
      type: 'post',
      color: BAMBOO_POST_COLOR,
      mass: 8,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 2
    });

    // Golden Imperial Dragon Pearl
    addGold(apexX, currentFloorY - 58, false);

    // 3. East Sacred Guardian Pavilion (3 Pillars, 4 Thatch Tiers)
    const eastPavX = pagodaX + pagodaW + 20;
    const eastPavW = 135;
    buildHut3Pillars(eastPavX, eastPavW, 130, 4, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'right',
      potSide: 'both',
      hasLantern: true,
      goldCount: 5
    });
  }

  // ===========================================================================
  // LEVEL 27: ROYAL SKYBRIDGE PALACE
  // Twin 3-story royal bamboo palace wings linked by an elevated suspension bridge
  // Dense bamboo pillar colonnades + moderate gold (6 gold items)
  // ===========================================================================
  else if (type === 'skybridge_palace') {
    const HelperBuildPalaceWing = (wingX: number, wingW: number, hasGoldLeft: boolean) => {
      // Floor 1: 4 Heavy Bamboo Pillars for dense structural colonnade
      const f1H = 86;
      const f1TopY = groundY - f1H;
      const f1Cols = [wingX, wingX + wingW * 0.33, wingX + wingW * 0.67, wingX + wingW];
      f1Cols.forEach((px) => {
        blocks.push({
          id: createId('post'),
          x: px,
          y: groundY - f1H / 2,
          width: 16,
          height: f1H,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 125,
          maxHp: 125,
          type: 'post',
          color: BAMBOO_POST_COLOR,
          mass: 16,
          isStructural: true,
          broken: false,
          grounded: true,
          nodes: 4
        });
      });

      // Floor 1 Woven Wall & Mid-Beam
      blocks.push({
        id: createId('wall'),
        x: wingX + wingW / 2,
        y: groundY - f1H * 0.45,
        width: wingW - 24,
        height: f1H * 0.72,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 85,
        maxHp: 85,
        type: 'wall',
        color: BAMBOO_WALL_COLOR,
        mass: 9,
        isStructural: false,
        broken: false,
        grounded: true
      });

      blocks.push({
        id: createId('beam'),
        x: wingX + wingW / 2,
        y: f1TopY - 6,
        width: wingW + 24,
        height: 15,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 135,
        maxHp: 135,
        type: 'beam',
        color: BAMBOO_BEAM_COLOR,
        mass: 16,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 5
      });

      // Floor 2: 4 Royal Gallery Pillars resting on Floor 1 Beam
      const f2BaseY = f1TopY - 13;
      const f2H = 70;
      const f2TopY = f2BaseY - f2H;
      f1Cols.forEach((px) => {
        blocks.push({
          id: createId('post'),
          x: px,
          y: f2BaseY - f2H / 2,
          width: 15,
          height: f2H,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 115,
          maxHp: 115,
          type: 'post',
          color: BAMBOO_POST_COLOR,
          mass: 14,
          isStructural: true,
          broken: false,
          grounded: true,
          nodes: 3
        });
      });

      addGold(wingX + wingW * (hasGoldLeft ? 0.35 : 0.65), f2BaseY - 7, false);

      blocks.push({
        id: createId('beam'),
        x: wingX + wingW / 2,
        y: f2TopY - 6,
        width: wingW + 22,
        height: 15,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 130,
        maxHp: 130,
        type: 'beam',
        color: BAMBOO_BEAM_COLOR,
        mass: 15,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 5
      });

      // Floor 3: 3 Crown Pavilion Pillars resting on Floor 2 Beam
      const f3BaseY = f2TopY - 13;
      const f3H = 58;
      const f3TopY = f3BaseY - f3H;
      [wingX + 10, wingX + wingW / 2, wingX + wingW - 10].forEach((px) => {
        blocks.push({
          id: createId('post'),
          x: px,
          y: f3BaseY - f3H / 2,
          width: 14,
          height: f3H,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 110,
          maxHp: 110,
          type: 'post',
          color: BAMBOO_POST_COLOR,
          mass: 12,
          isStructural: true,
          broken: false,
          grounded: true,
          nodes: 3
        });
      });

      addGold(wingX + wingW / 2, f3BaseY - 7, true);

      blocks.push({
        id: createId('beam'),
        x: wingX + wingW / 2,
        y: f3TopY - 6,
        width: wingW + 16,
        height: 14,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 125,
        maxHp: 125,
        type: 'beam',
        color: BAMBOO_BEAM_COLOR,
        mass: 14,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 4
      });

      // Stepped 3-Tier Royal Thatch Roof
      for (let r = 0; r < 3; r++) {
        blocks.push({
          id: createId('thatch'),
          x: wingX + wingW / 2,
          y: f3TopY - 19 - r * 14,
          width: wingW + 24 - r * 28,
          height: 15,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 75,
          maxHp: 75,
          type: 'thatch',
          color: THATCH_COLOR,
          mass: 8,
          isStructural: false,
          broken: false,
          grounded: true
        });
      }
    };

    // 1. West Royal Palace Wing
    const westWingX = baseX - 25;
    const wingW = 148;
    HelperBuildPalaceWing(westWingX, wingW, true);

    // 2. Central Elevated Suspension Bridge (Supported by 3 Tall Stilt Pylons + Upper Canopy Posts)
    const bridgeX = westWingX + wingW + 16;
    const bridgeW = 136;
    const pylonH = 140;
    const pylonTopY = groundY - pylonH;

    [bridgeX, bridgeX + bridgeW / 2, bridgeX + bridgeW].forEach((px) => {
      blocks.push({
        id: createId('stilt'),
        x: px,
        y: groundY - pylonH / 2,
        width: 15,
        height: pylonH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 120,
        maxHp: 120,
        type: 'stilt',
        color: STILT_COLOR,
        mass: 15,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 5
      });
    });

    // Lower Suspension Cross-Beam
    blocks.push({
      id: createId('beam'),
      x: bridgeX + bridgeW / 2,
      y: groundY - pylonH * 0.5,
      width: bridgeW + 16,
      height: 12,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 110,
      maxHp: 110,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 11,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 4
    });

    // Main Elevated Suspension Bridge Deck
    blocks.push({
      id: createId('beam'),
      x: bridgeX + bridgeW / 2,
      y: pylonTopY - 6,
      width: bridgeW + 26,
      height: 15,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 135,
      maxHp: 135,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 16,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Suspension Bridge Railing Posts & Overhead Canopy
    const bridgeDeckBaseY = pylonTopY - 13;
    const bridgeCanopyH = 60;
    const bridgeCanopyTopY = bridgeDeckBaseY - bridgeCanopyH;
    [bridgeX + 6, bridgeX + bridgeW / 2, bridgeX + bridgeW - 6].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: bridgeDeckBaseY - bridgeCanopyH / 2,
        width: 14,
        height: bridgeCanopyH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 105,
        maxHp: 105,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 11,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 3
      });
    });

    // Moderate Gold on the Suspension Bridge
    addGold(bridgeX + bridgeW * 0.35, bridgeDeckBaseY - 7, false);
    addGold(bridgeX + bridgeW * 0.65, bridgeDeckBaseY - 7, true);

    blocks.push({
      id: createId('beam'),
      x: bridgeX + bridgeW / 2,
      y: bridgeCanopyTopY - 6,
      width: bridgeW + 20,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 120,
      maxHp: 120,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 13,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 4
    });

    for (let r = 0; r < 2; r++) {
      blocks.push({
        id: createId('thatch'),
        x: bridgeX + bridgeW / 2,
        y: bridgeCanopyTopY - 19 - r * 14,
        width: bridgeW + 24 - r * 30,
        height: 15,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 70,
        maxHp: 70,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 7,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    // 3. East Royal Palace Wing
    const eastWingX = bridgeX + bridgeW + 16;
    HelperBuildPalaceWing(eastWingX, wingW, false);
  }

  // ===========================================================================
  // LEVEL 28: GRAND IMPERIAL BASTION
  // 4-Story Sovereign Keep with 5-pillar base colonnade & twin rampart towers
  // Dense bamboo pillar architecture + moderate gold (7 gold items)
  // ===========================================================================
  else if (type === 'imperial_bastion') {
    // 1. West Fortified Rampart Tower (3 Pillars, 2 Stories)
    const westX = baseX - 25;
    const sideW = 128;
    buildHut3Pillars(westX, sideW, 130, 3, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'left',
      potSide: 'left',
      hasLantern: true,
      goldCount: 2
    });

    // 2. Central 4-Story Sovereign Palace Keep (5 Ground Pillars, 4 Mid Pillars, 3 Upper Pillars)
    const keepX = westX + sideW + 18;
    const keepW = 200;

    // Story 1: 5 Heavy Bamboo Colonnade Pillars
    const s1H = 82;
    const s1TopY = groundY - s1H;
    [keepX, keepX + keepW * 0.25, keepX + keepW * 0.5, keepX + keepW * 0.75, keepX + keepW].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: groundY - s1H / 2,
        width: 17,
        height: s1H,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 135,
        maxHp: 135,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 18,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 4
      });
    });

    blocks.push({
      id: createId('wall'),
      x: keepX + keepW / 2,
      y: groundY - s1H * 0.45,
      width: keepW - 28,
      height: s1H * 0.75,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 95,
      maxHp: 95,
      type: 'wall',
      color: BAMBOO_WALL_COLOR,
      mass: 10,
      isStructural: false,
      broken: false,
      grounded: true
    });

    blocks.push({
      id: createId('beam'),
      x: keepX + keepW / 2,
      y: s1TopY - 6,
      width: keepW + 28,
      height: 16,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 145,
      maxHp: 145,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 18,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 6
    });

    // Story 2: 4 Sovereign Hall Pillars resting on Story 1 Beam
    const s2BaseY = s1TopY - 14;
    const s2H = 68;
    const s2TopY = s2BaseY - s2H;
    [keepX + 10, keepX + keepW * 0.36, keepX + keepW * 0.64, keepX + keepW - 10].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: s2BaseY - s2H / 2,
        width: 16,
        height: s2H,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 125,
        maxHp: 125,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 15,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 3
      });
    });

    addGold(keepX + keepW * 0.5, s2BaseY - 7, false);

    blocks.push({
      id: createId('beam'),
      x: keepX + keepW / 2,
      y: s2TopY - 6,
      width: keepW + 16,
      height: 15,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 135,
      maxHp: 135,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 16,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Story 3: 4 Royal Treasury Pillars resting on Story 2 Beam
    const s3BaseY = s2TopY - 13;
    const s3H = 60;
    const s3TopY = s3BaseY - s3H;
    [keepX + 18, keepX + keepW * 0.38, keepX + keepW * 0.62, keepX + keepW - 18].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: s3BaseY - s3H / 2,
        width: 15,
        height: s3H,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 115,
        maxHp: 115,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 13,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 3
      });
    });

    addGold(keepX + keepW * 0.3, s3BaseY - 7, true);
    addGold(keepX + keepW * 0.7, s3BaseY - 7, false);

    blocks.push({
      id: createId('beam'),
      x: keepX + keepW / 2,
      y: s3TopY - 6,
      width: keepW - 4,
      height: 15,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 130,
      maxHp: 130,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 15,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Story 4: 3 Imperial Crown Sanctum Pillars resting on Story 3 Beam
    const s4BaseY = s3TopY - 13;
    const s4H = 54;
    const s4TopY = s4BaseY - s4H;
    [keepX + 28, keepX + keepW / 2, keepX + keepW - 28].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: s4BaseY - s4H / 2,
        width: 14,
        height: s4H,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 110,
        maxHp: 110,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 12,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 3
      });
    });

    blocks.push({
      id: createId('beam'),
      x: keepX + keepW / 2,
      y: s4TopY - 6,
      width: keepW - 24,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 125,
      maxHp: 125,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 14,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 4
    });

    // 4-Tier Imperial Thatch Crown
    for (let r = 0; r < 4; r++) {
      blocks.push({
        id: createId('thatch'),
        x: keepX + keepW / 2,
        y: s4TopY - 19 - r * 14,
        width: keepW - 10 - r * 28,
        height: 15,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 75,
        maxHp: 75,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 8,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    // 3. East Fortified Rampart Tower (3 Pillars)
    const eastX = keepX + keepW + 18;
    buildHut3Pillars(eastX, sideW, 130, 3, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'right',
      potSide: 'right',
      hasLantern: true,
      goldCount: 2
    });
  }

  // ===========================================================================
  // LEVEL 29: TWIN FORTRESS & SUSPENSION BRIDGE
  // Dual 4-tier fortress bastions joined by a double-decked bamboo suspension bridge
  // High pillar density + moderate gold (7 gold items)
  // ===========================================================================
  else if (type === 'bridge_citadel') {
    const buildFortressKeep = (fx: number, fw: number, goldOnF2: number, goldOnF3: number) => {
      // Floor 1: 4 Heavy Fortress Pillars
      const f1H = 80;
      const f1TopY = groundY - f1H;
      const cols = [fx, fx + fw * 0.33, fx + fw * 0.67, fx + fw];
      cols.forEach((px) => {
        blocks.push({
          id: createId('post'),
          x: px,
          y: groundY - f1H / 2,
          width: 16,
          height: f1H,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 130,
          maxHp: 130,
          type: 'post',
          color: BAMBOO_POST_COLOR,
          mass: 16,
          isStructural: true,
          broken: false,
          grounded: true,
          nodes: 4
        });
      });

      blocks.push({
        id: createId('wall'),
        x: fx + fw / 2,
        y: groundY - f1H * 0.45,
        width: fw - 24,
        height: f1H * 0.74,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 90,
        maxHp: 90,
        type: 'wall',
        color: BAMBOO_WALL_COLOR,
        mass: 9,
        isStructural: false,
        broken: false,
        grounded: true
      });

      blocks.push({
        id: createId('beam'),
        x: fx + fw / 2,
        y: f1TopY - 6,
        width: fw + 22,
        height: 15,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 135,
        maxHp: 135,
        type: 'beam',
        color: BAMBOO_BEAM_COLOR,
        mass: 16,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 5
      });

      // Floor 2: 4 Garrison Pillars
      const f2BaseY = f1TopY - 13;
      const f2H = 66;
      const f2TopY = f2BaseY - f2H;
      cols.forEach((px) => {
        blocks.push({
          id: createId('post'),
          x: px,
          y: f2BaseY - f2H / 2,
          width: 15,
          height: f2H,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 120,
          maxHp: 120,
          type: 'post',
          color: BAMBOO_POST_COLOR,
          mass: 14,
          isStructural: true,
          broken: false,
          grounded: true,
          nodes: 3
        });
      });

      for (let g = 0; g < goldOnF2; g++) {
        addGold(fx + fw * (g === 0 ? 0.48 : 0.65), f2BaseY - 7, g % 2 === 1);
      }

      blocks.push({
        id: createId('beam'),
        x: fx + fw / 2,
        y: f2TopY - 6,
        width: fw + 18,
        height: 15,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 130,
        maxHp: 130,
        type: 'beam',
        color: BAMBOO_BEAM_COLOR,
        mass: 15,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 5
      });

      // Floor 3: 3 Watchtower Battlement Pillars
      const f3BaseY = f2TopY - 13;
      const f3H = 56;
      const f3TopY = f3BaseY - f3H;
      [fx + 10, fx + fw / 2, fx + fw - 10].forEach((px) => {
        blocks.push({
          id: createId('post'),
          x: px,
          y: f3BaseY - f3H / 2,
          width: 14,
          height: f3H,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 110,
          maxHp: 110,
          type: 'post',
          color: BAMBOO_POST_COLOR,
          mass: 12,
          isStructural: true,
          broken: false,
          grounded: true,
          nodes: 3
        });
      });

      for (let g = 0; g < goldOnF3; g++) {
        addGold(fx + fw / 2, f3BaseY - 7, false);
      }

      blocks.push({
        id: createId('beam'),
        x: fx + fw / 2,
        y: f3TopY - 6,
        width: fw + 12,
        height: 14,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 125,
        maxHp: 125,
        type: 'beam',
        color: BAMBOO_BEAM_COLOR,
        mass: 14,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 4
      });

      // 3-Tier Fortress Roof
      for (let r = 0; r < 3; r++) {
        blocks.push({
          id: createId('thatch'),
          x: fx + fw / 2,
          y: f3TopY - 19 - r * 14,
          width: fw + 20 - r * 26,
          height: 15,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 75,
          maxHp: 75,
          type: 'thatch',
          color: THATCH_COLOR,
          mass: 8,
          isStructural: false,
          broken: false,
          grounded: true
        });
      }
    };

    // 1. West Fortress Bastion
    const westKeepX = baseX - 25;
    const keepW = 144;
    buildFortressKeep(westKeepX, keepW, 1, 1);

    // 2. Central Double-Decked Bamboo Suspension Bridge (4 Tall Stilt Pylons + 2 Bridge Decks)
    const spanX = westKeepX + keepW + 14;
    const spanW = 152;
    const deck1H = 92;
    const deck1TopY = groundY - deck1H;

    // 4 Stilt Pylons supporting Lower Suspension Deck
    const spanCols = [spanX, spanX + spanW * 0.33, spanX + spanW * 0.67, spanX + spanW];
    spanCols.forEach((px) => {
      blocks.push({
        id: createId('stilt'),
        x: px,
        y: groundY - deck1H / 2,
        width: 15,
        height: deck1H,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 125,
        maxHp: 125,
        type: 'stilt',
        color: STILT_COLOR,
        mass: 15,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 4
      });
    });

    // Lower Suspension Bridge Deck Beam
    blocks.push({
      id: createId('beam'),
      x: spanX + spanW / 2,
      y: deck1TopY - 6,
      width: spanW + 24,
      height: 15,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 135,
      maxHp: 135,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 16,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Upper Suspension Bridge Deck Pillars (4 Posts on Lower Deck)
    const deck2BaseY = deck1TopY - 13;
    const deck2H = 68;
    const deck2TopY = deck2BaseY - deck2H;
    spanCols.forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: deck2BaseY - deck2H / 2,
        width: 14,
        height: deck2H,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 115,
        maxHp: 115,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 13,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 3
      });
    });

    addGold(spanX + spanW * 0.35, deck2BaseY - 7, false);
    addGold(spanX + spanW * 0.65, deck2BaseY - 7, true);

    // Upper Suspension Bridge Deck Beam
    blocks.push({
      id: createId('beam'),
      x: spanX + spanW / 2,
      y: deck2TopY - 6,
      width: spanW + 20,
      height: 15,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 130,
      maxHp: 130,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 15,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 5
    });

    // Bridge Watch-Pavilion on Upper Deck (3 Posts + Roof)
    const pavBaseY = deck2TopY - 13;
    const pavH = 54;
    const pavTopY = pavBaseY - pavH;
    [spanX + 14, spanX + spanW / 2, spanX + spanW - 14].forEach((px) => {
      blocks.push({
        id: createId('post'),
        x: px,
        y: pavBaseY - pavH / 2,
        width: 14,
        height: pavH,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 110,
        maxHp: 110,
        type: 'post',
        color: BAMBOO_POST_COLOR,
        mass: 12,
        isStructural: true,
        broken: false,
        grounded: true,
        nodes: 3
      });
    });

    addGold(spanX + spanW / 2, pavBaseY - 7, false);

    blocks.push({
      id: createId('beam'),
      x: spanX + spanW / 2,
      y: pavTopY - 6,
      width: spanW + 8,
      height: 14,
      angle: 0,
      vx: 0,
      vy: 0,
      vAngle: 0,
      hp: 120,
      maxHp: 120,
      type: 'beam',
      color: BAMBOO_BEAM_COLOR,
      mass: 13,
      isStructural: true,
      broken: false,
      grounded: true,
      nodes: 4
    });

    for (let r = 0; r < 2; r++) {
      blocks.push({
        id: createId('thatch'),
        x: spanX + spanW / 2,
        y: pavTopY - 19 - r * 14,
        width: spanW + 14 - r * 30,
        height: 15,
        angle: 0,
        vx: 0,
        vy: 0,
        vAngle: 0,
        hp: 72,
        maxHp: 72,
        type: 'thatch',
        color: THATCH_COLOR,
        mass: 8,
        isStructural: false,
        broken: false,
        grounded: true
      });
    }

    // 3. East Fortress Bastion
    const eastKeepX = spanX + spanW + 14;
    buildFortressKeep(eastKeepX, keepW, 1, 1);
  }

  // ===========================================================================
  // LEVELS 30 TO 50: LARGE STANDALONE MULTI-HOUSE BAMBOO COMPOUNDS (LEVEL 20 SCALE)
  // Every level from 30 to 50 builds 4 to 6 large, wide, completely separate bamboo
  // houses (150px to 240px wide, mixing 1-story, 2-story, 3-story, 4-story, and in
  // Levels 46-50 soaring 5-story towers up to 290px high) modeled on Level 20
  // with full woven chatai walls, 4-7 tier straw thatch roofs, hanging lanterns,
  // clay pots, and bamboo ladders. Separated by 28px open gaps with zero
  // connecting bridges and reinforced pillars (170-200 HP) so a single Bomb Ball
  // never clears the level.
  // ===========================================================================
  else if (
    type === 'sovereign_fortress' ||
    type === 'pagoda_watchtower' ||
    type === 'twin_bridge_citadel' ||
    type === 'celestial_pagoda_fortress' ||
    type === 'skybridge_garrison' ||
    type === 'supreme_pagoda_citadel' ||
    type === 'village_row_four' ||
    type === 'stilt_bazaar_four' ||
    type === 'bamboo_hamlet_five' ||
    type === 'merchant_quarter_four' ||
    type === 'grand_township_five' ||
    type === 'skyward_spire_quartet' ||
    type === 'twin_tower_bastion' ||
    type === 'imperial_high_hamlet' ||
    type === 'soaring_pagoda_row' ||
    type === 'grand_sky_citadel' ||
    type === 'skyline_pentagon_spire' ||
    type === 'twin_monarch_citadels' ||
    type === 'hexagonal_highland_row' ||
    type === 'imperial_skyline_bastion' ||
    type === 'grand_celestial_metropolis'
  ) {
    interface LargeHouseSpec {
      stories: 1 | 2 | 3 | 4 | 5;
      width: number;
      customHeight?: number;
      hasLadder?: boolean;
      ladderSide?: 'left' | 'right';
    }

    const buildLargeStandaloneHouse = (hx: number, spec: LargeHouseSpec, houseIdx: number) => {
      const w = spec.width;

      if (spec.stories === 1) {
        // --- LARGE 1-STORY BAMBOO GATEHOUSE (Width ~150px, Height 115px, 4 Thatch Tiers) ---
        const postH = 115;
        const midBeamY = groundY - postH * 0.45;
        const topBeamY = groundY - postH - 6;

        // 3 Heavy Reinforced Pillars
        [hx, hx + w / 2, hx + w].forEach((px) => {
          blocks.push({
            id: createId('post'),
            x: px,
            y: groundY - postH / 2,
            width: 16,
            height: postH,
            angle: 0,
            vx: 0,
            vy: 0,
            vAngle: 0,
            hp: 170,
            maxHp: 170,
            type: 'post',
            color: BAMBOO_POST_COLOR,
            mass: 16,
            isStructural: true,
            broken: false,
            grounded: true,
            nodes: 4
          });
        });

        // Mid-Rail Horizontal Beam
        blocks.push({
          id: createId('beam'),
          x: hx + w / 2,
          y: midBeamY,
          width: w + 18,
          height: 12,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 165,
          maxHp: 165,
          type: 'beam',
          color: BAMBOO_BEAM_COLOR,
          mass: 14,
          isStructural: true,
          broken: false,
          grounded: true,
          nodes: 4
        });

        // Top Eaves Beam
        blocks.push({
          id: createId('beam'),
          x: hx + w / 2,
          y: topBeamY,
          width: w + 26,
          height: 14,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 180,
          maxHp: 180,
          type: 'beam',
          color: BAMBOO_BEAM_COLOR,
          mass: 16,
          isStructural: true,
          broken: false,
          grounded: true,
          nodes: 5
        });

        // Woven Split-Bamboo Chatai Wall Panel
        blocks.push({
          id: createId('wall'),
          x: hx + w / 2,
          y: groundY - postH * 0.45,
          width: w - 26,
          height: postH * 0.76,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 110,
          maxHp: 110,
          type: 'wall',
          color: BAMBOO_WALL_COLOR,
          mass: 10,
          isStructural: false,
          broken: false,
          grounded: true
        });

        // 4-Tier Layered Straw Thatch Roof
        const roofBaseY = topBeamY - 10;
        for (let r = 0; r < 4; r++) {
          const tierW = (w + 34) - r * 30;
          if (tierW < 30) break;
          blocks.push({
            id: createId('thatch'),
            x: hx + w / 2,
            y: roofBaseY - r * 18 - 8,
            width: tierW,
            height: 18,
            angle: 0,
            vx: 0,
            vy: 0,
            vAngle: 0,
            hp: 85,
            maxHp: 85,
            type: 'thatch',
            color: THATCH_COLOR,
            mass: 8,
            isStructural: false,
            broken: false,
            grounded: true
          });
        }

        // Gold Caches inside the 1-Story House
        addGold(hx + w * 0.28, midBeamY - 11, houseIdx % 2 === 0);
        addGold(hx + w * 0.72, midBeamY - 12, houseIdx % 2 === 1);

        // Leaning Bamboo Ladder
        if (spec.hasLadder) {
          const ladderX = spec.ladderSide === 'right' ? hx + w + 10 : hx - 10;
          const ladderH = postH + 18;
          blocks.push({
            id: createId('ladder'),
            x: ladderX,
            y: groundY - ladderH / 2,
            width: 16,
            height: ladderH,
            angle: spec.ladderSide === 'right' ? -0.15 : 0.15,
            vx: 0,
            vy: 0,
            vAngle: 0,
            hp: 65,
            maxHp: 65,
            type: 'ladder',
            color: LADDER_COLOR,
            mass: 7,
            isStructural: false,
            broken: false,
            grounded: true
          });
        }

        // Hanging Clay Pots & Golden Lantern
        [hx - 8, hx + w + 8].forEach((potX) => {
          blocks.push({
            id: createId('pot'),
            x: potX,
            y: topBeamY + 22,
            width: 18,
            height: 22,
            angle: 0,
            vx: 0,
            vy: 0,
            vAngle: 0,
            hp: 45,
            maxHp: 45,
            type: 'pot',
            color: POT_COLOR,
            mass: 4,
            isStructural: false,
            broken: false,
            grounded: true,
            hanging: true
          });
        });

        blocks.push({
          id: createId('lantern'),
          x: hx + w / 2,
          y: topBeamY + 24,
          width: 16,
          height: 22,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 40,
          maxHp: 40,
          type: 'lantern',
          color: LANTERN_COLOR,
          mass: 3,
          isStructural: false,
          broken: false,
          grounded: true,
          hanging: true
        });
      } else if (spec.stories === 2) {
        // --- LARGE 2-STORY STILT RAMPART HOUSE (Width ~165px, Stilts 48px + Upper 96px, 4 Thatch Tiers) ---
        const stiltH = 48;
        const deckY = groundY - stiltH;
        const postH = 96;
        const topY = deckY - postH;

        // 3 Heavy Foundation Stilts
        [hx, hx + w / 2, hx + w].forEach((sx) => {
          blocks.push({
            id: createId('stilt'),
            x: sx,
            y: groundY - stiltH / 2,
            width: 16,
            height: stiltH,
            angle: 0,
            vx: 0,
            vy: 0,
            vAngle: 0,
            hp: 175,
            maxHp: 175,
            type: 'stilt',
            color: STILT_COLOR,
            mass: 16,
            isStructural: true,
            broken: false,
            grounded: true,
            nodes: 3
          });
        });

        // First-Floor Deck Beam
        blocks.push({
          id: createId('beam'),
          x: hx + w / 2,
          y: deckY - 6,
          width: w + 24,
          height: 14,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 185,
          maxHp: 185,
          type: 'beam',
          color: BAMBOO_BEAM_COLOR,
          mass: 16,
          isStructural: true,
          broken: false,
          grounded: true,
          nodes: 4
        });

        // 3 Upper Story Bamboo Posts
        [hx, hx + w / 2, hx + w].forEach((px) => {
          blocks.push({
            id: createId('post'),
            x: px,
            y: deckY - postH / 2,
            width: 15,
            height: postH,
            angle: 0,
            vx: 0,
            vy: 0,
            vAngle: 0,
            hp: 165,
            maxHp: 165,
            type: 'post',
            color: BAMBOO_POST_COLOR,
            mass: 15,
            isStructural: true,
            broken: false,
            grounded: true,
            nodes: 3
          });
        });

        // Upper Eaves Beam
        blocks.push({
          id: createId('beam'),
          x: hx + w / 2,
          y: topY - 6,
          width: w + 26,
          height: 14,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 180,
          maxHp: 180,
          type: 'beam',
          color: BAMBOO_BEAM_COLOR,
          mass: 16,
          isStructural: true,
          broken: false,
          grounded: true,
          nodes: 4
        });

        // Upper Woven Split-Bamboo Wall
        blocks.push({
          id: createId('wall'),
          x: hx + w / 2,
          y: deckY - postH * 0.5,
          width: w - 22,
          height: postH * 0.78,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 115,
          maxHp: 115,
          type: 'wall',
          color: BAMBOO_WALL_COLOR,
          mass: 11,
          isStructural: false,
          broken: false,
          grounded: true
        });

        // 4-Tier Layered Straw Thatch Roof
        const roofY = topY - 16;
        for (let r = 0; r < 4; r++) {
          const tierW = (w + 34) - r * 30;
          blocks.push({
            id: createId('thatch'),
            x: hx + w / 2,
            y: roofY - r * 18,
            width: tierW,
            height: 18,
            angle: 0,
            vx: 0,
            vy: 0,
            vAngle: 0,
            hp: 85,
            maxHp: 85,
            type: 'thatch',
            color: THATCH_COLOR,
            mass: 8,
            isStructural: false,
            broken: false,
            grounded: true
          });
        }

        // Gold Caches on Stilt Rampart Deck
        addGold(hx + w * 0.3, deckY - 18, false);
        addGold(hx + w * 0.7, deckY - 18, true);

        // Hanging Lanterns & Clay Pots
        [hx + 24, hx + w - 24].forEach((lx) => {
          blocks.push({
            id: createId('lantern'),
            x: lx,
            y: topY + 18,
            width: 16,
            height: 22,
            angle: 0,
            vx: 0,
            vy: 0,
            vAngle: 0,
            hp: 40,
            maxHp: 40,
            type: 'lantern',
            color: LANTERN_COLOR,
            mass: 3,
            isStructural: false,
            broken: false,
            grounded: true,
            hanging: true
          });
        });

        [hx - 8, hx + w + 8].forEach((potX) => {
          blocks.push({
            id: createId('pot'),
            x: potX,
            y: topY + 16,
            width: 18,
            height: 22,
            angle: 0,
            vx: 0,
            vy: 0,
            vAngle: 0,
            hp: 45,
            maxHp: 45,
            type: 'pot',
            color: POT_COLOR,
            mass: 4,
            isStructural: false,
            broken: false,
            grounded: true,
            hanging: true
          });
        });
      } else if (spec.stories === 3) {
        // --- LARGE 3-STORY CITADEL KEEP (Width ~220px, Height 190px, 4 Columns, 5 Thatch Tiers) ---
        const totalH = spec.customHeight || 190;
        const topY = groundY - totalH;
        const f1Y = groundY - 60;
        const f2Y = groundY - 120;

        // 4 Monumental Bamboo Columns
        [hx, hx + w * 0.33, hx + w * 0.67, hx + w].forEach((px) => {
          blocks.push({
            id: createId('post'),
            x: px,
            y: groundY - totalH / 2,
            width: 18,
            height: totalH,
            angle: 0,
            vx: 0,
            vy: 0,
            vAngle: 0,
            hp: 190,
            maxHp: 190,
            type: 'post',
            color: BAMBOO_POST_COLOR,
            mass: 20,
            isStructural: true,
            broken: false,
            grounded: true,
            nodes: 6
          });
        });

        // Floor 1 Beam
        blocks.push({
          id: createId('beam'),
          x: hx + w / 2,
          y: f1Y,
          width: w + 24,
          height: 14,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 180,
          maxHp: 180,
          type: 'beam',
          color: BAMBOO_BEAM_COLOR,
          mass: 16,
          isStructural: true,
          broken: false,
          grounded: true,
          nodes: 5
        });

        // Floor 2 Beam
        blocks.push({
          id: createId('beam'),
          x: hx + w / 2,
          y: f2Y,
          width: w + 28,
          height: 15,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 185,
          maxHp: 185,
          type: 'beam',
          color: BAMBOO_BEAM_COLOR,
          mass: 17,
          isStructural: true,
          broken: false,
          grounded: true,
          nodes: 5
        });

        // Floor 3 Top Eaves Beam
        blocks.push({
          id: createId('beam'),
          x: hx + w / 2,
          y: topY - 6,
          width: w + 34,
          height: 16,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 190,
          maxHp: 190,
          type: 'beam',
          color: BAMBOO_BEAM_COLOR,
          mass: 18,
          isStructural: true,
          broken: false,
          grounded: true,
          nodes: 6
        });

        // Full Woven Split-Bamboo Chatai Wall Backing
        blocks.push({
          id: createId('wall'),
          x: hx + w / 2,
          y: groundY - totalH * 0.48,
          width: w - 34,
          height: totalH * 0.78,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 130,
          maxHp: 130,
          type: 'wall',
          color: BAMBOO_WALL_COLOR,
          mass: 13,
          isStructural: false,
          broken: false,
          grounded: true
        });

        // 5-Tier Layered Straw Thatch Roof
        const roofY = topY - 16;
        for (let r = 0; r < 5; r++) {
          const tierW = (w + 40) - r * 32;
          blocks.push({
            id: createId('thatch'),
            x: hx + w / 2,
            y: roofY - r * 18,
            width: tierW,
            height: 18,
            angle: 0,
            vx: 0,
            vy: 0,
            vAngle: 0,
            hp: 90,
            maxHp: 90,
            type: 'thatch',
            color: THATCH_COLOR,
            mass: 9,
            isStructural: false,
            broken: false,
            grounded: true
          });
        }

        // Gold Caches across the 3 Stories
        addGold(hx + w * 0.28, f1Y - 12, false);
        addGold(hx + w * 0.72, f1Y - 12, true);
        addGold(hx + w * 0.5, f2Y - 12, true);

        // Hanging Golden Lanterns & Clay Pots
        [hx + 26, hx + w - 26].forEach((lx) => {
          blocks.push({
            id: createId('lantern'),
            x: lx,
            y: topY + 18,
            width: 16,
            height: 22,
            angle: 0,
            vx: 0,
            vy: 0,
            vAngle: 0,
            hp: 40,
            maxHp: 40,
            type: 'lantern',
            color: LANTERN_COLOR,
            mass: 3,
            isStructural: false,
            broken: false,
            grounded: true,
            hanging: true
          });
        });

        [hx - 8, hx + w + 8].forEach((potX) => {
          blocks.push({
            id: createId('pot'),
            x: potX,
            y: topY + 16,
            width: 18,
            height: 22,
            angle: 0,
            vx: 0,
            vy: 0,
            vAngle: 0,
            hp: 45,
            maxHp: 45,
            type: 'pot',
            color: POT_COLOR,
            mass: 4,
            isStructural: false,
            broken: false,
            grounded: true,
            hanging: true
          });
        });
      } else if (spec.stories === 4) {
        // --- TALL 4-STORY HIGH-RISE BAMBOO CITADEL TOWER (Width ~230px-235px, Height 240px-248px, 4 Columns, 6 Thatch Tiers) ---
        const totalH = spec.customHeight || 244;
        const topY = groundY - totalH;
        const f1Y = groundY - 58;
        const f2Y = groundY - 118;
        const f3Y = groundY - 178;

        // 4 Tall Monumental Bamboo Columns (HP 195)
        [hx, hx + w * 0.33, hx + w * 0.67, hx + w].forEach((px) => {
          blocks.push({
            id: createId('post'),
            x: px,
            y: groundY - totalH / 2,
            width: 19,
            height: totalH,
            angle: 0,
            vx: 0,
            vy: 0,
            vAngle: 0,
            hp: 195,
            maxHp: 195,
            type: 'post',
            color: BAMBOO_POST_COLOR,
            mass: 22,
            isStructural: true,
            broken: false,
            grounded: true,
            nodes: 8
          });
        });

        // Floor 1 Beam
        blocks.push({
          id: createId('beam'),
          x: hx + w / 2,
          y: f1Y,
          width: w + 24,
          height: 14,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 185,
          maxHp: 185,
          type: 'beam',
          color: BAMBOO_BEAM_COLOR,
          mass: 16,
          isStructural: true,
          broken: false,
          grounded: true,
          nodes: 5
        });

        // Floor 2 Beam
        blocks.push({
          id: createId('beam'),
          x: hx + w / 2,
          y: f2Y,
          width: w + 28,
          height: 15,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 188,
          maxHp: 188,
          type: 'beam',
          color: BAMBOO_BEAM_COLOR,
          mass: 17,
          isStructural: true,
          broken: false,
          grounded: true,
          nodes: 5
        });

        // Floor 3 Beam
        blocks.push({
          id: createId('beam'),
          x: hx + w / 2,
          y: f3Y,
          width: w + 32,
          height: 15,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 192,
          maxHp: 192,
          type: 'beam',
          color: BAMBOO_BEAM_COLOR,
          mass: 18,
          isStructural: true,
          broken: false,
          grounded: true,
          nodes: 6
        });

        // Floor 4 Top Eaves Beam
        blocks.push({
          id: createId('beam'),
          x: hx + w / 2,
          y: topY - 6,
          width: w + 38,
          height: 16,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 195,
          maxHp: 195,
          type: 'beam',
          color: BAMBOO_BEAM_COLOR,
          mass: 19,
          isStructural: true,
          broken: false,
          grounded: true,
          nodes: 6
        });

        // Lower & Upper Woven Split-Bamboo Chatai Wall Panels
        blocks.push({
          id: createId('wall'),
          x: hx + w / 2,
          y: groundY - totalH * 0.27,
          width: w - 34,
          height: totalH * 0.42,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 135,
          maxHp: 135,
          type: 'wall',
          color: BAMBOO_WALL_COLOR,
          mass: 13,
          isStructural: false,
          broken: false,
          grounded: true
        });

        blocks.push({
          id: createId('wall'),
          x: hx + w / 2,
          y: groundY - totalH * 0.72,
          width: w - 34,
          height: totalH * 0.42,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 135,
          maxHp: 135,
          type: 'wall',
          color: BAMBOO_WALL_COLOR,
          mass: 13,
          isStructural: false,
          broken: false,
          grounded: true
        });

        // Leaning Bamboo Ladder on Tall 4-Story House if specified
        if (spec.hasLadder) {
          const ladderX = spec.ladderSide === 'right' ? hx + w + 10 : hx - 10;
          const ladderH = 135;
          blocks.push({
            id: createId('ladder'),
            x: ladderX,
            y: groundY - ladderH / 2,
            width: 16,
            height: ladderH,
            angle: spec.ladderSide === 'right' ? -0.12 : 0.12,
            vx: 0,
            vy: 0,
            vAngle: 0,
            hp: 70,
            maxHp: 70,
            type: 'ladder',
            color: LADDER_COLOR,
            mass: 8,
            isStructural: false,
            broken: false,
            grounded: true
          });
        }

        // 6-Tier Layered Straw Thatch Roof
        const roofY = topY - 16;
        for (let r = 0; r < 6; r++) {
          const tierW = (w + 46) - r * 30;
          if (tierW < 32) break;
          blocks.push({
            id: createId('thatch'),
            x: hx + w / 2,
            y: roofY - r * 18,
            width: tierW,
            height: 18,
            angle: 0,
            vx: 0,
            vy: 0,
            vAngle: 0,
            hp: 92,
            maxHp: 92,
            type: 'thatch',
            color: THATCH_COLOR,
            mass: 9,
            isStructural: false,
            broken: false,
            grounded: true
          });
        }

        // Moderate Gold Caches across the 4 Stories (3 gold caches per 4-story house)
        addGold(hx + w * 0.28, f1Y - 12, false);
        addGold(hx + w * 0.72, f2Y - 12, true);
        addGold(hx + w * 0.5, f3Y - 12, true);

        // Hanging Golden Lanterns & Clay Pots
        [hx + 28, hx + w - 28].forEach((lx) => {
          blocks.push({
            id: createId('lantern'),
            x: lx,
            y: topY + 18,
            width: 16,
            height: 22,
            angle: 0,
            vx: 0,
            vy: 0,
            vAngle: 0,
            hp: 40,
            maxHp: 40,
            type: 'lantern',
            color: LANTERN_COLOR,
            mass: 3,
            isStructural: false,
            broken: false,
            grounded: true,
            hanging: true
          });
        });

        [hx - 8, hx + w + 8].forEach((potX) => {
          blocks.push({
            id: createId('pot'),
            x: potX,
            y: topY + 16,
            width: 18,
            height: 22,
            angle: 0,
            vx: 0,
            vy: 0,
            vAngle: 0,
            hp: 45,
            maxHp: 45,
            type: 'pot',
            color: POT_COLOR,
            mass: 4,
            isStructural: false,
            broken: false,
            grounded: true,
            hanging: true
          });
        });
      } else {
        // --- SOARING 5-STORY HIGH-RISE BAMBOO TOWER (Width ~235px-240px, Height 270px-290px, 4 Columns, 7 Thatch Tiers) ---
        const totalH = spec.customHeight || 280;
        const topY = groundY - totalH;
        const f1Y = groundY - Math.round(totalH * 0.20);
        const f2Y = groundY - Math.round(totalH * 0.40);
        const f3Y = groundY - Math.round(totalH * 0.60);
        const f4Y = groundY - Math.round(totalH * 0.80);

        // 4 Monumental Bamboo Columns (HP 200)
        [hx, hx + w * 0.33, hx + w * 0.67, hx + w].forEach((px) => {
          blocks.push({
            id: createId('post'),
            x: px,
            y: groundY - totalH / 2,
            width: 20,
            height: totalH,
            angle: 0,
            vx: 0,
            vy: 0,
            vAngle: 0,
            hp: 200,
            maxHp: 200,
            type: 'post',
            color: BAMBOO_POST_COLOR,
            mass: 25,
            isStructural: true,
            broken: false,
            grounded: true,
            nodes: 8
          });
        });

        // Floor 1 Beam
        blocks.push({
          id: createId('beam'),
          x: hx + w / 2,
          y: f1Y,
          width: w + 24,
          height: 14,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 190,
          maxHp: 190,
          type: 'beam',
          color: BAMBOO_BEAM_COLOR,
          mass: 17,
          isStructural: true,
          broken: false,
          grounded: true,
          nodes: 5
        });

        // Floor 2 Beam
        blocks.push({
          id: createId('beam'),
          x: hx + w / 2,
          y: f2Y,
          width: w + 28,
          height: 15,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 192,
          maxHp: 192,
          type: 'beam',
          color: BAMBOO_BEAM_COLOR,
          mass: 18,
          isStructural: true,
          broken: false,
          grounded: true,
          nodes: 5
        });

        // Floor 3 Beam
        blocks.push({
          id: createId('beam'),
          x: hx + w / 2,
          y: f3Y,
          width: w + 32,
          height: 15,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 195,
          maxHp: 195,
          type: 'beam',
          color: BAMBOO_BEAM_COLOR,
          mass: 18,
          isStructural: true,
          broken: false,
          grounded: true,
          nodes: 6
        });

        // Floor 4 Beam
        blocks.push({
          id: createId('beam'),
          x: hx + w / 2,
          y: f4Y,
          width: w + 36,
          height: 16,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 198,
          maxHp: 198,
          type: 'beam',
          color: BAMBOO_BEAM_COLOR,
          mass: 19,
          isStructural: true,
          broken: false,
          grounded: true,
          nodes: 6
        });

        // Floor 5 Top Eaves Beam
        blocks.push({
          id: createId('beam'),
          x: hx + w / 2,
          y: topY - 6,
          width: w + 42,
          height: 17,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 200,
          maxHp: 200,
          type: 'beam',
          color: BAMBOO_BEAM_COLOR,
          mass: 20,
          isStructural: true,
          broken: false,
          grounded: true,
          nodes: 7
        });

        // 3 Woven Split-Bamboo Chatai Wall Sections (Lower, Middle, Upper)
        blocks.push({
          id: createId('wall'),
          x: hx + w / 2,
          y: groundY - totalH * 0.20,
          width: w - 34,
          height: totalH * 0.28,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 140,
          maxHp: 140,
          type: 'wall',
          color: BAMBOO_WALL_COLOR,
          mass: 14,
          isStructural: false,
          broken: false,
          grounded: true
        });

        blocks.push({
          id: createId('wall'),
          x: hx + w / 2,
          y: groundY - totalH * 0.50,
          width: w - 34,
          height: totalH * 0.28,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 140,
          maxHp: 140,
          type: 'wall',
          color: BAMBOO_WALL_COLOR,
          mass: 14,
          isStructural: false,
          broken: false,
          grounded: true
        });

        blocks.push({
          id: createId('wall'),
          x: hx + w / 2,
          y: groundY - totalH * 0.80,
          width: w - 34,
          height: totalH * 0.28,
          angle: 0,
          vx: 0,
          vy: 0,
          vAngle: 0,
          hp: 140,
          maxHp: 140,
          type: 'wall',
          color: BAMBOO_WALL_COLOR,
          mass: 14,
          isStructural: false,
          broken: false,
          grounded: true
        });

        // Leaning Bamboo Ladder if specified
        if (spec.hasLadder) {
          const ladderX = spec.ladderSide === 'right' ? hx + w + 10 : hx - 10;
          const ladderH = 155;
          blocks.push({
            id: createId('ladder'),
            x: ladderX,
            y: groundY - ladderH / 2,
            width: 16,
            height: ladderH,
            angle: spec.ladderSide === 'right' ? -0.12 : 0.12,
            vx: 0,
            vy: 0,
            vAngle: 0,
            hp: 75,
            maxHp: 75,
            type: 'ladder',
            color: LADDER_COLOR,
            mass: 9,
            isStructural: false,
            broken: false,
            grounded: true
          });
        }

        // 7-Tier Layered Straw Thatch Roof
        const roofY = topY - 16;
        for (let r = 0; r < 7; r++) {
          const tierW = (w + 50) - r * 28;
          if (tierW < 32) break;
          blocks.push({
            id: createId('thatch'),
            x: hx + w / 2,
            y: roofY - r * 18,
            width: tierW,
            height: 18,
            angle: 0,
            vx: 0,
            vy: 0,
            vAngle: 0,
            hp: 95,
            maxHp: 95,
            type: 'thatch',
            color: THATCH_COLOR,
            mass: 9,
            isStructural: false,
            broken: false,
            grounded: true
          });
        }

        // Moderate Gold Caches across the 5 Stories
        addGold(hx + w * 0.28, f1Y - 12, false);
        addGold(hx + w * 0.72, f2Y - 12, true);
        addGold(hx + w * 0.35, f3Y - 12, false);
        addGold(hx + w * 0.65, f4Y - 12, true);

        // Hanging Golden Lanterns & Clay Pots
        [hx + 28, hx + w - 28].forEach((lx) => {
          blocks.push({
            id: createId('lantern'),
            x: lx,
            y: topY + 18,
            width: 16,
            height: 22,
            angle: 0,
            vx: 0,
            vy: 0,
            vAngle: 0,
            hp: 40,
            maxHp: 40,
            type: 'lantern',
            color: LANTERN_COLOR,
            mass: 3,
            isStructural: false,
            broken: false,
            grounded: true,
            hanging: true
          });
        });

        [hx - 8, hx + w + 8].forEach((potX) => {
          blocks.push({
            id: createId('pot'),
            x: potX,
            y: topY + 16,
            width: 18,
            height: 22,
            angle: 0,
            vx: 0,
            vy: 0,
            vAngle: 0,
            hp: 45,
            maxHp: 45,
            type: 'pot',
            color: POT_COLOR,
            mass: 4,
            isStructural: false,
            broken: false,
            grounded: true,
            hanging: true
          });
        });
      }
    };

    const layouts: Record<string, LargeHouseSpec[]> = {
      // Level 30: 1-story, 2-story, 3-story, 1-story (exact Level 20 progression)
      sovereign_fortress: [
        { stories: 1, width: 150, hasLadder: true, ladderSide: 'left' },
        { stories: 2, width: 165 },
        { stories: 3, width: 220 },
        { stories: 1, width: 150, hasLadder: true, ladderSide: 'right' }
      ],
      // Level 31: 2-story, 3-story, 1-story, 2-story
      pagoda_watchtower: [
        { stories: 2, width: 165 },
        { stories: 3, width: 220 },
        { stories: 1, width: 150, hasLadder: true, ladderSide: 'left' },
        { stories: 2, width: 165 }
      ],
      // Level 32: 1-story, 3-story, 2-story, 3-story
      twin_bridge_citadel: [
        { stories: 1, width: 150, hasLadder: true, ladderSide: 'left' },
        { stories: 3, width: 215 },
        { stories: 2, width: 165 },
        { stories: 3, width: 215 }
      ],
      // Level 33: 3-story, 1-story, 2-story, 3-story
      celestial_pagoda_fortress: [
        { stories: 3, width: 215 },
        { stories: 1, width: 150, hasLadder: true, ladderSide: 'left' },
        { stories: 2, width: 165 },
        { stories: 3, width: 215 }
      ],
      // Level 34: 2-story, 1-story, 3-story, 2-story
      skybridge_garrison: [
        { stories: 2, width: 165 },
        { stories: 1, width: 150, hasLadder: true, ladderSide: 'left' },
        { stories: 3, width: 220 },
        { stories: 2, width: 165 }
      ],
      // Level 35: 1-story, 2-story, 3-story, 2-story
      supreme_pagoda_citadel: [
        { stories: 1, width: 150, hasLadder: true, ladderSide: 'left' },
        { stories: 2, width: 165 },
        { stories: 3, width: 225 },
        { stories: 2, width: 165 }
      ],
      // Level 36: 1-story, 2-story, 3-story, 1-story
      village_row_four: [
        { stories: 1, width: 150, hasLadder: true, ladderSide: 'left' },
        { stories: 2, width: 165 },
        { stories: 3, width: 220 },
        { stories: 1, width: 150, hasLadder: true, ladderSide: 'right' }
      ],
      // Level 37: 2-story, 3-story, 1-story, 2-story
      stilt_bazaar_four: [
        { stories: 2, width: 165 },
        { stories: 3, width: 220 },
        { stories: 1, width: 150, hasLadder: true, ladderSide: 'left' },
        { stories: 2, width: 165 }
      ],
      // Level 38: 3-story, 2-story, 1-story, 3-story
      bamboo_hamlet_five: [
        { stories: 3, width: 215 },
        { stories: 2, width: 165 },
        { stories: 1, width: 150, hasLadder: true, ladderSide: 'right' },
        { stories: 3, width: 215 }
      ],
      // Level 39: 1-story, 3-story, 2-story, 3-story
      merchant_quarter_four: [
        { stories: 1, width: 150, hasLadder: true, ladderSide: 'left' },
        { stories: 3, width: 220 },
        { stories: 2, width: 165 },
        { stories: 3, width: 220 }
      ],
      // Level 40: 2-story, 3-story, 1-story, 3-story
      grand_township_five: [
        { stories: 2, width: 165 },
        { stories: 3, width: 220 },
        { stories: 1, width: 150, hasLadder: true, ladderSide: 'left' },
        { stories: 3, width: 225 }
      ],
      // Level 41: 1-story, 4-story (tall 242px), 2-story, 3-story (tall 200px)
      skyward_spire_quartet: [
        { stories: 1, width: 150, hasLadder: true, ladderSide: 'left' },
        { stories: 4, width: 230, customHeight: 242 },
        { stories: 2, width: 165 },
        { stories: 3, width: 215, customHeight: 200 }
      ],
      // Level 42: 2-story, 4-story (tall 245px), 1-story, 4-story (tall 238px)
      twin_tower_bastion: [
        { stories: 2, width: 165 },
        { stories: 4, width: 230, customHeight: 245 },
        { stories: 1, width: 150, hasLadder: true, ladderSide: 'left' },
        { stories: 4, width: 225, customHeight: 238, hasLadder: true, ladderSide: 'right' }
      ],
      // Level 43: 3-story (tall 205px), 1-story, 4-story (tall 246px), 2-story
      imperial_high_hamlet: [
        { stories: 3, width: 215, customHeight: 205 },
        { stories: 1, width: 150, hasLadder: true, ladderSide: 'left' },
        { stories: 4, width: 235, customHeight: 246 },
        { stories: 2, width: 165 }
      ],
      // Level 44: 4-story (tall 240px), 2-story, 3-story (tall 202px), 4-story (tall 248px)
      soaring_pagoda_row: [
        { stories: 4, width: 225, customHeight: 240, hasLadder: true, ladderSide: 'left' },
        { stories: 2, width: 165 },
        { stories: 3, width: 215, customHeight: 202 },
        { stories: 4, width: 230, customHeight: 248 }
      ],
      // Level 45: 2-story, 4-story (tall 246px), 3-story (tall 205px), 4-story (tall 248px)
      grand_sky_citadel: [
        { stories: 2, width: 165 },
        { stories: 4, width: 230, customHeight: 246, hasLadder: true, ladderSide: 'left' },
        { stories: 3, width: 215, customHeight: 205 },
        { stories: 4, width: 230, customHeight: 248, hasLadder: true, ladderSide: 'right' }
      ],
      // Level 46: 5 houses expanding to the right with soaring 5-story spire (275px)
      skyline_pentagon_spire: [
        { stories: 1, width: 150, hasLadder: true, ladderSide: 'left' },
        { stories: 2, width: 165 },
        { stories: 4, width: 230, customHeight: 242 },
        { stories: 2, width: 165 },
        { stories: 5, width: 235, customHeight: 275, hasLadder: true, ladderSide: 'right' }
      ],
      // Level 47: 5 houses with twin 5-story towers (282px & 280px)
      twin_monarch_citadels: [
        { stories: 2, width: 165 },
        { stories: 5, width: 238, customHeight: 282, hasLadder: true, ladderSide: 'left' },
        { stories: 1, width: 150 },
        { stories: 3, width: 215, customHeight: 200 },
        { stories: 5, width: 235, customHeight: 280, hasLadder: true, ladderSide: 'right' }
      ],
      // Level 48: 6 houses expanding further rightward with 5-story pagoda (285px)
      hexagonal_highland_row: [
        { stories: 1, width: 150, hasLadder: true, ladderSide: 'left' },
        { stories: 3, width: 215, customHeight: 202 },
        { stories: 2, width: 165 },
        { stories: 4, width: 230, customHeight: 244 },
        { stories: 1, width: 150 },
        { stories: 5, width: 240, customHeight: 285, hasLadder: true, ladderSide: 'right' }
      ],
      // Level 49: 6 houses with 5-story citadel (288px) and dual 4-story keeps
      imperial_skyline_bastion: [
        { stories: 2, width: 165 },
        { stories: 4, width: 230, customHeight: 245, hasLadder: true, ladderSide: 'left' },
        { stories: 1, width: 150 },
        { stories: 5, width: 240, customHeight: 288 },
        { stories: 2, width: 165 },
        { stories: 4, width: 230, customHeight: 246, hasLadder: true, ladderSide: 'right' }
      ],
      // Level 50: 6 monumental houses with twin 290px high 5-story citadels
      grand_celestial_metropolis: [
        { stories: 1, width: 150, hasLadder: true, ladderSide: 'left' },
        { stories: 3, width: 215, customHeight: 205 },
        { stories: 5, width: 240, customHeight: 290, hasLadder: true, ladderSide: 'left' },
        { stories: 2, width: 165 },
        { stories: 4, width: 230, customHeight: 246 },
        { stories: 5, width: 240, customHeight: 290, hasLadder: true, ladderSide: 'right' }
      ]
    };

    const levelHouses = layouts[type] || layouts.sovereign_fortress;
    let curX = baseX; // Starts at 990, matching Level 20
    const gap = 28; // 28px open separation between houses with zero connecting bridges

    levelHouses.forEach((houseSpec, idx) => {
      buildLargeStandaloneHouse(curX, houseSpec, idx);
      curX += houseSpec.width + gap;
    });
  }



  // Fallback default
  else {
    buildHut3Pillars(baseX + 15, 185, 115, 4, {
      hasWall: true,
      hasLadder: true,
      ladderSide: 'left',
      potSide: 'both',
      hasLantern: true,
      goldCount: 2
    });
  }

  return blocks;
}

export function calculateDestructionPercentage(blocks: BambooBlock[]): number {
  if (blocks.length === 0) return 0;
  let totalMaxHp = 0;
  let totalCurrentHp = 0;

  for (const b of blocks) {
    totalMaxHp += b.maxHp;
    if (!b.broken && !b.despawned && !b.isDespawning) {
      totalCurrentHp += Math.max(0, b.hp);
    }
  }

  const destroyedRatio = 1 - (totalCurrentHp / totalMaxHp);
  return Math.min(100, Math.max(0, Math.round(destroyedRatio * 100)));
}
