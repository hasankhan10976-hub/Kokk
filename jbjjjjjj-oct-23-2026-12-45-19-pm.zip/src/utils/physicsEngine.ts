import Matter from 'matter-js';
import { BambooBlock, SpecialBallType } from '../types/game';

const { Engine, Bodies, Body, Composite, Events, Vector } = Matter;

export interface PhysicsImpactEvent {
  x: number;
  y: number;
  intensity: number;
  blockTypeA: string;
  blockTypeB: string;
}

export class HutPhysicsEngine {
  private engine: Matter.Engine;
  private groundBody: Matter.Body;
  private leftWallBody: Matter.Body;
  private rightWallBody: Matter.Body;
  private blockBodies: Map<string, Matter.Body> = new Map();
  private blockMap: Map<string, BambooBlock> = new Map();
  private groundY: number;
  private recentImpacts: PhysicsImpactEvent[] = [];
  private lastImpactTime: number = 0;
  private maxSettlingMs: number = 3200; // Force settle after 3.2s of impact to guarantee next delivery
  private hasEverImpacted: boolean = false;

  constructor(initialBlocks: BambooBlock[], groundY: number = 570) {
    this.groundY = groundY;

    // Create Matter.js 2D physics engine with realistic gravity
    this.engine = Engine.create({
      enableSleeping: false,
    });
    this.engine.gravity.y = 1.05;
    this.engine.gravity.scale = 0.0016;
    this.engine.positionIterations = 8;
    this.engine.velocityIterations = 6;

    // Static Ground Body - pieces collide, bounce and pile on it
    this.groundBody = Bodies.rectangle(1100, groundY + 25, 2400, 50, {
      isStatic: true,
      friction: 0.88, // Authentic grass/soil friction for debris piles
      frictionStatic: 0.95,
      restitution: 0.12, // Low bounce so logs and thatch settle naturally
      label: 'ground',
    });

    // Pitch containment barrier (left side) - prevents debris from rolling onto bowler / batting crease
    this.leftWallBody = Bodies.rectangle(858, groundY - 80, 24, 180, {
      isStatic: true,
      friction: 0.6,
      restitution: 0.1,
      label: 'left_wall',
    });

    // Right boundary wall - prevents pieces from flying infinitely offscreen
    this.rightWallBody = Bodies.rectangle(1340, groundY - 250, 40, 600, {
      isStatic: true,
      friction: 0.6,
      restitution: 0.15,
      label: 'right_wall',
    });

    Composite.add(this.engine.world, [this.groundBody, this.leftWallBody, this.rightWallBody]);

    // Initialize all hut blocks
    this.initBlocks(initialBlocks);

    // Setup collision listener for domino chain reactions and debris impacts
    this.setupCollisionHandlers();
  }

  public initBlocks(blocks: BambooBlock[]): void {
    // Clear existing block bodies
    this.blockBodies.forEach((body) => {
      Composite.remove(this.engine.world, body);
    });
    this.blockBodies.clear();
    this.blockMap.clear();
    this.hasEverImpacted = false;

    // Find foundation posts directly standing on the ground
    blocks.forEach((block) => {
      this.blockMap.set(block.id, block);

      // Material properties tailored for Angry Birds-style destruction
      let density = 0.0028;
      let friction = 0.82;
      let restitution = 0.16;

      if (block.type === 'thatch') {
        density = 0.0012; // Lighter straw thatch roof
        friction = 0.92; // High friction so roof tiles cling and stack
        restitution = 0.06; // Soft thud
      } else if (block.type === 'post' || block.type === 'stilt') {
        density = 0.0036; // Dense solid bamboo pillar
        friction = 0.80;
        restitution = 0.18;
      } else if (block.type === 'beam') {
        density = 0.0026; // Cross-beam
        friction = 0.84;
        restitution = 0.15;
      } else if (block.type === 'pot') {
        density = 0.0022;
        friction = 0.65;
        restitution = 0.32; // Clay bounce
      } else if (block.type === 'wall') {
        density = 0.0020;
        friction = 0.85;
        restitution = 0.12;
      }

      // Initial state:
      // In Angry Birds, architectural structures stand completely steady until disturbed or impacted.
      // We start blocks as static or locked to avoid pre-delivery drift/sag,
      // and activate them dynamically upon ball hit, explosion, or supporting joint displacement!
      const body = Bodies.rectangle(block.x, block.y, block.width, block.height, {
        angle: block.angle || 0,
        density,
        friction,
        frictionStatic: 0.95,
        restitution,
        isStatic: true, // Activated on impact or domino cascade
        label: block.id,
      });

      // Custom metadata
      (body as any).blockId = block.id;
      (body as any).isActivated = false;
      (body as any).originalX = block.x;
      (body as any).originalY = block.y;

      this.blockBodies.set(block.id, body);
      Composite.add(this.engine.world, body);
    });
  }

  private setupCollisionHandlers(): void {
    Events.on(this.engine, 'collisionStart', (event) => {
      const pairs = event.pairs;
      for (let i = 0; i < pairs.length; i++) {
        const { bodyA, bodyB } = pairs[i];
        const isBodyAGround = bodyA.label === 'ground';
        const isBodyBGround = bodyB.label === 'ground';

        const idA = (bodyA as any).blockId as string | undefined;
        const idB = (bodyB as any).blockId as string | undefined;

        // If a moving dynamic piece hits a static intact block, awaken the intact block!
        if (idA && idB) {
          const actA = (bodyA as any).isActivated;
          const actB = (bodyB as any).isActivated;

          if (actA && !actB) {
            this.activateBlock(idB, bodyA.velocity.x * 0.45, bodyA.velocity.y * 0.45);
          } else if (actB && !actA) {
            this.activateBlock(idA, bodyB.velocity.x * 0.45, bodyB.velocity.y * 0.45);
          }

          // Calculate impact kinetic energy for secondary domino damage
          const relVx = bodyA.velocity.x - bodyB.velocity.x;
          const relVy = bodyA.velocity.y - bodyB.velocity.y;
          const relSpeed = Math.hypot(relVx, relVy);

          if (relSpeed > 1.8) {
            const blockA = this.blockMap.get(idA);
            const blockB = this.blockMap.get(idB);
            if (blockA && blockB) {
              const damage = Math.round(relSpeed * 10);
              blockA.hp = Math.max(0, blockA.hp - damage);
              blockB.hp = Math.max(0, blockB.hp - damage);

              if (blockA.hp <= 0) blockA.broken = true;
              if (blockB.hp <= 0) blockB.broken = true;

              this.recentImpacts.push({
                x: (bodyA.position.x + bodyB.position.x) / 2,
                y: (bodyA.position.y + bodyB.position.y) / 2,
                intensity: relSpeed,
                blockTypeA: blockA.type,
                blockTypeB: blockB.type,
              });
            }
          }
        }

        // Debris hitting the ground
        if (isBodyAGround && idB) {
          const speed = Math.hypot(bodyB.velocity.x, bodyB.velocity.y);
          if (speed > 2.0) {
            const blockB = this.blockMap.get(idB);
            if (blockB) {
              this.recentImpacts.push({
                x: bodyB.position.x,
                y: this.groundY,
                intensity: speed,
                blockTypeA: 'ground',
                blockTypeB: blockB.type,
              });
            }
          }
        } else if (isBodyBGround && idA) {
          const speed = Math.hypot(bodyA.velocity.x, bodyA.velocity.y);
          if (speed > 2.0) {
            const blockA = this.blockMap.get(idA);
            if (blockA) {
              this.recentImpacts.push({
                x: bodyA.position.x,
                y: this.groundY,
                intensity: speed,
                blockTypeA: 'ground',
                blockTypeB: blockA.type,
              });
            }
          }
        }
      }
    });
  }

  /**
   * Activates a block into a dynamic rigid body and notifies neighbors
   */
  public activateBlock(blockId: string, initialVx: number = 0, initialVy: number = 0): void {
    const body = this.blockBodies.get(blockId);
    const block = this.blockMap.get(blockId);
    if (!body || !block) return;

    if (!(body as any).isActivated) {
      (body as any).isActivated = true;
      Body.setStatic(body, false);
      Body.setVelocity(body, { x: initialVx, y: initialVy });
      block.grounded = false;
      this.hasEverImpacted = true;
      this.lastImpactTime = performance.now();

      // Check blocks resting immediately above or adjacent to this one,
      // and schedule them to activate if they lose physical support
      this.wakeAdjacentSupportedBlocks(block);
    }
  }

  /**
   * Wakes blocks that physically depend on the broken block
   */
  private wakeAdjacentSupportedBlocks(brokenBlock: BambooBlock): void {
    const bLeft = brokenBlock.x - brokenBlock.width / 2;
    const bRight = brokenBlock.x + brokenBlock.width / 2;
    const bTop = brokenBlock.y - brokenBlock.height / 2;
    const bBottom = brokenBlock.y + brokenBlock.height / 2;

    this.blockMap.forEach((other, otherId) => {
      if (otherId === brokenBlock.id) return;
      const otherBody = this.blockBodies.get(otherId);
      if (!otherBody || (otherBody as any).isActivated) return;

      const oLeft = other.x - other.width / 2;
      const oRight = other.x + other.width / 2;
      const oBottom = other.y + other.height / 2;
      const oTop = other.y - other.height / 2;

      const overlapsX = Math.max(bLeft, oLeft) <= Math.min(bRight, oRight);
      const isRestingAbove = other.y < brokenBlock.y && oBottom >= bTop - 10 && oBottom <= bTop + 14;
      const isSpannedByBrokenPost =
        (brokenBlock.type === 'post' || brokenBlock.type === 'stilt') &&
        bTop <= other.y + 4 &&
        bBottom >= other.y - 4;
      const isHangingBelow =
        (other.type === 'pot' || other.type === 'lantern' || other.hanging) &&
        Math.abs(oTop - bBottom) <= 36 &&
        overlapsX;

      if (overlapsX && (isRestingAbove || isSpannedByBrokenPost)) {
        if (other.type === 'beam' && other.width > 106) {
          // Check how many intact unactivated pillars still support this wide beam
          const maxPillarOffset = other.width / 2 - 6;
          let intactPillars = 0;
          this.blockMap.forEach((p, pId) => {
            const pBody = this.blockBodies.get(pId);
            if (!pBody || (pBody as any).isActivated || p.broken || p.hp <= 0) return;
            if (p.type !== 'post' && p.type !== 'stilt') return;
            if (Math.abs(p.x - other.x) <= maxPillarOffset) {
              const pTop = p.y - p.height / 2;
              const pBottom = p.y + p.height / 2;
              if ((other.y < p.y && oBottom >= pTop - 9 && oBottom <= pTop + 14) || (pTop <= other.y + 4 && pBottom >= other.y - 4)) {
                intactPillars++;
              }
            }
          });
          if (intactPillars < 2) {
            this.activateBlock(otherId, (Math.random() - 0.5) * 0.8, 1.2);
          }
        } else {
          this.activateBlock(otherId, (Math.random() - 0.5) * 0.8, 1.2);
        }
      } else if (isHangingBelow) {
        this.activateBlock(otherId, (Math.random() - 0.5) * 0.6, 1.2);
      }
    });
  }

  /**
   * Applies realistic cricket ball kinetic energy impact directly to hit block
   */
  public applyBallHit(
    blockId: string,
    ballVx: number,
    ballVy: number,
    hitPoint: { x: number; y: number },
    ballType: SpecialBallType
  ): { hitBlock: BambooBlock | null; brokenIds: string[] } {
    const body = this.blockBodies.get(blockId);
    const block = this.blockMap.get(blockId);
    if (!body || !block) return { hitBlock: null, brokenIds: [] };

    this.hasEverImpacted = true;
    this.lastImpactTime = performance.now();

    // Damage and break hit block
    block.hp = 0;
    block.broken = true;
    block.grounded = false;

    // Activate the body
    (body as any).isActivated = true;
    Body.setStatic(body, false);

    // Calculate realistic transfer of momentum
    const ballSpeed = Math.hypot(ballVx, ballVy);
    const forceFactor = 0.0035 * Math.min(ballSpeed, 28);
    const forceVector = {
      x: ballVx * forceFactor,
      y: (ballVy - 0.8) * forceFactor,
    };

    // Apply force at the exact contact point (creates realistic rotational toppling)
    Body.applyForce(body, hitPoint, forceVector);

    // Apply angular torque
    const torque = (ballVx >= 0 ? 0.06 : -0.06) * (Math.random() * 0.5 + 0.8);
    Body.setAngularVelocity(body, torque);

    const brokenIds: string[] = [blockId];

    // Wake supported structures above it
    this.wakeAdjacentSupportedBlocks(block);

    // Special Ball Effects
    if (ballType === 'BOMB') {
      const bombBroken = this.applyBombShockwave(hitPoint.x, hitPoint.y, 160);
      brokenIds.push(...bombBroken);
    } else if (ballType === 'FIRE') {
      block.isOnFire = true;
      block.fireTicks = 50;
    } else if (ballType === 'ACID') {
      block.isAcidMelting = true;
      block.acidTicks = 45;
    }

    return { hitBlock: block, brokenIds };
  }

  /**
   * Applies radial explosive blast force to all surrounding bodies
   */
  public applyBombShockwave(blastX: number, blastY: number, blastRadius: number = 160): string[] {
    const brokenIds: string[] = [];
    this.hasEverImpacted = true;
    this.lastImpactTime = performance.now();

    this.blockBodies.forEach((body, id) => {
      const block = this.blockMap.get(id);
      if (!block) return;

      const dx = body.position.x - blastX;
      const dy = body.position.y - blastY;
      const dist = Math.hypot(dx, dy);

      if (dist < blastRadius) {
        // Activate and break block
        (body as any).isActivated = true;
        Body.setStatic(body, false);
        block.hp = 0;
        block.broken = true;
        block.grounded = false;
        brokenIds.push(id);

        // Blast force inversely proportional to distance
        const blastFactor = Math.max(0.1, (1 - dist / blastRadius)) * 0.085;
        const normX = dist > 0.01 ? dx / dist : 0;
        const normY = dist > 0.01 ? dy / dist : -1;

        Body.applyForce(body, body.position, {
          x: normX * blastFactor * 1.3,
          y: (normY - 0.4) * blastFactor * 1.3,
        });

        Body.setAngularVelocity(body, (Math.random() - 0.5) * 0.22);
      }
    });

    return brokenIds;
  }

  /**
   * Steps the Matter.js physics engine forward and syncs positions/angles to BambooBlocks
   */
  public step(deltaMs: number = 1000 / 60): { hasStructuralShift: boolean; impacts: PhysicsImpactEvent[] } {
    // Run Matter.js engine step
    Engine.update(this.engine, deltaMs);

    let hasStructuralShift = false;

    // Sync all Matter.js rigid bodies back into BambooBlock state
    this.blockBodies.forEach((body, id) => {
      const block = this.blockMap.get(id);
      if (!block || block.despawned) return;

      const isAct = (body as any).isActivated;
      if (isAct) {
        block.x = body.position.x;
        block.y = body.position.y;
        block.angle = body.angle;
        block.vx = body.velocity.x;
        block.vy = body.velocity.y;
        block.vAngle = body.angularVelocity;

        // Keep within left boundary
        if (block.x < 865) {
          block.x = 865;
          Body.setPosition(body, { x: 865, y: body.position.y });
          if (body.velocity.x < 0) {
            Body.setVelocity(body, { x: 0, y: body.velocity.y });
          }
        }

        // Check if resting stably on the ground
        const halfExtentY = (Math.abs(Math.sin(block.angle)) * block.width + Math.abs(Math.cos(block.angle)) * block.height) / 2;
        const bottomY = block.y + halfExtentY;

        if (bottomY >= this.groundY - 10) {
          block.grounded = true;
          // Apply extra ground friction to settle piles
          Body.setVelocity(body, {
            x: body.velocity.x * 0.96,
            y: body.velocity.y,
          });
          Body.setAngularVelocity(body, body.angularVelocity * 0.94);
        }

        hasStructuralShift = true;
      }
    });

    // Check if max settling timeout reached to freeze lingering micro-vibrations
    if (this.hasEverImpacted) {
      const elapsedSinceImpact = performance.now() - this.lastImpactTime;
      if (elapsedSinceImpact > this.maxSettlingMs) {
        // Freeze low-speed debris to guarantee turn completion
        this.blockBodies.forEach((body) => {
          if ((body as any).isActivated) {
            const speed = Math.hypot(body.velocity.x, body.velocity.y);
            if (speed < 0.6) {
              Body.setVelocity(body, { x: 0, y: 0 });
              Body.setAngularVelocity(body, 0);
            }
          }
        });
      }
    }

    const impacts = [...this.recentImpacts];
    this.recentImpacts = [];

    return { hasStructuralShift, impacts };
  }

  /**
   * Determines if any broken blocks are actively moving.
   * Features a guaranteed settling timeout so the player is NEVER locked out of delivery.
   */
  public isHouseStillMoving(): boolean {
    if (!this.hasEverImpacted) return false;

    const elapsed = performance.now() - this.lastImpactTime;
    // Guaranteed safety timeout: if > 3.0s elapsed since impact, consider settled!
    if (elapsed > this.maxSettlingMs) {
      return false;
    }

    // Check if any activated body has significant velocity
    for (const body of this.blockBodies.values()) {
      if ((body as any).isActivated) {
        const speed = Math.hypot(body.velocity.x, body.velocity.y);
        const angSpeed = Math.abs(body.angularVelocity);
        if (speed > 0.32 || angSpeed > 0.06) {
          return true;
        }
      }
    }

    return false;
  }

  /**
   * Resets or updates blocks (e.g., when loading a new level)
   */
  public reset(newBlocks: BambooBlock[]): void {
    this.initBlocks(newBlocks);
  }

  /**
   * Cleanup Matter.js world on component unmount
   */
  public destroy(): void {
    Composite.clear(this.engine.world, false);
    Engine.clear(this.engine);
    this.blockBodies.clear();
    this.blockMap.clear();
  }
}
