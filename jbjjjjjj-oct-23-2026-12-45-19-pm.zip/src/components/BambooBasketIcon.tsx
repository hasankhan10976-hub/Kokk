import React from 'react';

interface BambooBasketIconProps {
  className?: string;
  size?: number;
}

export const BambooBasketIcon: React.FC<BambooBasketIconProps> = ({
  className = 'w-5 h-5',
  size,
}) => {
  return (
    <svg
      viewBox="0 0 32 32"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`shrink-0 drop-shadow-sm ${className}`}
      style={size ? { width: size, height: size } : undefined}
    >
      <defs>
        {/* Woven Bamboo Slat Gradient */}
        <linearGradient id="basketWoodGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#fef08a" />
          <stop offset="25%" stopColor="#f59e0b" />
          <stop offset="65%" stopColor="#d97706" />
          <stop offset="100%" stopColor="#92400e" />
        </linearGradient>

        {/* Braided Bamboo Rim Gradient */}
        <linearGradient id="basketRimGrad" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#b45309" />
          <stop offset="50%" stopColor="#fef08a" />
          <stop offset="100%" stopColor="#78350f" />
        </linearGradient>

        {/* Shiny Gold Coin in Basket */}
        <radialGradient id="basketCoinGrad" cx="35%" cy="35%" r="65%">
          <stop offset="0%" stopColor="#fef9c3" />
          <stop offset="40%" stopColor="#facc15" />
          <stop offset="85%" stopColor="#ca8a04" />
          <stop offset="100%" stopColor="#854d0e" />
        </radialGradient>
      </defs>

      {/* 1. Curved Bent Bamboo Handle */}
      <path
        d="M 8 13 C 8 4, 24 4, 24 13"
        stroke="url(#basketRimGrad)"
        strokeWidth="2.5"
        strokeLinecap="round"
        fill="none"
      />
      <path
        d="M 9 12 C 9 6, 23 6, 23 12"
        stroke="#451a03"
        strokeWidth="0.8"
        strokeLinecap="round"
        fill="none"
        opacity="0.4"
      />

      {/* 2. Shiny Gold Coins overflowing slightly from the woven basket */}
      <circle cx="13" cy="11.5" r="3.2" fill="url(#basketCoinGrad)" stroke="#78350f" strokeWidth="0.75" />
      <circle cx="19" cy="11.5" r="3.2" fill="url(#basketCoinGrad)" stroke="#78350f" strokeWidth="0.75" />
      <circle cx="16" cy="9.5" r="3.6" fill="url(#basketCoinGrad)" stroke="#78350f" strokeWidth="0.85" />
      <path d="M 15 9.5 L 17 9.5" stroke="#78350f" strokeWidth="0.7" strokeLinecap="round" />

      {/* 3. Basket Body (Woven Bamboo Flared Vessel) */}
      <path
        d="M 5 14 Q 4 19 8 28 C 9 29.5 23 29.5 24 28 Q 28 19 27 14 Z"
        fill="url(#basketWoodGrad)"
        stroke="#78350f"
        strokeWidth="1.6"
        strokeLinejoin="round"
      />

      {/* 4. Natural Woven Bamboo Interlace Strips (Diagonal Cross-Hatch) */}
      <g stroke="#78350f" strokeWidth="1" opacity="0.65" strokeLinecap="round">
        {/* Diagonal forward slats */}
        <line x1="8" y1="15" x2="11" y2="28" />
        <line x1="13" y1="14" x2="16" y2="29" />
        <line x1="19" y1="14" x2="21" y2="28" />
        <line x1="24" y1="15" x2="24" y2="25" />

        {/* Horizontal woven bamboo rib lines */}
        <path d="M 6.5 17 Q 16 19 25.5 17" fill="none" strokeWidth="1.2" />
        <path d="M 7.5 21 Q 16 23 24.5 21" fill="none" strokeWidth="1.2" />
        <path d="M 9.5 25 Q 16 26.5 22.5 25" fill="none" strokeWidth="1.2" />
      </g>

      {/* 5. Braided Top Lip / Bamboo Rim Band */}
      <rect
        x="4"
        y="12.5"
        width="24"
        height="3.5"
        rx="1.75"
        fill="url(#basketRimGrad)"
        stroke="#78350f"
        strokeWidth="1.4"
      />
      {/* Lip twist hash marks */}
      <line x1="8" y1="13.5" x2="10" y2="15" stroke="#78350f" strokeWidth="1" />
      <line x1="12" y1="13.5" x2="14" y2="15" stroke="#78350f" strokeWidth="1" />
      <line x1="16" y1="13.5" x2="18" y2="15" stroke="#78350f" strokeWidth="1" />
      <line x1="20" y1="13.5" x2="22" y2="15" stroke="#78350f" strokeWidth="1" />
      <line x1="24" y1="13.5" x2="26" y2="15" stroke="#78350f" strokeWidth="1" />

      {/* 6. Base Stand of Basket */}
      <ellipse cx="16" cy="28.5" rx="7" ry="1.4" fill="#78350f" opacity="0.8" />
    </svg>
  );
};
