import React from 'react';

export type JewelColor = 'amber' | 'emerald' | 'ruby' | 'sapphire' | 'amethyst' | 'titanium' | 'sunset';

interface JewelButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  variant?: 'orb' | 'badge' | 'wide';
  color?: JewelColor;
  asBadge?: boolean;
  isGlowing?: boolean;
  title?: string;
}

const COLOR_MAP: Record<JewelColor, {
  grad: string;
  border: string;
  glow: string;
  ring: string;
}> = {
  amber: {
    grad: 'bg-gradient-to-br from-amber-400 via-amber-500 to-yellow-600',
    border: 'border-amber-200/80',
    glow: 'shadow-md shadow-amber-500/30',
    ring: 'ring-2 ring-amber-300',
  },
  emerald: {
    grad: 'bg-gradient-to-br from-emerald-400 via-teal-500 to-green-700',
    border: 'border-emerald-200/80',
    glow: 'shadow-md shadow-emerald-500/30',
    ring: 'ring-2 ring-emerald-300',
  },
  ruby: {
    grad: 'bg-gradient-to-br from-rose-500 via-red-600 to-red-800',
    border: 'border-rose-200/80',
    glow: 'shadow-md shadow-rose-500/30',
    ring: 'ring-2 ring-rose-300',
  },
  sapphire: {
    grad: 'bg-gradient-to-br from-sky-400 via-blue-500 to-indigo-700',
    border: 'border-sky-200/80',
    glow: 'shadow-md shadow-sky-500/30',
    ring: 'ring-2 ring-sky-300',
  },
  amethyst: {
    grad: 'bg-gradient-to-br from-purple-400 via-violet-500 to-indigo-800',
    border: 'border-purple-200/80',
    glow: 'shadow-md shadow-purple-500/30',
    ring: 'ring-2 ring-purple-300',
  },
  titanium: {
    grad: 'bg-gradient-to-br from-slate-400 via-slate-500 to-slate-600',
    border: 'border-white/60',
    glow: 'shadow-md shadow-white/20',
    ring: 'ring-2 ring-white/60',
  },
  sunset: {
    grad: 'bg-gradient-to-br from-amber-400 via-orange-500 to-red-600',
    border: 'border-orange-200/80',
    glow: 'shadow-md shadow-orange-500/30',
    ring: 'ring-2 ring-orange-300',
  },
};

export const JewelButton: React.FC<JewelButtonProps> = ({
  children,
  onClick,
  disabled = false,
  className = '',
  size = 'md',
  variant = 'orb',
  color = 'titanium',
  asBadge = false,
  isGlowing = false,
  title,
}) => {
  const theme = COLOR_MAP[color];

  // Sizing definitions
  let dimensionClasses = '';
  if (variant === 'orb') {
    if (size === 'sm') dimensionClasses = 'w-9 h-9 sm:w-10 sm:h-10 rounded-full';
    else if (size === 'md') dimensionClasses = 'w-11 h-11 sm:w-12 sm:h-12 rounded-full';
    else dimensionClasses = 'w-14 h-14 sm:w-16 sm:h-16 rounded-full';
  } else if (variant === 'badge') {
    if (size === 'sm') dimensionClasses = 'h-9 sm:h-10 px-3 rounded-full min-w-[50px]';
    else if (size === 'md') dimensionClasses = 'h-10 sm:h-11 px-3.5 sm:px-4 rounded-full min-w-[70px]';
    else dimensionClasses = 'h-12 px-5 rounded-full min-w-[90px]';
  } else {
    // wide
    if (size === 'sm') dimensionClasses = 'h-9 sm:h-10 px-4 rounded-2xl w-full';
    else if (size === 'md') dimensionClasses = 'h-11 sm:h-12 px-5 rounded-2xl w-full';
    else dimensionClasses = 'h-14 sm:h-16 px-6 rounded-3xl w-full';
  }

  const content = (
    <div
      className={`relative inline-flex items-center justify-center select-none ${dimensionClasses} ${
        theme.grad
      } border-2 ${theme.border} ${theme.glow} ${
        isGlowing ? `${theme.ring} animate-pulse` : ''
      } ${
        !asBadge && !disabled
          ? 'cursor-pointer hover:scale-105 hover:brightness-110 active:scale-90'
          : ''
      } ${disabled ? 'opacity-40 cursor-not-allowed grayscale-[40%]' : ''} transition-all duration-150 overflow-hidden shadow-inner ${className}`}
      title={title}
    >
      {/* 3D Specular Highlight Arc (Creates realistic glass/orb spherical sheen) */}
      <div
        className="absolute top-1 left-2 w-3.5 sm:w-5 h-2 sm:h-2.5 rounded-full bg-white/50 blur-[0.7px] pointer-events-none transform -rotate-12"
      />
      {/* Subtle lower ambient glow reflection */}
      <div
        className="absolute bottom-0 right-1 w-5 sm:w-7 h-2 rounded-full bg-white/20 blur-[1px] pointer-events-none"
      />

      {/* Carved/Embossed Content (Pure icons and numbers) */}
      <div className="relative z-10 flex items-center justify-center gap-1.5 font-black text-white filter drop-shadow-[0_1px_2px_rgba(0,0,0,0.25)]">
        {children}
      </div>
    </div>
  );

  if (asBadge) {
    return content;
  }

  return (
    <button
      type="button"
      onClick={disabled ? undefined : onClick}
      disabled={disabled}
      className="inline-flex items-center justify-center p-0 bg-transparent border-0 outline-none cursor-pointer focus:outline-none select-none touch-manipulation"
      title={title}
    >
      {content}
    </button>
  );
};
