import React, { useRef, useEffect, useState } from 'react';
import { CircleDot, Bomb, Flame, FlaskConical, Lock } from 'lucide-react';
import { BambooBasketIcon } from './BambooBasketIcon';
import { JewelButton } from './JewelButton';
import { BambooBlock, Ball, Batsman, Bowler, FloatingText, LevelConfig, Particle, ShotElevation, BackgroundTheme, SpecialBallType } from '../types/game';
import { soundManager } from '../utils/audio';
import { renderProceduralBackground, renderAmbientBackgroundOverlay } from '../utils/backgroundRenderer';

interface FlyingCoin {
  id: string;
  startX: number;
  startY: number;
  currentX: number;
  currentY: number;
  targetX: number;
  targetY: number;
  controlX: number;
  controlY: number;
  progress: number;
  speed: number;
  delay: number;
  rotation: number;
  rotSpeed: number;
  size: number;
  value: number;
}

interface ScreenSparkle {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  decay: number;
}

interface CricketCanvasProps {
  level: LevelConfig;
  blocks: BambooBlock[];
  onBlocksUpdate: (blocks: BambooBlock[]) => void;
  ballsLeft: number;
  onBallConsumed: () => void;
  onBallHitCompleted: (destroyedPct: number, runsScored: number) => void;
  onBatsmanOut: () => void;
  isSuperShotActive: boolean;
  onSuperShotUsed: () => void;
  onSwingAttempt: (timingRating: string) => void;
  isPaused?: boolean;
  backgroundTheme: BackgroundTheme;
  selectedPowerRatio: number;
  onHitExecuted: () => void;
  selectedBallType: SpecialBallType;
  ballInventory: Record<SpecialBallType, number>;
  onSelectBallType: (ball: SpecialBallType) => void;
  onConsumeSpecialBall: (ball: SpecialBallType) => void;
  onOpenShop?: () => void;
  onCoinEarned: (amount: number) => void;
  bowlTrigger?: number;
  onReadyForDeliveryChange?: (ready: boolean) => void;
  resetKey?: number;
}

export const CricketCanvas: React.FC<CricketCanvasProps> = ({
  level,
  blocks,
  onBlocksUpdate,
  ballsLeft,
  onBallConsumed,
  onBallHitCompleted,
  onBatsmanOut,
  isSuperShotActive,
  onSuperShotUsed,
  onSwingAttempt,
  isPaused = false,
  backgroundTheme,
  selectedPowerRatio,
  onHitExecuted,
  selectedBallType,
  ballInventory,
  onSelectBallType,
  onConsumeSpecialBall,
  onOpenShop,
  onCoinEarned,
  bowlTrigger = 0,
  onReadyForDeliveryChange,
  resetKey = 0,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Full-screen dynamic viewport dimensions (zero black bars across mobile, tablet, and PC)
  const [viewport, setViewport] = useState<{ width: number; height: number }>({
    width: typeof window !== 'undefined' ? window.innerWidth : 1280,
    height: typeof window !== 'undefined' ? window.innerHeight : 720,
  });

  useEffect(() => {
    const handleResize = () => {
      if (typeof window !== 'undefined') {
        setViewport({
          width: window.innerWidth,
          height: window.innerHeight,
        });
      }
    };

    window.addEventListener('resize', handleResize);
    window.addEventListener('orientationchange', handleResize);
    handleResize();

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('orientationchange', handleResize);
    };
  }, []);

  // Mutable game physics state inside refs to allow continuous 60FPS animation loop
  const blocksRef = useRef<BambooBlock[]>(blocks);
  const particlesRef = useRef<Particle[]>([]);
  const floatingTextsRef = useRef<FloatingText[]>([]);
  const flyingCoinsRef = useRef<FlyingCoin[]>([]);
  const screenSparklesRef = useRef<ScreenSparkle[]>([]);
  const isSuperActiveRef = useRef<boolean>(isSuperShotActive);
  const bgThemeRef = useRef<BackgroundTheme>(backgroundTheme);
  const selectedPowerRatioRef = useRef<number>(selectedPowerRatio);
  const selectedBallTypeRef = useRef<SpecialBallType>(selectedBallType);
  const onCoinEarnedRef = useRef<(amount: number) => void>(onCoinEarned);
  const onConsumeSpecialBallRef = useRef<(ball: SpecialBallType) => void>(onConsumeSpecialBall);
  const groundY = 570; // Virtual gameplay world ground height

  useEffect(() => {
    selectedBallTypeRef.current = selectedBallType;
    // CRITICAL: Only configure pre-delivery ball state. NEVER overwrite an active ball in flight!
    if (ballRef.current && !ballActiveRef.current) {
      ballRef.current.ballType = selectedBallType;
      ballRef.current.damageMultiplier =
        selectedBallType === 'BOMB' ? 1.45 : selectedBallType === 'FIRE' ? 1.8 : selectedBallType === 'ACID' ? 1.25 : 1.0;
      ballRef.current.radius = selectedBallType === 'BOMB' ? 9.5 : 8;
    }
  }, [selectedBallType]);

  useEffect(() => {
    onCoinEarnedRef.current = onCoinEarned;
  }, [onCoinEarned]);

  useEffect(() => {
    onConsumeSpecialBallRef.current = onConsumeSpecialBall;
  }, [onConsumeSpecialBall]);

  const onReadyForDeliveryChangeRef = useRef(onReadyForDeliveryChange);
  useEffect(() => {
    onReadyForDeliveryChangeRef.current = onReadyForDeliveryChange;
  }, [onReadyForDeliveryChange]);

  const pendingBowlRef = useRef<boolean>(false);
  const isReadyForDeliveryRef = useRef<boolean>(true);
  const blockUpdateThrottleRef = useRef<number>(0);
  const cameraXRef = useRef<number>(0);
  const ballsLeftRef = useRef<number>(ballsLeft);
  useEffect(() => {
    ballsLeftRef.current = ballsLeft;
  }, [ballsLeft]);

  const ballInventoryRef = useRef<Record<SpecialBallType, number>>(ballInventory);
  useEffect(() => {
    ballInventoryRef.current = ballInventory;
  }, [ballInventory]);

  // Trigger delivery runup when player finishes charging and releases power button
  useEffect(() => {
    if (bowlTrigger > 0) {
      pendingBowlRef.current = true;
    }
  }, [bowlTrigger]);

  // High-performance offscreen canvas cache for 60FPS background
  const bgCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const bgCacheKeyRef = useRef<string>('');

  // Stumps state (for clean-bowled out animation)
  const stumpsRef = useRef<{
    broken: boolean;
    stump1Angle: number;
    stump2Angle: number;
    stump3Angle: number;
    bailsY: number;
    bailsVx: number;
    bailsVy: number;
  }>({
    broken: false,
    stump1Angle: 0,
    stump2Angle: 0,
    stump3Angle: 0,
    bailsY: 0,
    bailsVx: 0,
    bailsVy: 0,
  });

  useEffect(() => {
    bgThemeRef.current = backgroundTheme;
  }, [backgroundTheme]);

  useEffect(() => {
    selectedPowerRatioRef.current = selectedPowerRatio;
  }, [selectedPowerRatio]);

  useEffect(() => {
    blocksRef.current = blocks;
    hasBuildingBeenHitRef.current = false;
  }, [blocks]);

  useEffect(() => {
    isSuperActiveRef.current = isSuperShotActive;
  }, [isSuperShotActive]);

  // Reset stumps, bowler, flying coins, and all transient animations when starting/restarting a level or returning home
  useEffect(() => {
    stumpsRef.current = {
      broken: false,
      stump1Angle: 0,
      stump2Angle: 0,
      stump3Angle: 0,
      bailsY: 0,
      bailsVx: 0,
      bailsVy: 0,
    };
    batsmanRef.current = {
      x: 190,
      y: groundY,
      stance: 'ready',
      swingProgress: 0,
      batAngle: 0,
      elevation: 'FLAT',
    };
    bowlerRef.current = {
      x: 850,
      y: groundY,
      state: 'idle',
      progress: 0,
      deliveryType: level.bowlerType,
    };
    ballActiveRef.current = false;
    ballRef.current = null;
    ballSettledTimerRef.current = 0;
    ballInPlayTimerRef.current = 0;
    blockUpdateThrottleRef.current = 0;
    pendingBowlRef.current = false;
    isReadyForDeliveryRef.current = true;
    cameraXRef.current = 0;
    flyingCoinsRef.current = [];
    screenSparklesRef.current = [];
    particlesRef.current = [];
    floatingTextsRef.current = [];
    hasBuildingBeenHitRef.current = false;
  }, [level.id, level.bowlerType, resetKey]);

  // Batsman state
  const batsmanRef = useRef<Batsman>({
    x: 190,
    y: groundY,
    stance: 'ready',
    swingProgress: 0,
    batAngle: 0,
    elevation: 'FLAT',
  });

  // Bowler state
  const bowlerRef = useRef<Bowler>({
    x: 850,
    y: groundY,
    state: 'idle',
    progress: 0,
    deliveryType: level.bowlerType,
  });

  // Ball state
  const ballRef = useRef<Ball | null>(null);
  const ballActiveRef = useRef<boolean>(false);
  const ballSettledTimerRef = useRef<number>(0);
  const ballInPlayTimerRef = useRef<number>(0);
  const lastBambooSnapSoundTimeRef = useRef<number>(0);
  const lastStructureCrashSoundTimeRef = useRef<number>(0);
  const runsThisBallRef = useRef<number>(0);
  const lastHitBlockIdRef = useRef<string | null>(null);
  const lastHitBlockTimerRef = useRef<number>(0);
  const hasHitBlockThisDeliveryRef = useRef<boolean>(false);
  const hasBuildingBeenHitRef = useRef<boolean>(false);
  const lastGroundBounceTimeRef = useRef<number>(0);

  // Trigger Batsman Swing with continuous physics scaling
  const executeSwing = (powerRatio: number = 0.75) => {
    if (batsmanRef.current.stance === 'swinging') return;

    // Continuous power scaling from 0.65 (soft touch) up to 1.8 (full thunder blast)
    const powerScale = 0.65 + powerRatio * 1.15;

    batsmanRef.current.stance = 'swinging';
    batsmanRef.current.swingProgress = 0;

    const shotElevation: ShotElevation = powerRatio > 0.65 ? 'HIGH' : powerRatio > 0.35 ? 'FLAT' : 'LOW';
    batsmanRef.current.elevation = shotElevation;

    // Check hit against ball if ball is active and in flight
    const ball = ballRef.current;
    if (ball && ballActiveRef.current && !ball.hitByBat) {
      const batSweetSpotX = 205;
      const dist = Math.abs(ball.x - batSweetSpotX);
      const verticalDist = Math.abs(ball.y - (groundY - 60));

      if (dist < 85 && verticalDist < 120) {
        let rating = 'GOOD';
        let speedMultiplier = 1.0 * powerScale;
        let powerSound = 1.0 * powerScale;

        if (dist < 26) {
          rating = 'PERFECT';
          speedMultiplier = 1.5 * powerScale;
          powerSound = 1.6;
        } else if (dist < 50) {
          rating = 'GREAT';
          speedMultiplier = 1.25 * powerScale;
          powerSound = 1.3;
        } else if (ball.x > batSweetSpotX) {
          rating = 'EARLY';
          speedMultiplier = 0.85 * powerScale;
          powerSound = 0.8;
        } else {
          rating = 'LATE';
          speedMultiplier = 0.85 * powerScale;
          powerSound = 0.8;
        }

        // Apply Super Shot boost
        const isSuper = isSuperActiveRef.current;
        if (isSuper) {
          speedMultiplier *= 1.45;
          ball.isSuperShot = true;
          ball.damageMultiplier = 2.5;
          onSuperShotUsed();
        }

        soundManager.playBatCrack(powerSound, isSuper);
        ball.hitByBat = true;

        // Reset power right after ball is struck so player can charge for next shot!
        onHitExecuted();

        // Authentic cricket launch trajectory dynamics
        let launchAngleRad = -0.52; // default sweetspot angle (~30 deg)
        if (shotElevation === 'HIGH') {
          launchAngleRad = -(0.65 + Math.random() * 0.15); // ~38° to 46° lofted drive
        } else if (shotElevation === 'FLAT') {
          launchAngleRad = -(0.32 + Math.random() * 0.10); // ~18° to 24° bullet line drive
        } else {
          launchAngleRad = -(0.12 + Math.random() * 0.08); // ~7° to 12° deck skimmer
        }

        if (rating === 'EARLY') {
          launchAngleRad -= 0.07;
        } else if (rating === 'LATE') {
          launchAngleRad += 0.05;
        }

        const totalExitSpeed = (20 + 25 * powerRatio + Math.random() * 3) * speedMultiplier;
        ball.vx = Math.cos(launchAngleRad) * totalExitSpeed;
        ball.vy = Math.sin(launchAngleRad) * totalExitSpeed;
        ball.vRotation = 0.35;

        // Visual hit sparks
        for (let i = 0; i < 15; i++) {
          particlesRef.current.push({
            x: ball.x,
            y: ball.y,
            vx: (Math.random() - 0.2) * 8,
            vy: (Math.random() - 0.5) * 8,
            size: Math.random() * 4 + 2,
            color: isSuper ? '#f97316' : '#fef08a',
            life: 1,
            maxLife: 20,
            angle: 0,
            vAngle: 0,
            type: 'spark',
          });
        }

        onSwingAttempt(rating);
      } else {
        onSwingAttempt('MISS');
      }
    } else {
      onSwingAttempt('SWING');
    }
  };

  // Main Game Animation Loop with Full-Screen 100% Procedural Code Rendering
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    const gameLoop = () => {
      animId = requestAnimationFrame(gameLoop);

      // Viewport dimensions
      const width = canvas.width;
      const height = canvas.height;
      if (width <= 0 || height <= 0) {
        return;
      }

      // Scaling world coordinates so gameplay is grounded and centered
      const scale = Math.min(width / 1280, height / 720);
      const offsetX = Math.max(0, (width - 1280 * scale) / 2);
      const offsetY = height - 720 * scale;
      const screenGroundY = offsetY + groundY * scale;

      const currentBlocks = blocksRef.current;
      const batsman = batsmanRef.current;
      const ball = ballRef.current;

      // 1. ACTIVE GAMEPLAY SIMULATION & BOWLER LOGIC (Runs only when not paused)
      if (!isPaused) {
        // Bowler ONLY starts runup after player presses power button, selects power, and releases it!
        const houseStillMoving = currentBlocks.some(
          (blk) => !blk.despawned && !blk.isDespawning && (Math.abs(blk.vy) > 0.25 || Math.abs(blk.vx) > 0.25)
        );

        const curStock = ballInventoryRef.current[selectedBallTypeRef.current] ?? 0;
        const totalStock = Object.values(ballInventoryRef.current).reduce((a, b) => a + (b || 0), 0);
        const canDeliverNow = !ballActiveRef.current && totalStock > 0 && curStock > 0 && bowlerRef.current.state === 'idle' && !houseStillMoving;

      if (canDeliverNow) {
        if (!isReadyForDeliveryRef.current) {
          isReadyForDeliveryRef.current = true;
          onReadyForDeliveryChangeRef.current?.(true);
        }

        if (pendingBowlRef.current) {
          pendingBowlRef.current = false;
          isReadyForDeliveryRef.current = false;
          onReadyForDeliveryChangeRef.current?.(false);
          bowlerRef.current.state = 'runup';
          bowlerRef.current.progress = 0;
          bowlerRef.current.x = 850;
        }
      } else {
        if (isReadyForDeliveryRef.current) {
          isReadyForDeliveryRef.current = false;
          onReadyForDeliveryChangeRef.current?.(false);
        }
      }

      if (bowlerRef.current.state === 'runup') {
        bowlerRef.current.progress += 0.042;
        bowlerRef.current.x = 850 - bowlerRef.current.progress * 130;

        if (bowlerRef.current.progress >= 0.85 && !ballActiveRef.current) {
          bowlerRef.current.state = 'delivery';
          soundManager.playBowlerRelease();

          const speedFactor = level.bowlerSpeed / 100;
          let ballVx = -(11 + speedFactor * 4);
          let ballVy = 2.5;

          if (level.bowlerType === 'BOUNCER') {
            ballVy = 4.8;
            ballVx = -(13 + speedFactor * 4);
          } else if (level.bowlerType === 'YORKER') {
            ballVy = 1.0;
            ballVx = -(14 + speedFactor * 4);
          } else if (level.bowlerType === 'SPIN') {
            ballVy = 3.2;
            ballVx = -(9 + speedFactor * 2);
          } else if (level.bowlerType === 'SWING') {
            ballVy = 2.2;
            ballVx = -(11 + speedFactor * 3.5);
          }

          const curBallType = selectedBallTypeRef.current;
          ballRef.current = {
            x: bowlerRef.current.x - 20,
            y: groundY - 110,
            vx: ballVx,
            vy: ballVy,
            radius: curBallType === 'BOMB' ? 9.5 : 8,
            rotation: 0,
            vRotation: -0.2,
            inAir: true,
            hitByBat: false,
            hasBouncedPitch: false,
            trail: [],
            isSuperShot: false,
            damageMultiplier: curBallType === 'BOMB' ? 1.45 : curBallType === 'FIRE' ? 1.8 : curBallType === 'ACID' ? 1.25 : 1.0,
            ballType: curBallType,
          };

          ballActiveRef.current = true;
          ballSettledTimerRef.current = 0;
          ballInPlayTimerRef.current = 0;
          runsThisBallRef.current = 0;
          lastHitBlockIdRef.current = null;
          lastHitBlockTimerRef.current = 0;
          hasHitBlockThisDeliveryRef.current = false;
          onBallConsumed();
          if (curBallType !== 'STANDARD') {
            onConsumeSpecialBallRef.current(curBallType);
          }
        }
      }

      // 3. BALL PHYSICS & TRAJECTORY
      if (lastHitBlockTimerRef.current > 0) {
        lastHitBlockTimerRef.current--;
      }
      if (ball && ballActiveRef.current) {
        ball.trail.push({ x: ball.x, y: ball.y, alpha: 1.0 });
        if (ball.trail.length > 18) {
          ball.trail.shift();
        }
        ball.trail.forEach(t => (t.alpha *= 0.88));

        const gravity = ball.hitByBat ? 0.38 : 0.32;
        ball.vy += gravity;

        if (!ball.hitByBat) {
          if (level.bowlerType === 'SWING') {
            ball.vy += Math.sin(ball.x * 0.03) * 0.15;
          }
        }

        ball.x += ball.vx;
        ball.y += ball.vy;
        ball.rotation += ball.vRotation;

        // AUTOMATIC HIT: Strikes upon ball arrival at optimal batting strike point
        const hasPower = selectedPowerRatioRef.current > 0;
        const inHitZone = ball.x <= 218 && ball.x >= 180;

        if (!ball.hitByBat && inHitZone && hasPower) {
          executeSwing(selectedPowerRatioRef.current);
        }

        // BOWL OUT: If player has NOT set any power (<= 0), ball crashes into the wickets!
        if (!ball.hitByBat && ball.x <= 165 && !hasPower && !stumpsRef.current.broken) {
          stumpsRef.current.broken = true;
          stumpsRef.current.stump1Angle = -0.45;
          stumpsRef.current.stump2Angle = -0.65;
          stumpsRef.current.stump3Angle = -0.35;
          stumpsRef.current.bailsVy = -8;
          stumpsRef.current.bailsVx = -4;

          ball.vx = -1.5;
          ball.vy = -3;
          soundManager.playStumpShatter();

          for (let s = 0; s < 12; s++) {
            particlesRef.current.push({
              x: 155,
              y: groundY - 30,
              vx: (Math.random() - 0.7) * 8,
              vy: -Math.random() * 8,
              size: Math.random() * 4 + 2,
              color: '#f59e0b',
              life: 1,
              maxLife: 30,
              angle: Math.random() * Math.PI,
              vAngle: 0.2,
              type: 'wood',
            });
          }

          floatingTextsRef.current.push({
            id: `out_${Date.now()}`,
            text: '❌',
            x: 160,
            y: groundY - 70,
            color: '#ef4444',
            size: 32,
            life: 1,
            maxLife: 60,
            vy: -1.2,
          });

          // Batsman is OUT! Trigger game over / level failed
          setTimeout(() => {
            onBatsmanOut();
          }, 500);
        }

        // Pitch Bounce (if before bat hit) - triggers on each impact with downward velocity
        if (!ball.hitByBat && ball.y >= groundY - ball.radius) {
          ball.y = groundY - ball.radius;
          const preVy = ball.vy;
          let restitution = -0.68;
          if (level.bowlerType === 'BOUNCER') restitution = -0.85;
          else if (level.bowlerType === 'YORKER') restitution = -0.45;
          ball.vy *= restitution;

          const now = performance.now();
          if (preVy > 1.0 && now - lastGroundBounceTimeRef.current > 75) {
            lastGroundBounceTimeRef.current = now;
            soundManager.playBallBounce(Math.min(1.2, Math.max(0.4, preVy / 4.5)));
          }

          if (level.bowlerType === 'SPIN') {
            ball.vy -= 1.6;
            ball.vx *= 0.92;
          } else if (level.bowlerType === 'SWING') {
            ball.vx *= 0.96;
          }

          for (let p = 0; p < 6; p++) {
            particlesRef.current.push({
              x: ball.x,
              y: groundY,
              vx: (Math.random() - 0.5) * 4,
              vy: -Math.random() * 3,
              size: Math.random() * 3 + 1,
              color: '#d4b996',
              life: 1,
              maxLife: 20,
              angle: 0,
              vAngle: 0,
              type: 'smoke',
            });
          }
        }

        // Out of bounds settlement
        if (!ball.hitByBat && ball.x < 110) {
          ballSettledTimerRef.current++;
          if (ballSettledTimerRef.current > 16) {
            ballActiveRef.current = false;
            ballRef.current = null;
            bowlerRef.current.state = 'idle';
            bowlerRef.current.x = 850;
            bowlerRef.current.progress = 0;
            pendingBowlRef.current = false;
            isReadyForDeliveryRef.current = true;
            onReadyForDeliveryChangeRef.current?.(true);
            onBallHitCompleted(0, 0);
          }
        }

        // Ground collision after being hit - plays bounce sound on every genuine impact
        if (ball.hitByBat && ball.y >= groundY - ball.radius) {
          ball.y = groundY - ball.radius;
          const preVy = ball.vy;
          if (Math.abs(ball.vy) > 1.2) {
            ball.vy = -ball.vy * 0.5;
            ball.vx *= 0.92;

            const now = performance.now();
            if (preVy > 1.4 && now - lastGroundBounceTimeRef.current > 75) {
              lastGroundBounceTimeRef.current = now;
              soundManager.playBallBounce(Math.min(1.2, Math.max(0.35, preVy / 6.5)));
            }
          } else {
            ball.vy = 0;
            ball.vx *= 0.955; // Smooth realistic grass rolling friction
          }
          if (Math.abs(ball.vx) < 0.2) ball.vx = 0;
        }

        // 4. BAMBOO COLLISION DETECTION & IMPULSE DYNAMICS
        if (ball.hitByBat && !hasHitBlockThisDeliveryRef.current) {
          const currentBlocks = blocksRef.current;

          for (let i = 0; i < currentBlocks.length; i++) {
            const b = currentBlocks[i];
            if (b.broken || b.despawned || b.isDespawning) continue;
            if (lastHitBlockIdRef.current === b.id && lastHitBlockTimerRef.current > 0) continue;

            // Transform ball position into local coordinates of rotated block (OBB collision)
            const halfW = b.width / 2;
            const halfH = b.height / 2;
            const dx = ball.x - b.x;
            const dy = ball.y - b.y;

            const cos = Math.cos(-b.angle);
            const sin = Math.sin(-b.angle);
            const localX = cos * dx - sin * dy;
            const localY = sin * dx + cos * dy;

            if (Math.abs(localX) < halfW + ball.radius && Math.abs(localY) < halfH + ball.radius) {
              const ballSpeed = Math.hypot(ball.vx, ball.vy);

              // Calculate collision normal and penetration depth in local space
              const overlapX = (halfW + ball.radius) - Math.abs(localX);
              const overlapY = (halfH + ball.radius) - Math.abs(localY);
              let normLocalX = 0;
              let normLocalY = 0;
              let penDepth = 0;

              if (overlapX < overlapY) {
                normLocalX = localX >= 0 ? 1 : -1;
                penDepth = overlapX;
              } else {
                normLocalY = localY >= 0 ? 1 : -1;
                penDepth = overlapY;
              }

              // Transform collision normal into world coordinates
              const worldNormX = Math.cos(b.angle) * normLocalX - Math.sin(b.angle) * normLocalY;
              const worldNormY = Math.sin(b.angle) * normLocalX + Math.cos(b.angle) * normLocalY;

              // Cleanly separate ball from penetration along the true normal (no penetration / trapped state)
              ball.x += worldNormX * (penDepth + 0.6);
              ball.y += worldNormY * (penDepth + 0.6);

              // Keep ball above grass line if normal pushed it into ground
              if (ball.y > groundY - ball.radius) {
                ball.y = groundY - ball.radius;
                if (ball.vy > 0) ball.vy = 0;
              }

              // Normal velocity component: negative when approaching surface, positive when separating
              const normalVelocity = ball.vx * worldNormX + ball.vy * worldNormY;

              // FIX: Resting contact against bamboo, post, or woven fence / wall
              // If ball is moving slowly or resting against surface:
              // ZERO artificial velocity injection, ZERO cracking sounds, ZERO trembling/jittering!
              if (ballSpeed < 2.0 || (normalVelocity >= -0.6 && ballSpeed < 3.2)) {
                if (normalVelocity < 0) {
                  ball.vx -= normalVelocity * worldNormX;
                  ball.vy -= normalVelocity * worldNormY;
                }
                ball.vx *= 0.88;
                ball.vy *= 0.88;
                if (Math.hypot(ball.vx, ball.vy) < 0.25) {
                  ball.vx = 0;
                  ball.vy = 0;
                }
                continue; // Peacefully rest against bamboo/wall without damage, splinter particles, or sound!
              }

              // Authentically calibrated cricket ball kinetic energy impact:
              const damage = Math.round(Math.max(10, ballSpeed * 2.1) * ball.damageMultiplier);
              const effectiveDamage = Math.max(0, Math.min(b.hp, damage));
              runsThisBallRef.current += (effectiveDamage > 0 ? effectiveDamage : 25);
              lastHitBlockIdRef.current = b.id;
              lastHitBlockTimerRef.current = 6;

              // USER REQUIREMENT:
              // Whichever pillar or roof part the ball hits:
              // ONLY that specific one is damaged/hit, AND it falls to the ground!
              // Even if an open space/gap is created, the ball will NOT go and hit a second block!
              hasHitBlockThisDeliveryRef.current = true;
              hasBuildingBeenHitRef.current = true;

              // Hit pillar or roof part is broken and falls down to the ground:
              b.hp = 0;
              b.broken = true;
              b.grounded = false; // Dislodged to fall down to ground
              b.vy = 2.6; // Falls directly to the ground
              b.vAngle = (ball.vx >= 0 ? 0.025 : -0.025);
              b.vx = (ball.vx >= 0 ? 1.0 : -1.0);

              // Ball rebounds backward away from the hut (cannot continue deeper or hit a second block):
              const restitution = 0.45;
              ball.vx = -Math.abs(ball.vx) * restitution;
              ball.vy = Math.min(-1.6, ball.vy * 0.4 - 1.2);
              ball.x -= 4; // Moves away so it never penetrates deeper

              // User requirement: Breaking the house does NOT award any coins.
              // Money is strictly obtained ONLY when gold falls to the ground!

              // Apply special ball impact dynamics:
              if (ball.ballType === 'BOMB') {
                soundManager.playExplosion();
                floatingTextsRef.current.push({
                  id: `boom_${Date.now()}`,
                  text: '💣 BOOM!',
                  x: b.x,
                  y: b.y - 45,
                  color: '#f59e0b',
                  size: 22,
                  life: 1,
                  maxLife: 42,
                  vy: -1.8,
                });

                // Blast radius: tuned to 70px for localized compact demolition
                const blastRadius = 70;
                for (let bi = 0; bi < currentBlocks.length; bi++) {
                  const other = currentBlocks[bi];
                  if (other.id === b.id || other.broken || other.despawned) continue;
                  const dist = Math.hypot(other.x - b.x, other.y - b.y);
                  if (dist < blastRadius) {
                    other.hp = 0;
                    other.broken = true;
                    other.grounded = false;
                    const blastAngle = Math.atan2(other.y - b.y, other.x - b.x);
                    const blastForce = Math.max(1.5, (1 - dist / blastRadius) * 3.6);
                    other.vx = Math.cos(blastAngle) * blastForce;
                    other.vy = Math.min(-1.2, Math.sin(blastAngle) * blastForce);
                    other.vAngle = (Math.random() - 0.5) * 0.06;
                  }
                }

                // Explosive blast particles
                for (let p = 0; p < 35; p++) {
                  const ang = Math.random() * Math.PI * 2;
                  const spd = Math.random() * 13 + 3;
                  particlesRef.current.push({
                    x: b.x,
                    y: b.y,
                    vx: Math.cos(ang) * spd,
                    vy: Math.sin(ang) * spd - 2,
                    size: Math.random() * 9 + 4,
                    color: p % 3 === 0 ? '#f59e0b' : p % 3 === 1 ? '#ef4444' : '#27272a',
                    life: 1,
                    maxLife: 45 + Math.random() * 25,
                    angle: Math.random() * Math.PI,
                    vAngle: (Math.random() - 0.5) * 0.2,
                    type: 'explosion',
                  });
                }
              } else if (ball.ballType === 'FIRE') {
                b.isOnFire = true;
                b.fireTicks = 45;
                soundManager.playFireIgnite();
                floatingTextsRef.current.push({
                  id: `fire_${Date.now()}`,
                  text: '🔥 INFERNO!',
                  x: b.x,
                  y: b.y - 45,
                  color: '#f97316',
                  size: 20,
                  life: 1,
                  maxLife: 40,
                  vy: -1.6,
                });

                // Set nearby blocks on fire within 85px
                for (let bi = 0; bi < currentBlocks.length; bi++) {
                  const other = currentBlocks[bi];
                  if (other.id === b.id || other.broken || other.despawned) continue;
                  if (Math.hypot(other.x - b.x, other.y - b.y) < 85) {
                    other.isOnFire = true;
                    other.fireTicks = 35;
                  }
                }

                for (let p = 0; p < 24; p++) {
                  particlesRef.current.push({
                    x: b.x + (Math.random() - 0.5) * b.width,
                    y: b.y + (Math.random() - 0.5) * b.height,
                    vx: (Math.random() - 0.5) * 8,
                    vy: -Math.random() * 8 - 2,
                    size: Math.random() * 7 + 3,
                    color: Math.random() > 0.4 ? '#f97316' : '#facc15',
                    life: 1,
                    maxLife: 35 + Math.random() * 20,
                    angle: 0,
                    vAngle: 0,
                    type: 'fire',
                  });
                }
              } else if (ball.ballType === 'ACID') {
                b.isAcidMelting = true;
                b.acidTicks = 18;
                soundManager.playAcidBurn();
                floatingTextsRef.current.push({
                  id: `acid_${Date.now()}`,
                  text: '🧪 MELT!',
                  x: b.x,
                  y: b.y - 45,
                  color: '#84cc16',
                  size: 20,
                  life: 1,
                  maxLife: 40,
                  vy: -1.6,
                });

                // Melt nearby contact blocks within 32px
                for (let bi = 0; bi < currentBlocks.length; bi++) {
                  const other = currentBlocks[bi];
                  if (other.id === b.id || other.broken || other.despawned) continue;
                  if (Math.hypot(other.x - b.x, other.y - b.y) < 32) {
                    other.isAcidMelting = true;
                    other.acidTicks = 12;
                  }
                }

                for (let p = 0; p < 24; p++) {
                  particlesRef.current.push({
                    x: b.x + (Math.random() - 0.5) * b.width,
                    y: b.y + (Math.random() - 0.5) * b.height,
                    vx: (Math.random() - 0.5) * 6,
                    vy: Math.random() * 6 - 3,
                    size: Math.random() * 6 + 2,
                    color: Math.random() > 0.3 ? '#84cc16' : '#10b981',
                    life: 1,
                    maxLife: 32 + Math.random() * 18,
                    angle: 0,
                    vAngle: 0,
                    type: 'acid',
                  });
                }
              }

              // Sound throttle: only play crack sound for actual forceful strikes, never in a continuous loop
              const now = Date.now();
              if (now - lastBambooSnapSoundTimeRef.current > 200 && ballSpeed >= 3.4) {
                lastBambooSnapSoundTimeRef.current = now;
                soundManager.playBambooSnap(Math.min(1.8, Math.max(0.6, ballSpeed / 12)));
              }

              const splinterCount = ball.isSuperShot ? 16 : 8;
              for (let s = 0; s < splinterCount; s++) {
                particlesRef.current.push({
                  x: b.x + (Math.random() - 0.5) * b.width,
                  y: b.y + (Math.random() - 0.5) * b.height,
                  vx: (Math.random() - 0.3) * 12 + ball.vx * 0.2,
                  vy: (Math.random() - 0.8) * 12,
                  size: Math.random() * 6 + 2,
                  color: b.type === 'thatch' ? '#d4a34b' : b.type === 'pot' ? '#d9643a' : '#8da850',
                  life: 1,
                  maxLife: 35 + Math.random() * 20,
                  angle: Math.random() * Math.PI,
                  vAngle: (Math.random() - 0.3) * 0.3,
                  type: b.type === 'thatch' ? 'thatch' : 'wood',
                });
              }

              break;
            }
          }
        }

        // Settlement: Wait until ball stops AND all house blocks finish falling to ground and stop moving!
        if (ball.hitByBat) {
          const currentBlocks = blocksRef.current;
          const maxVillageX = currentBlocks.reduce((max, blk) => Math.max(max, blk.x + blk.width / 2), 1280);
          const isFarRight = ball.x > maxVillageX + 80;
          const isFarLeft = ball.x < -60;
          const isBallStopped = Math.hypot(ball.vx, ball.vy) < 0.45;

          // USER REQUIREMENT:
          // If a pillar or roof part falls or is falling, wait until it finishes falling to the ground
          // and all parts of the house completely stop moving before the next ball is allowed to bowl!
          const houseStillMoving = currentBlocks.some(
            (blk) =>
              !blk.despawned &&
              !blk.isDespawning &&
              (Math.abs(blk.vy) > 0.25 ||
                Math.abs(blk.vx) > 0.25 ||
                (blk.isOnFire && (blk.fireTicks ?? 0) > 0) ||
                (blk.isAcidMelting && (blk.acidTicks ?? 0) > 0))
          );

          ballInPlayTimerRef.current++;
          const safetyTimeout = ballInPlayTimerRef.current > 240; // 4 seconds safety fallback

          // Both ball must be settled/out-of-bounds AND house must be completely still!
          const allSettled = (isFarRight || isFarLeft || isBallStopped) && !houseStillMoving;

          if (allSettled || safetyTimeout) {
            ballSettledTimerRef.current++;
            if (ballSettledTimerRef.current > 15 || safetyTimeout) {
              ballActiveRef.current = false;
              ballRef.current = null;
              bowlerRef.current.state = 'idle';
              bowlerRef.current.x = 850;
              bowlerRef.current.progress = 0;
              pendingBowlRef.current = false;
              isReadyForDeliveryRef.current = true;
              onReadyForDeliveryChangeRef.current?.(true);
              onBlocksUpdate([...currentBlocks]);
              onBallHitCompleted(0, runsThisBallRef.current);
            }
          } else {
            // Keep settled timer 0 while ball is in motion or building blocks are actively falling or dissolving
            ballSettledTimerRef.current = 0;
          }
        }
      }

      // 5. BAMBOO BLOCKS RIGID-BODY SIMULATION & ROOTED STRUCTURAL COLLAPSE
      let hasStructuralShift = false;

      // Process continuous burning and acid melting effects on blocks
      currentBlocks.forEach((block) => {
        if (block.despawned) return;

        if (block.isOnFire && block.fireTicks && block.fireTicks > 0) {
          block.fireTicks--;
          if (block.fireTicks % 5 === 0) {
            block.hp = Math.max(0, block.hp - 18);
            particlesRef.current.push({
              x: block.x + (Math.random() - 0.5) * block.width,
              y: block.y - block.height * 0.25,
              vx: (Math.random() - 0.5) * 3,
              vy: -Math.random() * 4 - 1.5,
              size: Math.random() * 5 + 2,
              color: Math.random() > 0.4 ? '#f97316' : '#facc15',
              life: 1,
              maxLife: 20,
              angle: 0,
              vAngle: 0,
              type: 'fire',
            });
            if (block.hp <= 0 && !block.broken) {
              block.broken = true;
              block.grounded = false;
              block.vy = 2.4;
              hasStructuralShift = true;
              hasBuildingBeenHitRef.current = true;
            }
          }
        }

        if (block.isAcidMelting && block.acidTicks && block.acidTicks > 0) {
          block.acidTicks--;
          if (block.acidTicks % 4 === 0) {
            block.hp = Math.max(0, block.hp - 8);
            particlesRef.current.push({
              x: block.x + (Math.random() - 0.5) * block.width,
              y: block.y + (Math.random() - 0.5) * block.height,
              vx: (Math.random() - 0.5) * 2,
              vy: Math.random() * 3 + 1,
              size: Math.random() * 4 + 2,
              color: Math.random() > 0.3 ? '#84cc16' : '#10b981',
              life: 1,
              maxLife: 22,
              angle: 0,
              vAngle: 0,
              type: 'acid',
            });
            if (block.hp <= 0 && !block.broken) {
              block.broken = true;
              block.grounded = false;
              block.vy = 2.4;
              hasStructuralShift = true;
              hasBuildingBeenHitRef.current = true;
            }
          }
        }
      });

      // PRE-HIT RIGID STABILITY GUARD:
      // USER REQUIREMENT: 100% rigid stability until first cricket ball hit,
      // followed by realistic domino collapse upon impact.
      if (!hasBuildingBeenHitRef.current) {
        const isAnyDamaged = currentBlocks.some((b) => b.broken || b.hp < b.maxHp || b.isDespawning || b.despawned);
        if (isAnyDamaged) {
          hasBuildingBeenHitRef.current = true;
        } else {
          // Structure is untouched: enforce 100% rigid stability and bypass premature collapse!
          currentBlocks.forEach((b) => {
            b.vx = 0;
            b.vy = 0;
            b.vAngle = 0;
            b.grounded = true;
          });
        }
      }

      if (hasBuildingBeenHitRef.current) {
        // STEP 1: Compute Rooted Support & Center-of-Mass Balance Network
        // A block is structurally supported ONLY if it is an intact ground foundation root,
        // OR if it rests in balanced equilibrium on intact blocks that trace support down to the ground.
        const supportedIds = new Set<string>();

        // 1. Intact ground-level foundation blocks (posts, stilts, ground pots)
        // Note: Woven walls and leaning ladders are evaluated in Step 2 so they collapse when their supporting pillars break!
        currentBlocks.forEach((b) => {
          if (b.type === 'wall' || b.type === 'ladder') return;
          const isUpright = Math.abs(b.angle) < 0.52;
          const isIntact = !b.broken && b.hp > 0 && !b.despawned && !b.isDespawning;
          const isOnGround = (b.y + b.height / 2 >= groundY - 14) && b.grounded;
          if (isIntact && isOnGround && isUpright) {
            supportedIds.add(b.id);
          }
        });

        // 2. Propagate structural support and balance upwards iteratively
        let changed = true;
        let iterations = 0;
        while (changed && iterations < 35) {
          changed = false;
          iterations++;

          currentBlocks.forEach((b) => {
            if (supportedIds.has(b.id)) return;
            // Broken or ungrounded blocks cannot support themselves or structures above them
            if (b.broken || b.hp <= 0 || !b.grounded || b.despawned || b.isDespawning) return;

            const bLeft = b.x - b.width / 2;
            const bRight = b.x + b.width / 2;
            const bBottom = b.y + b.height / 2;
            const bTop = b.y - b.height / 2;

            // Find already-supported blocks directly below or spanning through this block
            const supportsBelow = currentBlocks.filter((other) => {
              if (!supportedIds.has(other.id)) return false;
              const otherLeft = other.x - other.width / 2;
              const otherRight = other.x + other.width / 2;
              const overlapsX = Math.max(bLeft, otherLeft) <= Math.min(bRight, otherRight);
              if (!overlapsX) return false;

              const otherTop = other.y - other.height / 2;
              const otherBottom = other.y + other.height / 2;

              // Tight vertical contact for resting on top of another block (no jumping across broken beam gaps!)
              const isDirectlyAbove = b.y < other.y && bBottom >= otherTop - 9 && bBottom <= otherTop + 14;
              // A mid-rail horizontal beam or crow's nest spanned by vertical bamboo posts
              const isSpannedByPost =
                (other.type === 'post' || other.type === 'stilt') &&
                otherTop <= b.y + 4 &&
                otherBottom >= b.y - 4;
              return isDirectlyAbove || isSpannedByPost;
            });

            let hasSufficientSupport = false;

            if (b.type === 'beam') {
              if (b.width <= 106) {
                // Short walkway bridge beam or ship mast yardarm:
                // Supported if resting on >= 2 supports OR centered on a vertical mast/stilt post
                const pillarSupports = supportsBelow.filter(
                  (s) => s.type === 'post' || s.type === 'stilt' || s.type === 'beam'
                );
                const hasCenteredPost = pillarSupports.some(
                  (s) => (s.type === 'post' || s.type === 'stilt') && Math.abs(s.x - b.x) <= 22
                );
                hasSufficientSupport = pillarSupports.length >= 2 || hasCenteredPost;
              } else {
                // Wide building beam (roof eaves beam, floor deck beam, or mid-rail beam):
                // Must be supported by at least 2 intact vertical pillars within its load-bearing span
                // (excluding outer decorative eave overhangs) AND balanced across its center of mass!
                const maxPillarOffset = b.width / 2 - 6;
                const pillarSupports = supportsBelow.filter(
                  (s) => (s.type === 'post' || s.type === 'stilt') && Math.abs(s.x - b.x) <= maxPillarOffset
                );
                if (pillarSupports.length >= 2) {
                  const minSupX = Math.min(...pillarSupports.map((s) => s.x - s.width / 2));
                  const maxSupX = Math.max(...pillarSupports.map((s) => s.x + s.width / 2));
                  const hasLeftSupport = minSupX <= b.x + 2;
                  const hasRightSupport = maxSupX >= b.x - 2;
                  const spanWidth = maxSupX - minSupX;
                  hasSufficientSupport = hasLeftSupport && hasRightSupport && spanWidth >= b.width * 0.22;
                }
              }
            } else if (b.type === 'thatch') {
              if (b.width <= 48) {
                // Small crow's nest thatch basket on ship mast
                hasSufficientSupport = supportsBelow.some(
                  (s) =>
                    ((s.type === 'beam' || s.type === 'thatch') && Math.abs(s.x - b.x) <= 30) ||
                    (s.type === 'post' && Math.abs(s.x - b.x) <= 20)
                );
              } else {
                // Wide thatch roof tier:
                // NEVER balances on vertical corner posts! Must rest on an intact horizontal roof beam
                // OR a wider lower thatch tier aligned with its center.
                hasSufficientSupport = supportsBelow.some(
                  (s) =>
                    (s.type === 'beam' &&
                      Math.abs(s.x - b.x) <= 25 &&
                      b.width >= s.width - 24 &&
                      bBottom <= s.y - s.height / 2 + 14) ||
                    (s.type === 'thatch' && s.width >= b.width && Math.abs(s.x - b.x) <= 25)
                );
              }
            } else if (b.type === 'post') {
              // Upper-story pillar or rooftop spire:
              // Must rest within the load-bearing span of an intact horizontal deck beam or pagoda eave thatch.
              // NEVER skips across a broken deck beam gap to grab onto a lower post!
              hasSufficientSupport = supportsBelow.some(
                (s) =>
                  (s.type === 'beam' && s.width >= 52 && Math.abs(b.x - s.x) <= s.width / 2 - 4) ||
                  (s.type === 'thatch' && Math.abs(b.x - s.x) <= s.width / 2 - 6)
              );
            } else if (b.type === 'wall') {
              // Woven bamboo chatai wall panel requires at least 2 intact room posts AND an intact floor/deck below it
              const roomPosts = currentBlocks.filter(
                (other) =>
                  supportedIds.has(other.id) &&
                  (other.type === 'post' || other.type === 'stilt') &&
                  Math.abs(other.x - b.x) <= b.width * 0.65 &&
                  other.y - other.height / 2 <= bBottom &&
                  other.y + other.height / 2 >= bTop
              );
              const beamOrDeckBelow = currentBlocks.some(
                (other) =>
                  supportedIds.has(other.id) &&
                  other.type === 'beam' &&
                  Math.abs(other.x - b.x) <= b.width * 0.5 &&
                  other.y >= b.y &&
                  other.y - other.height / 2 - bBottom <= 16
              );
              hasSufficientSupport = roomPosts.length >= 2 && (beamOrDeckBelow || bBottom >= groundY - 65);
            } else if (b.type === 'ladder') {
              // Leaning ladder requires ground contact AND an intact adjacent post, stilt, or beam to lean against
              const isOnGround = bBottom >= groundY - 20 && b.grounded;
              const hasAdjacentSupport = currentBlocks.some(
                (other) =>
                  supportedIds.has(other.id) &&
                  (other.type === 'post' || other.type === 'stilt' || other.type === 'beam') &&
                  Math.abs(other.x - b.x) <= 35 &&
                  Math.abs(other.y - b.y) <= b.height
              );
              hasSufficientSupport = isOnGround && hasAdjacentSupport;
            } else {
              // Gold, standing pots, rafters
              hasSufficientSupport = supportsBelow.some(
                (s) => s.type === 'beam' || s.type === 'thatch' || s.type === 'post'
              );
            }

            // Or check if hanging item (lantern, hanging pot) is supported from above by an intact beam or thatch
            const isHangingType = b.type === 'lantern' || b.type === 'pot' || b.hanging;
            let hasSupportAbove = false;
            if (isHangingType) {
              hasSupportAbove = currentBlocks.some((other) => {
                if (!supportedIds.has(other.id)) return false;
                if (other.type !== 'beam' && other.type !== 'thatch') return false;
                const otherLeft = other.x - other.width / 2 - 12;
                const otherRight = other.x + other.width / 2 + 12;
                const overlapsHoriz = b.x >= otherLeft && b.x <= otherRight;
                const otherBottom = other.y + other.height / 2;
                const isDirectlyBelow = bTop >= otherBottom - 10 && bTop <= otherBottom + 36;
                return overlapsHoriz && isDirectlyBelow;
              });
            }

            if (hasSufficientSupport || hasSupportAbove) {
              supportedIds.add(b.id);
              changed = true;
            }
          });
        }

        // STEP 2: Enforce Gravity, Asymmetric Tilting & Unobstructed Collapse on Unsupported Blocks
        currentBlocks.forEach((b) => {
          if (b.despawned) return;

          // If block touched ground and is dissolving/despawning:
          if (b.isDespawning) {
            b.opacity = (b.opacity ?? 1.0) - 0.08;
            b.vx = 0;
            b.vy = 0;
            b.vAngle = 0;
            if (b.opacity <= 0) {
              b.opacity = 0;
              b.despawned = true;
            }
            hasStructuralShift = true;
            return;
          }

          const isSupported = supportedIds.has(b.id);
          const halfExtentY = (Math.abs(Math.sin(b.angle)) * b.width + Math.abs(Math.cos(b.angle)) * b.height) / 2;
          const currentBottom = b.y + halfExtentY;

          // An intact foundation post/stilt standing rooted on ACTUAL GROUND:
          const isOnGround = b.y + b.height / 2 >= groundY - 14;
          const isRootPost =
            (b.type === 'post' || b.type === 'stilt') &&
            isOnGround &&
            b.grounded &&
            Math.abs(b.angle) < 0.52 &&
            !b.broken &&
            b.hp > 0 &&
            !b.despawned &&
            !b.isDespawning;

          // If block has lost structural support, immediately lose balance, tilt toward unsupported side, and fall!
          if (!isSupported && !isRootPost) {
            const justLostSupport = b.grounded;
            b.grounded = false;
            if (b.vy < 1.2) {
              b.vy = 2.5; // Immediate downward gravity drop
            }

            if (justLostSupport) {
              if (
                !b.broken &&
                (b.type === 'beam' || b.type === 'thatch' || b.type === 'post' || b.type === 'wall' || b.type === 'stilt')
              ) {
                const nowCollapse = Date.now();
                if (nowCollapse - lastStructureCrashSoundTimeRef.current > 450) {
                  lastStructureCrashSoundTimeRef.current = nowCollapse;
                  soundManager.playStructureCrash();
                }
              }

              // Check if there is an asymmetric remaining pillar on one side under this beam/roof
              const bLeft = b.x - b.width / 2;
              const bRight = b.x + b.width / 2;
              const remainingPillarsBelow = currentBlocks.filter(
                (other) =>
                  supportedIds.has(other.id) &&
                  (other.type === 'post' || other.type === 'stilt') &&
                  other.x >= bLeft - 10 &&
                  other.x <= bRight + 10 &&
                  other.y >= b.y - 20
              );

              if ((b.type === 'beam' || b.type === 'thatch' || b.type === 'wall') && remainingPillarsBelow.length > 0) {
                const avgPillarX =
                  remainingPillarsBelow.reduce((sum, p) => sum + p.x, 0) / remainingPillarsBelow.length;
                const dxSupport = avgPillarX - b.x;
                if (dxSupport > 8) {
                  // Remaining pillar is on the right -> left (unsupported) side tips downward
                  b.vAngle = -0.026;
                  b.vx = -0.85;
                } else if (dxSupport < -8) {
                  // Remaining pillar is on the left -> right (unsupported) side tips downward
                  b.vAngle = 0.026;
                  b.vx = 0.85;
                } else {
                  b.vAngle = (Math.random() - 0.5) * 0.016;
                }
              } else if (b.type === 'post' || b.type === 'stilt' || b.type === 'ladder') {
                if (Math.abs(b.vAngle) < 0.01) {
                  b.vAngle = (b.angle >= 0 ? 1 : -1) * 0.024;
                }
              }
            }
          }

          // Rigid body dynamics if ungrounded or in motion
          if (!b.grounded || Math.abs(b.vy) > 0.05 || Math.abs(b.vx) > 0.05) {
            b.vy += 0.85; // Solid realistic gravity
            b.vx *= 0.92;

            // Controlled rotational tipping:
            // Roofs and beams tilt naturally toward their unsupported side (up to ~33°) without spinning like propellers
            if (b.type === 'thatch' || b.type === 'beam') {
              b.vAngle = Math.max(-0.04, Math.min(0.04, b.vAngle * 0.96));
              if (Math.abs(b.angle) > 0.58) {
                b.angle = Math.sign(b.angle) * 0.58;
                b.vAngle = 0;
              }
            } else if (b.type === 'wall') {
              b.vAngle = Math.max(-0.03, Math.min(0.03, b.vAngle * 0.94));
              if (Math.abs(b.angle) > 0.45) {
                b.angle = Math.sign(b.angle) * 0.45;
                b.vAngle = 0;
              }
            } else {
              // Posts and ladders smoothly topple sideways
              b.vAngle = Math.max(-0.04, Math.min(0.04, b.vAngle * 0.92));
            }

            b.x += b.vx;
            b.y += b.vy;
            b.angle += b.vAngle;

            // Boundary containment: Prevent bamboo debris from flying backwards onto the cricket pitch
            const minHutX = 875;
            if (b.x < minHutX) {
              b.x = minHutX;
              if (b.vx < 0) b.vx = 0;
            }

            // Block-to-block interaction for falling debris (never snags or shoves wide falling roofs in mid-air)
            if ((Math.abs(b.vx) > 0.2 || Math.abs(b.vy) > 0.8) && b.width < 60) {
              for (let j = 0; j < currentBlocks.length; j++) {
                const other = currentBlocks[j];
                if (other.id === b.id || other.despawned || other.isDespawning) continue;

                const bHalfW = b.width / 2;
                const bHalfH = b.height / 2;
                const oHalfW = other.width / 2;
                const oHalfH = other.height / 2;

                const cdx = other.x - b.x;
                const cdy = other.y - b.y;
                const cOverlapX = bHalfW + oHalfW - Math.abs(cdx);
                const cOverlapY = bHalfH + oHalfH - Math.abs(cdy);

                if (cOverlapX > 0 && cOverlapY > 0) {
                  if (!other.broken && other.hp > 0 && other.grounded) {
                    b.vx *= 0.25;
                  } else if (other.broken || other.hp <= 0) {
                    other.vx += Math.min(1.2, b.vx * 0.25);
                    b.vx *= 0.5;
                  }
                }
              }
            }

          // Dislodged or falling parts tumble all the way down to the ground.
          // They must NEVER get trapped in mid-air loops!
          // When any part touches the ground (bamboo or thatch), it immediately dissolves/despawns.
          if (currentBottom >= groundY) {
            b.y = groundY - halfExtentY;
            b.vy = 0;
            b.vx = 0;
            b.vAngle = 0;
            b.grounded = true;
            b.isDespawning = true;
            b.opacity = 1.0;
            b.hp = 0;
            b.broken = true;

            // USER REQUIREMENT:
            // When gold falls to the ground, it starts an animation flying from the ground
            // towards where money is shown in the game (the HUD Coins counter), touches it,
            // vanishes, and awards coins upon contact!
            if (b.type === 'gold') {
              const goldValue = 50;
              b.despawned = true;

              // Announcement floating text on the ground (English only)
              floatingTextsRef.current.push({
                id: `gold_${Date.now()}_${b.id}`,
                text: '🪙 GOLD DROPPED!',
                x: b.x,
                y: groundY - 28,
                color: '#fbbf24',
                size: 20,
                life: 1,
                maxLife: 42,
                vy: -1.4,
              });

              // Golden sparkle ground explosion
              for (let sp = 0; sp < 16; sp++) {
                particlesRef.current.push({
                  x: b.x + (Math.random() - 0.5) * 18,
                  y: groundY - 4,
                  vx: (Math.random() - 0.5) * 7.5,
                  vy: -Math.random() * 5 - 1.5,
                  size: Math.random() * 3.5 + 2,
                  color: sp % 2 === 0 ? '#fbbf24' : '#fef08a',
                  life: 1,
                  maxLife: 26,
                  angle: Math.random() * Math.PI,
                  vAngle: 0.2,
                  type: 'spark',
                });
              }

              // Compute screen start coordinates of the gold ground impact
              const startScreenX = (offsetX - cameraXRef.current * scale) + b.x * scale;
              const startScreenY = offsetY + groundY * scale - 6;

              // Compute HUD coin target position
              let targetScreenX = width - 95;
              let targetScreenY = 32;
              const hudCoinEl = document.getElementById('hud-coins-counter');
              if (hudCoinEl) {
                const rect = hudCoinEl.getBoundingClientRect();
                if (rect.width > 0 && rect.height > 0) {
                  targetScreenX = rect.left + rect.width / 2;
                  targetScreenY = rect.top + rect.height / 2;
                }
              }

              // Spawn 5 flying gold coins (10 coins each = 50 coins total)
              const numCoins = 5;
              const coinValue = Math.round(goldValue / numCoins);
              for (let ci = 0; ci < numCoins; ci++) {
                const arcSpreadX = (Math.random() - 0.5) * 130;
                const arcHeight = 110 + Math.random() * 85;
                flyingCoinsRef.current.push({
                  id: `fc_${Date.now()}_${b.id}_${ci}`,
                  startX: startScreenX + (Math.random() - 0.5) * 16,
                  startY: startScreenY + (Math.random() - 0.5) * 8,
                  currentX: startScreenX,
                  currentY: startScreenY,
                  targetX: targetScreenX,
                  targetY: targetScreenY,
                  controlX: (startScreenX + targetScreenX) / 2 + arcSpreadX,
                  controlY: Math.min(startScreenY, targetScreenY) - arcHeight,
                  progress: 0,
                  speed: 0.024 + Math.random() * 0.005,
                  delay: ci * 5,
                  rotation: (ci * Math.PI) / 3,
                  rotSpeed: 0.22 + Math.random() * 0.08,
                  size: 11,
                  value: coinValue,
                });
              }
            }

            // Spawn ground impact dust/splinters
            const particleCount = b.type === 'thatch' ? 8 : 6;
            for (let p = 0; p < particleCount; p++) {
              particlesRef.current.push({
                x: b.x + (Math.random() - 0.5) * (b.width * 0.8),
                y: groundY - Math.random() * 4,
                vx: (Math.random() - 0.5) * 5,
                vy: -Math.random() * 3 - 0.8,
                size: Math.random() * 3.5 + 1.5,
                color: b.type === 'thatch' ? '#d4a34b' : '#8da850',
                life: 1,
                maxLife: 22,
                angle: Math.random() * Math.PI,
                vAngle: 0.1,
                type: b.type === 'thatch' ? 'thatch' : 'wood',
              });
            }
          }

          hasStructuralShift = true;
        }
      });
      } // End of if (hasBuildingBeenHitRef.current)

      if (hasStructuralShift) {
        blockUpdateThrottleRef.current++;
        if (blockUpdateThrottleRef.current >= 8) {
          blockUpdateThrottleRef.current = 0;
          onBlocksUpdate([...currentBlocks]);
        }
      }

      // 6. BATSMAN ANIMATION UPDATE
      if (batsman.stance === 'swinging') {
        batsman.swingProgress += 0.08;
        if (batsman.swingProgress >= 1.0) {
          batsman.stance = 'followThrough';
          batsman.swingProgress = 1.0;
        }
      } else if (batsman.stance === 'followThrough') {
        batsman.swingProgress -= 0.05;
        if (batsman.swingProgress <= 0) {
          batsman.stance = 'ready';
          batsman.swingProgress = 0;
        }
      } else if (bowlerRef.current.state === 'runup' || (ball && ballActiveRef.current && !ball.hitByBat)) {
        batsman.stance = 'backlift';
      }

      // 7. PARTICLES UPDATE
      particlesRef.current = particlesRef.current.filter((p) => {
        p.life++;
        p.x += p.vx;
        p.y += p.vy;
        p.vy += 0.25;
        p.angle += p.vAngle;

        if (p.y >= groundY) {
          p.y = groundY;
          p.vy = -p.vy * 0.35;
          p.vx *= 0.7;
        }

        return p.life < p.maxLife;
      });

      // 8. FLOATING TEXTS UPDATE
      floatingTextsRef.current = floatingTextsRef.current.filter((ft) => {
        ft.life++;
        ft.y += ft.vy;
        return ft.life < ft.maxLife;
      });

      // 9. SCREEN SPARKLES UPDATE (Trails and HUD impact bursts)
      screenSparklesRef.current = screenSparklesRef.current.filter((sp) => {
        sp.x += sp.vx;
        sp.y += sp.vy;
        sp.alpha -= sp.decay;
        return sp.alpha > 0;
      });

      // 10. FLYING GOLD COINS UPDATE (Fly smoothly along arc to HUD Coins Counter)
      let liveTargetX = width - 95;
      let liveTargetY = 32;
      const liveTargetEl = document.getElementById('hud-coins-counter');
      if (liveTargetEl) {
        const rect = liveTargetEl.getBoundingClientRect();
        if (rect.width > 0 && rect.height > 0) {
          liveTargetX = rect.left + rect.width / 2;
          liveTargetY = rect.top + rect.height / 2;
        }
      }

      flyingCoinsRef.current = flyingCoinsRef.current.filter((coin) => {
        if (coin.delay > 0) {
          coin.delay--;
          // Ground sparkle while waiting to launch
          if (Math.random() < 0.35) {
            screenSparklesRef.current.push({
              id: `sp_${Math.random()}`,
              x: coin.startX + (Math.random() - 0.5) * 8,
              y: coin.startY + (Math.random() - 0.5) * 6,
              vx: (Math.random() - 0.5) * 1.5,
              vy: -Math.random() * 2 - 0.5,
              size: Math.random() * 2.5 + 1.5,
              color: '#fef08a',
              alpha: 1.0,
              decay: 0.06,
            });
          }
          return true;
        }

        // Live target tracking
        coin.targetX = liveTargetX;
        coin.targetY = liveTargetY;

        coin.progress += coin.speed;
        const t = Math.min(1.0, coin.progress);
        const invT = 1.0 - t;

        // Quadratic bezier arc interpolation from ground to HUD counter
        coin.currentX = invT * invT * coin.startX + 2 * invT * t * coin.controlX + t * t * coin.targetX;
        coin.currentY = invT * invT * coin.startY + 2 * invT * t * coin.controlY + t * t * coin.targetY;
        coin.rotation += coin.rotSpeed;

        // Sparkle trail behind flying coin
        screenSparklesRef.current.push({
          id: `sp_${Math.random()}`,
          x: coin.currentX + (Math.random() - 0.5) * 6,
          y: coin.currentY + (Math.random() - 0.5) * 6,
          vx: (Math.random() - 0.5) * 1.2,
          vy: (Math.random() - 0.5) * 1.2,
          size: Math.random() * 3 + 1.5,
          color: Math.random() > 0.4 ? '#fef08a' : '#fbbf24',
          alpha: 1.0,
          decay: 0.05,
        });

        // Arrival check: when coin touches the HUD money display!
        if (coin.progress >= 1.0) {
          // Touch! Add money right now as requested
          onCoinEarnedRef.current(coin.value);
          soundManager.playCoin();

          // Golden sparkle impact burst at HUD counter
          for (let k = 0; k < 12; k++) {
            const ang = (Math.PI * 2 * k) / 12 + Math.random() * 0.4;
            const spd = Math.random() * 4.5 + 2.0;
            screenSparklesRef.current.push({
              id: `hit_sp_${Math.random()}`,
              x: coin.targetX,
              y: coin.targetY,
              vx: Math.cos(ang) * spd,
              vy: Math.sin(ang) * spd,
              size: Math.random() * 3.5 + 2,
              color: k % 2 === 0 ? '#fef08a' : '#fbbf24',
              alpha: 1.0,
              decay: 0.045,
            });
          }

          // Tactical pulse on HUD coin counter badge
          if (liveTargetEl) {
            liveTargetEl.style.transform = 'scale(1.25)';
            setTimeout(() => {
              if (liveTargetEl) {
                liveTargetEl.style.transform = 'scale(1)';
              }
            }, 120);
          }

          // Vanish!
          return false;
        }

        return true;
      });
      }

      // =========================================================================
      // RENDERING SECTION: HIGH-PERFORMANCE PROCEDURAL 60FPS CACHED BACKGROUND
      // =========================================================================
      ctx.save();
      ctx.clearRect(0, 0, width, height);

      // Dynamic Smooth Camera Panning:
      // Focus on the pitch during batsman readiness & bowler delivery (cameraX = 0).
      // When the ball is struck by the bat, glide smoothly rightward to follow the ball
      // into the outfield village complex (up to maxCameraPan).
      // When ball settles or resets, glide smoothly back to pitch view.
      const flightBall = ballRef.current;
      const rightmostBlock = currentBlocks.reduce((max, blk) => Math.max(max, blk.x + blk.width / 2), 1280);
      const maxCameraPan = Math.max(0, rightmostBlock + 80 - 1280);

      let targetCamX = 0;
      if (flightBall && ballActiveRef.current && flightBall.hitByBat && flightBall.x > 500) {
        targetCamX = Math.min(maxCameraPan, (flightBall.x - 500) * 0.95);
      } else if (!ballActiveRef.current) {
        targetCamX = 0;
      }
      cameraXRef.current += (targetCamX - cameraXRef.current) * 0.075;
      if (Math.abs(cameraXRef.current) < 0.2) cameraXRef.current = 0;

      const theme = bgThemeRef.current;
      const bgCacheKey = `${Math.round(width)}x${Math.round(height)}_${theme}_${Math.round(screenGroundY)}`;

      if (!bgCanvasRef.current) {
        bgCanvasRef.current = document.createElement('canvas');
      }

      const bgWidth = Math.max(1, Math.round(width * 1.45));
      const bgHeight = Math.max(1, Math.round(height));

      if (
        bgCacheKeyRef.current !== bgCacheKey ||
        bgCanvasRef.current.width !== bgWidth ||
        bgCanvasRef.current.height !== bgHeight
      ) {
        bgCanvasRef.current.width = bgWidth;
        bgCanvasRef.current.height = bgHeight;
        const bgCtx = bgCanvasRef.current.getContext('2d');
        if (bgCtx) {
          bgCtx.clearRect(0, 0, bgWidth, bgHeight);
          renderProceduralBackground(bgCtx, bgWidth, bgHeight, screenGroundY, theme);
          bgCacheKeyRef.current = bgCacheKey;
        }
      }

      // Draw pre-rendered background with subtle parallax depth
      if (bgCanvasRef.current.width > 0 && bgCanvasRef.current.height > 0) {
        const bgParallaxX = cameraXRef.current * scale * 0.25;
        ctx.drawImage(bgCanvasRef.current, -bgParallaxX, 0);
        renderAmbientBackgroundOverlay(
          ctx,
          bgWidth,
          bgHeight,
          screenGroundY,
          theme,
          performance.now(),
          bgParallaxX
        );
      }

      // =========================================================================
      // D. GAMEPLAY WORLD LAYER (Scaled, centered, and physically consistent)
      // =========================================================================
      ctx.save();
      ctx.translate(offsetX - cameraXRef.current * scale, offsetY);
      ctx.scale(scale, scale);

      // 1. Outfield Turf-to-Pitch Bevel Shadow & Rolled Border
      ctx.fillStyle = 'rgba(20, 83, 45, 0.42)';
      ctx.beginPath();
      ctx.roundRect(128, groundY - 5, 769, 45, 6);
      ctx.fill();

      // 2. Photorealistic Rolled Clay/Loam 22-Yard Cricket Pitch Strip
      const pitchGrad = ctx.createLinearGradient(132, groundY, 892, groundY);
      pitchGrad.addColorStop(0.0, '#b45309');   // Moist clay crease edge
      pitchGrad.addColorStop(0.12, '#d97706');  // Compacted tan loam
      pitchGrad.addColorStop(0.32, '#eab308');  // Sun-baked golden-tan good length
      pitchGrad.addColorStop(0.50, '#facc15');  // Dry baked center strip
      pitchGrad.addColorStop(0.68, '#eab308');  // Sun-baked golden-tan
      pitchGrad.addColorStop(0.88, '#d97706');  // Compacted tan loam
      pitchGrad.addColorStop(1.0, '#b45309');   // Moist clay bowler edge
      ctx.fillStyle = pitchGrad;
      ctx.beginPath();
      ctx.roundRect(132, groundY - 3, 760, 40, 4);
      ctx.fill();

      // Pitch Vertical Depth Shading (Top Edge Highlight to Front Lip Shadow)
      const pitchDepthGrad = ctx.createLinearGradient(0, groundY - 3, 0, groundY + 37);
      pitchDepthGrad.addColorStop(0.0, 'rgba(255, 255, 255, 0.18)');
      pitchDepthGrad.addColorStop(0.25, 'rgba(255, 255, 255, 0)');
      pitchDepthGrad.addColorStop(0.75, 'rgba(120, 53, 15, 0.12)');
      pitchDepthGrad.addColorStop(1.0, 'rgba(69, 26, 3, 0.38)');
      ctx.fillStyle = pitchDepthGrad;
      ctx.fillRect(132, groundY - 3, 760, 40);

      // Subtle Heavy Roller Compaction Bands Across Pitch
      for (let rb = 160; rb < 860; rb += 76) {
        ctx.fillStyle = 'rgba(254, 249, 195, 0.09)';
        ctx.fillRect(rb, groundY - 2, 34, 38);
      }

      // Natural Baked Clay Micro-Fissures & Soil Grain
      ctx.strokeStyle = 'rgba(120, 53, 15, 0.34)';
      ctx.lineWidth = 1.1;
      for (let crack = 152; crack < 875; crack += 38) {
        const cy = groundY + 4 + (crack % 6) * 4.5;
        ctx.beginPath();
        ctx.moveTo(crack, cy);
        ctx.lineTo(crack + 10, cy + 1.5);
        ctx.lineTo(crack + 21, cy - 0.8);
        ctx.stroke();
      }

      // Worn Batsman & Bowler Rough Footmark Patches
      const drawFootmarkPatch = (fx: number, fy: number, rx: number, ry: number) => {
        const fGrad = ctx.createRadialGradient(fx, fy, 2, fx, fy, rx);
        fGrad.addColorStop(0, 'rgba(120, 53, 15, 0.55)');
        fGrad.addColorStop(0.6, 'rgba(146, 64, 14, 0.32)');
        fGrad.addColorStop(1, 'rgba(180, 83, 9, 0)');
        ctx.fillStyle = fGrad;
        ctx.beginPath();
        ctx.ellipse(fx, fy, rx, ry, 0, 0, Math.PI * 2);
        ctx.fill();
      };
      drawFootmarkPatch(192, groundY + 13, 30, 11);
      drawFootmarkPatch(798, groundY + 14, 28, 10);

      // Fine Green Grass Tufting Along Upper & Lower Pitch Edges
      ctx.fillStyle = '#15803d';
      for (let gt = 136; gt < 888; gt += 14) {
        ctx.fillRect(gt, groundY - 5, 2, 3.5);
        ctx.fillRect(gt + 6, groundY + 35, 2, 3.5);
      }

      // 3. Crisp Lime-Washed Regulation White Crease Markings
      ctx.fillStyle = 'rgba(255, 255, 255, 0.94)';
      // Batsman Bowling Crease & Popping Crease
      ctx.fillRect(150, groundY - 3, 2.8, 39);
      ctx.fillRect(182, groundY - 3, 3.4, 39);
      ctx.fillRect(142, groundY - 3, 44, 2.2);
      ctx.fillRect(142, groundY + 34, 44, 2.2);

      // Bowler Bowling Crease & Popping Crease
      ctx.fillRect(815, groundY - 3, 2.8, 39);
      ctx.fillRect(785, groundY - 3, 3.4, 39);
      ctx.fillRect(780, groundY - 3, 44, 2.2);
      ctx.fillRect(780, groundY + 34, 44, 2.2);

      // 4. 3D Polished Ash-Wood Cricket Wickets & Sculpted Bails
      // Ground Cast Shadows for Wickets
      ctx.fillStyle = 'rgba(69, 26, 3, 0.35)';
      ctx.beginPath();
      ctx.ellipse(156, groundY + 2, 12, 3, 0, 0, Math.PI * 2);
      ctx.ellipse(816, groundY + 2, 12, 3, 0, 0, Math.PI * 2);
      ctx.fill();

      const draw3DStump = (stumpH: number) => {
        const sGrad = ctx.createLinearGradient(-2, 0, 2, 0);
        sGrad.addColorStop(0, '#b45309');
        sGrad.addColorStop(0.38, '#fef08a'); // Polished ash-wood specular highlight
        sGrad.addColorStop(0.7, '#f59e0b');
        sGrad.addColorStop(1, '#78350f');
        ctx.fillStyle = sGrad;
        ctx.beginPath();
        ctx.roundRect(-1.8, -stumpH, 3.6, stumpH, [2, 2, 0, 0]);
        ctx.fill();

        // Brass/Gold Ferrule Ring Near Top of Stump
        ctx.fillStyle = '#fef9c3';
        ctx.fillRect(-1.8, -stumpH + 4, 3.6, 1.6);
      };

      const st = stumpsRef.current;
      [0, 1, 2].forEach((idx) => {
        ctx.save();
        const sx = 150 + idx * 5;
        const sy = groundY;
        ctx.translate(sx, sy);
        if (st.broken) {
          const angles = [st.stump1Angle, st.stump2Angle, st.stump3Angle];
          ctx.rotate(angles[idx]);
        }
        draw3DStump(50);
        ctx.restore();
      });

      // Batsman Bails (3D Carved Spigots & Barrel)
      ctx.save();
      if (st.broken) {
        st.bailsY += st.bailsVy;
        st.bailsVy += 0.35;
        ctx.translate(148 + st.bailsVx, groundY - 52 + st.bailsY);
        ctx.rotate(st.bailsY * 0.1);
      } else {
        ctx.translate(148, groundY - 52);
      }
      ctx.fillStyle = '#fde047';
      ctx.fillRect(0, 0, 7.8, 3);
      ctx.fillRect(9.2, 0, 7.8, 3);
      ctx.fillStyle = '#b45309';
      ctx.fillRect(2, -0.6, 3.8, 4.2);
      ctx.fillRect(11.2, -0.6, 3.8, 4.2);
      ctx.restore();

      // Bowler End 3D Wickets & Bails
      for (let s = 0; s < 3; s++) {
        ctx.save();
        ctx.translate(810 + s * 5, groundY);
        draw3DStump(50);
        ctx.restore();
      }
      ctx.fillStyle = '#fde047';
      ctx.fillRect(808, groundY - 52, 7.8, 3);
      ctx.fillRect(817.2, groundY - 52, 7.8, 3);
      ctx.fillStyle = '#b45309';
      ctx.fillRect(810, groundY - 52.6, 3.8, 4.2);
      ctx.fillRect(819.2, groundY - 52.6, 3.8, 4.2);

      // C. Render Bamboo Hut Blocks
      currentBlocks.forEach((b) => {
        if (b.despawned) return;
        ctx.save();
        if (b.opacity !== undefined) {
          ctx.globalAlpha = Math.max(0, Math.min(1, b.opacity));
        }
        ctx.translate(b.x, b.y);
        ctx.rotate(b.angle);

        const w = b.width;
        const h = b.height;
        const hpRatio = Math.max(0, b.hp / b.maxHp);

        // =====================================================================
        // 1. BAMBOO POSTS, STILTS & HORIZONTAL BEAMS (Volumetric 3D Bamboo Culms)
        // =====================================================================
        if (b.type === 'post' || b.type === 'stilt' || b.type === 'beam') {
          const isVertical = h >= w;

          if (isVertical) {
            // --- VERTICAL BAMBOO CULM (Posts / Stilts) ---
            // 1a. Cylindrical 3D Lighting Gradient across width
            const culmGrad = ctx.createLinearGradient(-w / 2, 0, w / 2, 0);
            culmGrad.addColorStop(0.0, '#4a5b25'); // Deep olive shadow on left edge
            culmGrad.addColorStop(0.18, '#6b8235'); // Shaded bamboo body
            culmGrad.addColorStop(0.42, '#b8d26c'); // Bright sunlit specular ridge
            culmGrad.addColorStop(0.70, '#8ea84e'); // Warm natural olive body
            culmGrad.addColorStop(0.92, '#5e722f'); // Soft back-shadow
            culmGrad.addColorStop(1.0, '#3f4e1f'); // Ambient occlusion right edge
            ctx.fillStyle = culmGrad;
            ctx.beginPath();
            ctx.roundRect(-w / 2, -h / 2, w, h, 2.5);
            ctx.fill();

            // 1b. Longitudinal Fibrous Bamboo Grain
            ctx.strokeStyle = 'rgba(255, 255, 255, 0.16)';
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(-w * 0.15, -h / 2 + 2);
            ctx.lineTo(-w * 0.15, h / 2 - 2);
            ctx.stroke();

            ctx.strokeStyle = 'rgba(35, 45, 18, 0.22)';
            ctx.beginPath();
            ctx.moveTo(w * 0.2, -h / 2 + 2);
            ctx.lineTo(w * 0.2, h / 2 - 2);
            ctx.stroke();

            // 1c. Bamboo Outer Boundary Rim
            ctx.strokeStyle = '#38461b';
            ctx.lineWidth = 1.2;
            ctx.stroke();

            // 1d. Flared Bamboo Nodes (Joint Rings)
            const nodeCount = b.nodes || Math.max(3, Math.round(h / 30));
            const nodeStep = h / nodeCount;
            for (let n = 1; n < nodeCount; n++) {
              const ny = -h / 2 + n * nodeStep;

              // Dark constriction groove
              ctx.fillStyle = '#222d10';
              ctx.fillRect(-w / 2 - 1.2, ny - 1.2, w + 2.4, 2.4);

              // Raised swollen node collar ring
              const nodeRingGrad = ctx.createLinearGradient(-w / 2, 0, w / 2, 0);
              nodeRingGrad.addColorStop(0, '#536528');
              nodeRingGrad.addColorStop(0.4, '#d5e890');
              nodeRingGrad.addColorStop(1, '#445320');
              ctx.fillStyle = nodeRingGrad;
              ctx.beginPath();
              ctx.roundRect(-w / 2 - 1.8, ny - 2.2, w + 3.6, 2.2, 1.2);
              ctx.fill();

              // Transverse calloused ring highlight
              ctx.fillStyle = 'rgba(255, 255, 255, 0.65)';
              ctx.fillRect(-w * 0.35, ny - 2, w * 0.5, 0.9);
            }

            // 1e. Hollow Bamboo Top Cut End
            ctx.fillStyle = '#c8dd82'; // Cut bamboo wall rind
            ctx.beginPath();
            ctx.ellipse(0, -h / 2, w * 0.45, 2.2, 0, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = '#1c240c'; // Inner hollow dark void
            ctx.beginPath();
            ctx.ellipse(0, -h / 2, w * 0.25, 1.4, 0, 0, Math.PI * 2);
            ctx.fill();

            // 1f. Handcrafted Coir Rope Lashings (Cross-ties near upper and lower junctions)
            const lashYPositions = [-h / 2 + Math.min(22, h * 0.2), h / 2 - Math.min(20, h * 0.2)];
            lashYPositions.forEach((ly) => {
              // Rope Band Wrap
              ctx.fillStyle = '#855224'; // Hemp coir base
              ctx.fillRect(-w / 2 - 1.5, ly - 3, w + 3, 6);

              // Individual rope cords
              ctx.strokeStyle = '#d4a373'; // Sunlit hemp fibers
              ctx.lineWidth = 1.1;
              for (let c = -2; c <= 2; c += 2) {
                ctx.beginPath();
                ctx.moveTo(-w / 2 - 1.5, ly + c);
                ctx.lineTo(w / 2 + 1.5, ly + c);
                ctx.stroke();
              }

              // Diagonal X-lashing cord detail
              ctx.strokeStyle = '#5a3614';
              ctx.lineWidth = 1;
              ctx.beginPath();
              ctx.moveTo(-w * 0.4, ly - 3);
              ctx.lineTo(w * 0.4, ly + 3);
              ctx.moveTo(-w * 0.4, ly + 3);
              ctx.lineTo(w * 0.4, ly - 3);
              ctx.stroke();
            });
          } else {
            // --- HORIZONTAL BAMBOO BEAM ---
            // 2a. Horizontal Cylindrical Lighting Gradient across height
            const beamGrad = ctx.createLinearGradient(0, -h / 2, 0, h / 2);
            beamGrad.addColorStop(0.0, '#c7e076'); // Bright top sunlit ridge
            beamGrad.addColorStop(0.25, '#a6bf5c'); // Luminous upper bamboo body
            beamGrad.addColorStop(0.65, '#7f9840'); // Natural body tone
            beamGrad.addColorStop(1.0, '#425121'); // Deep underside shadow
            ctx.fillStyle = beamGrad;
            ctx.beginPath();
            ctx.roundRect(-w / 2, -h / 2, w, h, 2.5);
            ctx.fill();

            // 2b. Horizontal Fibrous Grain
            ctx.strokeStyle = 'rgba(255, 255, 255, 0.18)';
            ctx.lineWidth = 0.9;
            ctx.beginPath();
            ctx.moveTo(-w / 2 + 3, -h * 0.2);
            ctx.lineTo(w / 2 - 3, -h * 0.2);
            ctx.stroke();

            ctx.strokeStyle = 'rgba(35, 45, 18, 0.24)';
            ctx.beginPath();
            ctx.moveTo(-w / 2 + 3, h * 0.25);
            ctx.lineTo(w / 2 - 3, h * 0.25);
            ctx.stroke();

            // 2c. Beam Boundary Stroke
            ctx.strokeStyle = '#38461b';
            ctx.lineWidth = 1.2;
            ctx.stroke();

            // 2d. Horizontal Bamboo Nodes (Joint Rings)
            const nodeCount = b.nodes || Math.max(3, Math.round(w / 45));
            const nodeStep = w / nodeCount;
            for (let n = 1; n < nodeCount; n++) {
              const nx = -w / 2 + n * nodeStep;

              // Dark node constriction ring
              ctx.fillStyle = '#222d10';
              ctx.fillRect(nx - 1.2, -h / 2 - 1.2, 2.4, h + 2.4);

              // Swollen node ring collar
              const nodeCollar = ctx.createLinearGradient(0, -h / 2, 0, h / 2);
              nodeCollar.addColorStop(0, '#ddef98');
              nodeCollar.addColorStop(0.6, '#93ab4d');
              nodeCollar.addColorStop(1, '#485822');
              ctx.fillStyle = nodeCollar;
              ctx.beginPath();
              ctx.roundRect(nx - 2.2, -h / 2 - 1.6, 2.4, h + 3.2, 1.2);
              ctx.fill();

              // Transverse highlight glint
              ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
              ctx.fillRect(nx - 1.8, -h * 0.45, 1.8, h * 0.4);
            }

            // 2e. Hollow Cut Bamboo Ends (Left & Right)
            ctx.fillStyle = '#c8dd82';
            ctx.beginPath();
            ctx.ellipse(-w / 2, 0, 2.2, h * 0.45, 0, 0, Math.PI * 2);
            ctx.ellipse(w / 2, 0, 2.2, h * 0.45, 0, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = '#1c240c';
            ctx.beginPath();
            ctx.ellipse(-w / 2, 0, 1.4, h * 0.25, 0, 0, Math.PI * 2);
            ctx.ellipse(w / 2, 0, 1.4, h * 0.25, 0, 0, Math.PI * 2);
            ctx.fill();

            // 2f. Coir Rope Lashings at Connection Points along Beam
            const lashPoints = [-w * 0.35, 0, w * 0.35];
            lashPoints.forEach((lx) => {
              if (Math.abs(lx) < w / 2 - 10) {
                ctx.fillStyle = '#855224';
                ctx.fillRect(lx - 3, -h / 2 - 1.5, 6, h + 3);
                ctx.strokeStyle = '#d4a373';
                ctx.lineWidth = 1;
                for (let c = -2; c <= 2; c += 2) {
                  ctx.beginPath();
                  ctx.moveTo(lx + c, -h / 2 - 1.5);
                  ctx.lineTo(lx + c, h / 2 + 1.5);
                  ctx.stroke();
                }
              }
            });
          }
        } else if (b.type === 'wall') {
          // Woven Split-Bamboo Matting Wall (Hera / Chatai mat)
          ctx.fillStyle = '#c2a472';
          ctx.fillRect(-w / 2, -h / 2, w, h);
          ctx.strokeStyle = '#854d0e';
          ctx.lineWidth = 1.2;
          ctx.strokeRect(-w / 2, -h / 2, w, h);

          // Woven Bamboo Cross-Weave Texture
          ctx.strokeStyle = 'rgba(120, 53, 15, 0.35)';
          ctx.lineWidth = 1;
          ctx.beginPath();
          for (let l = -w / 2 + 7; l < w / 2; l += 7) {
            ctx.moveTo(l, -h / 2);
            ctx.lineTo(l, h / 2);
          }
          for (let l = -h / 2 + 7; l < h / 2; l += 7) {
            ctx.moveTo(-w / 2, l);
            ctx.lineTo(w / 2, l);
          }
          ctx.stroke();
        } else if (b.type === 'thatch') {
          // ===================================================================
          // 2. AUTHENTIC LAYERED THATCHED STRAW ROOF (Son / Straw Thatch Wedge)
          // ===================================================================
          // 2a. Rich Volumetric Straw Gradient
          const thatchGrad = ctx.createLinearGradient(0, -h / 2, 0, h / 2);
          thatchGrad.addColorStop(0.0, '#fef08a'); // Sunlit golden straw crest
          thatchGrad.addColorStop(0.18, '#f59e0b'); // Golden wheat
          thatchGrad.addColorStop(0.55, '#d97706'); // Warm toasted amber straw
          thatchGrad.addColorStop(0.85, '#92400e'); // Dense shaded straw under-tier
          thatchGrad.addColorStop(1.0, '#78350f'); // Dark eaves shadow
          ctx.fillStyle = thatchGrad;
          ctx.beginPath();
          ctx.roundRect(-w / 2, -h / 2, w, h, 3.5);
          ctx.fill();

          // 2b. Dense Angled Straw Striations (Woven Straw Fibers)
          ctx.strokeStyle = '#fef08a';
          ctx.lineWidth = 0.9;
          for (let str = -w / 2 + 4; str < w / 2 - 2; str += 6.5) {
            ctx.beginPath();
            ctx.moveTo(str, -h / 2 + 2);
            ctx.lineTo(str + 3.5, h / 2 - 1);
            ctx.stroke();
          }

          ctx.strokeStyle = '#b45309';
          ctx.lineWidth = 0.8;
          for (let str = -w / 2 + 7; str < w / 2 - 4; str += 7) {
            ctx.beginPath();
            ctx.moveTo(str, -h / 2 + 4);
            ctx.lineTo(str + 2.5, h / 2 + 1);
            ctx.stroke();
          }

          // 2c. Horizontal Bamboo Rafter Batten Strip (holding the thatch bundle)
          ctx.fillStyle = '#a3bc63'; // Green bamboo rafter batten
          ctx.fillRect(-w / 2 + 2, -h * 0.12, w - 4, 3);
          ctx.strokeStyle = '#4d5e28';
          ctx.lineWidth = 0.8;
          ctx.strokeRect(-w / 2 + 2, -h * 0.12, w - 4, 3);

          // Tied Twine Loops binding the batten strip
          ctx.strokeStyle = '#855224';
          ctx.lineWidth = 1;
          for (let t = -w / 2 + 14; t < w / 2 - 10; t += 20) {
            ctx.beginPath();
            ctx.arc(t, -h * 0.12 + 1.5, 2.5, 0, Math.PI * 2);
            ctx.stroke();
          }

          // 2d. Ragged Feathery Straw Overhang Fringe (Eaves Whisps)
          ctx.fillStyle = '#d97706';
          for (let f = -w / 2 + 2; f < w / 2 - 2; f += 5.5) {
            const fLen = 3.5 + ((Math.abs(f * 17) % 7) * 0.6);
            ctx.beginPath();
            ctx.moveTo(f, h / 2 - 1);
            ctx.lineTo(f + 2, h / 2 + fLen);
            ctx.lineTo(f + 4, h / 2 - 1);
            ctx.fill();

            // Bright highlight wisp
            if (f % 11 < 6) {
              ctx.strokeStyle = '#fef08a';
              ctx.lineWidth = 0.9;
              ctx.beginPath();
              ctx.moveTo(f + 1, h / 2);
              ctx.lineTo(f + 2, h / 2 + fLen - 0.5);
              ctx.stroke();
            }
          }

          // Thatch Perimeter Frame Stroke
          ctx.strokeStyle = '#78350f';
          ctx.lineWidth = 1.3;
          ctx.beginPath();
          ctx.roundRect(-w / 2, -h / 2, w, h, 3.5);
          ctx.stroke();
        } else if (b.type === 'pot') {
          // ===================================================================
          // 3. HANDCRAFTED TERRACOTTA CLAY POT (Matka / Handi with Rope Cradle)
          // ===================================================================
          const potR = w / 2;

          // 3a. Terracotta Curved 3D Radial Lighting
          const potGrad = ctx.createRadialGradient(-potR * 0.35, -potR * 0.35, potR * 0.1, 0, 0, potR);
          potGrad.addColorStop(0.0, '#fb923c'); // Specular clay highlight
          potGrad.addColorStop(0.35, '#ea580c'); // Vibrant terracotta orange
          potGrad.addColorStop(0.75, '#c2410c'); // Warm clay body
          potGrad.addColorStop(1.0, '#7c2d12'); // Deep shaded bottom
          ctx.fillStyle = potGrad;
          ctx.beginPath();
          ctx.arc(0, 0, potR, 0, Math.PI * 2);
          ctx.fill();

          // 3b. Outer Terracotta Stroke
          ctx.strokeStyle = '#581c0c';
          ctx.lineWidth = 1.3;
          ctx.stroke();

          // 3c. Flared Clay Mouth Collar / Neck Rim
          ctx.fillStyle = '#9a3412';
          ctx.beginPath();
          ctx.roundRect(-potR * 0.55, -h / 2 - 2, potR * 1.1, 4.5, 2);
          ctx.fill();
          ctx.strokeStyle = '#431407';
          ctx.lineWidth = 1;
          ctx.stroke();

          // Dark Inner Pot Mouth Cavity
          ctx.fillStyle = '#290c05';
          ctx.beginPath();
          ctx.ellipse(0, -h / 2, potR * 0.32, 1.4, 0, 0, Math.PI * 2);
          ctx.fill();

          // 3d. Decorative White Chalk Traditional Folk Motif Band around Belly
          ctx.strokeStyle = 'rgba(255, 255, 255, 0.45)';
          ctx.lineWidth = 1.1;
          ctx.beginPath();
          ctx.arc(0, 0, potR * 0.9, -0.3, Math.PI + 0.3);
          ctx.stroke();

          // 3e. Woven Coir Rope Sling Cradle (Hemp sling)
          ctx.strokeStyle = '#78350f';
          ctx.lineWidth = 1.1;
          // Sling cords wrapping underneath pot
          ctx.beginPath();
          ctx.moveTo(-potR * 0.8, -potR * 0.3);
          ctx.quadraticCurveTo(-potR * 0.4, potR * 0.9, 0, potR * 0.95);
          ctx.quadraticCurveTo(potR * 0.4, potR * 0.9, potR * 0.8, -potR * 0.3);
          ctx.stroke();

          // Upper Suspension Cord rising to eave
          ctx.strokeStyle = '#5a2507';
          ctx.lineWidth = 1.2;
          ctx.beginPath();
          ctx.moveTo(0, -h / 2 - 2);
          ctx.lineTo(0, -h / 2 - 8);
          ctx.stroke();
        } else if (b.type === 'lantern') {
          // ===================================================================
          // 4. BAMBOO CAGE LANTERN WITH WARM RADIANT GOLDEN CANDLELIGHT GLOW
          // ===================================================================
          // 4a. Ambient Outer Lantern Bloom Glow
          const bloom = ctx.createRadialGradient(0, 0, 4, 0, 0, w * 1.3);
          bloom.addColorStop(0, 'rgba(254, 240, 138, 0.4)');
          bloom.addColorStop(0.5, 'rgba(245, 158, 11, 0.15)');
          bloom.addColorStop(1, 'rgba(245, 158, 11, 0)');
          ctx.fillStyle = bloom;
          ctx.beginPath();
          ctx.arc(0, 0, w * 1.3, 0, Math.PI * 2);
          ctx.fill();

          // 4b. Dark Rustic Bamboo Outer Frame
          ctx.fillStyle = '#451a03';
          ctx.beginPath();
          ctx.roundRect(-w / 2, -h / 2, w, h, 4);
          ctx.fill();

          // 4c. Luminous Warm Inner Rice Paper Panel
          const paperGrad = ctx.createRadialGradient(0, 0, 2, 0, 0, w * 0.5);
          paperGrad.addColorStop(0, '#ffffff'); // Blazing white candle flame
          paperGrad.addColorStop(0.3, '#fef08a'); // Warm golden light
          paperGrad.addColorStop(0.7, '#f59e0b'); // Amber translucent paper
          paperGrad.addColorStop(1, '#d97706'); // Frame shadow
          ctx.fillStyle = paperGrad;
          ctx.beginPath();
          ctx.roundRect(-w * 0.38, -h * 0.38, w * 0.76, h * 0.76, 2.5);
          ctx.fill();

          // 4d. Delicate Bamboo Lattice Diagonal Grille
          ctx.strokeStyle = '#78350f';
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(-w * 0.38, -h * 0.38);
          ctx.lineTo(w * 0.38, h * 0.38);
          ctx.moveTo(-w * 0.38, h * 0.38);
          ctx.lineTo(w * 0.38, -h * 0.38);
          ctx.stroke();

          // 4e. Hanging Copper Ring on Top
          ctx.strokeStyle = '#b45309';
          ctx.lineWidth = 1.3;
          ctx.beginPath();
          ctx.arc(0, -h / 2 - 3, 3, 0, Math.PI * 2);
          ctx.stroke();

          // Hanging Tassel below
          ctx.strokeStyle = '#dc2626';
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.moveTo(0, h / 2);
          ctx.lineTo(0, h / 2 + 5);
          ctx.stroke();
        } else if (b.type === 'ladder') {
          // ===================================================================
          // 4B. AUTHENTIC BAMBOO LADDER (Rung Ladder leaning on hut/granary)
          // ===================================================================
          const poleW = 4;
          // Left side bamboo pole
          ctx.fillStyle = '#8ea84e';
          ctx.beginPath();
          ctx.roundRect(-w / 2, -h / 2, poleW, h, 1.5);
          ctx.fill();
          ctx.strokeStyle = '#425121';
          ctx.lineWidth = 1;
          ctx.stroke();

          // Right side bamboo pole
          ctx.fillStyle = '#8ea84e';
          ctx.beginPath();
          ctx.roundRect(w / 2 - poleW, -h / 2, poleW, h, 1.5);
          ctx.fill();
          ctx.stroke();

          // Bamboo rungs
          const rungCount = Math.max(3, Math.round(h / 20));
          const rungStep = h / rungCount;
          for (let r = 1; r < rungCount; r++) {
            const ry = -h / 2 + r * rungStep;
            ctx.fillStyle = '#b8d26c';
            ctx.fillRect(-w / 2 + poleW, ry - 2, w - poleW * 2, 4);
            ctx.strokeStyle = '#38461b';
            ctx.lineWidth = 0.8;
            ctx.strokeRect(-w / 2 + poleW, ry - 2, w - poleW * 2, 4);
            // Coir rope lashings on rung junctions
            ctx.fillStyle = '#855224';
            ctx.fillRect(-w / 2 - 1, ry - 2.5, poleW + 2, 5);
            ctx.fillRect(w / 2 - poleW - 1, ry - 2.5, poleW + 2, 5);
          }
        } else if (b.type === 'gold') {
          // ===================================================================
          // 4C. RADIANT SPARKLING GOLD BRICKS & COIN STACKS
          // ===================================================================
          // Beveled Metallic Gold Gradient
          const goldGrad = ctx.createLinearGradient(-w / 2, -h / 2, w / 2, h / 2);
          goldGrad.addColorStop(0, '#fef08a'); // Brilliant sunlit gold specular highlight
          goldGrad.addColorStop(0.25, '#fbbf24'); // Luminous bullion gold
          goldGrad.addColorStop(0.65, '#f59e0b'); // Warm rich amber gold
          goldGrad.addColorStop(1, '#b45309'); // Deep copper-gold shadow
          ctx.fillStyle = goldGrad;
          ctx.beginPath();
          ctx.roundRect(-w / 2, -h / 2, w, h, 2.5);
          ctx.fill();

          // Beveled Rim
          ctx.strokeStyle = '#d97706';
          ctx.lineWidth = 1.2;
          ctx.stroke();

          // Inner Mint Inset
          ctx.strokeStyle = 'rgba(254, 240, 138, 0.75)';
          ctx.lineWidth = 0.9;
          ctx.strokeRect(-w * 0.38, -h * 0.35, w * 0.76, h * 0.7);

          // Stamped Mint Symbol / Bullion Mark
          ctx.fillStyle = '#78350f';
          ctx.font = 'bold 8.5px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('999', 0, 0);

          // Specular Glint Cross
          ctx.strokeStyle = '#ffffff';
          ctx.lineWidth = 1.2;
          ctx.beginPath();
          ctx.moveTo(-w * 0.28, -h * 0.25);
          ctx.lineTo(-w * 0.28, -h * 0.25 + 4);
          ctx.moveTo(-w * 0.28 - 2, -h * 0.25 + 2);
          ctx.lineTo(-w * 0.28 + 2, -h * 0.25 + 2);
          ctx.stroke();
        }

        // =====================================================================
        // 5. NATURAL FIBER SPLINTERING & CRACKING UNDER DAMAGE
        // =====================================================================
        if (hpRatio < 0.75) {
          // Moderate Damage: Longitudinal Splinters along Bamboo Grain
          ctx.strokeStyle = '#1e1b18'; // Deep fracture core
          ctx.lineWidth = 1.3;
          ctx.beginPath();
          ctx.moveTo(-w * 0.22, -h * 0.35);
          ctx.lineTo(-w * 0.15, -h * 0.05);
          ctx.lineTo(-w * 0.25, h * 0.25);
          ctx.stroke();

          // Exposed Lighter Inner Bamboo Fiber Pith
          ctx.strokeStyle = '#fef9c3';
          ctx.lineWidth = 0.9;
          ctx.beginPath();
          ctx.moveTo(-w * 0.22 + 1, -h * 0.35);
          ctx.lineTo(-w * 0.15 + 1, -h * 0.05);
          ctx.lineTo(-w * 0.25 + 1, h * 0.25);
          ctx.stroke();
        }
        if (hpRatio < 0.40) {
          // Severe Damage: Secondary Major Splinter & Frayed Fibers
          ctx.strokeStyle = '#1e1b18';
          ctx.lineWidth = 1.6;
          ctx.beginPath();
          ctx.moveTo(w * 0.22, -h * 0.30);
          ctx.lineTo(w * 0.12, h * 0.08);
          ctx.lineTo(w * 0.28, h * 0.38);
          ctx.stroke();

          ctx.strokeStyle = '#fef9c3';
          ctx.lineWidth = 1.1;
          ctx.beginPath();
          ctx.moveTo(w * 0.22 - 1, -h * 0.30);
          ctx.lineTo(w * 0.12 - 1, h * 0.08);
          ctx.lineTo(w * 0.28 - 1, h * 0.38);
          ctx.stroke();
        }

        ctx.restore();
      });

      // D. Render Bowler (Professional Realistic Fast Bowler)
      const bowler = bowlerRef.current;
      ctx.save();
      ctx.translate(bowler.x, bowler.y);

      const isBowlerRunning = bowler.state === 'runup';
      const runCycle = isBowlerRunning ? bowler.progress * Math.PI * 10 : 0;
      const legStride = isBowlerRunning ? Math.sin(runCycle) * 16 : 0;
      const legLift = isBowlerRunning ? Math.max(0, -Math.cos(runCycle)) * 14 : 0;
      const bodyBob = isBowlerRunning ? Math.abs(Math.sin(runCycle)) * 4.5 : Math.sin(Date.now() / 350) * 0.8;
      const torsoLean = isBowlerRunning ? -0.15 : 0; // Athletic forward lean towards pitch

      // 1. Soft Dynamic Ground Shadow
      const bowlerShadowW = 26 + (isBowlerRunning ? Math.abs(legStride) * 0.6 : 0);
      const bowlerShadowGrad = ctx.createRadialGradient(0, 0, 2, 0, 0, bowlerShadowW);
      bowlerShadowGrad.addColorStop(0, 'rgba(15, 23, 42, 0.45)');
      bowlerShadowGrad.addColorStop(0.6, 'rgba(15, 23, 42, 0.18)');
      bowlerShadowGrad.addColorStop(1, 'rgba(15, 23, 42, 0)');
      ctx.fillStyle = bowlerShadowGrad;
      ctx.beginPath();
      ctx.ellipse(-2, 0, bowlerShadowW, 7, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.save();
      ctx.translate(0, -bodyBob);

      // 2. Realistic Legs & Cricket Bowling Spikes
      // Back Leg (Far side)
      ctx.save();
      const backLegX = 6 - legStride * 0.7;
      const backLegY = -48 + torsoLean * 6;
      ctx.translate(backLegX, backLegY);
      const backLegAngle = isBowlerRunning ? -legStride * 0.04 : 0.05;
      ctx.rotate(backLegAngle);

      // Thigh & Shin (Cream/white trousers with subtle shadow fold)
      const backLegGrad = ctx.createLinearGradient(-6, 0, 6, 0);
      backLegGrad.addColorStop(0, '#cbd5e1');
      backLegGrad.addColorStop(0.5, '#e2e8f0');
      backLegGrad.addColorStop(1, '#94a3b8');
      ctx.fillStyle = backLegGrad;
      ctx.beginPath();
      ctx.moveTo(-6, 0);
      ctx.lineTo(-4, 48 - (isBowlerRunning ? legLift * 0.5 : 0));
      ctx.lineTo(4, 48 - (isBowlerRunning ? legLift * 0.5 : 0));
      ctx.lineTo(6, 0);
      ctx.closePath();
      ctx.fill();

      // Back Shoe (Bowling Spike)
      const backShoeY = 48 - (isBowlerRunning ? legLift * 0.5 : 0);
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.roundRect(-8, backShoeY - 6, 15, 6, [3, 4, 1, 1]);
      ctx.fill();
      ctx.fillStyle = '#0284c7';
      ctx.fillRect(-9, backShoeY - 2, 16, 2.5);
      ctx.restore();

      // Front Leg (Near side)
      ctx.save();
      const frontLegX = -6 + legStride * 0.8;
      const frontLegY = -48;
      ctx.translate(frontLegX, frontLegY);
      const frontLegAngle = isBowlerRunning ? legStride * 0.04 : -0.05;
      ctx.rotate(frontLegAngle);

      // Front Thigh & Shin with crisp lighting
      const frontLegGrad = ctx.createLinearGradient(-7, 0, 7, 0);
      frontLegGrad.addColorStop(0, '#f8fafc');
      frontLegGrad.addColorStop(0.5, '#ffffff');
      frontLegGrad.addColorStop(1, '#cbd5e1');
      ctx.fillStyle = frontLegGrad;
      ctx.beginPath();
      ctx.moveTo(-7, 0);
      ctx.lineTo(-5, 48);
      ctx.lineTo(5, 48);
      ctx.lineTo(7, 0);
      ctx.closePath();
      ctx.fill();

      // Trousers side seam & knee crease
      ctx.strokeStyle = '#94a3b8';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(0, 4);
      ctx.lineTo(0, 44);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(-4, 26);
      ctx.lineTo(2, 28);
      ctx.stroke();

      // Front Cricket Bowling Shoe (High-grip spike)
      ctx.fillStyle = '#f8fafc';
      ctx.beginPath();
      ctx.roundRect(-10, 42, 17, 7, [4, 5, 2, 2]);
      ctx.fill();
      ctx.fillStyle = '#0284c7'; // Cyan trim
      ctx.fillRect(-10, 47, 17, 2);
      ctx.fillStyle = '#1e293b'; // Cleat studs
      ctx.fillRect(-8, 49, 3, 1.5);
      ctx.fillRect(1, 49, 3, 1.5);
      // Shoe laces
      ctx.strokeStyle = '#0284c7';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(-4, 43);
      ctx.lineTo(0, 45);
      ctx.stroke();
      ctx.restore();

      // 3. Realistic Athletic Torso & Jersey
      ctx.save();
      ctx.translate(0, -50);
      ctx.rotate(torsoLean);

      // Athletic Torso 3D Gradient
      const torsoGrad = ctx.createLinearGradient(-13, 0, 13, 0);
      torsoGrad.addColorStop(0, '#0369a1');   // Deep cyan shadow
      torsoGrad.addColorStop(0.4, '#0ea5e9'); // Sky blue body
      torsoGrad.addColorStop(0.8, '#38bdf8'); // Highlight
      torsoGrad.addColorStop(1, '#0284c7');   // Edge shadow
      ctx.fillStyle = torsoGrad;
      ctx.beginPath();
      ctx.roundRect(-13, -46, 26, 46, [6, 6, 2, 2]);
      ctx.fill();

      // Aerodynamic Side Panels
      ctx.fillStyle = '#0f172a';
      ctx.beginPath();
      ctx.moveTo(-13, -24);
      ctx.lineTo(-8, -4);
      ctx.lineTo(-13, -4);
      ctx.closePath();
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(13, -24);
      ctx.lineTo(8, -4);
      ctx.lineTo(13, -4);
      ctx.closePath();
      ctx.fill();

      // Athletic Neon Trim & Piping
      ctx.strokeStyle = '#a3e635';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(-12, -32);
      ctx.lineTo(-8, -4);
      ctx.moveTo(12, -32);
      ctx.lineTo(8, -4);
      ctx.stroke();

      // Jersey Collar (V-neck with crisp white edge)
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.moveTo(-6, -46);
      ctx.lineTo(0, -36);
      ctx.lineTo(6, -46);
      ctx.closePath();
      ctx.fill();

      // Team Crest on Left Chest
      ctx.fillStyle = '#fbbf24';
      ctx.beginPath();
      ctx.arc(-5, -34, 3, 0, Math.PI * 2);
      ctx.fill();

      // 4. Realistic Athletic Neck & Head
      // Neck
      const skinGrad = ctx.createLinearGradient(-4, 0, 4, 0);
      skinGrad.addColorStop(0, '#f5d0b0');
      skinGrad.addColorStop(1, '#e0b088');
      ctx.fillStyle = skinGrad;
      ctx.fillRect(-4, -54, 8, 10);

      // Head
      ctx.save();
      ctx.translate(0, -64);

      // Ears
      ctx.fillStyle = '#e0b088';
      ctx.beginPath();
      ctx.arc(6, 0, 3, 0, Math.PI * 2);
      ctx.fill();

      // Face Shape (Facing left toward batsman)
      ctx.fillStyle = skinGrad;
      ctx.beginPath();
      ctx.moveTo(-4, -10);
      ctx.quadraticCurveTo(-11, -4, -11, 2);
      ctx.lineTo(-9, 8); // Jawline
      ctx.lineTo(-2, 10); // Chin
      ctx.lineTo(6, 8);
      ctx.quadraticCurveTo(8, -2, 4, -10);
      ctx.closePath();
      ctx.fill();

      // Focused Eye (Looking left)
      ctx.fillStyle = '#1e293b';
      ctx.beginPath();
      ctx.ellipse(-7, 0, 1.8, 1.2, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(-7.4, -0.4, 0.6, 0, Math.PI * 2);
      ctx.fill();

      // Athletic Fade Haircut & Highlights
      ctx.fillStyle = '#1e293b';
      ctx.beginPath();
      ctx.moveTo(-11, -4);
      ctx.quadraticCurveTo(-12, -14, -2, -14);
      ctx.quadraticCurveTo(8, -14, 8, -2);
      ctx.lineTo(6, 2);
      ctx.lineTo(3, -4);
      ctx.lineTo(-6, -4);
      ctx.closePath();
      ctx.fill();

      // Hair texture locks
      ctx.strokeStyle = '#334155';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(-8, -12);
      ctx.lineTo(-4, -15);
      ctx.lineTo(-1, -12);
      ctx.lineTo(3, -15);
      ctx.lineTo(6, -11);
      ctx.stroke();

      // Athletic Sports Headband
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(-10, -8, 18, 3.5);
      ctx.fillStyle = '#0284c7';
      ctx.fillRect(-10, -6.5, 18, 1);

      ctx.restore(); // Head restore

      // 5. Non-bowling (Leading) Arm (Pumps for balance)
      ctx.save();
      ctx.translate(8, -40);
      const leadArmAngle = isBowlerRunning ? -legStride * 0.05 : 0.4;
      ctx.rotate(leadArmAngle);
      ctx.fillStyle = skinGrad;
      ctx.beginPath();
      ctx.roundRect(-3, 0, 6, 24, 3);
      ctx.fill();
      // Wrist sweatband
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(-3.5, 16, 7, 3);
      ctx.restore();

      // 6. Bowling Arm & Cricket Ball Delivery Action
      let armAngle = -Math.PI / 4;
      if (bowler.state === 'runup') {
        armAngle = (bowler.progress * Math.PI * 6) % (Math.PI * 2);
      }
      ctx.save();
      ctx.translate(-8, -40);
      ctx.rotate(armAngle);

      // Deltoid Shoulder Muscle & Arm Sleeve
      ctx.fillStyle = '#0369a1';
      ctx.beginPath();
      ctx.roundRect(-4.5, -4, 9, 12, 4);
      ctx.fill();

      // Arm (Bicep & Forearm)
      ctx.fillStyle = skinGrad;
      ctx.beginPath();
      ctx.roundRect(-3.5, 6, 7, 26, 3);
      ctx.fill();

      // Wristband
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(-4, 24, 8, 3.5);
      ctx.fillStyle = '#0284c7';
      ctx.fillRect(-4, 25.5, 8, 1);

      // Hand & Fingers
      ctx.fillStyle = '#e0b088';
      ctx.beginPath();
      ctx.arc(0, 34, 4, 0, Math.PI * 2);
      ctx.fill();

      // High-Fidelity Cricket Ball in Hand (Held before delivery release)
      if (bowler.state === 'runup' && bowler.progress < 0.85) {
        ctx.save();
        ctx.translate(0, 36);

        // Ball Shadow & Specular Cherry Shine
        const ballGrad = ctx.createRadialGradient(-1.5, -1.5, 1, 0, 0, 6);
        ballGrad.addColorStop(0, '#f87171');
        ballGrad.addColorStop(0.35, '#dc2626');
        ballGrad.addColorStop(0.9, '#991b1b');
        ballGrad.addColorStop(1, '#450a0a');
        ctx.fillStyle = ballGrad;
        ctx.beginPath();
        ctx.arc(0, 0, 6, 0, Math.PI * 2);
        ctx.fill();

        // Stitched White Seam
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.ellipse(0, 0, 5.5, 2.2, 0.4, 0, Math.PI * 2);
        ctx.stroke();

        ctx.restore();
      }

      ctx.restore(); // Bowling arm restore
      ctx.restore(); // Torso restore
      ctx.restore(); // Body bob restore
      ctx.restore(); // Bowler restore

      // E. Render Batsman (Professional Realistic Right-Hand Batsman)
      ctx.save();
      ctx.translate(batsman.x, batsman.y);

      // 1. Soft Dynamic Ground Shadow
      const batShadowGrad = ctx.createRadialGradient(2, 0, 4, 2, 0, 38);
      batShadowGrad.addColorStop(0, 'rgba(15, 23, 42, 0.55)');
      batShadowGrad.addColorStop(0.5, 'rgba(15, 23, 42, 0.22)');
      batShadowGrad.addColorStop(1, 'rgba(15, 23, 42, 0)');
      ctx.fillStyle = batShadowGrad;
      ctx.beginPath();
      ctx.ellipse(2, 0, 36, 8, 0, 0, Math.PI * 2);
      ctx.fill();

      // 2. Realistic Cricket Spikes (Batting Shoes)
      // Back Foot Spike (left side)
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.roundRect(-17, -6, 16, 6, [3, 4, 1, 1]);
      ctx.fill();
      ctx.fillStyle = '#dc2626'; // Red accent
      ctx.fillRect(-17, -2, 16, 2);

      // Front Foot Spike (right side, angled toward pitch)
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.roundRect(3, -6, 17, 6, [3, 4, 1, 1]);
      ctx.fill();
      ctx.fillStyle = '#dc2626';
      ctx.fillRect(3, -2, 17, 2);

      // 3. Professional Test Match Batting Pads (Legguards)
      const drawBattingPad = (padX: number, padY: number, width: number, height: number, isLeadLeg: boolean) => {
        ctx.save();
        ctx.translate(padX, padY);

        // Pad Base Contour
        const padGrad = ctx.createLinearGradient(0, 0, width, 0);
        padGrad.addColorStop(0, isLeadLeg ? '#ffffff' : '#f1f5f9');
        padGrad.addColorStop(0.5, isLeadLeg ? '#f8fafc' : '#e2e8f0');
        padGrad.addColorStop(1, isLeadLeg ? '#cbd5e1' : '#94a3b8');
        ctx.fillStyle = padGrad;
        ctx.beginPath();
        ctx.roundRect(0, 0, width, height, [6, 6, 3, 3]);
        ctx.fill();

        // Vertical Cane Rods with Embossed Highlights
        const numCanes = 5;
        const caneW = width / numCanes;
        for (let c = 0; c < numCanes; c++) {
          const cx = c * caneW;
          // Cane highlight
          ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
          ctx.fillRect(cx + caneW * 0.25, 4, caneW * 0.5, height - 8);
          // Cane seam grooves
          ctx.strokeStyle = 'rgba(100, 116, 139, 0.4)';
          ctx.lineWidth = 0.8;
          ctx.strokeRect(cx, 4, caneW, height - 8);
        }

        // Sculpted Knee Roll (Horizontal Bolster Cushion)
        const kneeY = height * 0.35;
        const kneeGrad = ctx.createLinearGradient(0, kneeY - 5, 0, kneeY + 5);
        kneeGrad.addColorStop(0, 'rgba(148, 163, 184, 0.5)');
        kneeGrad.addColorStop(0.5, 'rgba(255, 255, 255, 0.9)');
        kneeGrad.addColorStop(1, 'rgba(148, 163, 184, 0.5)');
        ctx.fillStyle = kneeGrad;
        ctx.beginPath();
        ctx.roundRect(-1, kneeY - 5, width + 2, 10, 3);
        ctx.fill();

        // Top Hat (Padded wing above knee)
        ctx.strokeStyle = '#94a3b8';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(2, kneeY - 8);
        ctx.lineTo(width - 2, kneeY - 8);
        ctx.stroke();

        // Fastening Straps & Buckles
        const strapYs = [height * 0.15, height * 0.6, height * 0.85];
        strapYs.forEach((sy) => {
          ctx.fillStyle = '#334155';
          ctx.fillRect(-1.5, sy - 1.5, width + 3, 3);
          ctx.fillStyle = '#ffffff'; // Buckle
          ctx.fillRect(width * 0.6, sy - 2.5, 3, 5);
        });

        // Crisp Outer Seam Piping
        ctx.strokeStyle = '#64748b';
        ctx.lineWidth = 1.2;
        ctx.strokeRect(0, 0, width, height);

        ctx.restore();
      };

      // Back Pad (left)
      drawBattingPad(-15, -60, 14, 56, false);
      // Front Pad (right)
      drawBattingPad(3, -60, 14, 56, true);

      // 4. Realistic Athletic Jersey & Torso
      ctx.save();
      ctx.translate(0, -60);

      // Jersey Waist Tuck & Shadow
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(-14, -4, 28, 4);

      // Pro Jersey (Canary Yellow / Amber with Forest Green Panels)
      const jerseyGrad = ctx.createLinearGradient(-15, 0, 15, 0);
      jerseyGrad.addColorStop(0, '#d97706'); // Deep amber shadow
      jerseyGrad.addColorStop(0.3, '#f59e0b');
      jerseyGrad.addColorStop(0.7, '#fbbf24'); // Sunlit center
      jerseyGrad.addColorStop(1, '#b45309');
      ctx.fillStyle = jerseyGrad;
      ctx.beginPath();
      ctx.roundRect(-15, -46, 30, 44, [6, 6, 2, 2]);
      ctx.fill();

      // Forest Green Athletic Raglan Panels
      ctx.fillStyle = '#15803d';
      ctx.beginPath();
      ctx.moveTo(-15, -46);
      ctx.lineTo(-7, -46);
      ctx.lineTo(-12, -26);
      ctx.lineTo(-15, -26);
      ctx.closePath();
      ctx.fill();

      ctx.beginPath();
      ctx.moveTo(15, -46);
      ctx.lineTo(7, -46);
      ctx.lineTo(12, -26);
      ctx.lineTo(15, -26);
      ctx.closePath();
      ctx.fill();

      // Jersey V-Neck Collar
      ctx.fillStyle = '#15803d';
      ctx.beginPath();
      ctx.moveTo(-7, -46);
      ctx.lineTo(0, -36);
      ctx.lineTo(7, -46);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(-1, -44, 2, 6);

      // Pro Jersey Number '7' with Shadow
      ctx.fillStyle = '#064e3b';
      ctx.font = 'bold 13px sans-serif';
      ctx.fillText('7', -3.5, -21);
      ctx.fillStyle = '#ffffff';
      ctx.fillText('7', -4.5, -22);

      // Forearm Arm-Guard on lead arm
      ctx.fillStyle = '#f8fafc';
      ctx.beginPath();
      ctx.roundRect(8, -32, 6, 14, 2);
      ctx.fill();
      ctx.strokeStyle = '#94a3b8';
      ctx.lineWidth = 1;
      ctx.stroke();

      ctx.restore(); // Torso restore

      // 5. Professional Cricket Helmet & Head
      ctx.save();
      ctx.translate(0, -114);

      // Neck
      const batSkinGrad = ctx.createLinearGradient(-4, 0, 4, 0);
      batSkinGrad.addColorStop(0, '#f5d0b0');
      batSkinGrad.addColorStop(1, '#e0b088');
      ctx.fillStyle = batSkinGrad;
      ctx.fillRect(-4, -6, 8, 10);

      // Athletic Focused Face (Eyes looking right towards incoming bowler/ball)
      ctx.fillStyle = batSkinGrad;
      ctx.beginPath();
      ctx.ellipse(1, -7, 10, 11, 0, 0, Math.PI * 2);
      ctx.fill();

      // Focused Eye
      ctx.fillStyle = '#0f172a';
      ctx.beginPath();
      ctx.ellipse(6, -8, 1.8, 1.2, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(6.5, -8.5, 0.5, 0, Math.PI * 2);
      ctx.fill();

      // Deep Navy / Carbon Helmet Shell
      const helmetGrad = ctx.createLinearGradient(-13, -22, 13, 0);
      helmetGrad.addColorStop(0, '#1e3a8a');
      helmetGrad.addColorStop(0.4, '#172554');
      helmetGrad.addColorStop(0.8, '#0f172a');
      helmetGrad.addColorStop(1, '#1e293b');
      ctx.fillStyle = helmetGrad;
      ctx.beginPath();
      ctx.arc(0, -9, 13, Math.PI * 0.85, Math.PI * 2.15);
      ctx.fill();

      // Helmet High-Gloss Specular Highlight Arc
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.55)';
      ctx.lineWidth = 1.8;
      ctx.beginPath();
      ctx.arc(0, -10, 11, Math.PI * 1.15, Math.PI * 1.7);
      ctx.stroke();

      // Helmet Peak / Visor (Extends forward over brow)
      ctx.fillStyle = '#0f172a';
      ctx.beginPath();
      ctx.moveTo(2, -10);
      ctx.lineTo(16, -10);
      ctx.lineTo(14, -6);
      ctx.lineTo(3, -6);
      ctx.closePath();
      ctx.fill();

      // Titanium Metallic Face Grill
      ctx.strokeStyle = '#cbd5e1';
      ctx.lineWidth = 1.6;
      // Main Visor Grill Bar
      ctx.beginPath();
      ctx.moveTo(4, -7);
      ctx.lineTo(15, -7);
      ctx.stroke();
      // Mouth / Jaw Bar
      ctx.beginPath();
      ctx.moveTo(2, -2);
      ctx.lineTo(14, -2);
      ctx.stroke();
      // Chin Bar
      ctx.beginPath();
      ctx.moveTo(1, 3);
      ctx.lineTo(12, 3);
      ctx.stroke();
      // Vertical Connectors
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(7, -7);
      ctx.lineTo(6, 4);
      ctx.moveTo(12, -7);
      ctx.lineTo(11, 4);
      ctx.stroke();

      // Padded Chin Cup & Strap
      ctx.fillStyle = '#334155';
      ctx.beginPath();
      ctx.roundRect(4, 3, 6, 3.5, 1.5);
      ctx.fill();

      // Ear Guard Vent Cover
      ctx.fillStyle = '#1e293b';
      ctx.beginPath();
      ctx.arc(-4, -6, 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(-5, -7, 2, 2);

      ctx.restore(); // Head restore

      // 6. Batting Arms, Pro Batting Gloves & English Willow Bat
      let batAngle = 0.35;
      const shoulderX = 6;
      const shoulderY = -96;

      if (batsman.stance === 'backlift') {
        batAngle = 1.05;
      } else if (batsman.stance === 'swinging') {
        const prog = batsman.swingProgress;
        batAngle = 1.05 - prog * 2.5;
      } else if (batsman.stance === 'followThrough') {
        batAngle = -1.55;
      }

      ctx.save();
      ctx.translate(shoulderX, shoulderY);
      ctx.rotate(batAngle);

      // Lead Arm Bicep / Sleeve
      ctx.fillStyle = '#f59e0b';
      ctx.beginPath();
      ctx.roundRect(-4.5, 0, 9, 20, 3);
      ctx.fill();

      // Top Hand Batting Glove (White leather with sausage padding)
      ctx.fillStyle = '#f8fafc';
      ctx.beginPath();
      ctx.arc(0, 22, 6.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#15803d'; // Green padded finger segments
      ctx.fillRect(-3, 19, 6, 3);
      ctx.fillRect(-3, 23, 6, 2.5);

      // Cane Handle (Between top and bottom hands)
      ctx.fillStyle = '#ffffff'; // Rubber grip
      ctx.fillRect(-2.5, 20, 5, 20);
      // Spiral texture on grip
      ctx.strokeStyle = '#dc2626';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(-2.5, 24);
      ctx.lineTo(2.5, 26);
      ctx.moveTo(-2.5, 30);
      ctx.lineTo(2.5, 32);
      ctx.stroke();

      // Bottom Hand Batting Glove
      ctx.fillStyle = '#f8fafc';
      ctx.beginPath();
      ctx.arc(0, 33, 6.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#15803d';
      ctx.fillRect(-3, 30, 6, 3);
      ctx.fillRect(-3, 34, 6, 2.5);

      // Pro English Willow Cricket Bat Blade
      const batLength = 58;
      const batBladeWidth = 12.5;

      ctx.save();
      ctx.translate(0, 38);

      // Natural English Willow Wood Gradient
      const willowGrad = ctx.createLinearGradient(-batBladeWidth / 2, 0, batBladeWidth / 2, 0);
      willowGrad.addColorStop(0, '#e5c99e'); // Natural edge
      willowGrad.addColorStop(0.35, '#f7e3bf'); // Center face
      willowGrad.addColorStop(0.75, '#ebce9e');
      willowGrad.addColorStop(1, '#c9a872'); // Spine shadow
      ctx.fillStyle = willowGrad;
      ctx.beginPath();
      ctx.roundRect(-batBladeWidth / 2, 0, batBladeWidth, batLength, [2, 2, 4, 4]);
      ctx.fill();

      // Subtle Willow Wood Grain Lines
      ctx.strokeStyle = 'rgba(161, 98, 7, 0.22)';
      ctx.lineWidth = 0.8;
      [-3, -0.5, 2, 4.5].forEach((gx) => {
        ctx.beginPath();
        ctx.moveTo(gx, 2);
        ctx.lineTo(gx, batLength - 4);
        ctx.stroke();
      });

      // Upper Blade Metallic Branded Sticker
      const stickerGrad = ctx.createLinearGradient(0, 4, 0, 18);
      stickerGrad.addColorStop(0, '#dc2626');
      stickerGrad.addColorStop(0.5, '#2563eb');
      stickerGrad.addColorStop(1, '#1e40af');
      ctx.fillStyle = stickerGrad;
      ctx.beginPath();
      ctx.roundRect(-batBladeWidth / 2 + 1, 4, batBladeWidth - 2, 14, 2);
      ctx.fill();

      // Gold Foil Trim on Sticker
      ctx.fillStyle = '#fbbf24';
      ctx.fillRect(-batBladeWidth / 2 + 2, 10, batBladeWidth - 4, 2);

      // Lower Sweet-Spot Badge
      ctx.fillStyle = '#dc2626';
      ctx.beginPath();
      ctx.ellipse(0, 32, batBladeWidth * 0.35, 5, 0, 0, Math.PI * 2);
      ctx.fill();

      // Protective Durable Black Rubber Toe Guard
      ctx.fillStyle = '#1e293b';
      ctx.beginPath();
      ctx.roundRect(-batBladeWidth / 2, batLength - 5, batBladeWidth, 5, [0, 0, 3, 3]);
      ctx.fill();

      // Outer Edge Bevel
      ctx.strokeStyle = '#92400e';
      ctx.lineWidth = 1;
      ctx.strokeRect(-batBladeWidth / 2, 0, batBladeWidth, batLength);

      ctx.restore(); // Bat restore
      ctx.restore(); // Shoulder restore
      ctx.restore(); // Batsman restore

      // F. Render Cricket Ball (Keep settled ball visible on field until next delivery starts)
      if (ball && (ballActiveRef.current || bowlerRef.current.state === 'idle')) {
        // Distinct Ball Trail
        ball.trail.forEach((t, i) => {
          ctx.beginPath();
          ctx.arc(t.x, t.y, ball.radius * (0.3 + (i / ball.trail.length) * 0.7), 0, Math.PI * 2);
          if (ball.ballType === 'BOMB') {
            ctx.fillStyle = `rgba(120, 113, 108, ${t.alpha * 0.5})`;
          } else if (ball.ballType === 'FIRE' || ball.isSuperShot) {
            ctx.fillStyle = `rgba(249, 115, 22, ${t.alpha * 0.75})`;
          } else if (ball.ballType === 'ACID') {
            ctx.fillStyle = `rgba(132, 204, 22, ${t.alpha * 0.65})`;
          } else {
            ctx.fillStyle = `rgba(239, 68, 68, ${t.alpha * 0.4})`;
          }
          ctx.fill();
        });

        ctx.save();
        ctx.translate(ball.x, ball.y);
        ctx.rotate(ball.rotation);

        if (ball.ballType === 'BOMB') {
          // ==================== BOMB BALL ====================
          // Heavy Cast-Iron Spherical Shell with Multi-layered Radial Metallic Lighting
          const bombGrad = ctx.createRadialGradient(-ball.radius * 0.35, -ball.radius * 0.35, 1, 0, 0, ball.radius);
          bombGrad.addColorStop(0, '#52525b');
          bombGrad.addColorStop(0.3, '#3f3f46');
          bombGrad.addColorStop(0.7, '#18181b');
          bombGrad.addColorStop(1, '#09090b');
          ctx.fillStyle = bombGrad;
          ctx.beginPath();
          ctx.arc(0, 0, ball.radius, 0, Math.PI * 2);
          ctx.fill();

          // Metallic Rim Outline
          ctx.strokeStyle = '#27272a';
          ctx.lineWidth = 1.2;
          ctx.stroke();

          // Specular Highlight on Iron Curvature
          ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
          ctx.beginPath();
          ctx.arc(-ball.radius * 0.32, -ball.radius * 0.32, ball.radius * 0.25, 0, Math.PI * 2);
          ctx.fill();

          // Turned Brass Fuse Neck Collar
          ctx.fillStyle = '#b45309';
          ctx.fillRect(-2.5, -ball.radius - 2.5, 5, 3.5);
          ctx.fillStyle = '#fbbf24';
          ctx.fillRect(-2, -ball.radius - 2, 4, 1.2);

          // Burning Sparking Braided Fuse
          const fuseTipY = -ball.radius - 7.5;
          ctx.strokeStyle = '#78350f';
          ctx.lineWidth = 1.8;
          ctx.beginPath();
          ctx.moveTo(0, -ball.radius - 2);
          ctx.quadraticCurveTo(3.5, -ball.radius - 5, 1.2, fuseTipY);
          ctx.stroke();

          // Sizzling Golden-White Fuse Spark Core
          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.arc(1.2, fuseTipY, 1.8, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#fef08a';
          ctx.beginPath();
          ctx.arc(1.2, fuseTipY, 3.2, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#f59e0b';
          ctx.beginPath();
          ctx.arc(1.2, fuseTipY, 5, 0, Math.PI * 2);
          ctx.fill();

          // Dynamic Flying Spark Particles from Burning Fuse
          const sparkTime = Date.now() / 45;
          for (let s = 0; s < 5; s++) {
            const sAngle = sparkTime + (s * Math.PI * 2) / 5;
            const sDist = 3 + (Math.sin(sparkTime * 2 + s) + 1) * 2.5;
            ctx.fillStyle = s % 2 === 0 ? '#fef08a' : '#f97316';
            ctx.beginPath();
            ctx.arc(1.2 + Math.cos(sAngle) * sDist, fuseTipY + Math.sin(sAngle) * sDist, 1.2, 0, Math.PI * 2);
            ctx.fill();
          }

        } else if (ball.ballType === 'FIRE') {
          // ==================== FIRE BALL ====================
          // Swirling Outer Fiery Corona
          const flameAura = ctx.createRadialGradient(0, 0, 2, 0, 0, ball.radius * 2.4);
          flameAura.addColorStop(0, 'rgba(254, 240, 138, 0.95)');
          flameAura.addColorStop(0.35, 'rgba(249, 115, 22, 0.85)');
          flameAura.addColorStop(0.75, 'rgba(220, 38, 38, 0.45)');
          flameAura.addColorStop(1, 'rgba(220, 38, 38, 0)');
          ctx.fillStyle = flameAura;
          ctx.beginPath();
          ctx.arc(0, 0, ball.radius * 2.4, 0, Math.PI * 2);
          ctx.fill();

          // Blazing Molten Inner Sphere
          const fireCore = ctx.createRadialGradient(-2, -2, 1, 0, 0, ball.radius);
          fireCore.addColorStop(0, '#ffffff');
          fireCore.addColorStop(0.25, '#fef08a');
          fireCore.addColorStop(0.65, '#ea580c');
          fireCore.addColorStop(1, '#991b1b');
          ctx.fillStyle = fireCore;
          ctx.beginPath();
          ctx.arc(0, 0, ball.radius, 0, Math.PI * 2);
          ctx.fill();

          // Animated Dancing Flame Tongue Wisps
          const time = Date.now() / 60;
          for (let f = 0; f < 6; f++) {
            const fAngle = (f * Math.PI) / 3 + Math.sin(time + f * 1.5) * 0.4;
            const fLen = ball.radius * (1.3 + Math.sin(time * 2 + f) * 0.3);
            ctx.strokeStyle = f % 2 === 0 ? '#fef08a' : '#f97316';
            ctx.lineWidth = 1.8;
            ctx.beginPath();
            ctx.moveTo(Math.cos(fAngle) * ball.radius * 0.7, Math.sin(fAngle) * ball.radius * 0.7);
            ctx.lineTo(Math.cos(fAngle) * fLen, Math.sin(fAngle) * fLen);
            ctx.stroke();
          }

        } else if (ball.ballType === 'ACID') {
          // ==================== ACID BALL ====================
          // Outer Toxic Chemical Glow
          const acidAura = ctx.createRadialGradient(0, 0, 2, 0, 0, ball.radius * 2.1);
          acidAura.addColorStop(0, 'rgba(190, 242, 100, 0.95)');
          acidAura.addColorStop(0.4, 'rgba(132, 204, 22, 0.7)');
          acidAura.addColorStop(0.8, 'rgba(16, 185, 129, 0.35)');
          acidAura.addColorStop(1, 'rgba(16, 185, 129, 0)');
          ctx.fillStyle = acidAura;
          ctx.beginPath();
          ctx.arc(0, 0, ball.radius * 2.1, 0, Math.PI * 2);
          ctx.fill();

          // Bubbling Toxic Acid Orb Core
          const acidCore = ctx.createRadialGradient(-2, -2, 1, 0, 0, ball.radius);
          acidCore.addColorStop(0, '#ecfccb');
          acidCore.addColorStop(0.35, '#a3e635');
          acidCore.addColorStop(0.75, '#65a30d');
          acidCore.addColorStop(1, '#14532d');
          ctx.fillStyle = acidCore;
          ctx.beginPath();
          ctx.arc(0, 0, ball.radius, 0, Math.PI * 2);
          ctx.fill();

          // Animated Corrosive Bubbles on Surface
          const acidTime = Date.now() / 90;
          const bubbleOffsets = [
            { x: -3, y: -2, r: 2.2 },
            { x: 3, y: -3, r: 1.8 },
            { x: 1, y: 3, r: 2.0 },
            { x: -2, y: 2.5, r: 1.5 },
          ];
          bubbleOffsets.forEach((bOff, bi) => {
            const bRad = bOff.r + Math.sin(acidTime + bi) * 0.4;
            ctx.fillStyle = '#bef264';
            ctx.beginPath();
            ctx.arc(bOff.x, bOff.y, bRad, 0, Math.PI * 2);
            ctx.fill();
            // Tiny bubble highlight
            ctx.fillStyle = '#ffffff';
            ctx.beginPath();
            ctx.arc(bOff.x - 0.6, bOff.y - 0.6, 0.6, 0, Math.PI * 2);
            ctx.fill();
          });

          // Sizzling Chemical Foam Specular Highlight
          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.arc(-2.5, -2.5, 1.4, 0, Math.PI * 2);
          ctx.fill();

        } else {
          // ==================== STANDARD BALL ====================
          // Super Shot Aura if activated
          if (ball.isSuperShot) {
            ctx.beginPath();
            ctx.arc(0, 0, ball.radius * 2.2, 0, Math.PI * 2);
            const fireGrad = ctx.createRadialGradient(0, 0, 2, 0, 0, ball.radius * 2.2);
            fireGrad.addColorStop(0, 'rgba(254, 240, 138, 0.9)');
            fireGrad.addColorStop(0.5, 'rgba(249, 115, 22, 0.8)');
            fireGrad.addColorStop(1, 'rgba(239, 68, 68, 0)');
            ctx.fillStyle = fireGrad;
            ctx.fill();
          }

          // Authentic Red Leather Cricket Ball
          const leatherGrad = ctx.createRadialGradient(-ball.radius * 0.3, -ball.radius * 0.3, 1, 0, 0, ball.radius);
          leatherGrad.addColorStop(0, '#ef4444');
          leatherGrad.addColorStop(0.6, '#dc2626');
          leatherGrad.addColorStop(1, '#991b1b');
          ctx.fillStyle = leatherGrad;
          ctx.beginPath();
          ctx.arc(0, 0, ball.radius, 0, Math.PI * 2);
          ctx.fill();

          // White Raised Stitched Seam
          ctx.strokeStyle = '#f8fafc';
          ctx.lineWidth = 1.6;
          ctx.beginPath();
          ctx.arc(0, 0, ball.radius, -Math.PI / 3, Math.PI / 3);
          ctx.stroke();

          // Specular Leather Sheen Dot
          ctx.fillStyle = 'rgba(255, 255, 255, 0.65)';
          ctx.beginPath();
          ctx.arc(-2, -2, 2.2, 0, Math.PI * 2);
          ctx.fill();
        }

        ctx.restore();
      }

      // G. Render Splinters & Dust Particles
      particlesRef.current.forEach((p) => {
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.angle);
        ctx.fillStyle = p.color;

        const alpha = Math.max(0, 1 - p.life / p.maxLife);
        ctx.globalAlpha = alpha;

        if (p.type === 'wood') {
          ctx.fillRect(-p.size, -p.size / 3, p.size * 2, p.size / 1.5);
        } else if (p.type === 'thatch') {
          ctx.fillRect(-p.size, -1, p.size * 2, 2);
        } else if (p.type === 'fire') {
          ctx.beginPath();
          ctx.arc(0, 0, p.size, 0, Math.PI * 2);
          ctx.fill();
        } else if (p.type === 'acid') {
          ctx.beginPath();
          ctx.arc(0, 0, p.size, 0, Math.PI * 2);
          ctx.fill();
        } else if (p.type === 'explosion') {
          ctx.beginPath();
          ctx.arc(0, 0, p.size, 0, Math.PI * 2);
          ctx.fill();
        } else {
          ctx.beginPath();
          ctx.arc(0, 0, p.size, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
      });

      // H. Render Floating Score & Damage Numbers
      floatingTextsRef.current.forEach((ft) => {
        ctx.save();
        const alpha = Math.max(0, 1 - ft.life / ft.maxLife);
        ctx.globalAlpha = alpha;
        ctx.font = `bold ${ft.size}px sans-serif`;
        ctx.fillStyle = ft.color;
        ctx.shadowColor = 'rgba(0,0,0,0.8)';
        ctx.shadowBlur = 6;
        ctx.fillText(ft.text, ft.x, ft.y);
        ctx.restore();
      });

      ctx.restore(); // Restore world transform

      // =========================================================================
      // I. SCREEN OVERLAY LAYER (Screen space: Flying Coins & Golden HUD Bursts)
      // =========================================================================
      // 1. Screen sparkles (trails and HUD arrival bursts)
      screenSparklesRef.current.forEach((sp) => {
        ctx.save();
        ctx.globalAlpha = Math.max(0, sp.alpha);
        ctx.fillStyle = sp.color;
        ctx.shadowColor = '#fbbf24';
        ctx.shadowBlur = 6;
        ctx.beginPath();
        ctx.arc(sp.x, sp.y, sp.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });

      // 2. Flying 3D Gold Coins
      flyingCoinsRef.current.forEach((coin) => {
        if (coin.delay > 0) {
          // Render gleaming coin on ground before takeoff
          ctx.save();
          ctx.translate(coin.startX, coin.startY);
          ctx.shadowColor = '#f59e0b';
          ctx.shadowBlur = 8;
          ctx.fillStyle = '#fbbf24';
          ctx.beginPath();
          ctx.arc(0, 0, coin.size * 0.8, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
          return;
        }

        ctx.save();
        ctx.translate(coin.currentX, coin.currentY);

        // 3D spinning coin effect: scale X by cosine of rotation
        const cosRot = Math.cos(coin.rotation);
        const scaleX = Math.max(0.12, Math.abs(cosRot)) * (cosRot < 0 ? -1 : 1);
        ctx.scale(scaleX, 1);

        // Brilliant golden outer glow
        ctx.shadowColor = '#f59e0b';
        ctx.shadowBlur = 10;

        // Outer coin disk with rim gradient
        const rimGrad = ctx.createLinearGradient(-coin.size, -coin.size, coin.size, coin.size);
        rimGrad.addColorStop(0, '#fef08a');   // Bright sun highlight
        rimGrad.addColorStop(0.25, '#fbbf24'); // Pure bullion gold
        rimGrad.addColorStop(0.75, '#f59e0b'); // Rich amber gold
        rimGrad.addColorStop(1, '#92400e');   // Deep bronze rim shadow
        ctx.fillStyle = rimGrad;
        ctx.beginPath();
        ctx.arc(0, 0, coin.size, 0, Math.PI * 2);
        ctx.fill();

        // Inner coin face (slightly recessed)
        const innerGrad = ctx.createRadialGradient(-coin.size * 0.3, -coin.size * 0.3, 1, 0, 0, coin.size * 0.8);
        innerGrad.addColorStop(0, '#fef9c3');
        innerGrad.addColorStop(0.5, '#fbbf24');
        innerGrad.addColorStop(1, '#d97706');
        ctx.fillStyle = innerGrad;
        ctx.beginPath();
        ctx.arc(0, 0, coin.size * 0.78, 0, Math.PI * 2);
        ctx.fill();

        // Embossed inner border ring
        ctx.strokeStyle = '#fef08a';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(0, 0, coin.size * 0.65, 0, Math.PI * 2);
        ctx.stroke();

        // Center coin star emblem
        ctx.fillStyle = '#92400e';
        ctx.font = `bold ${Math.round(coin.size * 0.9)}px sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('★', 0, 0.5);

        ctx.restore();
      });

      ctx.restore(); // Restore root canvas transform
    };

    animId = requestAnimationFrame(gameLoop);
    return () => cancelAnimationFrame(animId);
  }, [level, isPaused]);

  const BALL_SELECTOR_ITEMS: { id: SpecialBallType; name: string; icon: React.ReactNode; colorGrad: string }[] = [
    {
      id: 'STANDARD',
      name: 'Standard',
      icon: <CircleDot className="w-5 h-5 text-red-400" />,
      colorGrad: 'from-red-600 to-rose-950',
    },
    {
      id: 'BOMB',
      name: 'Bomb',
      icon: <Bomb className="w-5 h-5 text-amber-400" />,
      colorGrad: 'from-zinc-700 to-black',
    },
    {
      id: 'FIRE',
      name: 'Fireball',
      icon: <Flame className="w-5 h-5 text-orange-400" />,
      colorGrad: 'from-amber-500 to-red-700',
    },
    {
      id: 'ACID',
      name: 'Acid',
      icon: <FlaskConical className="w-5 h-5 text-emerald-400" />,
      colorGrad: 'from-lime-500 to-emerald-900',
    },
  ];

  return (
    <div className="absolute inset-0 w-full h-full overflow-hidden select-none bg-slate-950">
      <canvas
        ref={canvasRef}
        width={viewport.width}
        height={viewport.height}
        className="absolute inset-0 w-full h-full cursor-crosshair touch-none"
      />

      {/* In-Game Left Side Ball Selector (Visible ONLY during active gameplay after pressing Play) */}
      {!isPaused && (
        <div className="absolute left-2.5 sm:left-4 top-1/2 -translate-y-1/2 z-30 select-none touch-manipulation pointer-events-auto">
        <div className="flex items-center gap-2 max-w-[70vw] sm:max-w-xs overflow-x-auto touch-pan-x scrollbar-none py-1">
          {BALL_SELECTOR_ITEMS.map((item) => {
            const count = item.id === 'STANDARD' ? (ballInventory['STANDARD'] ?? ballsLeft) : (ballInventory[item.id] || 0);
            const hasStock = count > 0;
            const isSelected = selectedBallType === item.id;

            return (
              <button
                key={item.id}
                onClick={() => {
                  soundManager.playButtonClick();
                  if (hasStock) {
                    onSelectBallType(item.id);
                  } else if (onOpenShop) {
                    onOpenShop();
                  }
                }}
                title={item.name}
                className={`relative shrink-0 w-8.5 h-8.5 sm:w-9.5 sm:h-9.5 rounded-full flex items-center justify-center transition-all cursor-pointer border ${
                  isSelected
                    ? 'border-amber-300 ring-2 ring-amber-400 scale-110 opacity-100 shadow-md shadow-amber-500/50'
                    : hasStock
                    ? 'border-white/40 opacity-70 hover:opacity-100 scale-95'
                    : 'border-white/15 opacity-55 hover:opacity-90 scale-95'
                }`}
              >
                {/* Spherical Gradient Inner Circle */}
                <div
                  className={`w-full h-full rounded-full bg-gradient-to-br ${item.colorGrad} flex items-center justify-center p-1 relative overflow-hidden shadow-inner`}
                >
                  {/* Subtle 3D Sphere Specular Sheen */}
                  <div className="absolute top-0.5 left-1 w-2.5 h-1.5 rounded-full bg-white/40 blur-[0.5px] pointer-events-none" />

                  {item.id === 'STANDARD' && (
                    <CircleDot className="w-4 h-4 text-white" />
                  )}
                  {item.id === 'BOMB' && (
                    <Bomb className="w-4 h-4 text-amber-300" />
                  )}
                  {item.id === 'FIRE' && (
                    <Flame className="w-4 h-4 text-amber-200 animate-pulse" />
                  )}
                  {item.id === 'ACID' && (
                    <FlaskConical className="w-4 h-4 text-lime-200 animate-pulse" />
                  )}

                  {!hasStock && (
                    <div className="absolute inset-0 bg-slate-900/65 rounded-full flex items-center justify-center">
                      <Lock className="w-3 h-3 text-white/90" />
                    </div>
                  )}
                </div>

                {/* Remaining Stock Badge */}
                <div
                  className={`absolute -bottom-1 -right-1 min-w-[15px] h-[15px] px-0.5 rounded-full text-[9px] font-black flex items-center justify-center border shadow-xs ${
                    hasStock
                      ? 'bg-amber-400 text-slate-950 border-amber-300'
                      : 'bg-slate-800 text-slate-400 border-slate-600'
                  }`}
                >
                  {count}
                </div>

                {/* Selected Indicator Dot */}
                {isSelected && (
                  <div className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-amber-400 border border-black shadow-xs" />
                )}
              </button>
            );
          })}

          {/* Quick Shop Button to Buy Special Balls with Level Coins */}
          {onOpenShop && (
            <JewelButton
              size="sm"
              variant="orb"
              color="sunset"
              onClick={() => {
                soundManager.playButtonClick();
                onOpenShop();
              }}
              title="Shop"
            >
              <BambooBasketIcon className="w-5 h-5" />
            </JewelButton>
          )}
        </div>
      </div>
      )}
    </div>
  );
};
