import React from 'react';
import { Play } from 'lucide-react';

interface GrandBambooPlayButtonProps {
  onPlay: () => void;
  className?: string;
}

export const GrandBambooPlayButton: React.FC<GrandBambooPlayButtonProps> = ({
  onPlay,
  className = '',
}) => {
  const uid = React.useId().replace(/:/g, '_');
  const bambooGradId = `grandBambooGrad_${uid}`;
  const endCapGradId = `grandEndCapGrad_${uid}`;
  const ropeGradId = `grandRopeGrad_${uid}`;
  const ropeShadowId = `grandRopeShadow_${uid}`;

  return (
    <div className={`relative flex items-center justify-center my-auto ${className}`}>
      {/* Ambient Backlight Glow */}
      <div className="absolute w-80 h-32 rounded-full bg-emerald-500/20 blur-3xl pointer-events-none" />

      <button
        onClick={onPlay}
        onTouchStart={(e) => {
          e.preventDefault();
          onPlay();
        }}
        className="group relative flex items-center justify-center p-2 transition-all duration-200 hover:scale-105 active:scale-95 cursor-pointer outline-none select-none touch-manipulation"
        title="Play"
      >
        {/* GRAND BAMBOO STALK CONTAINER */}
        <div className="relative w-[280px] sm:w-[340px] md:w-[380px] h-[90px] sm:h-[105px] flex items-center justify-center">
          {/* Bamboo SVG Frame with 3D cylindrical lighting and coiled jute rope ends */}
          <svg
            className="absolute inset-0 w-full h-full pointer-events-none drop-shadow-2xl overflow-visible"
            preserveAspectRatio="none"
            viewBox="0 0 380 105"
          >
            <defs>
              {/* Grand Bamboo Stalk Gradient */}
              <linearGradient id={bambooGradId} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#365314" />
                <stop offset="12%" stopColor="#4d7c0f" />
                <stop offset="28%" stopColor="#84cc16" />
                <stop offset="45%" stopColor="#bef264" />
                <stop offset="68%" stopColor="#65a30d" />
                <stop offset="90%" stopColor="#365314" />
                <stop offset="100%" stopColor="#1a2e05" />
              </linearGradient>

              {/* End Cap Gradient */}
              <linearGradient id={endCapGradId} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#365314" />
                <stop offset="50%" stopColor="#65a30d" />
                <stop offset="100%" stopColor="#1a2e05" />
              </linearGradient>

              {/* Coiled Jute Rope Fiber Gradient */}
              <linearGradient id={ropeGradId} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#d97706" />
                <stop offset="30%" stopColor="#fef08a" />
                <stop offset="65%" stopColor="#b45309" />
                <stop offset="100%" stopColor="#78350f" />
              </linearGradient>

              {/* Rope Drop Shadow */}
              <filter id={ropeShadowId} x="-20%" y="-20%" width="140%" height="140%">
                <feDropShadow dx="0" dy="2" stdDeviation="2" floodColor="#000" floodOpacity="0.5" />
              </filter>
            </defs>

            {/* --- LEFT NOTCHED BAMBOO END --- */}
            <path
              d="M 22 8 Q 8 52 22 97 L 44 97 Q 30 52 44 8 Z"
              fill={`url(#${endCapGradId})`}
              stroke="#1a2e05"
              strokeWidth="2.5"
            />
            <path d="M 12 38 Q 20 52 12 66" stroke="#1a2e05" strokeWidth="2.5" fill="none" />

            {/* --- RIGHT NOTCHED BAMBOO END --- */}
            <path
              d="M 358 8 Q 372 52 358 97 L 336 97 Q 350 52 336 8 Z"
              fill={`url(#${endCapGradId})`}
              stroke="#1a2e05"
              strokeWidth="2.5"
            />
            <path d="M 368 38 Q 360 52 368 66" stroke="#1a2e05" strokeWidth="2.5" fill="none" />

            {/* --- MAIN BAMBOO CYLINDER BODY --- */}
            <rect
              x="36"
              y="8"
              width="308"
              height="89"
              rx="12"
              fill={`url(#${bambooGradId})`}
              stroke="#1a2e05"
              strokeWidth="2.8"
            />

            {/* Cylindrical Specular Glaze Sheen Lines */}
            <line x1="50" y1="24" x2="330" y2="24" stroke="#ecfccb" strokeWidth="4.5" opacity="0.85" strokeLinecap="round" />
            <line x1="56" y1="31" x2="324" y2="31" stroke="#f7fee7" strokeWidth="2" opacity="0.55" strokeLinecap="round" />

            {/* Natural Bamboo Fibers & Node Notches */}
            <line x1="100" y1="16" x2="135" y2="16" stroke="#1a2e05" strokeWidth="1.5" opacity="0.4" />
            <line x1="245" y1="84" x2="280" y2="84" stroke="#1a2e05" strokeWidth="1.5" opacity="0.45" />

            {/* --- LEFT COILED JUTE ROPE WRAP (4 turns with twist lines) --- */}
            <g filter={`url(#${ropeShadowId})`}>
              {/* Turn 1 */}
              <ellipse cx="44" cy="52.5" rx="6" ry="43.5" fill={`url(#${ropeGradId})`} stroke="#78350f" strokeWidth="1.5" />
              <line x1="41" y1="25" x2="47" y2="38" stroke="#78350f" strokeWidth="1.5" opacity="0.75" />
              <line x1="41" y1="58" x2="47" y2="72" stroke="#78350f" strokeWidth="1.5" opacity="0.75" />

              {/* Turn 2 */}
              <ellipse cx="54" cy="52.5" rx="6" ry="43.5" fill={`url(#${ropeGradId})`} stroke="#78350f" strokeWidth="1.5" />
              <line x1="51" y1="25" x2="57" y2="38" stroke="#78350f" strokeWidth="1.5" opacity="0.75" />
              <line x1="51" y1="58" x2="57" y2="72" stroke="#78350f" strokeWidth="1.5" opacity="0.75" />

              {/* Turn 3 */}
              <ellipse cx="64" cy="52.5" rx="6" ry="43.5" fill={`url(#${ropeGradId})`} stroke="#78350f" strokeWidth="1.5" />
              <line x1="61" y1="25" x2="67" y2="38" stroke="#78350f" strokeWidth="1.5" opacity="0.75" />
              <line x1="61" y1="58" x2="67" y2="72" stroke="#78350f" strokeWidth="1.5" opacity="0.75" />

              {/* Turn 4 */}
              <ellipse cx="74" cy="52.5" rx="6" ry="43.5" fill={`url(#${ropeGradId})`} stroke="#78350f" strokeWidth="1.5" />
              <line x1="71" y1="25" x2="77" y2="38" stroke="#78350f" strokeWidth="1.5" opacity="0.75" />
              <line x1="71" y1="58" x2="77" y2="72" stroke="#78350f" strokeWidth="1.5" opacity="0.75" />
            </g>

            {/* --- RIGHT COILED JUTE ROPE WRAP (4 turns with twist lines) --- */}
            <g filter={`url(#${ropeShadowId})`}>
              {/* Turn 1 */}
              <ellipse cx="306" cy="52.5" rx="6" ry="43.5" fill={`url(#${ropeGradId})`} stroke="#78350f" strokeWidth="1.5" />
              <line x1="303" y1="25" x2="309" y2="38" stroke="#78350f" strokeWidth="1.5" opacity="0.75" />
              <line x1="303" y1="58" x2="309" y2="72" stroke="#78350f" strokeWidth="1.5" opacity="0.75" />

              {/* Turn 2 */}
              <ellipse cx="316" cy="52.5" rx="6" ry="43.5" fill={`url(#${ropeGradId})`} stroke="#78350f" strokeWidth="1.5" />
              <line x1="313" y1="25" x2="319" y2="38" stroke="#78350f" strokeWidth="1.5" opacity="0.75" />
              <line x1="313" y1="58" x2="319" y2="72" stroke="#78350f" strokeWidth="1.5" opacity="0.75" />

              {/* Turn 3 */}
              <ellipse cx="326" cy="52.5" rx="6" ry="43.5" fill={`url(#${ropeGradId})`} stroke="#78350f" strokeWidth="1.5" />
              <line x1="323" y1="25" x2="329" y2="38" stroke="#78350f" strokeWidth="1.5" opacity="0.75" />
              <line x1="323" y1="58" x2="329" y2="72" stroke="#78350f" strokeWidth="1.5" opacity="0.75" />

              {/* Turn 4 */}
              <ellipse cx="336" cy="52.5" rx="6" ry="43.5" fill={`url(#${ropeGradId})`} stroke="#78350f" strokeWidth="1.5" />
              <line x1="333" y1="25" x2="339" y2="38" stroke="#78350f" strokeWidth="1.5" opacity="0.75" />
              <line x1="333" y1="58" x2="339" y2="72" stroke="#78350f" strokeWidth="1.5" opacity="0.75" />
            </g>
          </svg>

          {/* INNER CONTENT: BATSMAN + GLOWING CRICKET BALL PLAY ICON */}
          <div className="relative z-10 w-full h-full flex items-center justify-between px-6 sm:px-9 pointer-events-none">
            {/* 1. Dynamic Batsman in Action Swing (Left Side) */}
            <div className="relative flex items-center -ml-2 sm:-ml-1">
              <svg
                viewBox="0 0 160 170"
                className="w-20 h-22 sm:w-26 sm:h-28 -my-6 filter drop-shadow-xl"
              >
                {/* Batting ground shadow */}
                <ellipse cx="70" cy="162" rx="40" ry="6" fill="rgba(0,0,0,0.4)" />

                {/* Left Leg / Front Pad */}
                <path
                  d="M72 105 L92 155 L80 158 L62 108 Z"
                  fill="#f1f5f9"
                  stroke="#cbd5e1"
                  strokeWidth="2"
                />
                <line x1="72" y1="120" x2="84" y2="122" stroke="#94a3b8" strokeWidth="2" />
                <line x1="76" y1="135" x2="87" y2="137" stroke="#94a3b8" strokeWidth="2" />

                {/* Right Leg / Back Leg */}
                <path
                  d="M52 102 L44 152 L32 153 L42 104 Z"
                  fill="#e2e8f0"
                  stroke="#94a3b8"
                  strokeWidth="2"
                />
                {/* Shoes */}
                <path d="M78 157 L98 158 L96 163 L76 163 Z" fill="#ffffff" stroke="#64748b" strokeWidth="1.5" />
                <path d="M30 152 L46 153 L44 158 L28 157 Z" fill="#ffffff" stroke="#64748b" strokeWidth="1.5" />

                {/* Torso / Jersey (White Uniform with Team Stripe) */}
                <path
                  d="M46 55 L79 52 L86 108 L50 106 Z"
                  fill="#f8fafc"
                  stroke="#cbd5e1"
                  strokeWidth="2"
                />
                <path d="M64 53 L69 107" stroke="#22c55e" strokeWidth="3" strokeLinecap="round" />

                {/* Helmet with Visor and Grille */}
                <circle cx="62" cy="32" r="13" fill="#1e3a8a" stroke="#172554" strokeWidth="2" />
                <path d="M66 32 L82 34 L78 38 L64 36 Z" fill="#1d4ed8" />
                <path d="M70 35 L78 36 L74 45 L66 43 Z" fill="none" stroke="#94a3b8" strokeWidth="1.8" />

                {/* Left Arm (Reaching forward) */}
                <path
                  d="M76 60 L99 72 L94 82 L72 70 Z"
                  fill="#f1f5f9"
                  stroke="#cbd5e1"
                  strokeWidth="2"
                />

                {/* Right Arm (Guiding bat) */}
                <path
                  d="M49 58 L72 66 L69 76 L46 68 Z"
                  fill="#e2e8f0"
                  stroke="#cbd5e1"
                  strokeWidth="2"
                />

                {/* Batting Gloves */}
                <circle cx="98" cy="76" r="6.5" fill="#ffffff" stroke="#2563eb" strokeWidth="2" />
                <circle cx="90" cy="78" r="5.5" fill="#e2e8f0" stroke="#2563eb" strokeWidth="2" />

                {/* Cricket Bat in swing pointing towards the ball */}
                <g className="transition-transform group-hover:rotate-4 origin-[94px_78px]">
                  <path
                    d="M90 76 L112 70 L114 75 L92 81 Z"
                    fill="#ffffff"
                    stroke="#0284c7"
                    strokeWidth="1.5"
                  />
                  <path
                    d="M110 69 L156 54 L162 74 L114 78 Z"
                    fill="#f59e0b"
                    stroke="#b45309"
                    strokeWidth="2.5"
                  />
                  <line x1="118" y1="73" x2="156" y2="60" stroke="#d97706" strokeWidth="1.5" />
                  <line x1="120" y1="76" x2="158" y2="65" stroke="#d97706" strokeWidth="1.5" />
                  <path d="M128 64 L146 58 L148 66 L130 71 Z" fill="#dc2626" />
                </g>
              </svg>
            </div>

            {/* 2. Cricket Ball Play Button (Right / Center) with 3D Seam & Play Icon (▶) */}
            <div className="relative flex items-center justify-center mr-2 sm:mr-3">
              {/* Ball Aura */}
              <div className="absolute w-16 sm:w-20 h-16 sm:h-20 rounded-full bg-red-500/30 blur-lg group-hover:bg-red-400/50 transition-colors pointer-events-none" />

              {/* 3D Red Leather Cricket Ball Sphere */}
              <div
                className="relative w-14 h-14 sm:w-17 sm:h-17 rounded-full border-2 sm:border-3 border-amber-300 shadow-2xl flex items-center justify-center overflow-hidden transition-transform group-hover:scale-105 active:scale-95"
                style={{
                  background: 'radial-gradient(circle at 35% 30%, #ef4444 0%, #dc2626 40%, #991b1b 75%, #450a0a 100%)',
                }}
              >
                {/* Curved Stitched White Seam */}
                <svg viewBox="0 0 100 100" className="absolute inset-0 w-full h-full pointer-events-none">
                  <path
                    d="M18 88 Q48 48 78 12"
                    fill="none"
                    stroke="#ffffff"
                    strokeWidth="3.2"
                    strokeLinecap="round"
                  />
                  <path
                    d="M18 88 Q48 48 78 12"
                    fill="none"
                    stroke="#7f1d1d"
                    strokeWidth="1.4"
                    strokeDasharray="2,4"
                  />
                  <path
                    d="M22 91 Q52 51 82 15"
                    fill="none"
                    stroke="#ffffff"
                    strokeWidth="1.4"
                    opacity="0.8"
                  />
                </svg>

                {/* Specular Highlight Sheen */}
                <div className="absolute top-1 left-2 w-6 h-3 rounded-full bg-white/40 blur-[1px] pointer-events-none" />

                {/* Centered Glowing PLAY TRIANGLE (▶) */}
                <div className="relative z-10 w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-black/35 backdrop-blur-xs border border-white/50 flex items-center justify-center shadow-lg group-hover:bg-black/45 transition-colors">
                  <Play className="w-5 h-5 sm:w-6 sm:h-6 text-white fill-white ml-0.5 filter drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]" />
                </div>
              </div>

              {/* Idle Pulsing Ring */}
              <div className="absolute inset-0 rounded-full border-2 border-amber-300/40 animate-ping opacity-35 pointer-events-none" />
            </div>
          </div>
        </div>
      </button>
    </div>
  );
};
