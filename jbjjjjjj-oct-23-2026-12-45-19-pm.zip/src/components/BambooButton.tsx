import React from 'react';

interface BambooButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  asBadge?: boolean;
  isGlowing?: boolean;
  title?: string;
}

export const BambooButton: React.FC<BambooButtonProps> = ({
  children,
  onClick,
  disabled = false,
  className = '',
  size = 'md',
  asBadge = false,
  isGlowing = false,
  title,
}) => {
  // Height and padding scaling
  const heightClasses = {
    sm: 'h-10 min-w-[54px] px-2 text-xs',
    md: 'h-11 min-w-[70px] px-3 text-sm',
    lg: 'h-12 min-w-[100px] px-4 text-sm sm:text-base',
  }[size];

  const uid = React.useId().replace(/:/g, '_');
  const bambooGradId = isGlowing ? `bambooGradGlow_${uid}` : `bambooGrad_${uid}`;
  const endCapGradId = `endCapGrad_${uid}`;
  const ropeGradId = `ropeGrad_${uid}`;
  const shadowId = `bambooInnerDepth_${uid}`;

  const content = (
    <div
      className={`relative inline-flex items-center justify-center select-none ${heightClasses} ${
        !asBadge && !disabled ? 'cursor-pointer hover:brightness-110 active:scale-95' : ''
      } ${disabled ? 'opacity-50 cursor-not-allowed' : ''} transition-all duration-150 ${className}`}
      title={title}
    >
      {/* 1. Underlying Bamboo Stalk & Coiled Rope Frame (Vector SVG) */}
      <svg
        className="absolute inset-0 w-full h-full pointer-events-none drop-shadow-md overflow-visible"
        preserveAspectRatio="none"
        viewBox="0 0 160 50"
      >
        <defs>
          {/* Natural Bamboo Stalk Gradient (Yellow-green highlight down center, rich forest green edges) */}
          <linearGradient id={bambooGradId} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={isGlowing ? "#4ade80" : "#4d7c0f"} />
            <stop offset="25%" stopColor={isGlowing ? "#86efac" : "#84cc16"} />
            <stop offset="48%" stopColor={isGlowing ? "#bbf7d0" : "#bef264"} />
            <stop offset="70%" stopColor={isGlowing ? "#22c55e" : "#65a30d"} />
            <stop offset="100%" stopColor={isGlowing ? "#15803d" : "#365314"} />
          </linearGradient>

          {/* Bamboo Cut End Cap Gradient */}
          <linearGradient id={endCapGradId} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#3f6212" />
            <stop offset="50%" stopColor="#65a30d" />
            <stop offset="100%" stopColor="#1e3a0f" />
          </linearGradient>

          {/* Jute Rope Coil Gradient (Textured twisted golden-brown coir fibers) */}
          <linearGradient id={ropeGradId} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#d97706" />
            <stop offset="30%" stopColor="#fde68a" />
            <stop offset="70%" stopColor="#b45309" />
            <stop offset="100%" stopColor="#78350f" />
          </linearGradient>

          {/* Ambient Drop Shadow for inner depth */}
          <filter id={shadowId} x="-10%" y="-10%" width="120%" height="120%">
            <feDropShadow dx="0" dy="1.5" stdDeviation="1.5" floodColor="#000" floodOpacity="0.4" />
          </filter>
        </defs>

        {/* --- LEFT NOTCHED BAMBOO END --- */}
        <path
          d="M 12 3 Q 3 25 12 47 L 24 47 Q 15 25 24 3 Z"
          fill={`url(#${endCapGradId})`}
          stroke="#27400d"
          strokeWidth="1.5"
        />
        {/* Left End Ring Lip Notch */}
        <path d="M 6 18 Q 11 25 6 32" stroke="#1e3a0f" strokeWidth="2" fill="none" />

        {/* --- RIGHT NOTCHED BAMBOO END --- */}
        <path
          d="M 148 3 Q 157 25 148 47 L 136 47 Q 145 25 136 3 Z"
          fill={`url(#${endCapGradId})`}
          stroke="#27400d"
          strokeWidth="1.5"
        />
        {/* Right End Ring Lip Notch */}
        <path d="M 154 18 Q 149 25 154 32" stroke="#1e3a0f" strokeWidth="2" fill="none" />

        {/* --- MAIN BAMBOO CYLINDER BODY --- */}
        <rect
          x="18"
          y="3"
          width="124"
          height="44"
          rx="5"
          fill={`url(#${bambooGradId})`}
          stroke="#1e3a0f"
          strokeWidth="1.8"
        />

        {/* Top Cylindrical Specular Glaze Line */}
        <line x1="24" y1="11" x2="136" y2="11" stroke="#ecfccb" strokeWidth="2.2" opacity="0.8" strokeLinecap="round" />
        <line x1="28" y1="15" x2="132" y2="15" stroke="#f7fee7" strokeWidth="1.2" opacity="0.5" strokeLinecap="round" />

        {/* Natural Bamboo Node Fibers & Growth Striations */}
        <line x1="42" y1="7" x2="55" y2="7" stroke="#365314" strokeWidth="1" opacity="0.4" />
        <line x1="102" y1="41" x2="118" y2="41" stroke="#1a2e05" strokeWidth="1" opacity="0.45" />

        {/* --- LEFT COILED JUTE ROPE WRAP (3 turns with twist lines) --- */}
        <g id={`leftRopes_${uid}`} filter={`url(#${shadowId})`}>
          {/* Turn 1 */}
          <ellipse cx="21" cy="25" rx="3.5" ry="21.5" fill={`url(#${ropeGradId})`} stroke="#78350f" strokeWidth="1" />
          <line x1="19" y1="12" x2="23" y2="18" stroke="#78350f" strokeWidth="1" opacity="0.7" />
          <line x1="19" y1="28" x2="23" y2="34" stroke="#78350f" strokeWidth="1" opacity="0.7" />

          {/* Turn 2 */}
          <ellipse cx="26" cy="25" rx="3.5" ry="21.5" fill={`url(#${ropeGradId})`} stroke="#78350f" strokeWidth="1" />
          <line x1="24" y1="12" x2="28" y2="18" stroke="#78350f" strokeWidth="1" opacity="0.7" />
          <line x1="24" y1="28" x2="28" y2="34" stroke="#78350f" strokeWidth="1" opacity="0.7" />

          {/* Turn 3 */}
          <ellipse cx="31" cy="25" rx="3.5" ry="21.5" fill={`url(#${ropeGradId})`} stroke="#78350f" strokeWidth="1" />
          <line x1="29" y1="12" x2="33" y2="18" stroke="#78350f" strokeWidth="1" opacity="0.7" />
          <line x1="29" y1="28" x2="33" y2="34" stroke="#78350f" strokeWidth="1" opacity="0.7" />
        </g>

        {/* --- RIGHT COILED JUTE ROPE WRAP (3 turns with twist lines) --- */}
        <g id={`rightRopes_${uid}`} filter={`url(#${shadowId})`}>
          {/* Turn 1 */}
          <ellipse cx="129" cy="25" rx="3.5" ry="21.5" fill={`url(#${ropeGradId})`} stroke="#78350f" strokeWidth="1" />
          <line x1="127" y1="12" x2="131" y2="18" stroke="#78350f" strokeWidth="1" opacity="0.7" />
          <line x1="127" y1="28" x2="131" y2="34" stroke="#78350f" strokeWidth="1" opacity="0.7" />

          {/* Turn 2 */}
          <ellipse cx="134" cy="25" rx="3.5" ry="21.5" fill={`url(#${ropeGradId})`} stroke="#78350f" strokeWidth="1" />
          <line x1="132" y1="12" x2="136" y2="18" stroke="#78350f" strokeWidth="1" opacity="0.7" />
          <line x1="132" y1="28" x2="136" y2="34" stroke="#78350f" strokeWidth="1" opacity="0.7" />

          {/* Turn 3 */}
          <ellipse cx="139" cy="25" rx="3.5" ry="21.5" fill={`url(#${ropeGradId})`} stroke="#78350f" strokeWidth="1" />
          <line x1="137" y1="12" x2="141" y2="18" stroke="#78350f" strokeWidth="1" opacity="0.7" />
          <line x1="137" y1="28" x2="141" y2="34" stroke="#78350f" strokeWidth="1" opacity="0.7" />
        </g>
      </svg>

      {/* 2. Content (Icons, Numbers) with carved embossed effect */}
      <div className="relative z-10 flex items-center justify-center gap-1.5 px-3 font-black text-white filter drop-shadow-[0_1.5px_2px_rgba(0,0,0,0.85)]">
        {children}
      </div>
    </div>
  );

  if (asBadge) {
    return content;
  }

  return (
    <button
      type="button"
      onClick={disabled ? undefined : onClick}
      disabled={disabled}
      className="inline-block p-0 bg-transparent border-0 outline-none cursor-pointer focus:outline-none"
    >
      {content}
    </button>
  );
};
