import React from 'react';
import { BackgroundTheme } from '../types/game';

interface BackgroundMiniSceneProps {
  theme: BackgroundTheme;
}

export const BackgroundMiniScene: React.FC<BackgroundMiniSceneProps> = ({ theme }) => {
  switch (theme) {
    case 'DESERT':
      return (
        <svg viewBox="0 0 160 100" className="w-full h-full object-cover select-none" preserveAspectRatio="none">
          <defs>
            <linearGradient id="bg-thm-desert-sky" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#7c2d12" />
              <stop offset="35%" stopColor="#c2410c" />
              <stop offset="70%" stopColor="#ea580c" />
              <stop offset="100%" stopColor="#fde047" />
            </linearGradient>
            <radialGradient id="bg-thm-desert-sun" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#ffffff" />
              <stop offset="35%" stopColor="#fef08a" />
              <stop offset="75%" stopColor="#f59e0b" />
              <stop offset="100%" stopColor="#b45309" stopOpacity="0" />
            </radialGradient>
            <linearGradient id="bg-thm-dune-lit" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#fbbf24" />
              <stop offset="100%" stopColor="#d97706" />
            </linearGradient>
            <linearGradient id="bg-thm-dune-shade" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#b45309" />
              <stop offset="100%" stopColor="#78350f" />
            </linearGradient>
          </defs>
          <rect width="160" height="100" fill="url(#bg-thm-desert-sky)" />
          <circle cx="124" cy="24" r="18" fill="url(#bg-thm-desert-sun)" />
          <circle cx="124" cy="24" r="9" fill="#fef9c3" />
          <path d="M0 58 L28 52 L36 55 L75 49 L84 55 L112 51 L120 57 L160 52 L160 100 L0 100 Z" fill="#9a3412" opacity="0.6" />
          <path d="M0 63 Q50 49 95 65 Q135 53 160 63 L160 100 L0 100 Z" fill="url(#bg-thm-dune-lit)" />
          <path d="M95 65 Q125 59 160 67 L160 100 L95 100 Z" fill="url(#bg-thm-dune-shade)" opacity="0.6" />
          <path d="M0 73 Q45 59 85 76 Q125 66 160 75 L160 100 L0 100 Z" fill="url(#bg-thm-dune-lit)" />
          <path d="M85 76 Q120 71 160 79 L160 100 L85 100 Z" fill="url(#bg-thm-dune-shade)" opacity="0.5" />
          <path d="M40 68 Q42 60 41 54" stroke="#78350f" strokeWidth="1.5" fill="none" />
          <path d="M41 54 Q35 52 33 56 M41 54 Q40 48 39 47 M41 54 Q46 50 49 54 M41 54 Q44 56 46 59" stroke="#15803d" strokeWidth="1.2" fill="none" />
          <rect x="0" y="81" width="160" height="19" fill="#d97706" />
          <path d="M10 87 Q30 85 55 87 M75 89 Q100 87 130 89 M25 94 Q60 92 95 94" stroke="#b45309" strokeWidth="1" strokeLinecap="round" opacity="0.6" />
        </svg>
      );

    case 'SNOW':
      return (
        <svg viewBox="0 0 160 100" className="w-full h-full object-cover select-none" preserveAspectRatio="none">
          <defs>
            <linearGradient id="bg-thm-snow-sky" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#1e3a8a" />
              <stop offset="45%" stopColor="#0284c7" />
              <stop offset="85%" stopColor="#bae6fd" />
              <stop offset="100%" stopColor="#e0f2fe" />
            </linearGradient>
            <radialGradient id="bg-thm-snow-sun" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#ffffff" />
              <stop offset="40%" stopColor="#e0f2fe" />
              <stop offset="100%" stopColor="#38bdf8" stopOpacity="0" />
            </radialGradient>
            <linearGradient id="bg-thm-peak-lit" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#ffffff" />
              <stop offset="100%" stopColor="#cbd5e1" />
            </linearGradient>
            <linearGradient id="bg-thm-peak-shade" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#0284c7" />
              <stop offset="100%" stopColor="#0f172a" />
            </linearGradient>
          </defs>
          <rect width="160" height="100" fill="url(#bg-thm-snow-sky)" />
          <circle cx="128" cy="20" r="14" fill="url(#bg-thm-snow-sun)" />
          <circle cx="128" cy="20" r="6" fill="#ffffff" />
          <polygon points="15,64 50,32 82,64" fill="#0369a1" opacity="0.5" />
          <polygon points="50,32 82,64 50,64" fill="#0f172a" opacity="0.5" />
          <polygon points="65,66 105,26 145,66" fill="#0284c7" opacity="0.4" />
          <polygon points="0,74 38,36 68,74" fill="url(#bg-thm-peak-lit)" />
          <polygon points="38,36 68,74 38,74" fill="url(#bg-thm-peak-shade)" opacity="0.75" />
          <polygon points="38,36 26,50 38,54 48,50" fill="#ffffff" />
          <polygon points="45,76 96,22 148,76" fill="url(#bg-thm-peak-lit)" />
          <polygon points="96,22 148,76 96,76" fill="url(#bg-thm-peak-shade)" opacity="0.85" />
          <polygon points="96,22 81,42 96,47 111,43" fill="#ffffff" />
          <polygon points="20,75 15,66 25,66" fill="#064e3b" />
          <polygon points="20,68 17,61 23,61" fill="#f8fafc" />
          <polygon points="32,77 27,67 37,67" fill="#064e3b" />
          <polygon points="32,69 29,62 35,62" fill="#f8fafc" />
          <polygon points="135,76 130,65 140,65" fill="#064e3b" />
          <polygon points="135,68 132,60 138,60" fill="#f8fafc" />
          <path d="M0 76 Q40 71 85 77 Q130 70 160 75 L160 100 L0 100 Z" fill="#e0f2fe" />
          <path d="M0 84 Q55 79 110 85 Q140 82 160 84 L160 100 L0 100 Z" fill="#f8fafc" />
          <ellipse cx="60" cy="89" rx="25" ry="3" fill="#38bdf8" opacity="0.25" />
        </svg>
      );

    case 'BEACH':
      return (
        <svg viewBox="0 0 160 100" className="w-full h-full object-cover select-none" preserveAspectRatio="none">
          <defs>
            <linearGradient id="bg-thm-beach-sky" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#0284c7" />
              <stop offset="45%" stopColor="#38bdf8" />
              <stop offset="85%" stopColor="#a5f3fc" />
              <stop offset="100%" stopColor="#fef08a" />
            </linearGradient>
            <linearGradient id="bg-thm-ocean-water" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#0369a1" />
              <stop offset="30%" stopColor="#0891b2" />
              <stop offset="70%" stopColor="#06b6d4" />
              <stop offset="100%" stopColor="#22d3ee" />
            </linearGradient>
          </defs>
          <rect width="160" height="100" fill="url(#bg-thm-beach-sky)" />
          <circle cx="118" cy="20" r="12" fill="#fef08a" />
          <circle cx="118" cy="20" r="7" fill="#ffffff" />
          <path d="M15 22 Q23 16 31 22 Q38 18 45 24 L12 24 Z" fill="#ffffff" opacity="0.6" />
          <rect x="0" y="48" width="160" height="26" fill="url(#bg-thm-ocean-water)" />
          <path d="M0 64 Q40 56 80 62 Q120 54 160 60 L160 68 L0 68 Z" fill="#0891b2" />
          <path d="M0 62 Q35 55 75 60 Q115 53 155 58" stroke="#ffffff" strokeWidth="2" fill="none" opacity="0.9" />
          <path d="M10 65 Q45 61 85 64 Q125 59 160 63" stroke="#cffafe" strokeWidth="1.5" fill="none" opacity="0.7" />
          <path d="M0 72 Q45 68 90 73 Q130 69 160 72 L160 76 L0 76 Z" fill="#ffffff" opacity="0.85" />
          <rect x="0" y="74" width="160" height="26" fill="#fde047" />
          <path d="M0 80 Q60 78 120 82 Q145 80 160 81 L160 100 L0 100 Z" fill="#f59e0b" opacity="0.8" />
          <path d="M22 100 Q15 76 28 55 Q30 50 32 46" stroke="#78350f" strokeWidth="4.5" fill="none" strokeLinecap="round" />
          <path d="M22 100 Q15 76 28 55 Q30 50 32 46" stroke="#b45309" strokeWidth="2.5" fill="none" strokeLinecap="round" />
          <path d="M32 46 Q20 38 8 44 M32 46 Q28 32 20 28 M32 46 Q40 32 50 34 M32 46 Q46 42 54 50 M32 46 Q36 50 34 58 M32 46 Q24 48 16 54" stroke="#15803d" strokeWidth="2.5" fill="none" strokeLinecap="round" />
          <path d="M32 46 Q22 40 12 45 M32 46 Q38 34 46 36 M32 46 Q44 44 50 51" stroke="#22c55e" strokeWidth="1.5" fill="none" strokeLinecap="round" />
          <circle cx="31" cy="48" r="2" fill="#451a03" />
          <circle cx="34" cy="49" r="2" fill="#451a03" />
        </svg>
      );

    case 'TEMPLE':
      return (
        <svg viewBox="0 0 160 100" className="w-full h-full object-cover select-none" preserveAspectRatio="none">
          <defs>
            <linearGradient id="bg-thm-temple-sky" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#2a164d" />
              <stop offset="35%" stopColor="#581c4f" />
              <stop offset="65%" stopColor="#c85a32" />
              <stop offset="100%" stopColor="#fde68a" />
            </linearGradient>
            <radialGradient id="bg-thm-temple-sun" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#ffffff" />
              <stop offset="35%" stopColor="#fef08a" />
              <stop offset="70%" stopColor="#ea580c" />
              <stop offset="100%" stopColor="#581c4f" stopOpacity="0" />
            </radialGradient>
          </defs>
          <rect width="160" height="100" fill="url(#bg-thm-temple-sky)" />
          <circle cx="112" cy="30" r="16" fill="url(#bg-thm-temple-sun)" />
          <circle cx="112" cy="30" r="7" fill="#fef9c3" />
          <path d="M0 60 L35 52 L60 56 L100 50 L130 55 L160 51 L160 100 L0 100 Z" fill="#3b0764" opacity="0.6" />
          <path d="M35 68 L37 48 L39 42 L41 48 L43 68 Z" fill="#292524" />
          <path d="M33 58 L45 58 M35 52 L43 52 M37 46 L41 46" stroke="#44403c" strokeWidth="1.2" />
          <path d="M68 70 L72 38 L75 24 L78 38 L82 70 Z" fill="#1c1917" />
          <path d="M64 58 L86 58 M66 48 L84 48 M70 38 L80 38 M73 30 L77 30" stroke="#57534e" strokeWidth="1.5" />
          <polygon points="75,20 73,25 77,25" fill="#f59e0b" />
          <path d="M96 68 L99 46 L101 40 L103 46 L106 68 Z" fill="#292524" />
          <path d="M94 56 L108 56 M97 50 L105 50 M99 44 L103 44" stroke="#44403c" strokeWidth="1.2" />
          <rect x="25" y="65" width="90" height="12" fill="#292524" />
          <line x1="30" y1="65" x2="30" y2="77" stroke="#57534e" strokeWidth="2" />
          <line x1="45" y1="65" x2="45" y2="77" stroke="#57534e" strokeWidth="2" />
          <line x1="60" y1="65" x2="60" y2="77" stroke="#57534e" strokeWidth="2" />
          <line x1="75" y1="65" x2="75" y2="77" stroke="#57534e" strokeWidth="2" />
          <line x1="90" y1="65" x2="90" y2="77" stroke="#57534e" strokeWidth="2" />
          <line x1="105" y1="65" x2="105" y2="77" stroke="#57534e" strokeWidth="2" />
          <rect x="71" y="68" width="8" height="9" rx="2" fill="#f59e0b" opacity="0.9" />
          <rect x="0" y="77" width="160" height="23" fill="#1c1917" />
          <path d="M20 83 L140 83 M30 89 L130 89 M15 95 L145 95" stroke="#f59e0b" strokeWidth="1" strokeDasharray="6,4" opacity="0.3" />
          <circle cx="28" cy="88" r="4" fill="#065f46" />
          <circle cx="28" cy="87" r="1.5" fill="#f43f5e" />
          <circle cx="132" cy="86" r="4" fill="#065f46" />
          <circle cx="132" cy="85" r="1.5" fill="#f43f5e" />
        </svg>
      );

    case 'WATERFALL':
      return (
        <svg viewBox="0 0 160 100" className="w-full h-full object-cover select-none" preserveAspectRatio="none">
          <defs>
            <linearGradient id="bg-thm-falls-sky" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#042f2e" />
              <stop offset="40%" stopColor="#0d9488" />
              <stop offset="80%" stopColor="#5eead4" />
              <stop offset="100%" stopColor="#ccfbf1" />
            </linearGradient>
            <linearGradient id="bg-thm-falls-water" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#bae6fd" />
              <stop offset="30%" stopColor="#ffffff" />
              <stop offset="70%" stopColor="#38bdf8" />
              <stop offset="100%" stopColor="#ffffff" />
            </linearGradient>
          </defs>
          <rect width="160" height="100" fill="url(#bg-thm-falls-sky)" />
          <polygon points="0,52 45,28 90,52" fill="#134e4a" opacity="0.5" />
          <polygon points="70,52 115,25 160,52" fill="#115e59" opacity="0.4" />
          <path d="M0 10 L58 15 L62 76 L0 80 Z" fill="#0f172a" />
          <path d="M5 12 L52 17 L55 72 L5 76 Z" fill="#1e293b" />
          <path d="M98 15 L160 10 L160 80 L96 76 Z" fill="#0f172a" />
          <path d="M104 17 L155 12 L155 76 L102 72 Z" fill="#1e293b" />
          <path d="M10 18 Q25 28 35 20 M5 30 Q20 40 30 32 M120 18 Q135 28 150 22 M125 32 Q140 40 155 35" stroke="#16a34a" strokeWidth="2" fill="none" opacity="0.8" />
          <rect x="62" y="15" width="34" height="63" fill="url(#bg-thm-falls-water)" />
          <line x1="68" y1="15" x2="68" y2="78" stroke="#ffffff" strokeWidth="2" />
          <line x1="74" y1="15" x2="74" y2="78" stroke="#ffffff" strokeWidth="2.5" />
          <line x1="80" y1="15" x2="80" y2="78" stroke="#ffffff" strokeWidth="3" />
          <line x1="86" y1="15" x2="86" y2="78" stroke="#ffffff" strokeWidth="2" />
          <line x1="91" y1="15" x2="91" y2="78" stroke="#ffffff" strokeWidth="1.5" />
          <ellipse cx="79" cy="76" rx="28" ry="7" fill="#ffffff" opacity="0.85" />
          <ellipse cx="79" cy="74" rx="20" ry="5" fill="#ccfbf1" opacity="0.9" />
          <rect x="0" y="78" width="160" height="22" fill="#0f766e" />
          <rect x="0" y="83" width="160" height="17" fill="#115e59" />
          <ellipse cx="79" cy="85" rx="35" ry="4" stroke="#5eead4" strokeWidth="1.5" fill="none" opacity="0.8" />
          <ellipse cx="79" cy="90" rx="48" ry="4" stroke="#5eead4" strokeWidth="1.2" fill="none" opacity="0.6" />
          <ellipse cx="79" cy="95" rx="60" ry="3" stroke="#99f6e4" strokeWidth="1" fill="none" opacity="0.4" />
        </svg>
      );

    case 'DAY':
    default:
      return (
        <svg viewBox="0 0 160 100" className="w-full h-full object-cover select-none" preserveAspectRatio="none">
          <defs>
            <linearGradient id="bg-thm-day-sky" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#38bdf8" />
              <stop offset="55%" stopColor="#bae6fd" />
              <stop offset="100%" stopColor="#f0fdf4" />
            </linearGradient>
            <linearGradient id="bg-thm-day-hill-back" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#22c55e" />
              <stop offset="100%" stopColor="#15803d" />
            </linearGradient>
            <linearGradient id="bg-thm-day-hill-front" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#16a34a" />
              <stop offset="100%" stopColor="#166534" />
            </linearGradient>
            <radialGradient id="bg-thm-day-sun" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#ffffff" />
              <stop offset="40%" stopColor="#fef08a" />
              <stop offset="100%" stopColor="#f59e0b" stopOpacity="0" />
            </radialGradient>
          </defs>
          <rect width="160" height="100" fill="url(#bg-thm-day-sky)" />
          <circle cx="132" cy="22" r="16" fill="url(#bg-thm-day-sun)" />
          <circle cx="132" cy="22" r="8" fill="#fef08a" />
          <path d="M20 25 Q28 18 36 24 Q44 20 52 26 L15 26 Z" fill="#ffffff" opacity="0.65" />
          <path d="M75 18 Q83 12 91 17 Q98 14 104 19 L72 19 Z" fill="#ffffff" opacity="0.5" />
          <path d="M0 65 Q45 42 90 58 Q130 45 160 55 L160 100 L0 100 Z" fill="url(#bg-thm-day-hill-back)" />
          <path d="M0 72 Q35 62 80 68 Q125 60 160 67 L160 100 L0 100 Z" fill="url(#bg-thm-day-hill-front)" />
          <circle cx="28" cy="62" r="7" fill="#14532d" />
          <circle cx="36" cy="60" r="9" fill="#166534" />
          <circle cx="44" cy="63" r="6" fill="#15803d" />
          <circle cx="120" cy="61" r="8" fill="#14532d" />
          <circle cx="128" cy="59" r="7" fill="#166534" />
          <rect x="0" y="74" width="160" height="26" fill="#15803d" />
          <line x1="0" y1="81" x2="160" y2="81" stroke="#16a34a" strokeWidth="3" opacity="0.4" />
          <line x1="0" y1="89" x2="160" y2="89" stroke="#166534" strokeWidth="3" opacity="0.4" />
          <rect x="58" y="77" width="44" height="21" rx="2" fill="#ca8a04" opacity="0.9" />
          <rect x="61" y="79" width="38" height="17" rx="1" fill="#eab308" opacity="0.6" />
          <line x1="68" y1="77" x2="68" y2="98" stroke="#ffffff" strokeWidth="1" opacity="0.75" />
          <line x1="92" y1="77" x2="92" y2="98" stroke="#ffffff" strokeWidth="1" opacity="0.75" />
          <line x1="67" y1="83" x2="67" y2="91" stroke="#fef08a" strokeWidth="1.2" />
          <line x1="68" y1="83" x2="68" y2="91" stroke="#fef08a" strokeWidth="1.2" />
          <line x1="69" y1="83" x2="69" y2="91" stroke="#fef08a" strokeWidth="1.2" />
        </svg>
      );
  }
};
