import React, { useState, useEffect } from 'react';
import { X, Coins, Flame, Bomb, FlaskConical, CircleDot, Check, Lock } from 'lucide-react';
import { BackgroundTheme, SpecialBallType } from '../types/game';
import { JewelButton } from './JewelButton';
import { BambooBasketIcon } from './BambooBasketIcon';
import { CricketStickerBackdrop } from './CricketStickerBackdrop';
import { BackgroundMiniScene } from './BackgroundMiniScene';
import { soundManager } from '../utils/audio';

interface ShopModalProps {
  isOpen: boolean;
  onClose: () => void;
  coins: number;
  mode?: 'BALLS' | 'BACKGROUNDS';
  ballInventory: Record<SpecialBallType, number>;
  selectedBall: SpecialBallType;
  onSelectBall: (ball: SpecialBallType) => void;
  onBuyBall: (ball: SpecialBallType, cost: number, quantity?: number) => void;
  unlockedBackgrounds: Record<BackgroundTheme, boolean>;
  selectedBackground: BackgroundTheme;
  onSelectBackground: (bg: BackgroundTheme) => void;
  onBuyBackground: (bg: BackgroundTheme, cost: number) => void;
}

export const BALL_PRICES: Record<SpecialBallType, number> = {
  STANDARD: 20,
  BOMB: 150,
  FIRE: 140,
  ACID: 120,
};

export const BACKGROUND_PRICES: Record<BackgroundTheme, number> = {
  DAY: 0,
  DESERT: 100,
  SNOW: 150,
  BEACH: 200,
  TEMPLE: 250,
  WATERFALL: 300,
  SUNSET: 100,
  NIGHT: 150,
  JUNGLE: 200,
};

export const ShopModal: React.FC<ShopModalProps> = ({
  isOpen,
  onClose,
  coins,
  mode = 'BALLS',
  ballInventory,
  selectedBall,
  onSelectBall,
  onBuyBall,
  unlockedBackgrounds,
  selectedBackground,
  onSelectBackground,
  onBuyBackground,
}) => {
  const [modalScale, setModalScale] = useState<number>(1);

  useEffect(() => {
    const updateScale = () => {
      const vh = window.innerHeight;
      const vw = window.innerWidth;
      setModalScale(Math.max(0.45, Math.min(1, (vh - 16) / 310, (vw - 110) / 420)));
    };
    updateScale();
    window.addEventListener('resize', updateScale);
    return () => window.removeEventListener('resize', updateScale);
  }, []);

  if (!isOpen) return null;

  const ballCatalog: {
    id: SpecialBallType;
    cost: number;
    packQuantity: number;
    icon: React.ReactNode;
    colorGrad: string;
  }[] = [
    {
      id: 'STANDARD',
      cost: BALL_PRICES.STANDARD,
      packQuantity: 3,
      icon: <CircleDot className="w-7 h-7 text-red-400" />,
      colorGrad: 'from-red-600 via-rose-700 to-red-950',
    },
    {
      id: 'BOMB',
      cost: BALL_PRICES.BOMB,
      packQuantity: 1,
      icon: <Bomb className="w-7 h-7 text-amber-400" />,
      colorGrad: 'from-zinc-600 via-slate-700 to-zinc-800',
    },
    {
      id: 'FIRE',
      cost: BALL_PRICES.FIRE,
      packQuantity: 1,
      icon: <Flame className="w-7 h-7 text-orange-400" />,
      colorGrad: 'from-amber-500 via-orange-600 to-red-700',
    },
    {
      id: 'ACID',
      cost: BALL_PRICES.ACID,
      packQuantity: 1,
      icon: <FlaskConical className="w-7 h-7 text-emerald-400" />,
      colorGrad: 'from-lime-500 via-emerald-600 to-teal-900',
    },
  ];

  const backgroundCatalog: {
    id: BackgroundTheme;
    name: string;
    description: string;
    cost: number;
  }[] = [
    {
      id: 'DAY',
      name: 'DAY MEADOW',
      description: 'Cricket turf & rolling hills',
      cost: BACKGROUND_PRICES.DAY,
    },
    {
      id: 'DESERT',
      name: 'DESERT DUNES',
      description: 'Golden sands & sunbeams',
      cost: BACKGROUND_PRICES.DESERT,
    },
    {
      id: 'SNOW',
      name: 'SNOWY PEAKS',
      description: 'Glacier peaks & alpine pines',
      cost: BACKGROUND_PRICES.SNOW,
    },
    {
      id: 'BEACH',
      name: 'OCEAN BEACH',
      description: 'Lagoon waves & palm trees',
      cost: BACKGROUND_PRICES.BEACH,
    },
    {
      id: 'TEMPLE',
      name: 'STONE TEMPLE',
      description: 'Ancient ruins & twilight glow',
      cost: BACKGROUND_PRICES.TEMPLE,
    },
    {
      id: 'WATERFALL',
      name: 'WATERFALL VALLEY',
      description: 'Cascades & rainforest pool',
      cost: BACKGROUND_PRICES.WATERFALL,
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-5 animate-in fade-in duration-150 select-none touch-manipulation overflow-hidden">
      <CricketStickerBackdrop />
      <div
        style={{ transform: `scale(${modalScale})` }}
        className="relative z-10 w-full max-w-xl bg-white/10 backdrop-blur-md border-2 border-white/30 rounded-3xl shadow-2xl flex flex-col max-h-[290px] sm:max-h-[88vh] overflow-hidden origin-center"
      >
        {/* Header Bar */}
        <div className="flex items-center justify-between p-4 border-b border-white/10 bg-white/5 shrink-0">
          <JewelButton asBadge size="sm" variant="orb" color="sunset">
            <BambooBasketIcon className="w-5 h-5" />
          </JewelButton>

          <div className="flex items-center gap-2">
            {/* Single Unified Coin Badge */}
            <JewelButton asBadge size="sm" variant="badge" color="amber">
              <Coins className="w-3.5 h-3.5 text-amber-100 fill-amber-200" />
              <span className="font-black text-amber-100 text-xs sm:text-sm tabular-nums">{coins}</span>
            </JewelButton>

            {/* Close Button: Titanium Jewel Orb */}
            <JewelButton
              size="sm"
              variant="orb"
              color="titanium"
              onClick={() => {
                soundManager.playButtonClick();
                onClose();
              }}
              title="Close"
            >
              <X className="w-4 h-4 text-white" />
            </JewelButton>
          </div>
        </div>

        {/* Content Body: Mode-specific (HomeScreen = BACKGROUNDS ONLY, In-Game = BALLS ONLY) */}
        <div className="p-4 overflow-y-auto space-y-3">
          {mode === 'BALLS' ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {ballCatalog.map((b) => {
                const count = ballInventory[b.id] || 0;
                const hasStock = count > 0;
                const isSelected = selectedBall === b.id;
                const canAfford = coins >= b.cost;

                return (
                  <div
                    key={b.id}
                    className={`relative p-3.5 rounded-2xl border-2 transition-all flex flex-col gap-3 ${
                      isSelected
                        ? 'bg-amber-500/15 border-amber-400 shadow-lg shadow-amber-500/10'
                        : hasStock
                        ? 'bg-white/10 border-white/20 hover:border-white/30'
                        : 'bg-white/5 border-white/10 opacity-85'
                    }`}
                  >
                    {/* Top Row: Visual Ball Icon + Stock Count on Left, Select Check on Right */}
                    <div className="flex items-center justify-between gap-3 w-full">
                      <div className="flex items-center gap-3 min-w-0">
                        <div
                          className={`w-13 h-13 sm:w-14 sm:h-14 rounded-2xl bg-gradient-to-br ${b.colorGrad} p-1 border border-white/20 shadow-md flex items-center justify-center shrink-0 relative overflow-hidden`}
                        >
                          {b.icon}
                          {b.id === 'BOMB' && (
                            <div className="absolute top-1 right-1 w-2 h-2 rounded-full bg-amber-400 animate-ping opacity-75" />
                          )}
                        </div>

                        <div className="flex items-center gap-1.5">
                          <span className="font-black text-amber-300 text-lg sm:text-xl tabular-nums drop-shadow">
                            {count}
                          </span>
                        </div>
                      </div>

                      {/* Select / Selected Indicator */}
                      <div className="flex items-center shrink-0">
                        {hasStock && !isSelected && (
                          <JewelButton
                            size="sm"
                            variant="orb"
                            color="emerald"
                            onClick={() => {
                              soundManager.playButtonClick();
                              onSelectBall(b.id);
                            }}
                            title="Select Ball"
                          >
                            <Check className="w-4 h-4 text-white" />
                          </JewelButton>
                        )}
                        {hasStock && isSelected && (
                          <div className="w-9 h-9 rounded-full bg-emerald-500/20 border border-emerald-400/50 flex items-center justify-center text-emerald-300 shadow-inner">
                            <Check className="w-5 h-5 stroke-[3]" />
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Bottom Action Bar: Coin Buy Button */}
                    <div className="grid grid-cols-1 gap-2.5 w-full pt-2.5 border-t border-white/10">
                      {/* Jewel Buy Button with Price Number Only */}
                      <JewelButton
                        size="sm"
                        variant="badge"
                        color="amber"
                        disabled={!canAfford}
                        onClick={() => {
                          soundManager.playButtonClick();
                          onBuyBall(b.id, b.cost, b.packQuantity);
                        }}
                        title="Buy with Coins"
                        className="w-full justify-center"
                      >
                        <Coins className="w-3.5 h-3.5 text-amber-100 fill-amber-200 shrink-0" />
                        <span className="tabular-nums font-black text-xs sm:text-sm">{b.cost}</span>
                      </JewelButton>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {backgroundCatalog.map((bg) => {
                const isSelected = selectedBackground === bg.id;
                const isUnlocked = unlockedBackgrounds[bg.id] ?? false;
                const canAfford = coins >= bg.cost;

                return (
                  <div
                    key={bg.id}
                    className={`relative p-3 rounded-2xl border-2 transition-all flex items-center justify-between gap-3 ${
                      isSelected
                        ? 'bg-amber-500/15 border-amber-400 shadow-lg shadow-amber-500/10'
                        : isUnlocked
                        ? 'bg-white/10 border-white/20 hover:border-white/30'
                        : 'bg-white/5 border-white/10'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      {/* 4-cornered realistic miniature landscape scene preview */}
                      <div
                        className={`w-20 h-14 sm:w-24 sm:h-16 rounded-xl overflow-hidden border-2 shadow-md flex items-center justify-center shrink-0 relative bg-slate-950 transition-transform ${
                          isSelected
                            ? 'border-amber-400 ring-2 ring-amber-400/50 shadow-amber-500/20'
                            : 'border-white/25'
                        }`}
                      >
                        <BackgroundMiniScene theme={bg.id} />
                      </div>

                      {/* Name and English description */}
                      <div className="flex flex-col min-w-0">
                        <span className="font-black text-white text-xs sm:text-sm tracking-wide truncate">
                          {bg.name}
                        </span>
                        <span className="text-white/60 text-[10px] sm:text-xs font-medium truncate">
                          {bg.description}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {isUnlocked && !isSelected && (
                        <JewelButton
                          size="sm"
                          variant="orb"
                          color="emerald"
                          onClick={() => {
                            soundManager.playButtonClick();
                            onSelectBackground(bg.id);
                          }}
                        >
                          <Check className="w-4 h-4 text-white" />
                        </JewelButton>
                      )}
                      {isUnlocked && isSelected && (
                        <div className="p-1 text-emerald-400">
                          <Check className="w-6 h-6 stroke-[3]" />
                        </div>
                      )}
                      {!isUnlocked && (
                        <JewelButton
                          size="sm"
                          variant="badge"
                          color="amber"
                          disabled={!canAfford}
                          onClick={() => {
                            soundManager.playButtonClick();
                            onBuyBackground(bg.id, bg.cost);
                          }}
                          title="Unlock Background"
                        >
                          <Lock className="w-3.5 h-3.5 text-amber-200 mr-1" />
                          <Coins className="w-3.5 h-3.5 text-amber-100 fill-amber-200" />
                          <span className="tabular-nums font-black text-sm">{bg.cost}</span>
                        </JewelButton>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
