import React, { useState, useEffect } from 'react';
import { Settings, Volume2, VolumeX, RotateCcw, Home, Target, Star, Coins, X } from 'lucide-react';
import { LevelConfig } from '../types/game';
import { JewelButton } from './JewelButton';
import { CricketStickerBackdrop } from './CricketStickerBackdrop';
import { soundManager } from '../utils/audio';

interface GameHUDProps {
  level: LevelConfig;
  ballsLeft: number;
  maxBalls: number;
  destructionPct: number;
  score: number;
  coins: number;
  superMeter: number;
  isMuted: boolean;
  onToggleMute: () => void;
  onRestartLevel: () => void;
  onGoHome: () => void;
  onOpenShop?: () => void;
}

export const GameHUD: React.FC<GameHUDProps> = ({
  level,
  ballsLeft,
  maxBalls,
  destructionPct,
  coins,
  isMuted,
  onToggleMute,
  onRestartLevel,
  onGoHome,
  onOpenShop,
}) => {
  const [showSettings, setShowSettings] = useState<boolean>(false);
  const [modalScale, setModalScale] = useState<number>(1);
  const isTargetMet = destructionPct >= level.targetDestruction;

  useEffect(() => {
    const updateScale = () => {
      const vh = window.innerHeight;
      const vw = window.innerWidth;
      setModalScale(Math.max(0.4, Math.min(1, (vh - 20) / 260, (vw - 110) / 320)));
    };
    updateScale();
    window.addEventListener('resize', updateScale);
    return () => window.removeEventListener('resize', updateScale);
  }, []);

  return (
    <>
      {/* Top HUD: Clean, Perfectly Spaced 3D Jewel Badges & Buttons */}
      <div className="absolute top-0 left-0 right-0 p-2 sm:p-4 pointer-events-none z-20 flex flex-col gap-1 select-none">
        <div className="flex items-center justify-between gap-2 sm:gap-4">
          {/* 1. Level Indicator: Golden Jewel Badge with ⭐ + Number */}
          <div className="pointer-events-auto">
            <JewelButton asBadge size="sm" variant="badge" color="amber" title="Level">
              <Star className="w-3.5 h-3.5 text-amber-100 fill-amber-200" />
              <span className="tabular-nums font-black text-sm">{level.id}</span>
            </JewelButton>
          </div>

          {/* 2. Destruction Percentage Badge (Glossy Capsule Badge with Target Icon & %) */}
          <div className="pointer-events-auto">
            <JewelButton
              asBadge
              size="md"
              variant="badge"
              color={isTargetMet ? "emerald" : "ruby"}
              isGlowing={isTargetMet}
              title="Destruction Progress"
            >
              <Target className={`w-4 h-4 shrink-0 ${isTargetMet ? 'text-emerald-100' : 'text-rose-100'}`} />
              <span className={`tabular-nums font-black text-sm sm:text-base ${isTargetMet ? 'text-emerald-100' : 'text-amber-100'}`}>
                {destructionPct}%
              </span>
              <span className="text-white/40 text-xs font-bold">/</span>
              <span className="tabular-nums font-bold text-white/70 text-xs">
                {level.targetDestruction}%
              </span>
            </JewelButton>
          </div>

          {/* 3. Action Controls: Coins, and Settings (Restart inside Settings modal) */}
          <div className="flex items-center gap-2 sm:gap-2.5 pointer-events-auto">
            {/* Level Coins Badge (Clickable to open Ability Shop) */}
            <div
              id="hud-coins-counter"
              className="inline-flex transform transition-transform duration-200"
            >
              <JewelButton
                size="sm"
                variant="badge"
                color="amber"
                onClick={() => {
                  soundManager.playButtonClick();
                  onOpenShop?.();
                }}
                title="Coins"
              >
                <Coins className="w-3.5 h-3.5 text-amber-100 fill-amber-200" />
                <span className="tabular-nums text-amber-100 text-xs sm:text-sm font-black">{coins}</span>
              </JewelButton>
            </div>

            {/* Settings Button: Titanium Jewel Orb */}
            <JewelButton
              size="sm"
              variant="orb"
              color="titanium"
              onClick={() => {
                soundManager.playButtonClick();
                setShowSettings(true);
              }}
              title="Settings"
            >
              <Settings className="w-4 h-4 text-white" />
            </JewelButton>
          </div>
        </div>
      </div>

      {/* In-Game Settings Modal (Features Balanced 3-Item Grid: Sound, Restart, Home) */}
      {showSettings && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 select-none touch-manipulation animate-in fade-in duration-150 overflow-hidden">
          <CricketStickerBackdrop />
          <div
            style={{ transform: `scale(${modalScale})` }}
            className="relative z-10 w-full max-w-xs bg-white/10 backdrop-blur-md border-2 border-white/30 rounded-3xl p-5 shadow-2xl flex flex-col items-center gap-4 origin-center"
          >
            {/* Header: Settings Icon & Close Orb */}
            <div className="w-full flex items-center justify-between pb-3 border-b border-white/10">
              <JewelButton asBadge size="sm" variant="orb" color="titanium">
                <Settings className="w-4 h-4 text-white" />
              </JewelButton>
              <JewelButton
                size="sm"
                variant="orb"
                color="titanium"
                onClick={() => {
                  soundManager.playButtonClick();
                  setShowSettings(false);
                }}
                title="Close"
              >
                <X className="w-4 h-4 text-white" />
              </JewelButton>
            </div>

            {/* In-game Settings Options: Balanced 3-Item Grid (Sound, Restart, Home) */}
            <div className="w-full grid grid-cols-3 gap-2.5">
              {/* 1. Sound Toggle Button */}
              <JewelButton
                size="md"
                variant="wide"
                color={isMuted ? 'ruby' : 'emerald'}
                onClick={() => {
                  soundManager.playButtonClick();
                  onToggleMute();
                }}
                isGlowing={!isMuted}
                className="h-14 flex flex-col items-center justify-center gap-1"
                title={isMuted ? "Unmute" : "Mute"}
              >
                {isMuted ? (
                  <VolumeX className="w-6 h-6 text-white" />
                ) : (
                  <Volume2 className="w-6 h-6 text-white" />
                )}
              </JewelButton>

              {/* 2. Restart Level Button (Moved from top HUD into Settings as requested) */}
              <JewelButton
                size="md"
                variant="wide"
                color="sapphire"
                onClick={() => {
                  soundManager.playButtonClick();
                  setShowSettings(false);
                  onRestartLevel();
                }}
                className="h-14 flex flex-col items-center justify-center gap-1"
                title="Restart Level"
              >
                <RotateCcw className="w-6 h-6 text-white" />
              </JewelButton>

              {/* 3. Home Screen Button */}
              <JewelButton
                size="md"
                variant="wide"
                color="amber"
                onClick={() => {
                  soundManager.playButtonClick();
                  setShowSettings(false);
                  onGoHome();
                }}
                className="h-14 flex flex-col items-center justify-center gap-1"
                title="Home"
              >
                <Home className="w-6 h-6 text-white" />
              </JewelButton>
            </div>

            {/* Resume / Close Wide Button */}
            <JewelButton
              size="md"
              variant="wide"
              color="titanium"
              onClick={() => {
                soundManager.playButtonClick();
                setShowSettings(false);
              }}
              className="w-full"
              title="Resume"
            >
              <X className="w-5 h-5 text-white" />
            </JewelButton>
          </div>
        </div>
      )}
    </>
  );
};
