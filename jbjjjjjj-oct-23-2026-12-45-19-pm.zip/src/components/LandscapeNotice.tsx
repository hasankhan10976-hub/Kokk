import React, { useState, useEffect } from 'react';
import { Smartphone, Check } from 'lucide-react';

export const LandscapeNotice: React.FC = () => {
  const [isPortrait, setIsPortrait] = useState<boolean>(false);
  const [dismissed, setDismissed] = useState<boolean>(false);

  useEffect(() => {
    const checkOrientation = () => {
      if (typeof window !== 'undefined') {
        const isNarrow = window.innerHeight > window.innerWidth && window.innerWidth < 768;
        setIsPortrait(isNarrow);
      }
    };

    checkOrientation();
    window.addEventListener('resize', checkOrientation);
    window.addEventListener('orientationchange', checkOrientation);

    return () => {
      window.removeEventListener('resize', checkOrientation);
      window.removeEventListener('orientationchange', checkOrientation);
    };
  }, []);

  if (!isPortrait || dismissed) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center animate-in fade-in select-none touch-manipulation">
      <div className="w-20 h-20 rounded-3xl bg-amber-500/20 border border-amber-400/40 text-amber-400 flex items-center justify-center mb-6">
        <Smartphone className="w-10 h-10 rotate-90 animate-pulse" />
      </div>
      <button
        onClick={() => setDismissed(true)}
        className="w-12 h-12 bg-slate-800 border border-slate-700 hover:bg-slate-700 text-white rounded-2xl flex items-center justify-center cursor-pointer shadow-lg active:scale-95 transition-transform"
      >
        <Check className="w-6 h-6 text-emerald-400" />
      </button>
    </div>
  );
};
