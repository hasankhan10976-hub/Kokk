import React, { useState, useEffect } from 'react';
import { Play, Sun, Sunset, Moon, Palmtree, Lock, Star, Volume2, VolumeX, Image as ImageIcon, X, Check, Coins, Settings, Layers } from 'lucide-react';
import { BackgroundTheme } from '../types/game';
import { LEVEL_CONFIGS } from '../utils/bambooHuts';
import { JewelButton } from './JewelButton';
import { BambooBasketIcon } from './BambooBasketIcon';
import { CricketStickerBackdrop } from './CricketStickerBackdrop';
import { soundManager } from '../utils/audio';

interface HomeScreenProps {
  currentLevelId: number;
  unlockedLevelMax: number;
  selectedBackground: BackgroundTheme;
  onSelectBackground: (bg: BackgroundTheme) => void;
  onSelectLevel: (levelId: number) => void;
  onPlay: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
  savedCoins: number;
  onOpenShop: () => void;
  unlockedBackgrounds?: Record<BackgroundTheme, boolean>;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  currentLevelId,
  unlockedLevelMax,
  selectedBackground,
  onSelectBackground,
  onSelectLevel,
  onPlay,
  isMuted,
  onToggleMute,
  savedCoins,
  onOpenShop,
  unlockedBackgrounds,
}) => {
  const [showLevelModal, setShowLevelModal] = useState<boolean>(false);
  const [showSettingsModal, setShowSettingsModal] = useState<boolean>(false);
  const [playBtnScale, setPlayBtnScale] = useState<number>(1);
  const [modalScale, setModalScale] = useState<number>(1);

  useEffect(() => {
    const updateScale = () => {
      const vh = window.innerHeight;
      const vw = window.innerWidth;
      // Scale center play button if viewport height is short
      setPlayBtnScale(Math.max(0.45, Math.min(1, (vh - 64) / 170, (vw - 40) / 280)));
      // Scale Level/Settings modal cards if viewport height is short
      setModalScale(Math.max(0.4, Math.min(1, (vh - 20) / 310, (vw - 110) / 360)));
    };
    updateScale();
    window.addEventListener('resize', updateScale);
    return () => window.removeEventListener('resize', updateScale);
  }, []);

  return (
    <div className="absolute inset-0 z-30 flex flex-col justify-between p-2.5 sm:p-5 select-none pointer-events-auto overflow-hidden">
      {/* Top Bar: Balanced, Perfectly Spaced Jewel Buttons & Badges */}
      <div className="flex items-center justify-between gap-2 sm:gap-4 shrink-0">
        {/* Level Indicator Orb/Badge */}
        <JewelButton
          size="md"
          variant="badge"
          color="amber"
          onClick={() => {
            soundManager.playButtonClick();
            setShowLevelModal(true);
          }}
          title="Select Level"
        >
          <Star className="w-4 h-4 text-amber-100 fill-amber-200" />
          <span className="tabular-nums font-black text-sm sm:text-base">{currentLevelId}</span>
          <Layers className="w-3.5 h-3.5 text-white/70 ml-0.5" />
        </JewelButton>

        {/* Right Top Controls: Neat, Balanced Row of Jewel Orbs */}
        <div className="flex items-center gap-2 sm:gap-2.5">
          {/* Saved Coins Counter: Non-clickable display badge as requested */}
          <JewelButton
            asBadge
            size="md"
            variant="badge"
            color="amber"
            title="Saved Coins"
          >
            <Coins className="w-4 h-4 text-amber-100 fill-amber-200" />
            <span className="font-black text-amber-100 text-sm sm:text-base tabular-nums">{savedCoins}</span>
          </JewelButton>

          {/* Shop Button (Woven Basket Icon - opens Shop modal for balls and backgrounds) */}
          <JewelButton
            size="sm"
            variant="orb"
            color="sunset"
            onClick={() => {
              soundManager.playButtonClick();
              onOpenShop();
            }}
            title="Shop"
          >
            <BambooBasketIcon className="w-5 h-5" />
          </JewelButton>

          {/* Settings Button */}
          <JewelButton
            size="sm"
            variant="orb"
            color="titanium"
            onClick={() => {
              soundManager.playButtonClick();
              setShowSettingsModal(true);
            }}
            title="Settings"
          >
            <Settings className="w-4 h-4 text-white" />
          </JewelButton>
        </div>
      </div>

      {/* Center: Dynamic Batsman Striking Cricket Ball Play Button (Restored from previous version) */}
      <div
        style={{ transform: `scale(${playBtnScale})` }}
        className="flex flex-col items-center justify-center my-auto origin-center"
      >
        <button
          onClick={() => {
            soundManager.playButtonClick();
            onPlay();
          }}
          onTouchStart={(e) => {
            e.preventDefault();
            soundManager.playButtonClick();
            onPlay();
          }}
          className="group relative flex items-center justify-center p-2 transition-transform hover:scale-105 active:scale-95 cursor-pointer outline-none select-none touch-manipulation"
          title="Play"
        >
          {/* Composite Cricket Scene: Batsman poised with bat aiming to smash the cricket ball */}
          <div className="relative flex items-center justify-center">
            {/* Ambient Backlight Aura */}
            <div className="absolute w-44 h-44 rounded-full bg-red-600/25 blur-2xl group-hover:bg-red-500/40 transition-colors pointer-events-none" />

            {/* Dynamic Batsman Illustration (SVG Vector) positioned in full batting swing towards the ball */}
            <div className="relative z-10 flex items-center">
              <svg
                viewBox="0 0 160 180"
                className="w-32 h-36 sm:w-40 sm:h-44 -mr-6 sm:-mr-8 filter drop-shadow-xl select-none pointer-events-none"
              >
                {/* Batting Shadow on ground */}
                <ellipse cx="65" cy="172" rx="45" ry="7" fill="rgba(0,0,0,0.35)" />

                {/* Left Leg / Front Pad */}
                <path
                  d="M68 115 L88 165 L76 168 L58 118 Z"
                  fill="#f1f5f9"
                  stroke="#cbd5e1"
                  strokeWidth="2"
                />
                <line x1="68" y1="130" x2="80" y2="132" stroke="#94a3b8" strokeWidth="2" />
                <line x1="72" y1="145" x2="83" y2="147" stroke="#94a3b8" strokeWidth="2" />

                {/* Right Leg / Back Leg */}
                <path
                  d="M48 112 L40 162 L28 163 L38 114 Z"
                  fill="#e2e8f0"
                  stroke="#94a3b8"
                  strokeWidth="2"
                />
                {/* Shoes */}
                <path d="M74 167 L94 168 L92 173 L72 173 Z" fill="#ffffff" stroke="#64748b" strokeWidth="1.5" />
                <path d="M26 162 L42 163 L40 168 L24 167 Z" fill="#ffffff" stroke="#64748b" strokeWidth="1.5" />

                {/* Torso / Jersey (White Cricket Uniform with Team Stripe) */}
                <path
                  d="M42 65 L75 62 L82 118 L46 116 Z"
                  fill="#f8fafc"
                  stroke="#cbd5e1"
                  strokeWidth="2"
                />
                <path d="M60 63 L65 117" stroke="#3b82f6" strokeWidth="3" strokeLinecap="round" />

                {/* Head / Helmet with Visor and Grille */}
                <circle cx="58" cy="42" r="14" fill="#1e3a8a" stroke="#172554" strokeWidth="2" />
                <path d="M62 42 L78 44 L74 48 L60 46 Z" fill="#1d4ed8" />
                <path d="M66 45 L74 46 L70 55 L62 53 Z" fill="none" stroke="#94a3b8" strokeWidth="1.8" />

                {/* Left Arm (Reaching forward) */}
                <path
                  d="M72 70 L95 82 L90 92 L68 80 Z"
                  fill="#f1f5f9"
                  stroke="#cbd5e1"
                  strokeWidth="2"
                />

                {/* Right Arm (Backlift guiding the bat) */}
                <path
                  d="M45 68 L68 76 L65 86 L42 78 Z"
                  fill="#e2e8f0"
                  stroke="#cbd5e1"
                  strokeWidth="2"
                />

                {/* Batting Gloves */}
                <circle cx="94" cy="86" r="7" fill="#ffffff" stroke="#2563eb" strokeWidth="2" />
                <circle cx="86" cy="88" r="6" fill="#e2e8f0" stroke="#2563eb" strokeWidth="2" />

                {/* CRICKET BAT - Poised in powerful forward swing aimed directly at the ball */}
                <g className="transition-transform group-hover:rotate-3 origin-[90px_88px]">
                  <path
                    d="M86 86 L108 80 L110 85 L88 91 Z"
                    fill="#ffffff"
                    stroke="#0284c7"
                    strokeWidth="1.5"
                  />
                  <path
                    d="M106 79 L152 64 L158 84 L110 88 Z"
                    fill="#f59e0b"
                    stroke="#b45309"
                    strokeWidth="2.5"
                  />
                  <line x1="114" y1="83" x2="152" y2="70" stroke="#d97706" strokeWidth="1.5" />
                  <line x1="116" y1="86" x2="154" y2="75" stroke="#d97706" strokeWidth="1.5" />
                  <path d="M124 74 L142 68 L144 76 L126 81 Z" fill="#dc2626" />
                </g>
              </svg>

              {/* CRICKET BALL PLAY BUTTON (Circular, center play symbol, 3D raised seam) */}
              <div className="relative w-22 h-22 sm:w-28 sm:h-28 rounded-full shadow-2xl flex items-center justify-center group-hover:scale-105 active:scale-95 transition-transform">
                {/* 3D Ball Sphere (Deep red leather gradient with specular glow) */}
                <div
                  className="w-full h-full rounded-full border-4 border-amber-300/80 shadow-2xl relative overflow-hidden flex items-center justify-center"
                  style={{
                    background: 'radial-gradient(circle at 35% 30%, #ef4444 0%, #dc2626 40%, #991b1b 75%, #450a0a 100%)',
                  }}
                >
                  {/* Realistic Curved Stitched White Seam */}
                  <svg viewBox="0 0 100 100" className="absolute inset-0 w-full h-full pointer-events-none">
                    <path
                      d="M20 90 Q50 48 80 10"
                      fill="none"
                      stroke="#ffffff"
                      strokeWidth="3.5"
                      strokeLinecap="round"
                    />
                    <path
                      d="M20 90 Q50 48 80 10"
                      fill="none"
                      stroke="#f87171"
                      strokeWidth="4"
                      strokeDasharray="2,5"
                      strokeLinecap="butt"
                    />
                    <path
                      d="M23 93 Q53 51 83 13"
                      fill="none"
                      stroke="#ffffff"
                      strokeWidth="1.5"
                      opacity="0.75"
                    />
                  </svg>

                  {/* Specular Highlight Sheen */}
                  <div className="absolute top-2 left-4 w-10 h-6 rounded-full bg-white/40 blur-[2px] pointer-events-none" />

                  {/* Center PLAY SYMBOL (▶) - Pure White Glowing Embossed Symbol directly on the Red Cricket Ball */}
                  <div className="relative z-10 flex items-center justify-center pointer-events-none">
                    <Play className="w-9 h-9 sm:w-11 sm:h-11 text-white fill-white ml-1 filter drop-shadow-[0_2px_8px_rgba(255,255,255,0.9)] drop-shadow-[0_0_18px_rgba(255,255,255,0.7)] group-hover:scale-110 group-hover:drop-shadow-[0_0_24px_rgba(255,255,255,1)] transition-all duration-200" />
                  </div>
                </div>

                {/* Orbit Pulse Ring on Idle */}
                <div className="absolute inset-0 rounded-full border-2 border-amber-300/40 animate-ping opacity-40 pointer-events-none" />
              </div>
            </div>
          </div>
        </button>
      </div>

      {/* Level Selection Modal */}
      {showLevelModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 select-none touch-manipulation animate-in fade-in duration-150 overflow-hidden">
          <CricketStickerBackdrop />
          <div
            style={{ transform: `scale(${modalScale})` }}
            className="relative z-10 w-full max-w-sm bg-white/10 backdrop-blur-md border-2 border-white/30 rounded-3xl p-4 sm:p-5 shadow-2xl flex flex-col items-center origin-center"
          >
            {/* Header: Level Badge & Close Orb */}
            <div className="w-full flex items-center justify-between pb-3 border-b border-white/10 mb-2 shrink-0">
              <JewelButton asBadge size="sm" variant="orb" color="amber">
                <Star className="w-4 h-4 fill-amber-200 text-amber-100" />
              </JewelButton>
              <JewelButton
                size="sm"
                variant="orb"
                color="titanium"
                onClick={() => {
                  soundManager.playButtonClick();
                  setShowLevelModal(false);
                }}
                title="Close"
              >
                <X className="w-4 h-4 text-white" />
              </JewelButton>
            </div>

            {/* Level Selection Grid: Jewel Buttons */}
            <div className="w-full grid grid-cols-3 gap-2.5 my-2 max-h-[180px] sm:max-h-[220px] overflow-y-auto p-1">
              {LEVEL_CONFIGS.map((lvl) => {
                const isUnlocked = lvl.id <= unlockedLevelMax;
                const isSelected = lvl.id === currentLevelId;

                return (
                  <JewelButton
                    key={lvl.id}
                    size="md"
                    variant="wide"
                    className="h-16"
                    color={isSelected ? "amber" : isUnlocked ? "sapphire" : "titanium"}
                    isGlowing={isSelected}
                    disabled={!isUnlocked}
                    onClick={() => {
                      soundManager.playButtonClick();
                      if (isUnlocked) {
                        onSelectLevel(lvl.id);
                        setShowLevelModal(false);
                      }
                    }}
                  >
                    <div className="flex flex-col items-center gap-0.5">
                      <span className="font-black text-lg tabular-nums">{lvl.id}</span>
                      {isSelected ? (
                        <Star className="w-3.5 h-3.5 text-amber-100 fill-amber-200" />
                      ) : isUnlocked ? (
                        <Star className="w-3 h-3 text-white/80" />
                      ) : (
                        <Lock className="w-3 h-3 text-white/50" />
                      )}
                    </div>
                  </JewelButton>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Home Screen Settings Modal (Sound toggle only) */}
      {showSettingsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 select-none touch-manipulation animate-in fade-in duration-150 overflow-hidden">
          <CricketStickerBackdrop />
          <div
            style={{ transform: `scale(${modalScale})` }}
            className="relative z-10 w-full max-w-xs bg-white/10 backdrop-blur-md border-2 border-white/30 rounded-3xl p-5 shadow-2xl flex flex-col items-center gap-4 origin-center"
          >
            {/* Header: Settings Badge & Close Orb */}
            <div className="w-full flex items-center justify-between pb-3 border-b border-white/10">
              <JewelButton asBadge size="sm" variant="orb" color="titanium">
                <Settings className="w-4 h-4 text-white" />
              </JewelButton>
              <JewelButton
                size="sm"
                variant="orb"
                color="titanium"
                onClick={() => {
                  soundManager.playButtonClick();
                  setShowSettingsModal(false);
                }}
                title="Close"
              >
                <X className="w-4 h-4 text-white" />
              </JewelButton>
            </div>

            {/* Sound Toggle Button (Jewel Button) */}
            <JewelButton
              size="lg"
              variant="wide"
              className="w-full h-16"
              color={isMuted ? 'ruby' : 'emerald'}
              isGlowing={!isMuted}
              onClick={() => {
                soundManager.playButtonClick();
                onToggleMute();
              }}
              title={isMuted ? "Unmute" : "Mute"}
            >
              {isMuted ? (
                <VolumeX className="w-8 h-8 text-white" />
              ) : (
                <Volume2 className="w-8 h-8 text-white" />
              )}
            </JewelButton>

            {/* Close Button */}
            <JewelButton
              size="md"
              variant="wide"
              color="titanium"
              className="w-full"
              onClick={() => {
                soundManager.playButtonClick();
                setShowSettingsModal(false);
              }}
              title="Close"
            >
              <X className="w-5 h-5 text-white" />
            </JewelButton>
          </div>
        </div>
      )}

    </div>
  );
};
