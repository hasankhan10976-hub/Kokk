import React from 'react';

/**
 * CricketStickerBackdrop
 * 100% Code-generated (SVG) Cricket Sticker Backdrop.
 * Zero image files / raster images used.
 * Features discrete die-cut stickers positioned strictly on the left and right gutters.
 * Each sticker is completely contained within its safe bounding box — NO clipping,
 * NO pattern border slicing, and NO stickers going outside the screen.
 * Background is a vibrant full-screen blue gradient.
 */
export const CricketStickerBackdrop: React.FC<{ className?: string }> = ({ className = '' }) => {
  return (
    <div
      className={`absolute inset-0 w-full h-full pointer-events-none overflow-hidden select-none bg-gradient-to-b from-sky-600 via-blue-700 to-indigo-950 ${className}`}
      aria-hidden="true"
    >
      {/* Atmospheric Volumetric Stadium Sunbeams & Horizon Lawn Glow */}
      <div className="absolute inset-0 opacity-40 bg-[radial-gradient(circle_at_50%_18%,rgba(254,240,138,0.42)_0%,rgba(56,189,248,0.18)_38%,transparent_72%)]" />
      <div className="absolute inset-x-0 bottom-0 h-1/2 opacity-40 bg-[radial-gradient(ellipse_at_50%_100%,rgba(22,163,74,0.4)_0%,transparent_70%)]" />
      {/* Shared SVG Gradients Definition */}
      <svg className="absolute w-0 h-0 overflow-hidden" aria-hidden="true">
        <defs>
          <radialGradient id="sticker-leather-grad" cx="35%" cy="30%" r="70%">
            <stop offset="0%" stopColor="#ef4444" />
            <stop offset="55%" stopColor="#dc2626" />
            <stop offset="85%" stopColor="#991b1b" />
            <stop offset="100%" stopColor="#450a0a" />
          </radialGradient>

          <linearGradient id="sticker-fire-grad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#fde047" />
            <stop offset="35%" stopColor="#f97316" />
            <stop offset="80%" stopColor="#ef4444" />
            <stop offset="100%" stopColor="#b91c1c" />
          </linearGradient>

          <radialGradient id="sticker-bomb-grad" cx="30%" cy="30%" r="70%">
            <stop offset="0%" stopColor="#71717a" />
            <stop offset="45%" stopColor="#3f3f46" />
            <stop offset="80%" stopColor="#18181b" />
            <stop offset="100%" stopColor="#09090b" />
          </radialGradient>

          <radialGradient id="sticker-acid-grad" cx="35%" cy="30%" r="70%">
            <stop offset="0%" stopColor="#bef264" />
            <stop offset="45%" stopColor="#84cc16" />
            <stop offset="80%" stopColor="#16a34a" />
            <stop offset="100%" stopColor="#064e3b" />
          </radialGradient>
        </defs>
      </svg>

      {/* LEFT SIDE STICKER COLUMN: Safely padded, discrete, zero clipping even on ultra-short viewports */}
      <div className="absolute left-2 sm:left-6 top-2 bottom-2 w-[min(4rem,16vw)] sm:w-20 flex flex-col justify-evenly items-center pointer-events-none z-0">
        {/* 1. Classic Red Leather Cricket Ball Sticker */}
        <div className="transform -rotate-6 transition-transform hover:scale-105">
          <svg viewBox="0 0 64 64" className="w-[min(3.25rem,22vh)] h-[min(3.25rem,22vh)] sm:w-[min(4rem,22vh)] sm:h-[min(4rem,22vh)] filter drop-shadow-[0_2px_4px_rgba(0,0,0,0.18)]">
            {/* White Die-cut Sticker Base */}
            <circle cx="32" cy="32" r="26" fill="#ffffff" />
            {/* Inner Red Leather Ball */}
            <circle cx="32" cy="32" r="22" fill="url(#sticker-leather-grad)" />
            {/* Curved White Seam */}
            <path
              d="M18 46 Q32 30 46 18"
              fill="none"
              stroke="#ffffff"
              strokeWidth="2.5"
              strokeLinecap="round"
            />
            <path
              d="M18 46 Q32 30 46 18"
              fill="none"
              stroke="#fca5a5"
              strokeWidth="2.5"
              strokeDasharray="1.5 3"
            />
            {/* Specular Highlight */}
            <ellipse cx="25" cy="23" rx="7" ry="4" fill="#ffffff" opacity="0.45" transform="rotate(-30 25 23)" />
          </svg>
        </div>

        {/* 2. Cricket Player / Batsman Sticker */}
        <div className="transform rotate-8 transition-transform hover:scale-105">
          <svg viewBox="0 0 64 64" className="w-[min(3.25rem,22vh)] h-[min(3.25rem,22vh)] sm:w-[min(4rem,22vh)] sm:h-[min(4rem,22vh)] filter drop-shadow-[0_2px_4px_rgba(0,0,0,0.18)]">
            {/* White Die-cut Sticker Backing */}
            <path
              d="M26 10 L38 10 L44 20 L48 30 L54 30 L52 46 L44 44 L40 54 L30 55 L32 42 L22 54 L14 53 L18 38 L10 32 L14 20 Z"
              fill="#ffffff"
              stroke="#ffffff"
              strokeWidth="4"
              strokeLinejoin="round"
            />
            {/* Batsman Helmet */}
            <circle cx="32" cy="18" r="8" fill="#1e3a8a" />
            <path d="M34 18 L40 19 L38 23 L32 21 Z" fill="#94a3b8" />
            {/* Jersey */}
            <path d="M24 25 L40 24 L42 41 L22 39 Z" fill="#f8fafc" stroke="#cbd5e1" strokeWidth="1" />
            <line x1="32" y1="25" x2="33" y2="40" stroke="#2563eb" strokeWidth="2" strokeLinecap="round" />
            {/* Batting Pads */}
            <rect x="23" y="41" width="6" height="13" rx="2" fill="#f1f5f9" stroke="#cbd5e1" strokeWidth="1" />
            <rect x="33" y="41" width="6" height="13" rx="2" fill="#e2e8f0" stroke="#cbd5e1" strokeWidth="1" />
            {/* Wooden Bat */}
            <path d="M42 27 L54 39 L49 43 L37 31 Z" fill="#d97706" stroke="#92400e" strokeWidth="1" />
            <line x1="37" y1="31" x2="34" y2="28" stroke="#ffffff" strokeWidth="2.5" strokeLinecap="round" />
            {/* Batting Glove */}
            <circle cx="34" cy="28" r="2.5" fill="#3b82f6" />
          </svg>
        </div>

        {/* 3. Fireball Ability Ball Sticker */}
        <div className="transform -rotate-8 transition-transform hover:scale-105">
          <svg viewBox="0 0 64 64" className="w-[min(3.25rem,22vh)] h-[min(3.25rem,22vh)] sm:w-[min(4rem,22vh)] sm:h-[min(4rem,22vh)] filter drop-shadow-[0_2px_4px_rgba(0,0,0,0.18)]">
            {/* White Die-cut Sticker Backing */}
            <path
              d="M27 9 Q37 18 48 14 Q44 26 56 32 Q50 44 52 54 Q37 60 22 55 Q7 48 10 30 Q10 18 27 9 Z"
              fill="#ffffff"
            />
            {/* Outer Corona */}
            <path
              d="M28 12 Q37 20 45 16 Q42 27 52 33 Q47 43 49 51 Q36 57 23 52 Q10 46 13 31 Q13 20 28 12 Z"
              fill="url(#sticker-fire-grad)"
            />
            {/* Flaming Sphere */}
            <circle cx="32" cy="35" r="14" fill="#ef4444" />
            <circle cx="32" cy="35" r="9" fill="#f59e0b" />
            <circle cx="32" cy="35" r="5" fill="#fef08a" />
            <path d="M31 39 Q28 33 32 29 Q36 34 33 39 Z" fill="#ffffff" opacity="0.9" />
          </svg>
        </div>
      </div>

      {/* RIGHT SIDE STICKER COLUMN: Safely padded inside screen, discrete, zero clipping even on ultra-short viewports */}
      <div className="absolute right-2 sm:right-6 top-2 bottom-2 w-[min(4rem,16vw)] sm:w-20 flex flex-col justify-evenly items-center pointer-events-none z-0">
        {/* 4. Metallic Bomb Ability Ball Sticker */}
        <div className="transform rotate-6 transition-transform hover:scale-105">
          <svg viewBox="0 0 64 64" className="w-[min(3.25rem,22vh)] h-[min(3.25rem,22vh)] sm:w-[min(4rem,22vh)] sm:h-[min(4rem,22vh)] filter drop-shadow-[0_2px_4px_rgba(0,0,0,0.18)]">
            {/* White Die-cut Sticker Backing */}
            <circle cx="32" cy="36" r="23" fill="#ffffff" />
            <rect x="28" y="10" width="8" height="10" rx="2" fill="#ffffff" />
            <path d="M32 10 Q40 4 46 8" fill="none" stroke="#ffffff" strokeWidth="4" strokeLinecap="round" />
            <circle cx="46" cy="8" r="6" fill="#ffffff" />

            {/* Bomb Cap & Fuse */}
            <rect x="29" y="13" width="6" height="6" rx="1.5" fill="#71717a" />
            <path d="M32 14 Q38 8 44 10" fill="none" stroke="#eab308" strokeWidth="2.5" strokeLinecap="round" />
            <circle cx="45" cy="9" r="3.5" fill="#ef4444" />
            <circle cx="45" cy="9" r="1.5" fill="#fef08a" />

            {/* Bomb Body */}
            <circle cx="32" cy="36" r="20" fill="url(#sticker-bomb-grad)" />
            <ellipse cx="26" cy="30" rx="5" ry="3" fill="#ffffff" opacity="0.45" transform="rotate(-25 26 30)" />
          </svg>
        </div>

        {/* 5. Acid / Poison Green Orb Sticker */}
        <div className="transform -rotate-6 transition-transform hover:scale-105">
          <svg viewBox="0 0 64 64" className="w-[min(3.25rem,22vh)] h-[min(3.25rem,22vh)] sm:w-[min(4rem,22vh)] sm:h-[min(4rem,22vh)] filter drop-shadow-[0_2px_4px_rgba(0,0,0,0.18)]">
            {/* White Die-cut Sticker Backing */}
            <circle cx="32" cy="32" r="22" fill="#ffffff" />
            <circle cx="49" cy="22" r="4.5" fill="#ffffff" />
            <circle cx="16" cy="43" r="3.5" fill="#ffffff" />

            {/* Acid Sphere */}
            <circle cx="32" cy="32" r="19" fill="url(#sticker-acid-grad)" />
            <circle cx="49" cy="22" r="3" fill="#84cc16" />
            <circle cx="16" cy="43" r="2" fill="#22c55e" />

            {/* Bio Rings */}
            <circle cx="29" cy="34" r="5" fill="#ecfccb" opacity="0.6" />
            <circle cx="37" cy="29" r="3" fill="#ecfccb" opacity="0.75" />
            <circle cx="35" cy="38" r="2.5" fill="#ecfccb" opacity="0.6" />
            <ellipse cx="27" cy="25" rx="5" ry="2.5" fill="#ffffff" opacity="0.55" transform="rotate(-30 27 25)" />
          </svg>
        </div>

        {/* 6. Mini Cricket Bat & Golden Star Sticker */}
        <div className="transform rotate-10 transition-transform hover:scale-105">
          <svg viewBox="0 0 64 64" className="w-[min(3.25rem,22vh)] h-[min(3.25rem,22vh)] sm:w-[min(4rem,22vh)] sm:h-[min(4rem,22vh)] filter drop-shadow-[0_2px_4px_rgba(0,0,0,0.18)]">
            {/* Wooden Bat */}
            <g transform="translate(18, 30) rotate(35)">
              <rect x="-4" y="-22" width="8" height="44" rx="4" fill="#ffffff" />
              <rect x="-3" y="-21" width="6" height="28" rx="2" fill="#d97706" />
              <rect x="-2" y="7" width="4" height="14" rx="1.5" fill="#ef4444" />
            </g>
            {/* Golden Star */}
            <g transform="translate(42, 22)">
              <path
                d="M0 -12 L3.5 -3.5 L12 -3.5 L5 2.5 L7.5 11 L0 6 L-7.5 11 L-5 2.5 L-12 -3.5 L-3.5 -3.5 Z"
                fill="#ffffff"
                stroke="#ffffff"
                strokeWidth="3"
                strokeLinejoin="round"
              />
              <path
                d="M0 -12 L3.5 -3.5 L12 -3.5 L5 2.5 L7.5 11 L0 6 L-7.5 11 L-5 2.5 L-12 -3.5 L-3.5 -3.5 Z"
                fill="#facc15"
                stroke="#ca8a04"
                strokeWidth="1"
              />
            </g>
          </svg>
        </div>
      </div>
    </div>
  );
};
