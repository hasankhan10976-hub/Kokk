import React, { useState, useEffect } from 'react';
import { Star, RotateCcw, Play, Check, X, Home, Target, Coins } from 'lucide-react';
import { LevelConfig } from '../types/game';
import { JewelButton } from './JewelButton';
import { CricketStickerBackdrop } from './CricketStickerBackdrop';
import { soundManager } from '../utils/audio';

interface LevelCompleteModalProps {
  isSuccess: boolean;
  level: LevelConfig;
  destructionPct: number;
  score?: number;
  ballsUsed: number;
  coinsEarned?: number;
  levelCoinsSaved?: number;
  totalSavedCoins?: number;
  onNextLevel: () => void;
  onRetry: () => void;
  onGoHome: () => void;
  hasNextLevel: boolean;
}

export const LevelCompleteModal: React.FC<LevelCompleteModalProps> = ({
  isSuccess,
  level,
  destructionPct,
  ballsUsed,
  coinsEarned,
  levelCoinsSaved = 0,
  totalSavedCoins = 0,
  onNextLevel,
  onRetry,
  onGoHome,
  hasNextLevel,
}) => {
  const [modalScale, setModalScale] = useState<number>(1);

  useEffect(() => {
    const updateScale = () => {
      const vh = window.innerHeight;
      const vw = window.innerWidth;
      // Natural modal height is ~340px and width with side sticker gutters is ~440px
      const scaleH = (vh - 20) / 345;
      const scaleW = (vw - 110) / 320;
      setModalScale(Math.max(0.35, Math.min(1, scaleH, scaleW)));
    };
    updateScale();
    window.addEventListener('resize', updateScale);
    return () => window.removeEventListener('resize', updateScale);
  }, []);

  let stars = 0;
  if (isSuccess) {
    stars = 1;
    if (destructionPct >= level.targetDestruction + 15) stars = 2;
    if (destructionPct >= 95 || (destructionPct >= level.targetDestruction + 20 && ballsUsed <= level.balls - 2)) stars = 3;
  }

  const displayedCoins = coinsEarned ?? (levelCoinsSaved > 0 ? levelCoinsSaved : totalSavedCoins);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-3 select-none touch-manipulation animate-in fade-in duration-200 overflow-hidden">
      <CricketStickerBackdrop />
      <div
        style={{ transform: `scale(${modalScale})` }}
        className="relative z-10 w-full max-w-xs bg-white/10 backdrop-blur-md border-2 border-white/30 rounded-3xl p-4 sm:p-5 shadow-2xl flex flex-col items-center text-center origin-center transition-transform duration-150"
      >
        {/* Header Icon (No Trophy) */}
        <div
          className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-2 shadow-lg ${
            isSuccess
              ? 'bg-emerald-500/20 border border-emerald-400/40 text-emerald-300'
              : 'bg-red-500/20 border border-red-400/40 text-red-300'
          }`}
        >
          {isSuccess ? <Check className="w-8 h-8 stroke-[3]" /> : <X className="w-8 h-8 stroke-[3]" />}
        </div>

        {/* Stars */}
        <div className="flex items-center gap-2 my-2">
          {[1, 2, 3].map((starNum) => (
            <Star
              key={starNum}
              className={`w-7 h-7 transition-all ${
                isSuccess && starNum <= stars
                  ? 'text-amber-400 fill-amber-400 scale-110 drop-shadow-md'
                  : 'text-white/20'
              }`}
            />
          ))}
        </div>

        {/* Stats Grid: Purely Destruction Target and Balls Used (Zero Trophy, Zero Score, No Dark Background) */}
        <div className="w-full grid grid-cols-2 gap-2 my-3 bg-white/10 backdrop-blur-md p-2.5 rounded-2xl border border-white/20">
          <div className="flex flex-col items-center">
            <Target className="w-4 h-4 text-rose-300 mb-1" />
            <span
              className={`text-base font-black tabular-nums ${
                isSuccess ? 'text-emerald-300' : 'text-amber-300'
              }`}
            >
              {destructionPct}%
            </span>
          </div>

          <div className="flex flex-col items-center border-l border-white/20">
            <div className="w-3.5 h-3.5 rounded-full bg-red-500 border border-red-300 mb-1" />
            <span className="text-base font-black text-white tabular-nums">
              {ballsUsed}/{level.balls}
            </span>
          </div>
        </div>

        {/* Single Coins Badge (Only one type of money) */}
        {displayedCoins > 0 && (
          <div className="w-full flex items-center justify-center bg-white/10 backdrop-blur-md border border-white/20 px-3.5 py-2 rounded-2xl mb-3 gap-2">
            <Coins className="w-4 h-4 fill-amber-300 text-amber-300" />
            <span className="font-black text-amber-300 text-sm tabular-nums">+{displayedCoins}</span>
          </div>
        )}

        {/* Action Buttons: (Home, Retry, Next) - 3D Jewel Buttons */}
        <div className="w-full flex items-center justify-center gap-2.5 mt-2">
          <JewelButton
            size="md"
            variant="orb"
            color="amber"
            onClick={() => {
              soundManager.playButtonClick();
              onGoHome();
            }}
            title="Home"
          >
            <Home className="w-5 h-5 text-white" />
          </JewelButton>

          <JewelButton
            size="md"
            variant="orb"
            color="sapphire"
            onClick={() => {
              soundManager.playButtonClick();
              onRetry();
            }}
            title="Retry"
          >
            <RotateCcw className="w-5 h-5 text-white" />
          </JewelButton>

          {isSuccess && hasNextLevel && (
            <JewelButton
              size="md"
              variant="wide"
              color="emerald"
              className="flex-1 h-12"
              isGlowing
              onClick={() => {
                soundManager.playButtonClick();
                onNextLevel();
              }}
              title="Next Level"
            >
              <Play className="w-6 h-6 fill-white text-white ml-0.5" />
            </JewelButton>
          )}
        </div>
      </div>
    </div>
  );
};
