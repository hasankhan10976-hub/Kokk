import React, { useRef, useState, useEffect, useCallback } from 'react';
import { soundManager } from '../utils/audio';

interface ControlsOverlayProps {
  selectedPowerRatio: number; // 0.0 to 1.0
  onUpdatePowerRatio: (ratio: number) => void;
  onPowerReleased: (ratio: number) => void;
  lastTimingRating: string | null;
  isReadyForDelivery?: boolean;
}

export const ControlsOverlay: React.FC<ControlsOverlayProps> = ({
  selectedPowerRatio,
  onUpdatePowerRatio,
  onPowerReleased,
  lastTimingRating,
  isReadyForDelivery = true,
}) => {
  const [isHolding, setIsHolding] = useState<boolean>(false);
  const isHoldingRef = useRef<boolean>(false);
  const currentRatioRef = useRef<number>(selectedPowerRatio);
  const animFrameRef = useRef<number | null>(null);
  const lastTimeRef = useRef<number | null>(null);

  const isReadyRef = useRef<boolean>(isReadyForDelivery);
  useEffect(() => {
    isReadyRef.current = isReadyForDelivery;
  }, [isReadyForDelivery]);

  // Sync ref with external updates (e.g. when power resets after ball hit)
  useEffect(() => {
    currentRatioRef.current = selectedPowerRatio;
  }, [selectedPowerRatio]);

  // Press and hold charging loop
  const startCharging = useCallback(() => {
    if (!isReadyRef.current || isHoldingRef.current) return;
    isHoldingRef.current = true;
    setIsHolding(true);
    currentRatioRef.current = 0;
    onUpdatePowerRatio(0);
    lastTimeRef.current = performance.now();
    soundManager.playButtonClick();

    const chargeStep = (now: number) => {
      if (!isHoldingRef.current) return;
      if (lastTimeRef.current === null) lastTimeRef.current = now;
      const dt = now - lastTimeRef.current;
      lastTimeRef.current = now;

      // Charge up smoothly: goes from 0 to 100% in ~1.3 seconds
      const chargeRate = 1.0 / 1300;
      const nextRatio = Math.min(1.0, currentRatioRef.current + dt * chargeRate);
      currentRatioRef.current = nextRatio;
      onUpdatePowerRatio(Math.round(nextRatio * 100) / 100);

      if (nextRatio < 1.0 && isHoldingRef.current) {
        animFrameRef.current = requestAnimationFrame(chargeStep);
      }
    };

    if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    animFrameRef.current = requestAnimationFrame(chargeStep);
  }, [onUpdatePowerRatio]);

  const stopCharging = useCallback(() => {
    const wasHolding = isHoldingRef.current;
    isHoldingRef.current = false;
    setIsHolding(false);
    lastTimeRef.current = null;
    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = null;
    }

    if (wasHolding) {
      const finalRatio = Math.max(0.2, currentRatioRef.current);
      currentRatioRef.current = finalRatio;
      onUpdatePowerRatio(Math.round(finalRatio * 100) / 100);
      onPowerReleased(finalRatio);
    }
  }, [onUpdatePowerRatio, onPowerReleased]);

  // Global window listeners to ensure release is always caught
  useEffect(() => {
    const handleGlobalPointerUp = () => {
      if (isHoldingRef.current) {
        stopCharging();
      }
    };

    window.addEventListener('pointerup', handleGlobalPointerUp);
    window.addEventListener('pointercancel', handleGlobalPointerUp);

    return () => {
      window.removeEventListener('pointerup', handleGlobalPointerUp);
      window.removeEventListener('pointercancel', handleGlobalPointerUp);
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [stopCharging]);

  // Spacebar press-and-hold support
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.repeat) return;
      if (e.code === 'Space') {
        e.preventDefault();
        startCharging();
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        e.preventDefault();
        stopCharging();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [startCharging, stopCharging]);

  const [batScale, setBatScale] = useState<number>(1);

  useEffect(() => {
    const updateScale = () => {
      const vh = window.innerHeight;
      setBatScale(Math.max(0.45, Math.min(1, (vh - 60) / 220)));
    };
    updateScale();
    window.addEventListener('resize', updateScale);
    return () => window.removeEventListener('resize', updateScale);
  }, []);

  const powerPercent = Math.round(selectedPowerRatio * 100);

  return (
    <div className="absolute inset-0 pointer-events-none z-20 flex select-none touch-none">
      {/* Center: Timing Alert Symbol (💥 ⚡ ✨ 💨) */}
      {lastTimingRating && (
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none flex flex-col items-center">
          <div
            className={`w-12 h-12 sm:w-14 sm:h-14 rounded-full flex items-center justify-center text-xl sm:text-2xl shadow-2xl animate-bounce transition-all ${
              lastTimingRating === 'PERFECT'
                ? 'bg-amber-400 text-slate-950 shadow-amber-400/60 ring-4 ring-amber-300'
                : lastTimingRating === 'GREAT'
                ? 'bg-emerald-400 text-slate-950 shadow-emerald-400/60'
                : lastTimingRating === 'MISS'
                ? 'bg-red-500 text-white shadow-red-500/60'
                : 'bg-sky-400 text-slate-950 shadow-sky-400/60'
            }`}
          >
            {lastTimingRating === 'PERFECT'
              ? '💥'
              : lastTimingRating === 'GREAT'
              ? '⚡'
              : lastTimingRating === 'MISS'
              ? '💨'
              : '✨'}
          </div>
        </div>
      )}

      {/* Right Side: Authentic Cricket Bat Button - Press & Hold to Charge Power! */}
      <div
        style={{ transform: `scale(${batScale})` }}
        className="absolute right-3 sm:right-8 bottom-2 sm:bottom-6 pointer-events-auto flex flex-col items-center touch-none origin-bottom-right"
      >
        {/* Power Status & Instruction Badge */}
        <div className="mb-1.5 px-2.5 py-0.5 rounded-full bg-slate-900/90 border border-amber-400/50 shadow-md text-[10px] sm:text-xs font-black text-amber-300 tracking-wider flex items-center gap-1 select-none pointer-events-none">
          {!isReadyForDelivery ? (
            <span className="text-slate-400">IN PLAY...</span>
          ) : isHolding ? (
            <span className="text-amber-400 animate-pulse">{powerPercent}% POWER</span>
          ) : selectedPowerRatio > 0 ? (
            <span className="text-emerald-400">BOWLING ({powerPercent}%)</span>
          ) : (
            <span className="text-amber-300">HOLD & RELEASE</span>
          )}
        </div>

        <div
          onPointerDown={(e) => {
            if (!isReadyForDelivery) return;
            e.preventDefault();
            e.stopPropagation();
            startCharging();
          }}
          onPointerUp={stopCharging}
          onPointerCancel={stopCharging}
          className={`relative group flex flex-col items-center p-1.5 rounded-3xl touch-none transition-transform ${
            !isReadyForDelivery
              ? 'opacity-60 cursor-not-allowed pointer-events-none'
              : isHolding
              ? 'cursor-pointer scale-105'
              : 'cursor-pointer hover:scale-102 active:scale-98'
          }`}
        >
          {/* Authentic Cricket Bat Vector with Straight Linear Power Meter */}
          <div className="relative w-16 sm:w-20 h-44 sm:h-52 flex flex-col items-center drop-shadow-2xl">
            {/* 1. Bat Handle with Rubber Grip */}
            <div className="relative w-5 sm:w-6 h-14 sm:h-16 rounded-t-md overflow-hidden bg-gradient-to-r from-red-700 via-red-600 to-red-800 border border-red-500 shadow-md">
              <div className="w-full h-full flex flex-col justify-between py-1 opacity-60">
                <div className="w-full h-0.5 bg-black/40" />
                <div className="w-full h-0.5 bg-white/30" />
                <div className="w-full h-0.5 bg-black/40" />
                <div className="w-full h-0.5 bg-white/30" />
                <div className="w-full h-0.5 bg-black/40" />
                <div className="w-full h-0.5 bg-white/30" />
                <div className="w-full h-0.5 bg-black/40" />
              </div>
            </div>

            {/* Handle to Blade Shoulder */}
            <div
              className="w-8 sm:w-10 h-3 bg-gradient-to-r from-amber-700 via-amber-600 to-amber-800"
              style={{ clipPath: 'polygon(20% 0%, 80% 0%, 100% 100%, 0% 100%)' }}
            />

            {/* 2. English Willow Blade Body with Power Meter Line */}
            <div className="relative w-14 sm:w-16 flex-1 rounded-b-2xl bg-gradient-to-r from-[#d9b57a] via-[#f5d9a0] to-[#cba366] border-2 border-[#9b763e] shadow-xl overflow-hidden flex flex-col items-center justify-between p-1.5 touch-none">
              {/* Wood grain overlay lines */}
              <div className="absolute inset-0 opacity-20 pointer-events-none flex justify-around">
                <div className="w-px h-full bg-[#805826]" />
                <div className="w-px h-full bg-[#805826]" />
                <div className="w-px h-full bg-[#805826]" />
              </div>

              {/* Bat brand sticker badge */}
              <div className="w-10 h-3 rounded bg-blue-600 border border-blue-400/80 shadow-xs z-10 opacity-80" />

              {/* 3. The Straight Linear Power Meter Bar directly on the Bat Face */}
              <div className="relative w-4 sm:w-5 flex-1 my-1 rounded-full bg-slate-950/85 border border-black/50 overflow-hidden shadow-inner flex flex-col justify-end z-10 touch-none">
                {/* Glowing linear power fill line */}
                <div
                  className={`w-full transition-all duration-75 rounded-full ${
                    powerPercent > 80
                      ? 'bg-gradient-to-t from-orange-500 via-red-500 to-rose-400 shadow-md shadow-red-500/80'
                      : powerPercent > 45
                      ? 'bg-gradient-to-t from-emerald-500 via-yellow-400 to-amber-400 shadow-md shadow-yellow-400/70'
                      : powerPercent > 0
                      ? 'bg-gradient-to-t from-cyan-500 to-emerald-400 shadow-md shadow-cyan-400/60'
                      : 'bg-transparent'
                  }`}
                  style={{ height: `${powerPercent}%` }}
                />

                {/* Slider Thumb Handle Indicator Line */}
                {powerPercent > 0 && (
                  <div
                    className="absolute left-0 right-0 h-2 bg-white rounded-full shadow-lg border-2 border-amber-400 pointer-events-none transition-all duration-75"
                    style={{ bottom: `calc(${powerPercent}% - 4px)` }}
                  />
                )}

                {/* Subtitle graduation tick marks along the straight line */}
                <div className="absolute inset-0 flex flex-col justify-between py-1.5 pointer-events-none opacity-40">
                  <div className="w-full h-px bg-white" />
                  <div className="w-full h-px bg-white" />
                  <div className="w-full h-px bg-white" />
                  <div className="w-full h-px bg-white" />
                </div>
              </div>

              {/* Bat toe curve */}
              <div className="w-10 h-1.5 rounded-full bg-[#9b763e] opacity-60 z-10" />

              {/* Glowing Aura when power > 0 or holding */}
              {(powerPercent > 0 || isHolding) && (
                <div
                  className={`absolute inset-0 pointer-events-none rounded-b-2xl ${
                    isHolding
                      ? 'bg-amber-400/25 ring-2 ring-amber-300 animate-pulse'
                      : 'bg-amber-400/10 ring-1 ring-amber-400/40'
                  }`}
                />
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
