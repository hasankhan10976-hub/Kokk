import React, { useState, useCallback, useRef, useEffect } from 'react';
import { CricketCanvas } from './components/CricketCanvas';
import { GameHUD } from './components/GameHUD';
import { ControlsOverlay } from './components/ControlsOverlay';
import { LevelCompleteModal } from './components/LevelCompleteModal';
import { HomeScreen } from './components/HomeScreen';
import { ShopModal } from './components/ShopModal';
import { LandscapeNotice } from './components/LandscapeNotice';
import { BambooBlock, GameState, BackgroundTheme, SpecialBallType } from './types/game';
import { LEVEL_CONFIGS, generateBambooHut, calculateDestructionPercentage } from './utils/bambooHuts';
import { soundManager } from './utils/audio';
import { JewelButton } from './components/JewelButton';
import { CheckCircle2 } from 'lucide-react';

export default function App() {
  const [currentLevelIndex, setCurrentLevelIndex] = useState<number>(0);
  const currentLevel = LEVEL_CONFIGS[currentLevelIndex] || LEVEL_CONFIGS[0];

  // Game state (NO browser localStorage used)
  // Only Level 1 is unlocked initially; subsequent levels unlock as the player clears them
  const [unlockedLevelMax, setUnlockedLevelMax] = useState<number>(1);
  const [selectedBackground, setSelectedBackground] = useState<BackgroundTheme>('DAY');
  const [ballsLeft, setBallsLeft] = useState<number>(currentLevel.balls);
  const [ballsUsed, setBallsUsed] = useState<number>(0);
  const [blocks, setBlocks] = useState<BambooBlock[]>(() => generateBambooHut(currentLevel.hutType));
  const [destructionPct, setDestructionPct] = useState<number>(0);
  const [score, setScore] = useState<number>(0);
  const [superMeter, setSuperMeter] = useState<number>(0);
  const [isSuperShotActive, setIsSuperShotActive] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [gameState, setGameState] = useState<GameState>('MENU');
  const gameStateRef = useRef<GameState>('MENU');
  useEffect(() => {
    gameStateRef.current = gameState;
  }, [gameState]);

  const [lastTimingRating, setLastTimingRating] = useState<string | null>(null);
  const [roundResetKey, setRoundResetKey] = useState<number>(0);
  const ballSettledTimeoutRef = useRef<number | null>(null);

  // Player Economy & Shop State (NO browser localStorage used!)
  // Home Screen Coins: Banked money used solely to unlock backgrounds
  const [homeCoins, setHomeCoins] = useState<number>(0);

  // In-Game Level Coins: Starts at 0 for every level, earned by playing, spent on ability balls
  const [levelCoins, setLevelCoins] = useState<number>(0);
  const levelCoinsRef = useRef<number>(0);
  const levelCoinsBankedRef = useRef<boolean>(false);

  // Shop modal state & mode controller ('BACKGROUNDS' for HomeScreen, 'BALLS' for In-Game)
  const [isShopOpen, setIsShopOpen] = useState<boolean>(false);
  const [shopMode, setShopMode] = useState<'BALLS' | 'BACKGROUNDS'>('BACKGROUNDS');

  const [ballInventory, setBallInventory] = useState<Record<SpecialBallType, number>>({
    STANDARD: 12,
    BOMB: 2,
    FIRE: 1,
    ACID: 1,
  });
  const [selectedBallType, setSelectedBallType] = useState<SpecialBallType>('STANDARD');
  const [unlockedBackgrounds, setUnlockedBackgrounds] = useState<Record<BackgroundTheme, boolean>>({
    DAY: true,
    DESERT: false,
    SNOW: false,
    BEACH: false,
    TEMPLE: false,
    WATERFALL: false,
    SUNSET: false,
    NIGHT: false,
    JUNGLE: false,
  });

  // Collecting gold in the level awards coins to in-game levelCoins ONLY during active gameplay
  const handleEarnCoins = useCallback((amount: number) => {
    if (gameStateRef.current !== 'PLAYING') return;
    setLevelCoins((prev) => {
      const next = prev + amount;
      levelCoinsRef.current = next;
      return next;
    });
  }, []);

  // Buying ball abilities inside the level uses in-game levelCoins
  const handleBuyBall = useCallback((ball: SpecialBallType, cost: number, quantity: number = 1) => {
    setLevelCoins((prev) => {
      if (prev >= cost) {
        const next = prev - cost;
        levelCoinsRef.current = next;
        setBallInventory((bi) => ({
          ...bi,
          [ball]: (bi[ball] || 0) + quantity,
        }));
        if (ball === 'STANDARD') {
          setBallsLeft((bl) => bl + quantity);
        }
        setSelectedBallType(ball);
        soundManager.playVictory();
        return next;
      }
      return prev;
    });
  }, []);

  const handleConsumeSpecialBall = useCallback((ball: SpecialBallType) => {
    if (ball === 'STANDARD') return;
    setBallInventory((prev) => {
      const current = prev[ball] || 0;
      const nextCount = Math.max(0, current - 1);
      return {
        ...prev,
        [ball]: nextCount,
      };
    });
  }, []);

  // Buying new backgrounds from Home Screen uses homeCoins
  const handleBuyBackground = useCallback((bg: BackgroundTheme, cost: number) => {
    setHomeCoins((prev) => {
      if (prev >= cost) {
        setUnlockedBackgrounds((ubg) => ({ ...ubg, [bg]: true }));
        setSelectedBackground(bg);
        soundManager.playVictory();
        return prev - cost;
      }
      return prev;
    });
  }, []);

  // Bank any leftover/unspent levelCoins to homeCoins for each level
  const bankUnspentLevelCoins = useCallback(() => {
    if (levelCoinsBankedRef.current) return;
    levelCoinsBankedRef.current = true;
    const unspent = levelCoinsRef.current;
    if (unspent > 0) {
      setHomeCoins((prev) => prev + unspent);
    }
  }, []);

  // Batting Power Ratio (0.0 to 1.0)
  // Resets power to 0 only after a ball is hit or play ends, allowing the player to charge for the next ball!
  const [selectedPowerRatio, setSelectedPowerRatio] = useState<number>(0);
  const [bowlTrigger, setBowlTrigger] = useState<number>(0);
  const [isReadyForDelivery, setIsReadyForDelivery] = useState<boolean>(true);

  // Initialize or reset level (always starts with 0 in-game coins and clears all leftover animations)
  const startLevel = useCallback((levelIndex: number) => {
    if (ballSettledTimeoutRef.current !== null) {
      window.clearTimeout(ballSettledTimeoutRef.current);
      ballSettledTimeoutRef.current = null;
    }

    const lvl = LEVEL_CONFIGS[levelIndex] || LEVEL_CONFIGS[0];
    setCurrentLevelIndex(levelIndex);
    setBallsLeft(lvl.balls);
    setBallsUsed(0);
    const newBlocks = generateBambooHut(lvl.hutType);
    setBlocks(newBlocks);
    setDestructionPct(0);
    gameStateRef.current = 'PLAYING';
    setGameState('PLAYING');
    setIsSuperShotActive(false);
    setLastTimingRating(null);
    setSelectedPowerRatio(0);
    setBowlTrigger(0);
    setIsReadyForDelivery(true);

    // Force CricketCanvas to wipe all flying coins, sparkles, particles, and active ball state
    setRoundResetKey((prev) => prev + 1);

    // In-game level coins strictly reset to 0 for every level (even when replaying the same level)
    levelCoinsRef.current = 0;
    setLevelCoins(0);
    levelCoinsBankedRef.current = false;

    // User requirement: Every level starts with 12 Standard balls, 2 Bomb balls, 1 Acid ball, and 1 Fire ball!
    setBallInventory((prev) => ({
      ...prev,
      STANDARD: lvl.balls || 12,
      BOMB: Math.max(prev.BOMB, 2),
      ACID: Math.max(prev.ACID, 1),
      FIRE: Math.max(prev.FIRE, 1),
    }));
    setSelectedBallType('STANDARD');
  }, []);

  // Return to Home screen with full state & animation refresh
  const handleGoHome = useCallback((advanceToNextLevel: boolean = false) => {
    if (ballSettledTimeoutRef.current !== null) {
      window.clearTimeout(ballSettledTimeoutRef.current);
      ballSettledTimeoutRef.current = null;
    }

    bankUnspentLevelCoins();

    const targetIndex =
      advanceToNextLevel && currentLevelIndex < LEVEL_CONFIGS.length - 1
        ? currentLevelIndex + 1
        : currentLevelIndex;
    const targetLvl = LEVEL_CONFIGS[targetIndex] || LEVEL_CONFIGS[0];

    gameStateRef.current = 'MENU';
    setGameState('MENU');
    setCurrentLevelIndex(targetIndex);
    setBallsLeft(targetLvl.balls);
    setBallsUsed(0);
    setBlocks(generateBambooHut(targetLvl.hutType));
    setDestructionPct(0);
    setIsSuperShotActive(false);
    setLastTimingRating(null);
    setSelectedPowerRatio(0);
    setBowlTrigger(0);
    setIsReadyForDelivery(true);

    // Clear all in-game coins and wipe any mid-air flying coin animations
    levelCoinsRef.current = 0;
    setLevelCoins(0);
    levelCoinsBankedRef.current = false;
    setRoundResetKey((prev) => prev + 1);
  }, [currentLevelIndex, bankUnspentLevelCoins]);

  // When player charges up power and releases, the bowler begins delivery runup
  const handlePowerReleased = useCallback((power: number) => {
    setSelectedPowerRatio(power);
    setIsReadyForDelivery(false);
    setBowlTrigger((prev) => prev + 1);
  }, []);

  // When a shot is executed, reset power so player can charge for the next ball!
  const handleHitExecuted = useCallback(() => {
    setSelectedPowerRatio(0);
  }, []);

  // When blocks shift or break, update destruction %
  const handleBlocksUpdate = useCallback((updatedBlocks: BambooBlock[]) => {
    if (gameStateRef.current !== 'PLAYING') return;
    setBlocks(updatedBlocks);
    const pct = calculateDestructionPercentage(updatedBlocks);
    setDestructionPct(pct);
    // User requirement: If 100% destruction is reached, level automatically ends on its own
    if (pct >= 100) {
      setGameState((cur) => {
        if (cur === 'PLAYING') {
          gameStateRef.current = 'LEVEL_CLEARED';
          bankUnspentLevelCoins();
          soundManager.playVictory();
          setUnlockedLevelMax((prevMax) => Math.max(prevMax, currentLevel.id + 1));
          return 'LEVEL_CLEARED';
        }
        return cur;
      });
    }
  }, [currentLevel.id, bankUnspentLevelCoins]);

  // When a ball is released by the bowler
  const handleBallConsumed = useCallback(() => {
    setBallsLeft((prev) => Math.max(0, prev - 1));
    setBallsUsed((prev) => prev + 1);
    setSelectedBallType((cur) => {
      if (cur === 'STANDARD') {
        setBallInventory((prev) => ({
          ...prev,
          STANDARD: Math.max(0, (prev.STANDARD || 0) - 1),
        }));
      }
      return cur;
    });
  }, []);

  // When batsman fails to have power set and is clean bowled out
  const handleBatsmanOut = useCallback(() => {
    if (gameStateRef.current !== 'PLAYING') return;
    bankUnspentLevelCoins();
    // If target has already been met or exceeded, batsman out concludes the level as cleared
    if (destructionPct >= currentLevel.targetDestruction) {
      gameStateRef.current = 'LEVEL_CLEARED';
      setGameState('LEVEL_CLEARED');
      soundManager.playVictory();
      setUnlockedLevelMax((prevMax) => Math.max(prevMax, currentLevel.id + 1));
    } else {
      gameStateRef.current = 'LEVEL_FAILED';
      setGameState('LEVEL_FAILED');
      soundManager.playFailure();
    }
  }, [destructionPct, currentLevel, bankUnspentLevelCoins]);

  // User requirement: Player can manually click Finish Level button when target is achieved
  const handleFinishLevelNow = useCallback(() => {
    bankUnspentLevelCoins();
    soundManager.playButtonClick();
    gameStateRef.current = 'LEVEL_CLEARED';
    setGameState('LEVEL_CLEARED');
    soundManager.playVictory();
    setUnlockedLevelMax((prevMax) => Math.max(prevMax, currentLevel.id + 1));
  }, [currentLevel.id, bankUnspentLevelCoins]);

  const handleBallHitCompleted = useCallback((_settledPct: number, runsScored: number) => {
    if (gameStateRef.current !== 'PLAYING') return;
    setSelectedPowerRatio(0);
    setIsReadyForDelivery(true);

    // After the delivery is completely settled, if the currently selected ball has 0 stock remaining,
    // switch to standard or the next ball with stock!
    setBallInventory((currentInv) => {
      setSelectedBallType((currentSelected) => {
        if ((currentInv[currentSelected] || 0) <= 0) {
          const ballKeys: SpecialBallType[] = ['STANDARD', 'BOMB', 'FIRE', 'ACID'];
          const nextWithStock = ballKeys.find((b) => (currentInv[b] || 0) > 0);
          return nextWithStock || 'STANDARD';
        }
        return currentSelected;
      });
      return currentInv;
    });

    if (runsScored > 0) {
      setScore((prev) => prev + runsScored);
      setSuperMeter((prev) => Math.min(100, prev + Math.round(runsScored * 0.15) + 15));
    }

    if (ballSettledTimeoutRef.current !== null) {
      window.clearTimeout(ballSettledTimeoutRef.current);
    }

    ballSettledTimeoutRef.current = window.setTimeout(() => {
      ballSettledTimeoutRef.current = null;
      if (gameStateRef.current !== 'PLAYING') return;

      setBlocks((latestBlocks) => {
        const currentPct = calculateDestructionPercentage(latestBlocks);
        setDestructionPct(currentPct);

        setBallInventory((latestInv) => {
          const totalRemaining = (latestInv.STANDARD || 0) + (latestInv.BOMB || 0) + (latestInv.FIRE || 0) + (latestInv.ACID || 0);

          // User requirement:
          // 1. If 100% destroyed, auto-complete level
          // 2. If target is met (< 100%) and player still has balls, do NOT auto-complete; let player keep playing or use the finish button
          // 3. If out of balls, check if target was met -> success, else failure
          if (currentPct >= 100) {
            bankUnspentLevelCoins();
            gameStateRef.current = 'LEVEL_CLEARED';
            setGameState('LEVEL_CLEARED');
            soundManager.playVictory();
            setUnlockedLevelMax((prevMax) => Math.max(prevMax, currentLevel.id + 1));
          } else if (totalRemaining <= 0) {
            bankUnspentLevelCoins();
            if (currentPct >= currentLevel.targetDestruction) {
              gameStateRef.current = 'LEVEL_CLEARED';
              setGameState('LEVEL_CLEARED');
              soundManager.playVictory();
              setUnlockedLevelMax((prevMax) => Math.max(prevMax, currentLevel.id + 1));
            } else {
              gameStateRef.current = 'LEVEL_FAILED';
              setGameState('LEVEL_FAILED');
              soundManager.playFailure();
            }
          }

          return latestInv;
        });

        return latestBlocks;
      });
    }, 400);
  }, [currentLevel, bankUnspentLevelCoins]);

  // Batsman swing rating display
  const handleSwingAttempt = useCallback((rating: string) => {
    setLastTimingRating(rating);
    const timer = setTimeout(() => setLastTimingRating(null), 1200);
    return () => clearTimeout(timer);
  }, []);

  const handleSuperShotUsed = () => {
    setIsSuperShotActive(false);
    setSuperMeter(0);
  };

  // Toggle Mute
  const handleToggleMute = () => {
    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    soundManager.isMuted = nextMuted;
  };

  // Move to next level
  const handleNextLevel = () => {
    bankUnspentLevelCoins();
    if (currentLevelIndex < LEVEL_CONFIGS.length - 1) {
      startLevel(currentLevelIndex + 1);
    }
  };

  // Replay current level
  const handleRetry = () => {
    bankUnspentLevelCoins();
    startLevel(currentLevelIndex);
  };

  // Select level from homescreen
  const handleSelectLevel = (levelId: number) => {
    const idx = LEVEL_CONFIGS.findIndex((l) => l.id === levelId);
    if (idx !== -1) {
      setCurrentLevelIndex(idx);
      setBallsLeft(LEVEL_CONFIGS[idx].balls);
      setBallsUsed(0);
      setBlocks(generateBambooHut(LEVEL_CONFIGS[idx].hutType));
      setDestructionPct(0);
      setLevelCoins(0);
      levelCoinsRef.current = 0;
      levelCoinsBankedRef.current = false;
      setRoundResetKey((prev) => prev + 1);
    }
  };

  return (
    <div className="w-screen h-screen bg-slate-950 flex items-center justify-center overflow-hidden font-sans select-none touch-manipulation">
      {/* Responsive Landscape Game Wrapper */}
      <div className="relative w-full h-full flex items-center justify-center overflow-hidden bg-black">
        {/* Main 2D Cricket Physics Engine Canvas */}
        <CricketCanvas
          level={currentLevel}
          blocks={blocks}
          onBlocksUpdate={handleBlocksUpdate}
          ballsLeft={ballsLeft}
          onBallConsumed={handleBallConsumed}
          onBallHitCompleted={handleBallHitCompleted}
          onBatsmanOut={handleBatsmanOut}
          isSuperShotActive={isSuperShotActive}
          onSuperShotUsed={handleSuperShotUsed}
          onSwingAttempt={handleSwingAttempt}
          isPaused={gameState !== 'PLAYING'}
          backgroundTheme={selectedBackground}
          selectedPowerRatio={selectedPowerRatio}
          onHitExecuted={handleHitExecuted}
          selectedBallType={selectedBallType}
          ballInventory={ballInventory}
          onSelectBallType={setSelectedBallType}
          onConsumeSpecialBall={handleConsumeSpecialBall}
          onOpenShop={() => {
            setShopMode('BALLS');
            setIsShopOpen(true);
          }}
          onCoinEarned={handleEarnCoins}
          bowlTrigger={bowlTrigger}
          onReadyForDeliveryChange={setIsReadyForDelivery}
          resetKey={roundResetKey}
        />

        {/* Homescreen with Play button, Shop, Level Select & Indicator */}
        {gameState === 'MENU' && (
          <HomeScreen
            currentLevelId={currentLevel.id}
            unlockedLevelMax={unlockedLevelMax}
            selectedBackground={selectedBackground}
            onSelectBackground={setSelectedBackground}
            onSelectLevel={handleSelectLevel}
            onPlay={() => startLevel(currentLevelIndex)}
            isMuted={isMuted}
            onToggleMute={handleToggleMute}
            savedCoins={homeCoins}
            unlockedBackgrounds={unlockedBackgrounds}
            onOpenShop={() => {
              setShopMode('BACKGROUNDS');
              setIsShopOpen(true);
            }}
          />
        )}

        {/* Top HUD */}
        {gameState !== 'MENU' && (
          <GameHUD
            level={currentLevel}
            ballsLeft={ballsLeft}
            maxBalls={currentLevel.balls}
            destructionPct={destructionPct}
            score={score}
            coins={levelCoins}
            superMeter={superMeter}
            isMuted={isMuted}
            onToggleMute={handleToggleMute}
            onRestartLevel={() => {
              bankUnspentLevelCoins();
              handleRetry();
            }}
            onGoHome={() => {
              handleGoHome(false);
            }}
            onOpenShop={() => {
              setShopMode('BALLS');
              setIsShopOpen(true);
            }}
          />
        )}

        {/* Single Authentic Cricket Bat - Press and Hold to Charge Power! */}
        {gameState === 'PLAYING' && (
          <ControlsOverlay
            selectedPowerRatio={selectedPowerRatio}
            onUpdatePowerRatio={setSelectedPowerRatio}
            onPowerReleased={handlePowerReleased}
            lastTimingRating={lastTimingRating}
            isReadyForDelivery={isReadyForDelivery}
          />
        )}

        {/* User requirement: Optional Finish Level Button in bottom-center when target is achieved */}
        {gameState === 'PLAYING' && destructionPct >= currentLevel.targetDestruction && destructionPct < 100 && (
          <div className="fixed bottom-3 sm:bottom-6 left-1/2 -translate-x-1/2 z-40 pointer-events-auto flex flex-col items-center animate-in fade-in slide-in-from-bottom-2 duration-300">
            <JewelButton
              size="md"
              variant="badge"
              color="emerald"
              isGlowing
              onClick={handleFinishLevelNow}
              title="Finish Level"
              className="shadow-2xl shadow-emerald-500/50 ring-2 ring-emerald-300 px-5 sm:px-6"
            >
              <CheckCircle2 className="w-5 h-5 text-emerald-100 shrink-0" />
              <span className="text-xs sm:text-sm font-black tracking-wider uppercase px-1">FINISH LEVEL</span>
            </JewelButton>
          </div>
        )}

        {/* Level Complete / Failure Modal */}
        {(gameState === 'LEVEL_CLEARED' || gameState === 'LEVEL_FAILED') && (
          <LevelCompleteModal
            isSuccess={gameState === 'LEVEL_CLEARED'}
            level={currentLevel}
            destructionPct={destructionPct}
            ballsUsed={ballsUsed}
            coinsEarned={levelCoins}
            levelCoinsSaved={levelCoins}
            totalSavedCoins={homeCoins}
            onNextLevel={handleNextLevel}
            onRetry={handleRetry}
            onGoHome={() => {
              handleGoHome(gameState === 'LEVEL_CLEARED');
            }}
            hasNextLevel={currentLevelIndex < LEVEL_CONFIGS.length - 1}
          />
        )}

        {/* Shop Modal for Special Balls & Background Themes */}
        <ShopModal
          isOpen={isShopOpen}
          onClose={() => setIsShopOpen(false)}
          coins={shopMode === 'BALLS' ? levelCoins : homeCoins}
          mode={shopMode}
          ballInventory={ballInventory}
          selectedBall={selectedBallType}
          onSelectBall={setSelectedBallType}
          onBuyBall={handleBuyBall}
          unlockedBackgrounds={unlockedBackgrounds}
          selectedBackground={selectedBackground}
          onSelectBackground={setSelectedBackground}
          onBuyBackground={handleBuyBackground}
        />

        {/* Portrait Orientation Helper */}
        <LandscapeNotice />
      </div>
    </div>
  );
}
