export type GameState = 'MENU' | 'PLAYING' | 'BALL_IN_PLAY' | 'LEVEL_CLEARED' | 'LEVEL_FAILED' | 'PRACTICE';

export type BackgroundTheme = 'DAY' | 'DESERT' | 'SNOW' | 'BEACH' | 'TEMPLE' | 'WATERFALL' | 'SUNSET' | 'NIGHT' | 'JUNGLE';

export type SpecialBallType = 'STANDARD' | 'BOMB' | 'FIRE' | 'ACID';

export type DeliveryType = 'FAST' | 'SWING' | 'SPIN' | 'BOUNCER' | 'YORKER';

export type ShotElevation = 'LOW' | 'MEDIUM' | 'HIGH' | 'FLAT';

export interface BambooBlock {
  id: string;
  x: number;
  y: number;
  width: number;
  height: number;
  angle: number;
  vx: number;
  vy: number;
  vAngle: number;
  hp: number;
  maxHp: number;
  type: 'post' | 'beam' | 'thatch' | 'wall' | 'stilt' | 'pot' | 'lantern' | 'rafter' | 'ladder' | 'gold';
  color: string;
  mass: number;
  isStructural?: boolean;
  broken: boolean;
  grounded: boolean;
  nodes?: number; // bamboo node count
  despawned?: boolean;
  opacity?: number;
  isDespawning?: boolean;
  hanging?: boolean;
  isOnFire?: boolean;
  fireTicks?: number;
  isAcidMelting?: boolean;
  acidTicks?: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  life: number;
  maxLife: number;
  angle: number;
  vAngle: number;
  type: 'wood' | 'thatch' | 'smoke' | 'spark' | 'shockwave' | 'confetti' | 'fire' | 'acid' | 'explosion';
}

export interface Ball {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  rotation: number;
  vRotation: number;
  inAir: boolean;
  hitByBat: boolean;
  trail: { x: number; y: number; alpha: number }[];
  isSuperShot: boolean;
  damageMultiplier: number;
  ballType: SpecialBallType;
  hasBouncedPitch?: boolean;
}

export interface Batsman {
  x: number;
  y: number;
  stance: 'ready' | 'backlift' | 'swinging' | 'followThrough';
  swingProgress: number; // 0 to 1
  batAngle: number;
  elevation: ShotElevation;
}

export interface Bowler {
  x: number;
  y: number;
  state: 'idle' | 'runup' | 'delivery' | 'followThrough';
  progress: number;
  deliveryType: DeliveryType;
}

export interface LevelConfig {
  id: number;
  name: string;
  subtitle: string;
  balls: number;
  targetDestruction: number; // percentage, e.g. 70
  bowlerSpeed: number; // km/h representation
  bowlerType: DeliveryType;
  bowlerLabel: string;
  description: string;
  hutType: 'simple_hut' | 'two_story' | 'stilt_house' | 'granary' | 'royal_pavilion' | 'fortress' | 'monastery' | 'harbor_wharf' | 'tea_mill' | 'imperial_citadel' | 'floating_citadel' | 'dragon_ridge' | 'spice_bazaar' | 'bamboo_colosseum' | 'celestial_observatory' | 'serpent_temple' | 'wind_mill_bastion' | 'lotus_water_palace' | 'phoenix_spire' | 'thunder_mountain' | 'sunken_temple' | 'bamboo_acropolis' | 'mythical_fortress' | 'pirate_galleon' | 'royal_clocktower' | 'dragon_pagoda' | 'skybridge_palace' | 'imperial_bastion' | 'bridge_citadel' | 'sovereign_fortress' | 'pagoda_watchtower' | 'twin_bridge_citadel' | 'celestial_pagoda_fortress' | 'skybridge_garrison' | 'supreme_pagoda_citadel' | 'village_row_four' | 'stilt_bazaar_four' | 'bamboo_hamlet_five' | 'merchant_quarter_four' | 'grand_township_five' | 'skyward_spire_quartet' | 'twin_tower_bastion' | 'imperial_high_hamlet' | 'soaring_pagoda_row' | 'grand_sky_citadel' | 'skyline_pentagon_spire' | 'twin_monarch_citadels' | 'hexagonal_highland_row' | 'imperial_skyline_bastion' | 'grand_celestial_metropolis';
}

export interface FloatingText {
  id: string;
  text: string;
  x: number;
  y: number;
  color: string;
  size: number;
  life: number;
  maxLife: number;
  vy: number;
}
