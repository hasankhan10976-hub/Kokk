# Implementation Plan: Multi-Bounce Ground Sound, Rising Power Hum, & Tactile Button Audio

Implement dynamic multi-bounce ground impacts, a continuous rising acoustic power charging sound, and tactile wooden button click sound effects across all UI buttons.

---

## User Review Required

> [!IMPORTANT]
> - **Multi-Bounce Physics**: Rather than only playing once on the first pitch bounce, the ball will now emit the authentic turf thud whenever it hits the ground with downward velocity ($|v_y| > 1.2$), both during bowler delivery and after being struck into the field, with a short debounce to avoid repetitive noise during smooth rolling.
> - **Continuous Power Charging SFX**: A smooth rising acoustic hum with subtle power build will play in real time as the player holds the bat button to charge power (0% to 100%), immediately silencing upon release. No voiceover is used.
> - **Tactile Wooden Button Clicks**: High-quality crisp wooden taps will play on level selection, shop opening/purchasing, settings/mute, and special ball selection buttons.
> - **Strict Constraints**: No localStorage usage, and zero Bangla text in the game UI or code.

---

## Proposed Changes

### 1. `src/utils/audio.ts`
- **Dynamic Multi-Bounce Audio (`playBallBounce`)**:
  - Accept an optional intensity / velocity parameter so lighter subsequent bounces sound proportionally lighter.
- **Batting Power Charge Sound (`startPowerChargeSound`, `updatePowerChargeProgress`, `stopPowerChargeSound`)**:
  - Create a Web Audio node graph for an acoustic rising harmonic hum (frequency rises smoothly from 120Hz to 480Hz with subtle resonant harmonics as power increases from 0 to 1).
  - Stop cleanly on button release.
- **Tactile Wooden Button Click SFX (`playButtonClick`)**:
  - Add a crisp tactile wooden click audio using a dedicated sample and instant procedural wood tap (35ms transient, 1200Hz bamboo/wood resonance).

### 2. `src/components/CricketCanvas.tsx`
- **Multi-Bounce Ground Triggering**:
  - Before bat hit: Play bounce sound on each genuine pitch impact where `vy > 1.2` or before restitution, with a minimum frame cooldown (e.g. 70ms) to allow multiple genuine bounces without rolling buzz.
  - After bat hit (ground collision): When ball rebounds off the field turf with $|v_y| > 1.2$, trigger `soundManager.playBallBounce(volumeScale)`.
- **Ball Selector Buttons Audio**:
  - When switching special ball types (Standard, Bomb, Fire, Acid) or opening the quick shop, trigger `soundManager.playButtonClick()`.

### 3. `src/components/ControlsOverlay.tsx`
- **Real-Time Power Charge Audio Integration**:
  - In `startCharging()`: Call `soundManager.startPowerChargeSound()`.
  - In `chargeStep(now)`: Call `soundManager.updatePowerChargeProgress(nextRatio)`.
  - In `stopCharging()`: Call `soundManager.stopPowerChargeSound()`.

### 4. UI Components (`HomeScreen.tsx`, `HeaderBar.tsx`, `ShopModal.tsx`, `App.tsx`, `GameOverModal.tsx`)
- Attach `soundManager.playButtonClick()` to:
  - Level selection cards and Play button (`HomeScreen.tsx`)
  - Sound Mute toggle, Shop button, and Restart button (`HeaderBar.tsx`)
  - Shop buy tabs, purchase buttons, and close button (`ShopModal.tsx`)
  - "Finish Level", "Next Level", and "Retry" buttons (`GameOverModal.tsx`, `App.tsx`)

---

## Verification Plan

### Automated Verification
1. **Compilation Check**:
   ```bash
   compile_applet
   ```
2. **Linter Validation**:
   ```bash
   lint_applet
   ```

### Manual Verification
1. **Multi-Bounce Test**: Let a bouncer delivery or high-lofted shot bounce multiple times; verify each physical impact produces a proportional turf thud without buzzing on flat rolls.
2. **Power Charging SFX**: Hold the bat button down; verify the rising acoustic hum smoothly ascends from low to high and immediately stops upon release.
3. **UI Button Audits**: Click level buttons, ball selector icons, shop tabs, and mute button; verify each triggers a crisp wooden click sound.
