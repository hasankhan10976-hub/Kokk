# Complete Playgama Bridge SDK v2.3.0 Integration Plan

Integrating the official **Playgama Bridge SDK v2.3.0** (`@playgama/bridge@2.3.0`, per `https://wiki.playgama.com/playgama/llms.txt`) across the entire game in a single, comprehensive pass—covering all mandatory platform lifecycle events, audio/visibility rules, alternate-level Interstitial Ads (every 2nd level finished, win or loss), and In-Game Rewarded Ads to claim any ability ball without spending coins.

## User Review & Critical Decisions

> [!IMPORTANT]
> Confirmed user preferences and revisions:
> - **Pinned SDK Version (`v2.3.0`)**: Explicitly target and load **Playgama Bridge SDK v2.3.0** (`https://bridge.playgama.com/v2.3.0/playgama-bridge.js` / `@playgama/bridge@2.3.0` with automatic CDN fallback) alongside `playgama-bridge-config.json`.
> - **All-in-One Complete SDK Integration**: Implement every mandatory Playgama SDK v2.3.0 rule, lifecycle signal, audio/visibility handler, Interstitial Ad, and Rewarded Ad together in one complete, production-ready pass.
> - **Interstitial Ads on Every 2nd Level Played (Win or Loss)**: The 1st level played shows no ad; the 2nd level finished (whether won or lost) triggers an Interstitial Ad, continuing on every alternate level completion (`levelsPlayed % 2 === 0`).
> - **In-Game Free Ability Ball via Rewarded Ad (Ball Shop + HUD)**: Once gameplay starts, players can watch a Rewarded Ad to receive any ability ball (`STANDARD`, `BOMB`, `FIRE`, or `ACID`) for free—both via a dedicated Ad button next to each ball in the In-Game Ball Shop and directly from empty (`0` stock) ball slots on the in-game HUD.
> - **Strict Zero-LocalStorage & Zero-Bangla UI Rule**: All game state remains 100% in-memory (no `localStorage` or `sessionStorage`), and all in-game UI uses clean icons/English labels with zero Bangla text.

---

## 1. Overview & Core Concept

- **What It Does**: Connects the HTML5 cricket physics game to **Playgama Bridge SDK v2.3.0** (`playgama-bridge.js` v2.3.0) so it passes all Playgama QA & moderation checks out of the box while monetizing via alternate-level Interstitial Ads and opt-in Rewarded Ads for special ability balls.
- **Key Value**:
  - **Exact v2.3.0 Compatibility & Moderation Compliance**: Uses Playgama Bridge v2.3.0, properly awaits `bridge.initialize()`, fires `game_ready`, `gameplay_started`, and `gameplay_stopped`, and automatically mutes/pauses the game when the browser tab is hidden or an ad is open.
  - **Player-Friendly Ad Cadence**: Never interrupts the player's first level; shows an Interstitial Ad only after every 2nd completed level attempt.
  - **High-Value Opt-In Rewarded Ads**: Lets players acquire any special ability ball (`BOMB`, `FIRE`, `ACID`, or `STANDARD` pack) during a match by watching a rewarded video ad without needing coins.

---

## 2. User Experience & Visual Design

### A. In-Game Ball Shop Rewarded Ad Controls
- Inside the In-Game Ball Shop (`mode === 'BALLS'`), each of the 4 ball cards (`STANDARD`, `BOMB`, `FIRE`, `ACID`) displays:
  1. The existing **Coin Buy Button** (Amber Jewel Badge showing coin icon + price).
  2. A new **Watch Ad for Free Ball Button** (3D Emerald/Violet Jewel Badge with a crisp video film/play icon + `+1` or `+3` count, disabled while an ad is actively loading).
- Clicking the Watch Ad button launches `playgamaSdk.showRewardedAd()`. When the SDK emits the `'rewarded'` state, the ball is immediately added to the player's inventory, automatically selected for the next delivery, and accompanied by a celebratory sound effect.

### B. In-Game Left-Side HUD Empty Ball Slot Ad Trigger
- During active gameplay on the left-side ball selector bar:
  - When a ball type (`BOMB`, `FIRE`, `ACID`, or `STANDARD`) has `count === 0`, its slot displays a small video-ad indicator badge instead of just a static lock.
  - Clicking an empty (`0` stock) ball slot immediately triggers a **Rewarded Ad** for that specific ball type, granting `+1` (or `+3` for Standard) and auto-selecting it upon completion so the player can use it right away without even opening the shop.

### C. Alternate-Level Interstitial Ad Flow
- A session counter tracks how many level rounds have finished (`LEVEL_CLEARED` or `LEVEL_FAILED`).
- **Round 1 Finished**: Counter becomes `1` → No Interstitial Ad is shown; the Level Complete / Failed modal appears immediately.
- **Round 2 Finished**: Counter becomes `2` (`2 % 2 === 0`) → `playgamaSdk.showInterstitialAd()` is called automatically as the round concludes (muting audio during the ad and restoring audio when closed).
- **Round 3 Finished**: Counter becomes `3` → No ad.
- **Round 4 Finished**: Counter becomes `4` → Interstitial Ad shown, and so on for every alternate round played.

---

## 3. Key Product Decisions & Playgama SDK v2.3.0 Rules

- **Mandatory `bridge.initialize()` & `game_ready` Handshake (v2.3.0)**:
  - *Chosen Approach*: Load Playgama Bridge **v2.3.0** (`https://bridge.playgama.com/v2.3.0/playgama-bridge.js` with fallback to `https://cdn.jsdelivr.net/gh/Playgama/bridge@v2.3.0/dist/playgama-bridge.js` and `https://bridge.playgama.com/v2/stable/playgama-bridge.js`) in `index.html` alongside a root `playgama-bridge-config.json` file. Initialize the SDK on boot, set minimum interstitial delay to `0` (`bridge.advertisement.setMinimumDelayBetweenInterstitial(0)`), attach event listeners, and immediately send `bridge.platform.sendMessage('game_ready')`.
  - *Why*: Playgama v2.3.0 requires `game_ready` to dismiss platform loading curtains and start session telemetry.
- **Strict `'rewarded'` State Verification**:
  - *Chosen Approach*: Listen to `bridge.EVENT_NAME.REWARDED_STATE_CHANGED` (`'loading' | 'opened' | 'rewarded' | 'closed' | 'failed'`). Grant the free ability ball **only** when state equals `'rewarded'`.
  - *Why*: Playgama moderation rejects games that grant rewards on `'closed'` without verifying `'rewarded'`.
- **Automatic Audio & Visibility Synchronization**:
  - *Chosen Approach*: Centralize audio muting in `soundManager` so that platform mute events (`AUDIO_STATE_CHANGED`), hidden tab events (`VISIBILITY_STATE_CHANGED === 'hidden'`), and open ad states (`INTERSTITIAL_STATE_CHANGED === 'opened'`, `REWARDED_STATE_CHANGED === 'opened'`) suspend/mute `AudioContext`, and restore the user's mute preference only when the tab is visible, platform audio is enabled, and no ad is open.

---

## 4. Technical Architecture & Lifecycle Flow

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                   HTML5 Boot & Playgama Bridge v2.3.0                       │
│  index.html (<script src=".../v2.3.0/playgama-bridge.js">)                  │
│  public/playgama-bridge-config.json                                         │
│         │                                                                   │
│         ▼                                                                   │
│  Playgama SDK v2.3.0 Service (bridge.initialize())                          │
│  ├─► bridge.platform.sendMessage('game_ready')                              │
│  ├─► bridge.advertisement.setMinimumDelayBetweenInterstitial(0)             │
│  ├─► bridge.platform.on(AUDIO_STATE_CHANGED) ──► soundManager.setSdkMute()  │
│  └─► bridge.game.on(VISIBILITY_STATE_CHANGED) ──► Pause & Mute on 'hidden'  │
└────────────────────────────────────┬────────────────────────────────────────┘
                                     │
         ┌───────────────────────────┴───────────────────────────┐
         ▼                                                       ▼
┌─────────────────────────────────────────┐   ┌───────────────────────────────┐
│      Alternate-Level Interstitial       │   │   In-Game Free Ball Rewarded  │
│                                         │   │                               │
│  Level Ends (Cleared or Failed)         │   │  Player clicks Free Ad Button │
│  levelsPlayedCountRef.current += 1      │   │  (in Ball Shop or 0-stock HUD)│
│  ├─► Odd (1, 3, 5...): No Ad            │   │         │                     │
│  └─► Even (2, 4, 6...):                 │   │         ▼                     │
│      bridge.advertisement               │   │  bridge.advertisement         │
│        .showInterstitial()              │   │    .showRewarded()            │
│      - 'opened' ──► Mute & Pause        │   │  - 'opened'   ──► Mute/Pause  │
│      - 'closed'/'failed' ──► Restore    │   │  - 'rewarded' ──► Grant Ball! │
│                                         │   │  - 'closed'   ──► Restore     │
└─────────────────────────────────────────┘   └───────────────────────────────┘
```

### Interactive Component & State Mapping
- **SDK v2.3.0 Lifecycle Controller**:
  - Tracks `isAdOpen` and `isPlatformHidden` states to pause physics updates in `CricketCanvas` while an ad or background tab is active.
  - Emits `gameplay_started` when entering `'PLAYING'` state (with modals closed) and `gameplay_stopped` when opening modals, completing/failing a level, or returning to `'MENU'`.
- **Rewarded Ball Grant Handler (`handleRewardBall(ballType)`)**:
  - Invokes `playgamaSdk.showRewardedAd(onRewarded)`.
  - Inside `onRewarded`: increments `ballInventory[ballType]` by `3` (for `'STANDARD'`) or `1` (for `'BOMB'`, `'FIRE'`, `'ACID'`), increments `ballsLeft` by `3` if `'STANDARD'`, sets `selectedBallType(ballType)`, and plays victory audio once the ad closes.
